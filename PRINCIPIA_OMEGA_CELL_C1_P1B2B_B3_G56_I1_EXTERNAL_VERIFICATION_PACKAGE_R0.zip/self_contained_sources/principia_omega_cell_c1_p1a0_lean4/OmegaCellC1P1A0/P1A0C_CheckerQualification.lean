/-
  PRINCIPIA Ω-CELL-C1-P1A0 — Isolated Minimal Whitebox Type Kernel
  Module: OmegaCellC1P1A0.P1A0C_CheckerQualification (Stage P1A0-C)

  Authorization Scope (`PRINCIPIA_OMEGA_CELL_C1_P1A0_R1` Conditionally Authorized — Stage P1A0-C):
    1. Canonical Premise Ordering & Transitive Premise Survival (`Deps*`):
       Independent strict linear order `strStrictLt`, canonical deduplicating sort `canonSortStrs`,
       and fuel-bounded transitive DAG closure `depsStarCanon` (`TRANSITIVE_PREMISE_SURVIVAL_REQUIRED`).
    2. Typed Event Log (`LedgerEvent`), Detached Payload Store (`DetachedReceiptStore`),
       Monotone `InfoState` vs Non-Monotonic `Standing` (`F-C0-V22-01`, `F-C0-R1-04`).
    3. Explicit Checker-to-Semantics Soundness Bridge (`F-A0-02`, `T-A0-06a` & `T-A0-06b`):
       Separates computable `Bool` checkers (`verifyWitness`, `verifyProt`, `verifyRatClaimBool`,
       `verifyRatProtBool`) from `Prop` semantics (`ModelsStrictPred`), proves abstract bridged
       soundness (`T-A0-06a`) and unconditional concrete rational soundness with explicit positive
       acceptance witnesses and bogus-claim rejection (`T-A0-06b`).
    4. Claim/Spec/Active-Bound `QualifiedScope`, Cross-Claim Anti-Laundering (`T-A0-07` / `CE-C1-08`),
       2-Step `Retreat → Refinement` Re-Qualification with Indelible `HistoricalScopeLoss_B` (`T-A0-08`),
       and Non-Monotonic Premise Retraction Laws (`T-A0-09a`, `T-A0-09b`, `T-A0-09c`).

  Explicitly Excluded (`NOT AUTHORIZED` / `FROZEN` / `HELD`):
    - Zero imports from `GPED-MINCORE-0` (`36` GPED assets remain strictly `FROZEN`).
    - Wire/CID/Merkle framing, `C1-P1B/C` full `G1..G8` checker, `MT-22b`, `L3-P2C`, and
      `checkTraceDec` remain `NOT AUTHORIZED`.
-/
import OmegaCellC1P1A0.P1A0B_TransportScopeLoss

namespace OmegaCellC1P1A0

/-! ### 1. Canonical Premise Ordering & Transitive Dependency Closure `Deps*` -/

/-- Codepoint-lexicographic strict order on `List Char`. -/
def charListLt : List Char → List Char → Bool
  | [], [] => false
  | [], _ :: _ => true
  | _ :: _, [] => false
  | a :: as, b :: bs =>
      if a.toNat < b.toNat then true
      else if b.toNat < a.toNat then false
      else charListLt as bs

/-- Strict linear order on `String` for canonical premise sets. -/
def strStrictLt (a b : String) : Bool :=
  charListLt a.toList b.toList

private theorem charListLt_irrefl : ∀ cs : List Char, charListLt cs cs = false
  | [] => rfl
  | c :: cs => by
      unfold charListLt
      have h : ¬ (c.toNat < c.toNat) := Nat.lt_irrefl c.toNat
      rw [if_neg h, if_neg h]
      exact charListLt_irrefl cs

/-- Irreflexivity of `strStrictLt`. -/
theorem strStrictLt_irrefl (s : String) : strStrictLt s s = false :=
  charListLt_irrefl s.toList

private theorem char_eq_of_toNat_eq {a b : Char} (h : a.toNat = b.toNat) : a = b := by
  have h1 := congrArg Char.ofNat h
  rwa [Char.ofNat_toNat, Char.ofNat_toNat] at h1

private theorem charListLt_trans :
    ∀ {as bs cs : List Char},
      charListLt as bs = true → charListLt bs cs = true → charListLt as cs = true
  | [], [], _, hab, _ => nomatch hab
  | [], _ :: _, [], _, hbc => nomatch hbc
  | [], _ :: _, _ :: _, _, _ => rfl
  | _ :: _, [], _, hab, _ => nomatch hab
  | _ :: _, _ :: _, [], _, hbc => nomatch hbc
  | a :: as, b :: bs, c :: cs, hab, hbc => by
      unfold charListLt at hab hbc ⊢
      by_cases hab1 : a.toNat < b.toNat
      · rw [if_pos hab1] at hab
        by_cases hbc1 : b.toNat < c.toNat
        · rw [if_pos (Nat.lt_trans hab1 hbc1)]
        · rw [if_neg hbc1] at hbc
          by_cases hbc2 : c.toNat < b.toNat
          · rw [if_pos hbc2] at hbc; nomatch hbc
          · have heq : b.toNat = c.toNat := by omega
            rw [← heq, if_pos hab1]
      · rw [if_neg hab1] at hab
        by_cases hab2 : b.toNat < a.toNat
        · rw [if_pos hab2] at hab; nomatch hab
        · rw [if_neg hab2] at hab
          have heq_ab : a.toNat = b.toNat := by omega
          by_cases hbc1 : b.toNat < c.toNat
          · rw [heq_ab, if_pos hbc1]
          · rw [if_neg hbc1] at hbc
            by_cases hbc2 : c.toNat < b.toNat
            · rw [if_pos hbc2] at hbc; nomatch hbc
            · rw [if_neg hbc2] at hbc
              have heq_bc : b.toNat = c.toNat := by omega
              have hac1 : ¬ (a.toNat < c.toNat) := by omega
              have hac2 : ¬ (c.toNat < a.toNat) := by omega
              rw [if_neg hac1, if_neg hac2]
              exact charListLt_trans hab hbc

private theorem charListLt_trichotomy :
    ∀ (as bs : List Char),
      charListLt as bs = true ∨ as = bs ∨ charListLt bs as = true
  | [], [] => Or.inr (Or.inl rfl)
  | [], _ :: _ => Or.inl rfl
  | _ :: _, [] => Or.inr (Or.inr rfl)
  | a :: as, b :: bs => by
      by_cases h1 : a.toNat < b.toNat
      · unfold charListLt
        exact Or.inl (if_pos h1)
      · by_cases h2 : b.toNat < a.toNat
        · exact Or.inr (Or.inr (by unfold charListLt; exact if_pos h2))
        · have heq_nat : a.toNat = b.toNat := by omega
          have heq_c : a = b := char_eq_of_toNat_eq heq_nat
          subst heq_c
          have hlhs : charListLt (a :: as) (a :: bs) = charListLt as bs := by
            change (if a.toNat < a.toNat then true else if a.toNat < a.toNat then false else charListLt as bs) = charListLt as bs
            rw [if_neg h1, if_neg h1]
          have hrhs : charListLt (a :: bs) (a :: as) = charListLt bs as := by
            change (if a.toNat < a.toNat then true else if a.toNat < a.toNat then false else charListLt bs as) = charListLt bs as
            rw [if_neg h1, if_neg h1]
          rw [hlhs, hrhs]
          rcases charListLt_trichotomy as bs with hlt | rfl | hgt
          · exact Or.inl hlt
          · exact Or.inr (Or.inl rfl)
          · exact Or.inr (Or.inr hgt)

/-- Transitivity of `strStrictLt`. -/
theorem strStrictLt_trans {a b c : String}
    (hab : strStrictLt a b = true) (hbc : strStrictLt b c = true) :
    strStrictLt a c = true :=
  charListLt_trans hab hbc

/-- Trichotomy of `strStrictLt`. -/
theorem strStrictLt_trichotomy (a b : String) :
    strStrictLt a b = true ∨ a = b ∨ strStrictLt b a = true := by
  rcases charListLt_trichotomy a.toList b.toList with hlt | heq | hgt
  · exact Or.inl hlt
  · exact Or.inr (Or.inl (String.ext heq))
  · exact Or.inr (Or.inr hgt)

/-- Computable strict canonical list check (`<`-sorted and therefore duplicate-free). -/
def isStrictCanonStrList : List String → Bool
  | [] => true
  | [_] => true
  | a :: b :: rest => strStrictLt a b && isStrictCanonStrList (b :: rest)

/-- Sorted deduplicating insertion into a `String` list. -/
def insertCanonStr (x : String) : List String → List String
  | [] => [x]
  | y :: ys =>
      if x == y then y :: ys
      else if strStrictLt x y then x :: y :: ys
      else y :: insertCanonStr x ys

/-- Canonical sorted deduplicating projection on `List String`. -/
def canonSortStrs : List String → List String
  | [] => []
  | x :: xs => insertCanonStr x (canonSortStrs xs)

theorem mem_insertCanonStr (x : String) (ys : List String) (k : String) :
    k ∈ insertCanonStr x ys ↔ k = x ∨ k ∈ ys := by
  induction ys with
  | nil =>
      simp [insertCanonStr]
  | cons y ys ih =>
      unfold insertCanonStr
      by_cases hxy : (x == y) = true
      · rw [if_pos hxy]
        have heq : x = y := eq_of_beq hxy
        subst heq
        simp
      · rw [if_neg hxy]
        by_cases hlt : strStrictLt x y = true
        · rw [if_pos hlt]
          simp
        · rw [if_neg hlt]
          simp only [List.mem_cons, ih]
          constructor
          · rintro (rfl | rfl | h)
            · exact Or.inr (Or.inl rfl)
            · exact Or.inl rfl
            · exact Or.inr (Or.inr h)
          · rintro (rfl | rfl | h)
            · exact Or.inr (Or.inl rfl)
            · exact Or.inl rfl
            · exact Or.inr (Or.inr h)

/-- Membership preservation `k ∈ canonSortStrs L ↔ k ∈ L`. -/
theorem mem_canonSortStrs (L : List String) (k : String) :
    k ∈ canonSortStrs L ↔ k ∈ L := by
  induction L with
  | nil => rfl
  | cons x xs ih =>
      unfold canonSortStrs
      rw [mem_insertCanonStr, ih]
      simp

private theorem pairwise_insertCanonStr (x : String) :
    ∀ {ys : List String},
      List.Pairwise (fun a b => strStrictLt a b = true) ys →
      List.Pairwise (fun a b => strStrictLt a b = true) (insertCanonStr x ys)
  | [], _ => List.Pairwise.cons (fun _ h => nomatch h) List.Pairwise.nil
  | y :: ys, hpw => by
      rcases List.pairwise_cons.mp hpw with ⟨hy_all, hpw_ys⟩
      unfold insertCanonStr
      by_cases hxy : (x == y) = true
      · rw [if_pos hxy]; exact hpw
      · rw [if_neg hxy]
        have hne : x ≠ y := fun heq => hxy (beq_iff_eq.mpr heq)
        by_cases hlt : strStrictLt x y = true
        · rw [if_pos hlt]
          refine List.Pairwise.cons ?_ hpw
          intro z hz
          rcases List.mem_cons.mp hz with rfl | hmem
          · exact hlt
          · exact strStrictLt_trans hlt (hy_all z hmem)
        · rw [if_neg hlt]
          have hyx : strStrictLt y x = true := by
            rcases strStrictLt_trichotomy x y with h1 | rfl | h2
            · exact False.elim (hlt h1)
            · exact False.elim (hne rfl)
            · exact h2
          refine List.Pairwise.cons ?_ (pairwise_insertCanonStr x hpw_ys)
          intro z hz
          rcases (mem_insertCanonStr x ys z).mp hz with rfl | hmem
          · exact hyx
          · exact hy_all z hmem

private theorem isStrictCanonStrList_of_pairwise :
    ∀ {L : List String},
      List.Pairwise (fun a b => strStrictLt a b = true) L →
      isStrictCanonStrList L = true
  | [], _ => rfl
  | [_], _ => rfl
  | a :: b :: rest, hpw => by
      rcases List.pairwise_cons.mp hpw with ⟨ha_all, hpw_tail⟩
      unfold isStrictCanonStrList
      rw [Bool.and_eq_true]
      exact ⟨ha_all b (List.mem_cons_self ..), isStrictCanonStrList_of_pairwise hpw_tail⟩

private theorem insert_sorted_head_eq (x : String) (xs : List String)
    (hx_all : ∀ z ∈ xs, strStrictLt x z = true)
    (hrec : canonSortStrs xs = xs) :
    insertCanonStr x (canonSortStrs xs) = x :: xs := by
  rw [hrec]
  cases xs with
  | nil => rfl
  | cons y ys =>
      have hlt : strStrictLt x y = true := hx_all y (List.mem_cons_self ..)
      have hne : (x == y) = false := by
        apply Bool.eq_false_iff.mpr
        intro hbeq
        have heq : x = y := eq_of_beq hbeq
        subst heq
        rw [strStrictLt_irrefl] at hlt
        contradiction
      unfold insertCanonStr
      simp [hne, hlt]

/-- `canonSortStrs L` is always pairwise strictly sorted, satisfies `isStrictCanonStrList = true`,
    and is idempotent (`canonSortStrs (canonSortStrs L) = canonSortStrs L`). -/
theorem canonSortStrs_canonical_laws (L : List String) :
    List.Pairwise (fun a b => strStrictLt a b = true) (canonSortStrs L) ∧
    isStrictCanonStrList (canonSortStrs L) = true ∧
    canonSortStrs (canonSortStrs L) = canonSortStrs L := by
  have hpw : List.Pairwise (fun a b => strStrictLt a b = true) (canonSortStrs L) := by
    induction L with
    | nil => exact List.Pairwise.nil
    | cons x xs ih => exact pairwise_insertCanonStr x ih
  have hidem : ∀ {M : List String},
      List.Pairwise (fun a b => strStrictLt a b = true) M → canonSortStrs M = M := by
    intro M hM
    induction M with
    | nil => rfl
    | cons x xs ih =>
        rcases List.pairwise_cons.mp hM with ⟨hx_all, hxs⟩
        unfold canonSortStrs
        exact insert_sorted_head_eq x xs hx_all (ih hxs)
  exact ⟨hpw, isStrictCanonStrList_of_pairwise hpw, hidem hpw⟩

/-- Premise DAG adjacency list mapping premise ID `p` to its direct parent premises. -/
abbrev PremDag : Type := List (String × List String)

/-- Lookup direct parent premises of `p` in `dag`. -/
def lookupPremParents (dag : PremDag) (p : String) : List String :=
  match dag.find? (fun entry => entry.1 == p) with
  | some (_, pars) => pars
  | none           => []

/-- Single-hop expansion preserving all already-accumulated premises. -/
def expandPremStep (dag : PremDag) (cur : List String) : List String :=
  cur.foldr (fun p acc => p :: (lookupPremParents dag p ++ acc)) []

/-- Iterated premise expansion up to `fuel` hops. -/
def transPremIter : Nat → PremDag → List String → List String
  | 0,     _,   cur => cur
  | n + 1, dag, cur => transPremIter n dag (expandPremStep dag cur)

/-- Canonical transitive premise closure `Deps*(dag, directRefs)`. -/
def depsStarCanon (dag : PremDag) (directRefs : List String) : List String :=
  canonSortStrs (transPremIter (dag.length + 1) dag directRefs)

/-- Declarative transitive reachability relation `PremReachable dag directRefs q`. -/
inductive PremReachable (dag : PremDag) (directRefs : List String) : String → Prop where
  | direct {p : String} : p ∈ directRefs → PremReachable dag directRefs p
  | parent {p q : String} :
      PremReachable dag directRefs p → q ∈ lookupPremParents dag p →
        PremReachable dag directRefs q

private theorem subset_expandPremStep (dag : PremDag) (cur : List String) :
    ∀ p ∈ cur, p ∈ expandPremStep dag cur := by
  induction cur with
  | nil => intro _ h; nomatch h
  | cons x xs ih =>
      intro p hp
      unfold expandPremStep
      simp only [List.foldr_cons, List.mem_cons, List.mem_append]
      rcases List.mem_cons.mp hp with rfl | hrest
      · exact Or.inl rfl
      · exact Or.inr (Or.inr (ih p hrest))

private theorem subset_transPremIter (n : Nat) (dag : PremDag) (cur : List String) :
    ∀ p ∈ cur, p ∈ transPremIter n dag cur := by
  induction n generalizing cur with
  | zero => intro p hp; exact hp
  | succ k ih =>
      intro p hp
      exact ih (expandPremStep dag cur) p (subset_expandPremStep dag cur p hp)

/-- Every direct premise `p ∈ directRefs` is included in `depsStarCanon dag directRefs`. -/
theorem direct_mem_depsStarCanon (dag : PremDag) (directRefs : List String) {p : String}
    (hp : p ∈ directRefs) :
    p ∈ depsStarCanon dag directRefs := by
  unfold depsStarCanon
  rw [mem_canonSortStrs]
  exact subset_transPremIter (dag.length + 1) dag directRefs p hp

private theorem expandPremStep_reachable (dag : PremDag) (directRefs cur : List String)
    (hcur : ∀ p ∈ cur, PremReachable dag directRefs p) :
    ∀ q ∈ expandPremStep dag cur, PremReachable dag directRefs q := by
  induction cur with
  | nil => intro _ h; nomatch h
  | cons x xs ih =>
      intro q hq
      have hx : PremReachable dag directRefs x := hcur x (List.mem_cons_self ..)
      have hxs : ∀ p ∈ xs, PremReachable dag directRefs p :=
        fun p hp => hcur p (List.mem_cons_of_mem x hp)
      unfold expandPremStep at hq
      simp only [List.foldr_cons, List.mem_cons, List.mem_append] at hq
      rcases hq with rfl | hpar | hrest
      · exact hx
      · exact PremReachable.parent hx hpar
      · exact ih hxs q hrest

private theorem transPremIter_reachable (n : Nat) (dag : PremDag) (directRefs cur : List String)
    (hcur : ∀ p ∈ cur, PremReachable dag directRefs p) :
    ∀ q ∈ transPremIter n dag cur, PremReachable dag directRefs q := by
  induction n generalizing cur with
  | zero => exact hcur
  | succ k ih =>
      exact ih (expandPremStep dag cur) (expandPremStep_reachable dag directRefs cur hcur)

/-- Soundness of `depsStarCanon`: every `q ∈ depsStarCanon dag directRefs` is transitively reachable. -/
theorem depsStarCanon_reachable (dag : PremDag) (directRefs : List String) {q : String}
    (hq : q ∈ depsStarCanon dag directRefs) :
    PremReachable dag directRefs q := by
  unfold depsStarCanon at hq
  rw [mem_canonSortStrs] at hq
  exact transPremIter_reachable (dag.length + 1) dag directRefs directRefs
    (fun _ hp => PremReachable.direct hp) q hq

/-! ### 2. Typed Event Log, Detached Store, Monotone `InfoState` vs Non-Monotonic `Standing` -/

/-- Append-only ledger event type storing CIDs/identifiers only (`F-C0-V22-01` type separation). -/
inductive LedgerEvent where
  | recordWitness  : String → LedgerEvent
  | recordProtPres : String → LedgerEvent
  | retractPremise : String → LedgerEvent
  | revokeWitness  : String → LedgerEvent
  | deprecateSpec  : String → LedgerEvent
  | setPolicyEpoch : String → Nat → LedgerEvent
  deriving DecidableEq, Repr

/-- Prefix order `L1 ≼_prefix L2` on ordered append-only event logs. -/
def IsLogPrefix (L1 L2 : List LedgerEvent) : Prop :=
  ∃ tail : List LedgerEvent, L2 = L1 ++ tail

/-- Monotone accumulated epistemic/historical evidence record (`InfoState`). -/
structure InfoState where
  recordedWitnessCids : List String
  recordedProtCids    : List String
  eventHistory        : List LedgerEvent

/-- Extract optional witness CID from a `LedgerEvent`. -/
def eventWitnessCid? : LedgerEvent → Option String
  | .recordWitness cid => some cid
  | _                  => none

/-- Extract optional protected-preservation CID from a `LedgerEvent`. -/
def eventProtCid? : LedgerEvent → Option String
  | .recordProtPres cid => some cid
  | _                   => none

/-- Fold collecting event-extracted identifiers in encounter order. -/
def collectEventCids (f : LedgerEvent → Option String) (L : List LedgerEvent) : List String :=
  L.foldl (fun acc ev => match f ev with | some x => acc ++ [x] | none => acc) []

/-- Fold accumulating monotone `InfoState` from `L`. -/
def infoStateOf (L : List LedgerEvent) : InfoState where
  recordedWitnessCids := collectEventCids eventWitnessCid? L
  recordedProtCids    := collectEventCids eventProtCid? L
  eventHistory        := L

/-- Componentwise monotone information order `I1 ⊑ I2`. -/
def InfoStateLe (I1 I2 : InfoState) : Prop :=
  (∀ c ∈ I1.recordedWitnessCids, c ∈ I2.recordedWitnessCids) ∧
  (∀ c ∈ I1.recordedProtCids, c ∈ I2.recordedProtCids) ∧
  IsLogPrefix I1.eventHistory I2.eventHistory

private theorem foldl_opt_mem_mono (f : LedgerEvent → Option String)
    (tail : List LedgerEvent) :
    ∀ (base : List String) {c : String},
      c ∈ base →
      c ∈ tail.foldl (fun acc ev => match f ev with | some x => acc ++ [x] | none => acc) base := by
  induction tail with
  | nil => intro _ _ hc; exact hc
  | cons e es ih =>
      intro base c hc
      simp only [List.foldl_cons]
      apply ih
      cases f e with
      | none => exact hc
      | some x => exact List.mem_append_left [x] hc

/-- Monotonicity law: `L1 ≼_prefix L2 → InfoStateLe (infoStateOf L1) (infoStateOf L2)`. -/
theorem infoState_monotone_of_prefix {L1 L2 : List LedgerEvent} (hp : IsLogPrefix L1 L2) :
    InfoStateLe (infoStateOf L1) (infoStateOf L2) := by
  rcases hp with ⟨tail, rfl⟩
  refine ⟨?_, ?_, ⟨tail, rfl⟩⟩
  · intro c hc
    dsimp only [infoStateOf, collectEventCids] at hc ⊢
    rw [List.foldl_append]
    exact foldl_opt_mem_mono eventWitnessCid? tail _ hc
  · intro c hc
    dsimp only [infoStateOf, collectEventCids] at hc ⊢
    rw [List.foldl_append]
    exact foldl_opt_mem_mono eventProtCid? tail _ hc

/-- Non-monotonic operational standing folded from `L` (`F-C0-R1-04`). -/
structure Standing where
  recordedWitnessCids : List String
  recordedProtCids    : List String
  retractedPremises   : List String
  revokedWitnesses    : List String
  deprecatedSpecs     : List String
  activePolicyId      : String
  currentEpoch        : Nat
  deriving DecidableEq, Repr

/-- Single-event transition for `Standing`. -/
def stepStanding (st : Standing) (ev : LedgerEvent) : Standing :=
  match ev with
  | .recordWitness cid       => { st with recordedWitnessCids := st.recordedWitnessCids ++ [cid] }
  | .recordProtPres cid      => { st with recordedProtCids := st.recordedProtCids ++ [cid] }
  | .retractPremise pid      => { st with retractedPremises := st.retractedPremises ++ [pid] }
  | .revokeWitness cid       => { st with revokedWitnesses := st.revokedWitnesses ++ [cid] }
  | .deprecateSpec sid       => { st with deprecatedSpecs := st.deprecatedSpecs ++ [sid] }
  | .setPolicyEpoch pid ep   => { st with activePolicyId := pid, currentEpoch := ep }

/-- Initial standing at empty log (`"plcy_v1"`, epoch `0`). -/
def initStanding : Standing where
  recordedWitnessCids := []
  recordedProtCids    := []
  retractedPremises   := []
  revokedWitnesses    := []
  deprecatedSpecs     := []
  activePolicyId      := "plcy_v1"
  currentEpoch        := 0

/-- Folded current standing `Standing_t := foldStanding L_t`. -/
def foldStanding (L : List LedgerEvent) : Standing :=
  L.foldl stepStanding initStanding

/-! ### 3. Syntactic Receipts, Detached Store, & Explicit Checker-to-Semantics Soundness Bridge -/

/-- Pure syntactic witness receipt (`0` embedded `Prop`s — `F-A0-02` non-circularity). -/
structure WitnessReceipt (ClaimId SubdomId ProofCert : Type) where
  witCid         : String
  cellId         : String
  claimId        : ClaimId
  specId         : String
  subdomId       : SubdomId
  directPremises : List String
  expiresEpoch   : Nat
  proofCert      : ProofCert
  deriving DecidableEq, Repr

/-- Pure syntactic protected-preservation receipt (`0` embedded `Prop`s). -/
structure ProtPresReceipt (ClaimId ProtCert : Type) where
  protCid    : String
  srcCellId  : String
  dstCellId  : String
  srcClaimId : ClaimId
  dstClaimId : ClaimId
  srcSpecId  : String
  dstSpecId  : String
  protCert   : ProtCert
  deriving DecidableEq, Repr

/-- Detached content store mapping CIDs to optional receipt payloads (`Unavailable` = `none`). -/
structure DetachedReceiptStore (ClaimId SubdomId ProofCert ProtCert : Type) where
  lookupWitness? : String → Option (WitnessReceipt ClaimId SubdomId ProofCert)
  lookupProt?    : String → Option (ProtPresReceipt ClaimId ProtCert)

/-- Policy gate checking active policy ID and specification admissibility. -/
structure PolicyRule where
  allowsPolicyId : String → Bool
  allowsSpecId   : String → Bool

/-- Computable boolean witness-standing check binding `ReceiptRecorded`, `verifyWitness`,
    canonical premise sorting, **transitive premise survival** (`depsStarCanon`), witness/spec
    non-revocation, and epoch/policy eligibility. -/
def checkWitnessActiveBool {ClaimId SubdomId ProofCert : Type}
    (dag : PremDag) (policy : PolicyRule)
    (verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool)
    (st : Standing) (w : WitnessReceipt ClaimId SubdomId ProofCert) : Bool :=
  st.recordedWitnessCids.contains w.witCid &&
  verifyWitness w &&
  isStrictCanonStrList w.directPremises &&
  (depsStarCanon dag w.directPremises).all (fun p => !st.retractedPremises.contains p) &&
  !st.revokedWitnesses.contains w.witCid &&
  !st.deprecatedSpecs.contains w.specId &&
  decide (st.currentEpoch < w.expiresEpoch) &&
  policy.allowsPolicyId st.activePolicyId &&
  policy.allowsSpecId w.specId

/-- Full witness admission & current activity predicate (`PayloadAvailable` ∧ `checkWitnessActiveBool`). -/
def ActiveWitnessInLog {ClaimId SubdomId ProofCert ProtCert : Type}
    (dag : PremDag) (policy : PolicyRule)
    (verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool)
    (store : DetachedReceiptStore ClaimId SubdomId ProofCert ProtCert)
    (L : List LedgerEvent)
    (w : WitnessReceipt ClaimId SubdomId ProofCert) : Prop :=
  store.lookupWitness? w.witCid = some w ∧
  checkWitnessActiveBool dag policy verifyWitness (foldStanding L) w = true

/-- `F-C0-V22-01` Unavailable-Payload Firewall: recording a CID in `L` when `lookupWitness? = none`
    never produces an `ActiveWitnessInLog`. -/
theorem recorded_unavailable_witness_not_active {ClaimId SubdomId ProofCert ProtCert : Type}
    (dag : PremDag) (policy : PolicyRule)
    (verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool)
    (store : DetachedReceiptStore ClaimId SubdomId ProofCert ProtCert)
    (L : List LedgerEvent) (w : WitnessReceipt ClaimId SubdomId ProofCert)
    (hmiss : store.lookupWitness? w.witCid = none) :
    ¬ ActiveWitnessInLog dag policy verifyWitness store L w := by
  intro hact
  have hs := hact.1
  rw [hmiss] at hs
  nomatch hs

/-- Freshly verified scope on `cellId` for exact `(claimId, specId)` (`F-C1-R1-02`). -/
def FreshQualifiedScope {D ClaimId SubdomId ProofCert ProtCert : Type}
    (evalSubdom : SubdomId → D → Prop)
    (dag : PremDag) (policy : PolicyRule)
    (verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool)
    (store : DetachedReceiptStore ClaimId SubdomId ProofCert ProtCert)
    (L : List LedgerEvent)
    (cellId : String) (claimId : ClaimId) (specId : String) (x : D) : Prop :=
  ∃ w : WitnessReceipt ClaimId SubdomId ProofCert,
    ActiveWitnessInLog dag policy verifyWitness store L w ∧
    w.cellId = cellId ∧
    w.claimId = claimId ∧
    w.specId = specId ∧
    evalSubdom w.subdomId x

/-- Transport-preserved scope along `τ : anchSrc ⇝ anchDst` from an active source witness. -/
def PreservedScopeAlong {B ObsIdx DSrc DDst ClaimId SubdomId ProofCert ProtCert : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domSrc domDst : String}
    {anchSrc : CertifiedChartAnchor reg baseId domSrc DSrc}
    {anchDst : CertifiedChartAnchor reg baseId domDst DDst}
    (τ : SemanticTransport anchSrc anchDst)
    (evalSrcSubdom : SubdomId → DSrc → Prop)
    (dag : PremDag) (policy : PolicyRule)
    (verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool)
    (verifyProt : ProtPresReceipt ClaimId ProtCert → Bool)
    (store : DetachedReceiptStore ClaimId SubdomId ProofCert ProtCert)
    (L : List LedgerEvent)
    (dstCellId : String) (dstClaim : ClaimId) (dstSpec : String) (y : DDst) : Prop :=
  ∃ (hy : τ.imgDom y)
    (wSrc : WitnessReceipt ClaimId SubdomId ProofCert)
    (ρ : ProtPresReceipt ClaimId ProtCert),
    ActiveWitnessInLog dag policy verifyWitness store L wSrc ∧
    (foldStanding L).recordedProtCids.contains ρ.protCid = true ∧
    store.lookupProt? ρ.protCid = some ρ ∧
    verifyProt ρ = true ∧
    !(foldStanding L).deprecatedSpecs.contains ρ.dstSpecId = true ∧
    ρ.srcCellId = wSrc.cellId ∧
    ρ.dstCellId = dstCellId ∧
    ρ.srcClaimId = wSrc.claimId ∧
    ρ.dstClaimId = dstClaim ∧
    ρ.srcSpecId = wSrc.specId ∧
    ρ.dstSpecId = dstSpec ∧
    evalSrcSubdom wSrc.subdomId (τ.invFun ⟨y, hy⟩).1

/-- Claim-, spec-, and active-standing-bound `QualifiedScope_t(g, φ, spec)` (`F-C1-R1-02`). -/
def QualifiedScope {B ObsIdx DSrc DDst ClaimId SubdomId ProofCert ProtCert : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domSrc domDst : String}
    {anchSrc : CertifiedChartAnchor reg baseId domSrc DSrc}
    {anchDst : CertifiedChartAnchor reg baseId domDst DDst}
    (τ : SemanticTransport anchSrc anchDst)
    (evalSrcSubdom : SubdomId → DSrc → Prop)
    (evalDstSubdom : SubdomId → DDst → Prop)
    (dag : PremDag) (policy : PolicyRule)
    (verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool)
    (verifyProt : ProtPresReceipt ClaimId ProtCert → Bool)
    (store : DetachedReceiptStore ClaimId SubdomId ProofCert ProtCert)
    (L : List LedgerEvent)
    (dstCellId : String) (dstClaim : ClaimId) (dstSpec : String) (y : DDst) : Prop :=
  PreservedScopeAlong τ evalSrcSubdom dag policy verifyWitness verifyProt store L
    dstCellId dstClaim dstSpec y ∨
  FreshQualifiedScope evalDstSubdom dag policy verifyWitness store L
    dstCellId dstClaim dstSpec y

/-- **`F-A0-02` Explicit Soundness Bridge Predicate (`SoundWitnessChecker`)**:
    Connects computable `verifyWitness w = true` + semantic validity of all transitive premises
    `depsStarCanon` to `ModelsStrictPred` on `evalSubdom w.subdomId`. -/
def SoundWitnessChecker {D ClaimId SubdomId ProofCert : Type}
    (dag : PremDag)
    (PremSemValid : String → Prop)
    (evalSubdom : SubdomId → D → Prop)
    (evalClaim : String → ClaimId → StrictPred D)
    (verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool) : Prop :=
  ∀ w : WitnessReceipt ClaimId SubdomId ProofCert,
    verifyWitness w = true →
    (∀ p ∈ depsStarCanon dag w.directPremises, PremSemValid p) →
    ∀ x : D, evalSubdom w.subdomId x →
      ModelsStrictPred (evalClaim w.specId w.claimId) x

/-- **`F-A0-02` Explicit Transport-Preservation Soundness Bridge (`SoundProtChecker`)**. -/
def SoundProtChecker {B ObsIdx DSrc DDst ClaimId ProtCert : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domSrc domDst : String}
    {anchSrc : CertifiedChartAnchor reg baseId domSrc DSrc}
    {anchDst : CertifiedChartAnchor reg baseId domDst DDst}
    (τ : SemanticTransport anchSrc anchDst)
    (evalSrcClaim : String → ClaimId → StrictPred DSrc)
    (evalDstClaim : String → ClaimId → StrictPred DDst)
    (verifyProt : ProtPresReceipt ClaimId ProtCert → Bool) : Prop :=
  ∀ (ρ : ProtPresReceipt ClaimId ProtCert) (x : { u : DSrc // τ.retDom u }),
    verifyProt ρ = true →
    ModelsStrictPred (evalSrcClaim ρ.srcSpecId ρ.srcClaimId) x.1 →
    ModelsStrictPred (evalDstClaim ρ.dstSpecId ρ.dstClaimId) (τ.toFun x).1

/-- Independent hypothesis that every currently non-retracted premise is semantically valid. -/
def ActivePremisesSemValid (L : List LedgerEvent) (PremSemValid : String → Prop) : Prop :=
  ∀ p : String, (foldStanding L).retractedPremises.contains p = false → PremSemValid p

private theorem activeWitness_verify_and_prems {ClaimId SubdomId ProofCert ProtCert : Type}
    {dag : PremDag} {policy : PolicyRule}
    {verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool}
    {store : DetachedReceiptStore ClaimId SubdomId ProofCert ProtCert}
    {L : List LedgerEvent} {PremSemValid : String → Prop}
    {w : WitnessReceipt ClaimId SubdomId ProofCert}
    (hact : ActiveWitnessInLog dag policy verifyWitness store L w)
    (hprem : ActivePremisesSemValid L PremSemValid) :
    verifyWitness w = true ∧ (∀ p ∈ depsStarCanon dag w.directPremises, PremSemValid p) := by
  have hb := hact.2
  unfold checkWitnessActiveBool at hb
  simp only [Bool.and_eq_true] at hb
  rcases hb with ⟨⟨⟨⟨⟨⟨⟨⟨_, hver⟩, _⟩, hall⟩, _⟩, _⟩, _⟩, _⟩, _⟩
  refine ⟨hver, ?_⟩
  intro p hp
  have hnot := List.all_eq_true.mp hall p hp
  cases hc : (foldStanding L).retractedPremises.contains p with
  | false => exact hprem p hc
  | true =>
      rw [hc] at hnot
      contradiction

/-- **`T-A0-06a` — General Parametric `QualifiedScope` Soundness via Explicit Checker Bridges**:
    Under `SoundWitnessChecker`, `SoundProtChecker`, and `ActivePremisesSemValid`, every point
    `y ∈ QualifiedScope ... dstCellId dstClaim dstSpec` satisfies `ModelsStrictPred`. -/
theorem T_A0_06a_abstract_qualifiedScope_sound
    {B ObsIdx DSrc DDst ClaimId SubdomId ProofCert ProtCert : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domSrc domDst : String}
    {anchSrc : CertifiedChartAnchor reg baseId domSrc DSrc}
    {anchDst : CertifiedChartAnchor reg baseId domDst DDst}
    (τ : SemanticTransport anchSrc anchDst)
    (evalSrcSubdom : SubdomId → DSrc → Prop)
    (evalDstSubdom : SubdomId → DDst → Prop)
    (evalSrcClaim : String → ClaimId → StrictPred DSrc)
    (evalDstClaim : String → ClaimId → StrictPred DDst)
    (dag : PremDag) (policy : PolicyRule)
    (PremSemValid : String → Prop)
    (verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool)
    (verifyProt : ProtPresReceipt ClaimId ProtCert → Bool)
    (store : DetachedReceiptStore ClaimId SubdomId ProofCert ProtCert)
    (L : List LedgerEvent)
    (dstCellId : String) (dstClaim : ClaimId) (dstSpec : String) (y : DDst)
    (hSoundWsrc : SoundWitnessChecker dag PremSemValid evalSrcSubdom evalSrcClaim verifyWitness)
    (hSoundWdst : SoundWitnessChecker dag PremSemValid evalDstSubdom evalDstClaim verifyWitness)
    (hSoundP    : SoundProtChecker τ evalSrcClaim evalDstClaim verifyProt)
    (hPremValid : ActivePremisesSemValid L PremSemValid)
    (hq : QualifiedScope τ evalSrcSubdom evalDstSubdom dag policy verifyWitness verifyProt store L
            dstCellId dstClaim dstSpec y) :
    ModelsStrictPred (evalDstClaim dstSpec dstClaim) y := by
  rcases hq with hpres | hfresh
  · rcases hpres with ⟨hy, wSrc, ρ, hact, _, _, hvprot, _, _, _, hsc, hdc, hss, hds, hdom⟩
    rcases activeWitness_verify_and_prems hact hPremValid with ⟨hvw, hprems⟩
    let xSrc := τ.invFun ⟨y, hy⟩
    have hmSrc : ModelsStrictPred (evalSrcClaim wSrc.specId wSrc.claimId) xSrc.1 :=
      hSoundWsrc wSrc hvw hprems xSrc.1 hdom
    rw [← hss, ← hsc] at hmSrc
    have hmDst : ModelsStrictPred (evalDstClaim ρ.dstSpecId ρ.dstClaimId) (τ.toFun xSrc).1 :=
      hSoundP ρ xSrc hvprot hmSrc
    have hval : (τ.toFun xSrc).1 = y := congrArg Subtype.val (τ.right_inv ⟨y, hy⟩)
    rw [hval, hds, hdc] at hmDst
    exact hmDst
  · rcases hfresh with ⟨w, hact, _, rfl, rfl, hdom⟩
    rcases activeWitness_verify_and_prems hact hPremValid with ⟨hvw, hprems⟩
    exact hSoundWdst w hvw hprems y hdom

/-! ### 4. Concrete Rational Checker `verifyRatClaimBool` & Theorems `T-A0-06b`, `07`, `08`, `09` -/

/-- Syntactic claim identifiers for concrete rational qualification tests. -/
inductive RatClaimId where
  | sqNonneg : RatClaimId
  | sqPos    : RatClaimId
  deriving DecidableEq, Repr

/-- Syntactic subdomain identifiers over `ℚ`. -/
inductive RatSubdomId where
  | allRat     : RatSubdomId
  | nonzeroRat : RatSubdomId
  deriving DecidableEq, Repr

/-- Syntactic proof-certificate tags checked by `verifyRatClaimBool`. -/
inductive RatProofCert where
  | sumOfSquaresId      : RatProofCert
  | nonzeroSqStrictPos  : RatProofCert
  | bogusAllRatSqPos    : RatProofCert
  deriving DecidableEq, Repr

/-- Syntactic protected-transport certificate tags checked by `verifyRatProtBool`. -/
inductive RatProtCert where
  | baseCommIdentityPres : RatProtCert
  | invalidCrossClaim    : RatProtCert
  deriving DecidableEq, Repr

/-- Semantic interpretation of `RatSubdomId` on `ℚ`. -/
def evalRatSubdom : RatSubdomId → Rat → Prop
  | .allRat,     _ => True
  | .nonzeroRat, x => x ≠ 0

/-- Semantic interpretation of `RatClaimId` on `ℚ`. -/
def evalRatClaimPred (_specId : String) : RatClaimId → StrictPred Rat
  | .sqNonneg => ratSqNonnegPred
  | .sqPos    => ratSqPosPred

/-- Computable boolean witness checker `verifyRatClaimBool` (`Bool`, zero `Prop`s). -/
def verifyRatClaimBool (w : WitnessReceipt RatClaimId RatSubdomId RatProofCert) : Bool :=
  (w.specId == "spec_v1" || w.specId == "spec_v2") &&
  isStrictCanonStrList w.directPremises &&
  match w.claimId, w.subdomId, w.proofCert with
  | .sqNonneg, .allRat,     .sumOfSquaresId     => true
  | .sqNonneg, .nonzeroRat, .sumOfSquaresId     => true
  | .sqPos,    .nonzeroRat, .nonzeroSqStrictPos => true
  | _,         _,           _                   => false

/-- Computable boolean protected-transport checker `verifyRatProtBool`. -/
def verifyRatProtBool (ρ : ProtPresReceipt RatClaimId RatProtCert) : Bool :=
  (ρ.srcClaimId == ρ.dstClaimId) &&
  (ρ.protCert == .baseCommIdentityPres) &&
  (ρ.dstSpecId == "spec_v1" || ρ.dstSpecId == "spec_v2")

/-- Standard permissive policy allowing `"plcy_v1"` and `"spec_v1"` / `"spec_v2"`. -/
def stdRatPolicy : PolicyRule where
  allowsPolicyId pid := pid == "plcy_v1"
  allowsSpecId sid   := sid == "spec_v1" || sid == "spec_v2"

/-- Genuine accepted witness: `x^2 ≥ 0` on all `ℚ` for `"g0"` under `"spec_v1"`. -/
def wTrivAllG0 : WitnessReceipt RatClaimId RatSubdomId RatProofCert where
  witCid         := "w_triv_all_g0"
  cellId         := "g0"
  claimId        := .sqNonneg
  specId         := "spec_v1"
  subdomId       := .allRat
  directPremises := ["p1"]
  expiresEpoch   := 100
  proofCert      := .sumOfSquaresId

/-- Genuine accepted witness: `x^2 > 0` on `ℚ \ {0}` for `"g0"` under `"spec_v1"`. -/
def wPosNonzeroG0 : WitnessReceipt RatClaimId RatSubdomId RatProofCert where
  witCid         := "w_pos_nz_g0"
  cellId         := "g0"
  claimId        := .sqPos
  specId         := "spec_v1"
  subdomId       := .nonzeroRat
  directPremises := ["p1"]
  expiresEpoch   := 100
  proofCert      := .nonzeroSqStrictPos

/-- Bogus witness claiming `x^2 > 0` on all `ℚ` (rejected by `verifyRatClaimBool`). -/
def wBogusPosAllG0 : WitnessReceipt RatClaimId RatSubdomId RatProofCert where
  witCid         := "w_bogus_pos_all"
  cellId         := "g0"
  claimId        := .sqPos
  specId         := "spec_v1"
  subdomId       := .allRat
  directPremises := ["p1"]
  expiresEpoch   := 100
  proofCert      := .bogusAllRatSqPos

/-- Genuine fresh witness on re-expanded `"g2"`: `x^2 ≥ 0` on `D2 = ℚ` under `"spec_v2"`. -/
def wFreshFixedG2 : WitnessReceipt RatClaimId RatSubdomId RatProofCert where
  witCid         := "w_fresh_fixed_g2"
  cellId         := "g2"
  claimId        := .sqNonneg
  specId         := "spec_v2"
  subdomId       := .allRat
  directPremises := ["p2"]
  expiresEpoch   := 100
  proofCert      := .sumOfSquaresId

/-- Secondary independent witness on `"g0"` using premise `["p2"]` for `T-A0-09b/c`. -/
def wTrivAllG0Prem2 : WitnessReceipt RatClaimId RatSubdomId RatProofCert where
  witCid         := "w_triv_all_g0_p2"
  cellId         := "g0"
  claimId        := .sqNonneg
  specId         := "spec_v1"
  subdomId       := .allRat
  directPremises := ["p2"]
  expiresEpoch   := 100
  proofCert      := .sumOfSquaresId

/-- Protected-transport receipt carrying `.sqPos` from `"g0"` (`"spec_v1"`) to `"g2"` (`"spec_v2"`)
    across the retained locus `ℚ \ {0}` of `ratRetreatThenReexpand`. -/
def protPosG0ToG2 : ProtPresReceipt RatClaimId RatProtCert where
  protCid    := "prot_pos_g0_g2"
  srcCellId  := "g0"
  dstCellId  := "g2"
  srcClaimId := .sqPos
  dstClaimId := .sqPos
  srcSpecId  := "spec_v1"
  dstSpecId  := "spec_v2"
  protCert   := .baseCommIdentityPres

/-- Concrete detached receipt store containing all test receipts. -/
def stdRatStore : DetachedReceiptStore RatClaimId RatSubdomId RatProofCert RatProtCert where
  lookupWitness? cid :=
    if cid == "w_triv_all_g0"    then some wTrivAllG0
    else if cid == "w_pos_nz_g0" then some wPosNonzeroG0
    else if cid == "w_bogus_pos_all" then some wBogusPosAllG0
    else if cid == "w_fresh_fixed_g2" then some wFreshFixedG2
    else if cid == "w_triv_all_g0_p2" then some wTrivAllG0Prem2
    else none
  lookupProt? cid :=
    if cid == "prot_pos_g0_g2" then some protPosG0ToG2 else none

/-- **`T-A0-06b` — Unconditional Soundness & Non-Vacuity of `verifyRatClaimBool` / `verifyRatProtBool`**:
    (1) `verifyRatClaimBool` satisfies `SoundWitnessChecker` unconditionally for any `dag` and `PremSemValid`;
    (2) `verifyRatProtBool` satisfies `SoundProtChecker` unconditionally along any `SemanticTransport`
        from `ratFullCertifiedAnchor` to `ratFullCertifiedAnchor`;
    (3) Non-vacuity: `verifyRatClaimBool` accepts `wTrivAllG0`, `wPosNonzeroG0`, and `wFreshFixedG2` (`= true`),
        while rejecting invalid `wBogusPosAllG0` (`= false`). -/
theorem T_A0_06b_concrete_rat_checker_sound_and_nonvacuous :
    (∀ (dag : PremDag) (PremSemValid : String → Prop),
      SoundWitnessChecker dag PremSemValid evalRatSubdom evalRatClaimPred verifyRatClaimBool) ∧
    (∀ (τ : SemanticTransport ratFullCertifiedAnchor ratFullCertifiedAnchor),
      SoundProtChecker τ evalRatClaimPred evalRatClaimPred verifyRatProtBool) ∧
    (verifyRatClaimBool wTrivAllG0 = true ∧
     verifyRatClaimBool wPosNonzeroG0 = true ∧
     verifyRatClaimBool wFreshFixedG2 = true ∧
     verifyRatClaimBool wBogusPosAllG0 = false) := by
  refine ⟨?_, ?_, ⟨by decide, by decide, by decide, by decide⟩⟩
  · intro dag PremSemValid w hver _ x hdom
    unfold verifyRatClaimBool at hver
    simp only [Bool.and_eq_true] at hver
    rcases hver with ⟨_, hmatch⟩
    cases hc : w.claimId <;> cases hs : w.subdomId <;> cases hp : w.proofCert <;>
      rw [hc, hs, hp] at hmatch
    · exact ⟨trivial, rat_sq_nonneg x⟩
    · contradiction
    · contradiction
    · exact ⟨trivial, rat_sq_nonneg x⟩
    · contradiction
    · contradiction
    · contradiction
    · contradiction
    · contradiction
    · contradiction
    · rw [hs] at hdom
      exact ⟨trivial, (rat_sq_pos_iff_ne_zero x).mpr hdom⟩
    · contradiction
  · intro τ ρ x hv hm
    unfold verifyRatProtBool at hv
    simp only [Bool.and_eq_true] at hv
    rcases hv with ⟨⟨hcl, _⟩, _⟩
    have hc_eq : ρ.srcClaimId = ρ.dstClaimId := eq_of_beq hcl
    have hx_eq : (τ.toFun x).1 = x.1 := τ.base_comm x
    unfold evalRatClaimPred at hm ⊢
    rw [← hc_eq, hx_eq]
    exact hm

/-- **`T-A0-07` (`CE-C1-08`) — Cross-Claim Scope Laundering Blocked**:
    When both `wTrivAllG0` (`x^2 ≥ 0` on `ℚ`) and `wPosNonzeroG0` (`x^2 > 0` on `ℚ \ {0}`) are active
    on `"g0"`, `"g0"` achieves full-`ℚ` qualification for `.sqNonneg`, achieves `ℚ \ {0}` qualification
    for `.sqPos`, yet `0` is strictly excluded from `QualifiedScope` for `.sqPos`. -/
theorem T_A0_07_cross_claim_scope_laundering_blocked :
    let dag0 : PremDag := [("p1", [])]
    let L0 : List LedgerEvent := [.recordWitness "w_triv_all_g0", .recordWitness "w_pos_nz_g0"]
    let τId := idSemanticTransport ratFullCertifiedAnchor
    (∀ x : Rat,
      QualifiedScope τId evalRatSubdom evalRatSubdom dag0 stdRatPolicy
        verifyRatClaimBool verifyRatProtBool stdRatStore L0 "g0" .sqNonneg "spec_v1" x) ∧
    (∀ x : Rat, x ≠ 0 →
      QualifiedScope τId evalRatSubdom evalRatSubdom dag0 stdRatPolicy
        verifyRatClaimBool verifyRatProtBool stdRatStore L0 "g0" .sqPos "spec_v1" x) ∧
    ¬ QualifiedScope τId evalRatSubdom evalRatSubdom dag0 stdRatPolicy
        verifyRatClaimBool verifyRatProtBool stdRatStore L0 "g0" .sqPos "spec_v1" 0 := by
  dsimp only
  let dag0 : PremDag := [("p1", [])]
  let L0 : List LedgerEvent := [.recordWitness "w_triv_all_g0", .recordWitness "w_pos_nz_g0"]
  let τId := idSemanticTransport ratFullCertifiedAnchor
  refine ⟨?_, ?_, ?_⟩
  · intro x
    refine Or.inr ⟨wTrivAllG0, ⟨rfl, by decide⟩, rfl, rfl, rfl, trivial⟩
  · intro x hne
    refine Or.inr ⟨wPosNonzeroG0, ⟨rfl, by decide⟩, rfl, rfl, rfl, hne⟩
  · intro hbad
    have hm : ModelsStrictPred (evalRatClaimPred "spec_v1" .sqPos) 0 :=
      T_A0_06a_abstract_qualifiedScope_sound
        τId evalRatSubdom evalRatSubdom evalRatClaimPred evalRatClaimPred
        dag0 stdRatPolicy (fun _ => True) verifyRatClaimBool verifyRatProtBool
        stdRatStore L0 "g0" .sqPos "spec_v1" 0
        (T_A0_06b_concrete_rat_checker_sound_and_nonvacuous.1 dag0 (fun _ => True))
        (T_A0_06b_concrete_rat_checker_sound_and_nonvacuous.1 dag0 (fun _ => True))
        (T_A0_06b_concrete_rat_checker_sound_and_nonvacuous.2.1 τId)
        (fun _ _ => trivial) hbad
    exact (rat_sq_pos_iff_ne_zero 0).mp hm.2 rfl

/-- **`T-A0-08` (`F-A0-03`) — Simultaneous Preservation of `HistoricalScopeLoss_B = {0}` &
    Fresh Global Re-Qualification on Re-Expanded `g2` (`D2 = ℚ`)**:
    Along `ratRetreatThenReexpand` (`g0(ℚ) → g1(ℚ\{0}) → g2(ℚ)`):
    (1) `HistoricalScopeLoss_B ratRetreatThenReexpand 0` holds (`{0}` loss is never erased);
    (2) `0` is NOT in `PreservedScopeAlong` for any claim;
    (3) Fresh witness `wFreshFixedG2` lawfully qualifies all `x : Rat` on `("g2", .sqNonneg, "spec_v2")`;
    (4) Transported witness `wPosNonzeroG0` + `protPosG0ToG2` qualifies `x ≠ 0` on `("g2", .sqPos, "spec_v2")`,
        while `0` remains excluded from `("g2", .sqPos, "spec_v2")`. -/
theorem T_A0_08_historicalLoss_preserved_yet_fresh_requalification_succeeds :
    let dag2 : PremDag := [("p1", []), ("p2", [])]
    let L2 : List LedgerEvent :=
      [ .recordWitness "w_pos_nz_g0"
      , .recordProtPres "prot_pos_g0_g2"
      , .recordWitness "w_fresh_fixed_g2" ]
    HistoricalScopeLoss_B ratRetreatThenReexpand 0 ∧
    ¬ PreservedScopeAlong ratRetreatThenReexpand evalRatSubdom dag2 stdRatPolicy
        verifyRatClaimBool verifyRatProtBool stdRatStore L2 "g2" .sqNonneg "spec_v2" 0 ∧
    (∀ x : Rat,
      QualifiedScope ratRetreatThenReexpand evalRatSubdom evalRatSubdom dag2 stdRatPolicy
        verifyRatClaimBool verifyRatProtBool stdRatStore L2 "g2" .sqNonneg "spec_v2" x) ∧
    (∀ x : Rat, x ≠ 0 →
      QualifiedScope ratRetreatThenReexpand evalRatSubdom evalRatSubdom dag2 stdRatPolicy
        verifyRatClaimBool verifyRatProtBool stdRatStore L2 "g2" .sqPos "spec_v2" x) ∧
    ¬ QualifiedScope ratRetreatThenReexpand evalRatSubdom evalRatSubdom dag2 stdRatPolicy
        verifyRatClaimBool verifyRatProtBool stdRatStore L2 "g2" .sqPos "spec_v2" 0 := by
  dsimp only
  let dag2 : PremDag := [("p1", []), ("p2", [])]
  let L2 : List LedgerEvent :=
    [ .recordWitness "w_pos_nz_g0"
    , .recordProtPres "prot_pos_g0_g2"
    , .recordWitness "w_fresh_fixed_g2" ]
  refine ⟨?_, ?_, ?_, ?_, ?_⟩
  · exact (ratRetreatThenReexpand_historicalLoss_eq_singleton_zero.2.2.1 0).mpr rfl
  · rintro ⟨hy, _⟩
    exact hy.1 rfl
  · intro x
    exact Or.inr ⟨wFreshFixedG2, ⟨rfl, by decide⟩, rfl, rfl, rfl, trivial⟩
  · intro x hne
    have hy : ratRetreatThenReexpand.imgDom x := ⟨hne, trivial⟩
    refine Or.inl ⟨hy, wPosNonzeroG0, protPosG0ToG2, ⟨rfl, by decide⟩,
      by decide, rfl, by decide, by decide, rfl, rfl, rfl, rfl, rfl, rfl, hne⟩
  · intro hbad
    have hm : ModelsStrictPred (evalRatClaimPred "spec_v2" .sqPos) 0 :=
      T_A0_06a_abstract_qualifiedScope_sound
        ratRetreatThenReexpand evalRatSubdom evalRatSubdom evalRatClaimPred evalRatClaimPred
        dag2 stdRatPolicy (fun _ => True) verifyRatClaimBool verifyRatProtBool
        stdRatStore L2 "g2" .sqPos "spec_v2" 0
        (T_A0_06b_concrete_rat_checker_sound_and_nonvacuous.1 dag2 (fun _ => True))
        (T_A0_06b_concrete_rat_checker_sound_and_nonvacuous.1 dag2 (fun _ => True))
        (T_A0_06b_concrete_rat_checker_sound_and_nonvacuous.2.1 ratRetreatThenReexpand)
        (fun _ _ => trivial) hbad
    exact (rat_sq_pos_iff_ne_zero 0).mp hm.2 rfl

/-- **`T-A0-09a` (`F-A0-03`) — Existential Strict Scope Shrinkage Under Append-Only Log Extension**:
    Exhibits `L0 ≼_prefix L1` where `InfoStateLe (infoStateOf L0) (infoStateOf L1)` holds, yet
    appending `.retractPremise "p1"` strictly shrinks `QualifiedScope` from all `ℚ` to `∅`. -/
theorem T_A0_09a_existential_nonmonotonic_shrinkage :
    ∃ (L0 L1 : List LedgerEvent),
      let dag : PremDag := [("p1", [])]
      let τId := idSemanticTransport ratFullCertifiedAnchor
      IsLogPrefix L0 L1 ∧
      InfoStateLe (infoStateOf L0) (infoStateOf L1) ∧
      (∀ x : Rat,
        QualifiedScope τId evalRatSubdom evalRatSubdom dag stdRatPolicy
          verifyRatClaimBool verifyRatProtBool stdRatStore L0 "g0" .sqNonneg "spec_v1" x) ∧
      (∀ x : Rat,
        ¬ QualifiedScope τId evalRatSubdom evalRatSubdom dag stdRatPolicy
            verifyRatClaimBool verifyRatProtBool stdRatStore L1 "g0" .sqNonneg "spec_v1" x) := by
  let L0 : List LedgerEvent := [.recordWitness "w_triv_all_g0"]
  let L1 : List LedgerEvent := [.recordWitness "w_triv_all_g0", .retractPremise "p1"]
  have hpref : IsLogPrefix L0 L1 := ⟨[.retractPremise "p1"], rfl⟩
  refine ⟨L0, L1, hpref, infoState_monotone_of_prefix hpref, ?_, ?_⟩
  · intro x
    exact Or.inr ⟨wTrivAllG0, ⟨rfl, by decide⟩, rfl, rfl, rfl, trivial⟩
  · intro x hq
    have check_w : ∀ w : WitnessReceipt RatClaimId RatSubdomId RatProofCert,
        ¬ ActiveWitnessInLog [("p1", [])] stdRatPolicy verifyRatClaimBool stdRatStore L1 w := by
      intro w ⟨hstore, hact⟩
      unfold stdRatStore at hstore
      dsimp only at hstore
      by_cases h1 : (w.witCid == "w_triv_all_g0") = true
      · rw [if_pos h1] at hstore; injection hstore with hw; subst hw; revert hact; decide
      · rw [if_neg h1] at hstore
        by_cases h2 : (w.witCid == "w_pos_nz_g0") = true
        · rw [if_pos h2] at hstore; injection hstore with hw; subst hw; revert hact; decide
        · rw [if_neg h2] at hstore
          by_cases h3 : (w.witCid == "w_bogus_pos_all") = true
          · rw [if_pos h3] at hstore; injection hstore with hw; subst hw; revert hact; decide
          · rw [if_neg h3] at hstore
            by_cases h4 : (w.witCid == "w_fresh_fixed_g2") = true
            · rw [if_pos h4] at hstore; injection hstore with hw; subst hw; revert hact; decide
            · rw [if_neg h4] at hstore
              by_cases h5 : (w.witCid == "w_triv_all_g0_p2") = true
              · rw [if_pos h5] at hstore; injection hstore with hw; subst hw; revert hact; decide
              · rw [if_neg h5] at hstore; nomatch hstore
    rcases hq with ⟨_, wSrc, _, hact, _⟩ | ⟨w, hact, _⟩
    · exact check_w wSrc hact
    · exact check_w w hact

/-- **`T-A0-09b` (Concrete Instance) — Multi-Witness Resilience Under Disjoint `Deps*`**:
    When `wTrivAllG0` (`["p1"]`) and `wTrivAllG0Prem2` (`["p2"]`) have disjoint transitive closures
    in `dagIndep = [("p1", []), ("p2", [])]`, retracting `"p1"` deactivates `wTrivAllG0` while
    `Deps*(wTrivAllG0Prem2) ∩ Retracted = ∅` preserves `wTrivAllG0Prem2` and full `ℚ` qualification. -/
theorem T_A0_09b_disjoint_transitive_premises_survive :
    let dagIndep : PremDag := [("p1", []), ("p2", [])]
    let L1 : List LedgerEvent :=
      [ .recordWitness "w_triv_all_g0"
      , .recordWitness "w_triv_all_g0_p2"
      , .retractPremise "p1" ]
    let τId := idSemanticTransport ratFullCertifiedAnchor
    "p1" ∈ (foldStanding L1).retractedPremises ∧
    (∀ p ∈ depsStarCanon dagIndep wTrivAllG0Prem2.directPremises,
      p ∉ (foldStanding L1).retractedPremises) ∧
    ¬ ActiveWitnessInLog dagIndep stdRatPolicy verifyRatClaimBool stdRatStore L1 wTrivAllG0 ∧
    ActiveWitnessInLog dagIndep stdRatPolicy verifyRatClaimBool stdRatStore L1 wTrivAllG0Prem2 ∧
    (∀ x : Rat,
      QualifiedScope τId evalRatSubdom evalRatSubdom dagIndep stdRatPolicy
        verifyRatClaimBool verifyRatProtBool stdRatStore L1 "g0" .sqNonneg "spec_v1" x) := by
  dsimp only
  refine ⟨by decide, by decide, ?_, ⟨rfl, by decide⟩, ?_⟩
  · rintro ⟨_, hact⟩
    revert hact; decide
  · intro x
    exact Or.inr ⟨wTrivAllG0Prem2, ⟨rfl, by decide⟩, rfl, rfl, rfl, trivial⟩

/-- **General Transitive-Retraction Firewall & Multi-Witness Survival Law (`T-A0-09b` Universal Form)**:
    For ANY premise DAG `dag`, event log `L`, and witnesses `w1`, `w2`:
    (1) If any `pRet ∈ depsStarCanon dag w1.directPremises` is in `(foldStanding L).retractedPremises`,
        `w1` is unconditionally deactivated (`¬ ActiveWitnessInLog ... L w1`);
    (2) If `w2` has `Deps*(w2) ∩ RetractedPremises = ∅` together with valid store/checker/spec/policy/epoch
        standing in `L`, `w2` remains active and preserves `QualifiedScope` across its entire `subdomId`. -/
theorem T_A0_09b_general_multi_witness_resilience
    {B ObsIdx DSrc DDst ClaimId SubdomId ProofCert ProtCert : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domSrc domDst : String}
    {anchSrc : CertifiedChartAnchor reg baseId domSrc DSrc}
    {anchDst : CertifiedChartAnchor reg baseId domDst DDst}
    (τ : SemanticTransport anchSrc anchDst)
    (evalSrcSubdom : SubdomId → DSrc → Prop)
    (evalDstSubdom : SubdomId → DDst → Prop)
    (dag : PremDag) (policy : PolicyRule)
    (verifyWitness : WitnessReceipt ClaimId SubdomId ProofCert → Bool)
    (verifyProt : ProtPresReceipt ClaimId ProtCert → Bool)
    (store : DetachedReceiptStore ClaimId SubdomId ProofCert ProtCert)
    (L : List LedgerEvent)
    (w1 w2 : WitnessReceipt ClaimId SubdomId ProofCert)
    (pRet : String)
    (hp1_dep : pRet ∈ depsStarCanon dag w1.directPremises)
    (hp1_ret : pRet ∈ (foldStanding L).retractedPremises)
    (hw2_store : store.lookupWitness? w2.witCid = some w2)
    (hw2_rec   : (foldStanding L).recordedWitnessCids.contains w2.witCid = true)
    (hw2_ver   : verifyWitness w2 = true)
    (hw2_canon : isStrictCanonStrList w2.directPremises = true)
    (hw2_deps  : ∀ p ∈ depsStarCanon dag w2.directPremises,
                   p ∉ (foldStanding L).retractedPremises)
    (hw2_unrev : (foldStanding L).revokedWitnesses.contains w2.witCid = false)
    (hw2_spec  : (foldStanding L).deprecatedSpecs.contains w2.specId = false)
    (hw2_epoch : (foldStanding L).currentEpoch < w2.expiresEpoch)
    (hw2_plcy  : policy.allowsPolicyId (foldStanding L).activePolicyId = true ∧
                 policy.allowsSpecId w2.specId = true) :
    ¬ ActiveWitnessInLog dag policy verifyWitness store L w1 ∧
    ActiveWitnessInLog dag policy verifyWitness store L w2 ∧
    (∀ y : DDst, evalDstSubdom w2.subdomId y →
      QualifiedScope τ evalSrcSubdom evalDstSubdom dag policy verifyWitness verifyProt store L
        w2.cellId w2.claimId w2.specId y) := by
  have hnot1 : ¬ ActiveWitnessInLog dag policy verifyWitness store L w1 := by
    rintro ⟨_, hb⟩
    unfold checkWitnessActiveBool at hb
    simp only [Bool.and_eq_true] at hb
    rcases hb with ⟨⟨⟨⟨⟨⟨⟨⟨_, _⟩, _⟩, hall⟩, _⟩, _⟩, _⟩, _⟩, _⟩
    have hok := List.all_eq_true.mp hall pRet hp1_dep
    have hcont : (foldStanding L).retractedPremises.contains pRet = true :=
      List.contains_iff_mem.mpr hp1_ret
    rw [hcont] at hok
    contradiction
  have hall2 : (depsStarCanon dag w2.directPremises).all
      (fun p => !(foldStanding L).retractedPremises.contains p) = true := by
    apply List.all_eq_true.mpr
    intro p hp
    have hnotmem := hw2_deps p hp
    cases hc : (foldStanding L).retractedPremises.contains p with
    | false => rfl
    | true => exact False.elim (hnotmem (List.contains_iff_mem.mp hc))
  have hact2 : ActiveWitnessInLog dag policy verifyWitness store L w2 := by
    refine ⟨hw2_store, ?_⟩
    unfold checkWitnessActiveBool
    rw [hw2_rec, hw2_ver, hw2_canon, hall2, hw2_unrev, hw2_spec,
        decide_eq_true hw2_epoch, hw2_plcy.1, hw2_plcy.2]
    rfl
  refine ⟨hnot1, hact2, ?_⟩
  intro y hy
  exact Or.inr ⟨w2, hact2, rfl, rfl, rfl, hy⟩

/-- **`T-A0-09c` — Shared-Ancestor Transitive Collapse (Tribunal §4 & §5 Cross-Term Obligation)**:
    Even though direct premise lists `["p1"]` and `["p2"]` are disjoint, in
    `dagShared = [("p1", ["p0"]), ("p2", ["p0"]), ("p0", [])]` both transitive closures `Deps*`
    contain shared ancestor `"p0"`, so retracting `"p0"` simultaneously deactivates BOTH witnesses
    and collapses `QualifiedScope` to `∅`. -/
theorem T_A0_09c_shared_ancestor_transitive_collapse :
    let dagShared : PremDag := [("p1", ["p0"]), ("p2", ["p0"]), ("p0", [])]
    let L1 : List LedgerEvent :=
      [ .recordWitness "w_triv_all_g0"
      , .recordWitness "w_triv_all_g0_p2"
      , .retractPremise "p0" ]
    let τId := idSemanticTransport ratFullCertifiedAnchor
    (∀ k : String, ¬ (k ∈ wTrivAllG0.directPremises ∧ k ∈ wTrivAllG0Prem2.directPremises)) ∧
    "p0" ∈ depsStarCanon dagShared wTrivAllG0.directPremises ∧
    "p0" ∈ depsStarCanon dagShared wTrivAllG0Prem2.directPremises ∧
    ¬ ActiveWitnessInLog dagShared stdRatPolicy verifyRatClaimBool stdRatStore L1 wTrivAllG0 ∧
    ¬ ActiveWitnessInLog dagShared stdRatPolicy verifyRatClaimBool stdRatStore L1 wTrivAllG0Prem2 ∧
    (∀ x : Rat,
      ¬ QualifiedScope τId evalRatSubdom evalRatSubdom dagShared stdRatPolicy
          verifyRatClaimBool verifyRatProtBool stdRatStore L1 "g0" .sqNonneg "spec_v1" x) := by
  dsimp only
  refine ⟨?_, by decide, by decide, ?_, ?_, ?_⟩
  · intro k ⟨hk1, hk2⟩
    simp [wTrivAllG0, wTrivAllG0Prem2] at hk1 hk2
    rw [hk1] at hk2
    exact (by decide : "p1" ≠ "p2") hk2
  · rintro ⟨_, hact⟩; revert hact; decide
  · rintro ⟨_, hact⟩; revert hact; decide
  · intro x hq
    have check_w : ∀ w : WitnessReceipt RatClaimId RatSubdomId RatProofCert,
        ¬ ActiveWitnessInLog [("p1", ["p0"]), ("p2", ["p0"]), ("p0", [])]
            stdRatPolicy verifyRatClaimBool stdRatStore
            [.recordWitness "w_triv_all_g0", .recordWitness "w_triv_all_g0_p2", .retractPremise "p0"] w := by
      intro w ⟨hstore, hact⟩
      unfold stdRatStore at hstore
      dsimp only at hstore
      by_cases h1 : (w.witCid == "w_triv_all_g0") = true
      · rw [if_pos h1] at hstore; injection hstore with hw; subst hw; revert hact; decide
      · rw [if_neg h1] at hstore
        by_cases h2 : (w.witCid == "w_pos_nz_g0") = true
        · rw [if_pos h2] at hstore; injection hstore with hw; subst hw; revert hact; decide
        · rw [if_neg h2] at hstore
          by_cases h3 : (w.witCid == "w_bogus_pos_all") = true
          · rw [if_pos h3] at hstore; injection hstore with hw; subst hw; revert hact; decide
          · rw [if_neg h3] at hstore
            by_cases h4 : (w.witCid == "w_fresh_fixed_g2") = true
            · rw [if_pos h4] at hstore; injection hstore with hw; subst hw; revert hact; decide
            · rw [if_neg h4] at hstore
              by_cases h5 : (w.witCid == "w_triv_all_g0_p2") = true
              · rw [if_pos h5] at hstore; injection hstore with hw; subst hw; revert hact; decide
              · rw [if_neg h5] at hstore; nomatch hstore
    rcases hq with ⟨_, wSrc, _, hact, _⟩ | ⟨w, hact, _⟩
    · exact check_w wSrc hact
    · exact check_w w hact

end OmegaCellC1P1A0
