/-
  PRINCIPIA Ω-CELL-C1-P1B2B — Isolated Proof Core A0
  Module: OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm

  Authorized Scope (`A0_ISOLATED_LEAN_MECHANIZATION_APPROVED`):
    - `A0-01` (`L_B2B_DomNz`): Domain intrinsic nonzero soundness across ALL 4 `G7DomTag`
      constructors (`.domQ`, `.domQNonzero`, `.domQ2`, `.domFiniteGrid`) + composition with
      frozen `OmegaCellC1P1B2A.checkFormDefUnderNz_sound`.
    - `A0-02` (`L_B2B_ImpNorm`): Conditional strict-implication guard normalization
      (`foldStrictImp`) soundness & semantic biconditional under `checkGuardsAndGoalDomDefBool`,
      plus explicit counterexample proving necessity of the definedness guard when partial
      divisions are present (`F_A0_02_ImpNorm_WithoutDefGuard_Fails`).
-/
import OmegaCellC1P1A0
import OmegaCellC1P1B1
import OmegaCellC1P1B2A

namespace OmegaCellC1P1B2BA0

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A

/-! ### 1. Pure Semantic Effective Domain (`S_sem` — `0` Executable Checker Calls) -/

/-- Pure declarative effective post-guard domain membership (`0` checker calls):
    `ρ` belongs to base domain `D`, every guard in `Γ` is telescopically defined at `ρ`,
    and every guard in `Γ` strictly holds at `ρ`. -/
def InEffDom (D : G7DomTag) (Γ : List StrictForm) (ρ : Env2) : Prop :=
  inG7Dom D ρ ∧ TelescopicGuardsDefined Γ ρ ∧ ∀ γ ∈ Γ, ModelsStrictForm γ ρ

/-- Pointwise bidirectional effective-domain equality (`0` checker calls). -/
def SemSameEffDom (D1 : G7DomTag) (Γ1 : List StrictForm)
    (D2 : G7DomTag) (Γ2 : List StrictForm) : Prop :=
  ∀ ρ : Env2, InEffDom D1 Γ1 ρ ↔ InEffDom D2 Γ2 ρ

theorem semSameEffDom_refl (D : G7DomTag) (Γ : List StrictForm) :
    SemSameEffDom D Γ D Γ :=
  fun _ => Iff.rfl

theorem semSameEffDom_symm {D1 : G7DomTag} {Γ1 : List StrictForm}
    {D2 : G7DomTag} {Γ2 : List StrictForm}
    (h : SemSameEffDom D1 Γ1 D2 Γ2) :
    SemSameEffDom D2 Γ2 D1 Γ1 :=
  fun ρ => (h ρ).symm

theorem semSameEffDom_trans {D1 : G7DomTag} {Γ1 : List StrictForm}
    {D2 : G7DomTag} {Γ2 : List StrictForm}
    {D3 : G7DomTag} {Γ3 : List StrictForm}
    (h12 : SemSameEffDom D1 Γ1 D2 Γ2) (h23 : SemSameEffDom D2 Γ2 D3 Γ3) :
    SemSameEffDom D1 Γ1 D3 Γ3 :=
  fun ρ => (h12 ρ).trans (h23 ρ)

/-! ### 2. `A0-01` — `L_B2B_DomNz` Across All 4 `G7DomTag` Constructors -/

/-- Intrinsic nonzero coordinate expressions guaranteed across EVERY point of `inG7Dom D`,
    explicitly handling all 4 constructors of `G7DomTag`. -/
def intrinsicNzOfDom : G7DomTag → List PartExpr
  | .domQ            => []
  | .domQNonzero     => [.varX]
  | .domQ2           => []
  | .domFiniteGrid L =>
      (if !L.isEmpty && L.all (fun p => p.1 != 0) then [.varX] else []) ++
      (if !L.isEmpty && L.all (fun p => p.2 != 0) then [.varY] else [])

private theorem intCast_ne_zero_of_bne {z : Int} (h : (z != 0) = true) :
    (z : Rat) ≠ 0 := by
  intro hCast
  have hz0 : ((0 : Int) : Rat) = 0 := rfl
  rw [← hz0] at hCast
  have hz : z = 0 := Rat.intCast_eq_zero_iff.mp hCast
  subst hz
  nomatch h

/-- **`A0-01` (`L_B2B_DomNz`) — Domain Intrinsic Nonzero Soundness**:
    Across ALL 4 constructors of `G7DomTag` (`.domQ`, `.domQNonzero`, `.domQ2`, `.domFiniteGrid`),
    every expression `d ∈ intrinsicNzOfDom D` evaluates strictly to a nonzero rational at every
    point `ρ` satisfying `inG7Dom D ρ`. -/
theorem L_B2B_DomNz (D : G7DomTag) (ρ : Env2) (hDom : inG7Dom D ρ) :
    ∀ d ∈ intrinsicNzOfDom D, ∃ vd : Rat, PartExprEvalRel d ρ vd ∧ vd ≠ 0 := by
  cases D with
  | domQ =>
      intro _ hd
      nomatch hd
  | domQNonzero =>
      intro d hd
      dsimp [intrinsicNzOfDom] at hd
      rcases List.mem_cons.mp hd with rfl | hNil
      · exact ⟨ρ.1, .varX ρ, hDom.1⟩
      · nomatch hNil
  | domQ2 =>
      intro _ hd
      nomatch hd
  | domFiniteGrid L =>
      rcases hDom with ⟨p, hpMem, hpEq⟩
      subst hpEq
      intro d hd
      dsimp [intrinsicNzOfDom] at hd
      rcases List.mem_append.mp hd with hdX | hdY
      · split at hdX
        · rename_i hCondX
          simp only [Bool.and_eq_true] at hCondX
          rcases List.mem_cons.mp hdX with rfl | hNil
          · have hpNz : (p.1 != 0) = true := List.all_eq_true.mp hCondX.2 p hpMem
            exact ⟨(p.1 : Rat), .varX (gridPtToEnv2 p), intCast_ne_zero_of_bne hpNz⟩
          · nomatch hNil
        · nomatch hdX
      · split at hdY
        · rename_i hCondY
          simp only [Bool.and_eq_true] at hCondY
          rcases List.mem_cons.mp hdY with rfl | hNil
          · have hpNz : (p.2 != 0) = true := List.all_eq_true.mp hCondY.2 p hpMem
            exact ⟨(p.2 : Rat), .varY (gridPtToEnv2 p), intCast_ne_zero_of_bne hpNz⟩
          · nomatch hNil
        · nomatch hdY

/-- Direct bridge composing `L_B2B_DomNz` with frozen `OmegaCellC1P1B2A.checkFormDefUnderNz_sound`:
    `checkFormDefUnderNzBool (intrinsicNzOfDom D) φ = true` guarantees `FormDefined φ ρ`
    across ALL `ρ` in `inG7Dom D`. -/
theorem L_B2B_DomIntrinsicDef_sound {D : G7DomTag} {ρ : Env2} {φ : StrictForm}
    (hDom : inG7Dom D ρ)
    (hChk : checkFormDefUnderNzBool (intrinsicNzOfDom D) φ = true) :
    FormDefined φ ρ :=
  checkFormDefUnderNz_sound (L_B2B_DomNz D ρ hDom) φ hChk

/-- Concrete positive and negative checks for `intrinsicNzOfDom` + `checkFormDefUnderNzBool`. -/
theorem A0_01_domNz_positive_and_negative_checks :
    let recipPos : StrictForm := .pos (.div (.const 1) .varX)
    -- Accepted on .domQNonzero and nonzero finite grid:
    checkFormDefUnderNzBool (intrinsicNzOfDom .domQNonzero) recipPos = true ∧
    checkFormDefUnderNzBool (intrinsicNzOfDom (.domFiniteGrid [(1, 0), (-2, 3)])) recipPos = true ∧
    -- Rejected on .domQ, .domQ2, empty grid, and grid containing x = 0:
    checkFormDefUnderNzBool (intrinsicNzOfDom .domQ) recipPos = false ∧
    checkFormDefUnderNzBool (intrinsicNzOfDom .domQ2) recipPos = false ∧
    checkFormDefUnderNzBool (intrinsicNzOfDom (.domFiniteGrid [])) recipPos = false ∧
    checkFormDefUnderNzBool (intrinsicNzOfDom (.domFiniteGrid [(0, 1), (2, 1)])) recipPos = false := by
  decide

/-! ### 3. `A0-02` — `L_B2B_ImpNorm` (Strict Implication Normalization & Necessity Proof) -/

/-- Right-nested strict implication `γ₁ ⇒_strict (γ₂ ⇒_strict ... ψ)`. -/
def foldStrictImp : List StrictForm → StrictForm → StrictForm
  | [],      ψ => ψ
  | γ :: γs, ψ => .impStrict γ (foldStrictImp γs ψ)

/--Computable intrinsic domain-wide definedness check for a guard list `Γ` and goal `ψ` on `D`. -/
def checkGuardsAndGoalDomDefBool (D : G7DomTag) (Γ : List StrictForm) (ψ : StrictForm) : Bool :=
  let nz := intrinsicNzOfDom D
  Γ.all (checkFormDefUnderNzBool nz) && checkFormDefUnderNzBool nz ψ

private theorem all_domDef_implies_telescopic {Γ : List StrictForm} {ρ : Env2}
    (hAllDef : ∀ γ ∈ Γ, FormDefined γ ρ) :
    TelescopicGuardsDefined Γ ρ := by
  induction Γ with
  | nil => trivial
  | cons γ γs ih =>
      exact ⟨hAllDef γ (List.mem_cons_self ..),
        fun _ => ih (fun g hg => hAllDef g (List.mem_cons_of_mem γ hg))⟩

private theorem foldStrictImp_defined_of_allDef {Γ : List StrictForm} {ψ : StrictForm} {ρ : Env2}
    (hAllDef : ∀ γ ∈ Γ, FormDefined γ ρ) (hPsiDef : FormDefined ψ ρ) :
    FormDefined (foldStrictImp Γ ψ) ρ := by
  induction Γ with
  | nil => exact hPsiDef
  | cons γ γs ih =>
      exact ⟨hAllDef γ (List.mem_cons_self ..),
        ih (fun g hg => hAllDef g (List.mem_cons_of_mem γ hg))⟩

private theorem foldStrictImp_models_iff_under_def {Γ : List StrictForm} {ψ : StrictForm} {ρ : Env2}
    (hAllDef : ∀ γ ∈ Γ, FormDefined γ ρ) (hPsiDef : FormDefined ψ ρ) :
    ModelsStrictForm (foldStrictImp Γ ψ) ρ ↔
      ((∀ γ ∈ Γ, ModelsStrictForm γ ρ) → ModelsStrictForm ψ ρ) := by
  induction Γ with
  | nil =>
      dsimp [foldStrictImp]
      constructor
      · intro hM _
        exact hM
      · intro hImp
        exact hImp (fun _ h => nomatch h)
  | cons γ γs ih =>
      have hSubDef : ∀ g ∈ γs, FormDefined g ρ :=
        fun g hg => hAllDef g (List.mem_cons_of_mem γ hg)
      have hGammaDef : FormDefined γ ρ := hAllDef γ (List.mem_cons_self ..)
      have hTailDef : FormDefined (foldStrictImp γs ψ) ρ :=
        foldStrictImp_defined_of_allDef hSubDef hPsiDef
      have ihEq := ih hSubDef
      constructor
      · intro hImpM hAllSat
        have hGammaSat : ModelsStrictForm γ ρ := hAllSat γ (List.mem_cons_self ..)
        have hTailSat : ModelsStrictForm (foldStrictImp γs ψ) ρ :=
          strictMPStep_sound hGammaSat hImpM
        exact ihEq.mp hTailSat (fun g hg => hAllSat g (List.mem_cons_of_mem γ hg))
      · intro hGoalFromAll
        refine ⟨⟨hGammaDef, hTailDef⟩, ?_⟩
        intro hGammaRaw
        have hGammaM : ModelsStrictForm γ ρ := ⟨hGammaDef, hGammaRaw⟩
        have hTailM : ModelsStrictForm (foldStrictImp γs ψ) ρ := by
          apply ihEq.mpr
          intro hRestSat
          apply hGoalFromAll
          intro g hg
          rcases List.mem_cons.mp hg with rfl | hTailMem
          · exact hGammaM
          · exact hRestSat g hTailMem
        exact hTailM.2

/-- **`A0-02` (`L_B2B_ImpNorm`) — Conditional Strict-Implication Guard Normalization**:
    Whenever `checkGuardsAndGoalDomDefBool D Γ ψ = true` holds, at EVERY point `ρ` in `inG7Dom D`:
    (1) `foldStrictImp Γ ψ` is strictly defined (`FormDefined`) AND `Γ` is telescopically defined;
    (2) `ModelsStrictForm (foldStrictImp Γ ψ) ρ` is strictly equivalent (`↔`) to
        `InEffDom D Γ ρ → ModelsStrictForm ψ ρ`. -/
theorem L_B2B_ImpNorm {D : G7DomTag} {Γ : List StrictForm} {ψ : StrictForm}
    (hChk : checkGuardsAndGoalDomDefBool D Γ ψ = true) :
    ∀ ρ : Env2, inG7Dom D ρ →
      (FormDefined (foldStrictImp Γ ψ) ρ ∧ TelescopicGuardsDefined Γ ρ) ∧
      (ModelsStrictForm (foldStrictImp Γ ψ) ρ ↔ (InEffDom D Γ ρ → ModelsStrictForm ψ ρ)) := by
  unfold checkGuardsAndGoalDomDefBool at hChk
  simp only [Bool.and_eq_true] at hChk
  rcases hChk with ⟨hGuardsChk, hPsiChk⟩
  intro ρ hDom
  have hAllDef : ∀ γ ∈ Γ, FormDefined γ ρ := by
    intro γ hMem
    exact L_B2B_DomIntrinsicDef_sound hDom (List.all_eq_true.mp hGuardsChk γ hMem)
  have hPsiDef : FormDefined ψ ρ :=
    L_B2B_DomIntrinsicDef_sound hDom hPsiChk
  have hTel : TelescopicGuardsDefined Γ ρ := all_domDef_implies_telescopic hAllDef
  have hFoldDef : FormDefined (foldStrictImp Γ ψ) ρ :=
    foldStrictImp_defined_of_allDef hAllDef hPsiDef
  refine ⟨⟨hFoldDef, hTel⟩, ?_⟩
  rw [foldStrictImp_models_iff_under_def hAllDef hPsiDef]
  constructor
  · intro hImp hEff
    exact hImp hEff.2.2
  · intro hEffImp hSatAll
    exact hEffImp ⟨hDom, hTel, hSatAll⟩

/-- **Orthogonal Necessity Counterexample (`F_A0_02_ImpNorm_WithoutDefGuard_Fails`)**:
    On `D = .domQ`, for `Γ = [x ≠ 0]` and partial goal `ψ = (1/x > 0)`,
    `checkGuardsAndGoalDomDefBool .domQ Γ ψ = false`. At `ρ = (0, 0) ∈ inG7Dom .domQ`:
    `InEffDom .domQ Γ (0, 0) → ModelsStrictForm ψ (0, 0)` holds vacuously, YET
    `ModelsStrictForm (foldStrictImp Γ ψ) (0, 0)` is FALSE because `1/x` is undefined at `x = 0`!
    This proves `checkGuardsAndGoalDomDefBool` in `L_B2B_ImpNorm` cannot be omitted. -/
theorem F_A0_02_ImpNorm_WithoutDefGuard_Fails :
    let Γ : List StrictForm := [.neqZero .varX]
    let ψ : StrictForm := .pos (.div (.const 1) .varX)
    checkGuardsAndGoalDomDefBool .domQ Γ ψ = false ∧
    inG7Dom .domQ (0, 0) ∧
    (InEffDom .domQ Γ (0, 0) → ModelsStrictForm ψ (0, 0)) ∧
    ¬ ModelsStrictForm (foldStrictImp Γ ψ) (0, 0) := by
  refine ⟨by decide, rfl, ?_, ?_⟩
  · intro hEff
    have hNeq : ModelsStrictForm (.neqZero .varX) (0, 0) :=
      hEff.2.2 (.neqZero .varX) (List.mem_cons_self ..)
    rcases hNeq.2 with ⟨v, hRel, hNe⟩
    cases hRel
    exact False.elim (hNe rfl)
  · intro hFold
    rcases hFold.1.2 with ⟨v, hDivRel⟩
    cases hDivRel with
    | div _ hDen hNe =>
        cases hDen
        exact hNe rfl

end OmegaCellC1P1B2BA0
