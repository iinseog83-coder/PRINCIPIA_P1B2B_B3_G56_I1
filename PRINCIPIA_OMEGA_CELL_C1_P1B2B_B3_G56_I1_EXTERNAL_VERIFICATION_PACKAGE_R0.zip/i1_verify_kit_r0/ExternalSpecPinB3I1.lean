/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B3 G56 — I1 Independent External Replay Act (`KitB3I1`)
  File: ExternalSpecPinB3I1.lean
  Scope: Strictly Detached External Verification Module (0 bytes modified in I0 or 6 Ancestors)

  Implements:
    - `I1-A5`: Kernel `isDefEq` exact proposition-type pins for all `41/41` B3 I0 headline theorems.
    - `I1-A9` & `F-B3-T19-01`: Provenance-bound consumer entrypoints (`ProvenanceBoundG56Diagnostic`,
      `consumeProvenanceBoundVerdict`, `consumeProvenanceBoundQualifiedRecord?`), proving both that
      unbound `projectCoupledVerdictR1` on spoofed `det` can return `.g56Verified` on an invalid
      coupling (`T_I1_A9_01`) AND that provenance-bound consumption strictly equals `checkG56Coupling`
      and blocks spoofed qualification (`T_I1_A9_02`).
    - `I1-A7`, `F-B3-T19-02`, & `Q-B3-I1-03`: Explicit separation between `M_registered` (`12` I0
      probes classified by layer) and `M_end_to_end` (`12` brand-new isolated single-fault full-pipeline
      mutants `E2E-I1-01..12`), with a universal zero-fault exactness proof (`T_I1_A7_01`), `12/12`
      positive-preservation + adversarial-kill theorem (`T_I1_A7_02`), and a constructive equivalent-mutant
      theorem (`T_I1_A7_03_EQ01_CommutedUnionIsProvablyEquivalentMutant`).
    - `I1-A6` & `F-B3-T19-03`: Dynamic 71-case live execution table invoking `qualifyG56Coupled?`
      at runtime on all 55 coupled-certificate cases (`0` hardcoded qualification booleans).
-/
import OmegaCellC1P1B2BB3

namespace ExternalSpecPinB3I1

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2
open OmegaCellC1P1B2BB3

/-! ## Section 1 (`I1-A5`): Exact `41/41` Headline Theorem Type-Signature Pins (`isDefEq`) -/

theorem Pin_01_T_I0_A1_01 :
    (∀ a5 : G5ContextAssignedEpochCert,
       (projectG5Transition a5).toCoreKey = projectG5CoreKey a5.cert ∧
       (projectG5Transition a5).assignedEvalEpoch = a5.assignedEvalEpoch ∧
       (projectG5Transition a5).domOld = a5.cert.domOld ∧
       (projectG5Transition a5).guardsOld = a5.cert.guardsOld ∧
       (projectG5Transition a5).domNew = a5.cert.domNew ∧
       (projectG5Transition a5).guardsNew = a5.cert.guardsNew ∧
       (projectG5Transition a5).reflexKind = a5.cert.reflexKind ∧
       (projectG5Transition a5).requiresRetreatHistory = a5.cert.requiresRetreatHistory) ∧
    Equivalence (fun a1 a2 : G5ContextAssignedEpochCert =>
      projectG5Transition a1 = projectG5Transition a2) :=
  OmegaCellC1P1B2BB3.T_I0_A1_01_G5TransitionProjectionExact

theorem Pin_02_T_I0_A1_02 :
    (∀ g : RelationallyBoundG6Suite,
       projectRelBoundG6 g = g.binding ∧
       G6TransitionCompatibleRel g.suite (projectRelBoundG6 g)) ∧
    (∀ b : G56TransitionBinding,
       (∃ s6 : G6ProtectedSuite, G6TransitionCompatibleRel s6 b) ↔
       (∃ g : RelationallyBoundG6Suite, projectRelBoundG6 g = b)) ∧
    (∃ b_bad : G56TransitionBinding,
       ∀ s6 : G6ProtectedSuite, ¬ G6TransitionCompatibleRel s6 b_bad) :=
  OmegaCellC1P1B2BB3.T_I0_A1_02_G6RelationalWitnessBinding

theorem Pin_03_T_I0_A1_03 :
    (∀ p : G56RelationalPullback,
       projectG5Transition (pullbackProjG5 p) = projectRelBoundG6 (pullbackProjG6 p) ∧
       G6TransitionCompatibleRel (pullbackProjG6 p).suite
         (projectG5Transition (pullbackProjG5 p))) ∧
    (∀ {X : Type} (f5 : X → G5ContextAssignedEpochCert)
       (f6 : X → RelationallyBoundG6Suite)
       (hComm : ∀ x : X, projectG5Transition (f5 x) = projectRelBoundG6 (f6 x)),
       let m := liftToG56RelationalPullback f5 f6 hComm
       (∀ x : X, pullbackProjG5 (m x) = f5 x ∧ pullbackProjG6 (m x) = f6 x) ∧
       (∀ m' : X → G56RelationalPullback,
         (∀ x : X, pullbackProjG5 (m' x) = f5 x ∧ pullbackProjG6 (m' x) = f6 x) →
         ∀ x : X, m' x = m x)) :=
  OmegaCellC1P1B2BB3.T_I0_A1_03_PullbackCoupledTransitionCoherence

theorem Pin_04_T_I0_A1_04 (c5 : G5DischargeCert) (e1 e2 : Nat) :
    (⟨c5, e1⟩ : G5ContextAssignedEpochCert).cert = c5 ∧
    (⟨c5, e2⟩ : G5ContextAssignedEpochCert).cert = c5 ∧
    (projectG5Transition ⟨c5, e1⟩).toCoreKey = (projectG5Transition ⟨c5, e2⟩).toCoreKey ∧
    ((⟨c5, e1⟩ : G5ContextAssignedEpochCert) = ⟨c5, e2⟩ ↔ e1 = e2) ∧
    (projectG5Transition ⟨c5, e1⟩ = projectG5Transition ⟨c5, e2⟩ ↔ e1 = e2) :=
  OmegaCellC1P1B2BB3.T_I0_A1_04_ContextAssignedEpochSemantics c5 e1 e2

theorem Pin_05_T_I0_A1_05 :
    a1BindingRepair ≠ a1BindingRefinement ∧
    a1BindingRepair.reflexKind = .repair ∧
    a1BindingRefinement.reflexKind = .refinement ∧
    G6TransitionCompatibleRel a1AmbiguousSameScopeSuite a1BindingRepair ∧
    G6TransitionCompatibleRel a1AmbiguousSameScopeSuite a1BindingRefinement :=
  OmegaCellC1P1B2BB3.T_I0_A1_05_G6ReflexKindNonUniquenessCounterexample

theorem Pin_06_T_I0_A2_01 (ctx : G56SharedContext) (pkt : G56UntrustedCandidatePacket) :
    checkG56PacketContextError? ctx pkt = none ↔
      (pkt.g5ClaimedEnv = ctx.primEnv ∧
       pkt.g6ClaimedEnv = ctx.primEnv ∧
       pkt.g5ClaimedCont = ctx.dagCont ∧
       pkt.g6ClaimedCont = ctx.dagCont) :=
  OmegaCellC1P1B2BB3.T_I0_A2_01_PacketContextExactSharedIdentity ctx pkt

theorem Pin_07_T_I0_A2_02 :
    SyntacticValidPrimEnv a2FalsePremiseEnv ∧
    ¬ SemValidPrimId a2FalsePremiseEnv "p_false_zero_pos" :=
  OmegaCellC1P1B2BB3.T_I0_A2_02_SyntacticEnvDoesNotImplySemValidPrim

theorem Pin_08_nodup_of_pairwise_strStrictLt :
    ∀ {L : List String},
      List.Pairwise (fun a b => strStrictLt a b = true) L → L.Nodup :=
  @OmegaCellC1P1B2BB3.nodup_of_pairwise_strStrictLt

theorem Pin_09_pairwise_strStrictLt_ext :
    ∀ {L1 L2 : List String},
      List.Pairwise (fun a b => strStrictLt a b = true) L1 →
      List.Pairwise (fun a b => strStrictLt a b = true) L2 →
      (∀ x : String, x ∈ L1 ↔ x ∈ L2) →
      L1 = L2 :=
  @OmegaCellC1P1B2BB3.pairwise_strStrictLt_ext

theorem Pin_10_canonSortStrs_eq_iff_mem (L1 L2 : List String) :
    canonSortStrs L1 = canonSortStrs L2 ↔ (∀ x : String, x ∈ L1 ↔ x ∈ L2) :=
  OmegaCellC1P1B2BB3.canonSortStrs_eq_iff_mem L1 L2

theorem Pin_11_multiRootTransitivePrimDeps_append_eq
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (R1 R2 : List String) :
    multiRootTransitivePrimDeps Γ C (R1 ++ R2) =
      canonSortStrs (multiRootTransitivePrimDeps Γ C R1 ++ multiRootTransitivePrimDeps Γ C R2) :=
  OmegaCellC1P1B2BB3.multiRootTransitivePrimDeps_append_eq Γ C R1 R2

theorem Pin_12_T_I0_A3_01
    (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite) :
    let D5  := deriveG5PrimDeps Γ C c5
    let D6  := deriveG6PrimDeps Γ C s6
    let D56 := deriveG56JointPrimDeps Γ C c5 s6
    let R5  := collectG5ProofRootIds c5
    let R6  := collectG6ProofRootIds s6
    (∀ p : String, p ∈ D56 ↔ (p ∈ D5 ∨ p ∈ D6)) ∧
    D56 = canonSortStrs (D5 ++ D6) ∧
    D56 = multiRootTransitivePrimDeps Γ C (R5 ++ R6) ∧
    isStrictCanonStrList D56 = true ∧
    D56.Nodup :=
  OmegaCellC1P1B2BB3.T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure Γ C c5 s6

theorem Pin_13_T_I0_A3_02
    (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite) (D7 : List String) :
    let D5  := deriveG5PrimDeps Γ C c5
    let D6  := deriveG6PrimDeps Γ C s6
    let D56 := deriveG56JointPrimDeps Γ C c5 s6
    ((∀ p ∈ D56, SemValidPrimId Γ p) ↔
      ((∀ p ∈ D5, SemValidPrimId Γ p) ∧ (∀ p ∈ D6, SemValidPrimId Γ p))) ∧
    ((∀ p ∈ D7, p ∈ D56) →
      (∀ p ∈ D56, SemValidPrimId Γ p) →
      (∀ p ∈ D7, SemValidPrimId Γ p)) :=
  OmegaCellC1P1B2BB3.T_I0_A3_02_SemanticPremiseDistributionAndConfinement Γ C c5 s6 D7

theorem Pin_14_T_I0_A3_03
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite) (sc : G56ScopeCompatibility) :
    let R_joint := collectG56JointProofRootIds c5 s6 sc
    (∀ r ∈ collectG5ProofRootIds c5, r ∈ R_joint) ∧
    (∀ r ∈ collectG6ProofRootIds s6, r ∈ R_joint) ∧
    (∀ r ∈ collectScopeCompatLossRootIds sc, r ∈ R_joint) :=
  OmegaCellC1P1B2BB3.T_I0_A3_03_JointProofRootsContainAllSubRoots c5 s6 sc

theorem Pin_15_T_I0_A3_04
    (fuel5 fuel6 : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite)
    (p_out : String) (newFormula : StrictForm)
    (hEnv  : SyntacticValidPrimEnv Γ)
    (hCont : ValidContainer C)
    (hOut  : p_out ∉ deriveG56JointPrimDeps Γ C c5 s6) :
    let Γ' := replacePrimFormulaInEnv Γ p_out newFormula
    SyntacticValidPrimEnv Γ' ∧
    deriveG5PrimDeps Γ' C c5 = deriveG5PrimDeps Γ C c5 ∧
    deriveG6PrimDeps Γ' C s6 = deriveG6PrimDeps Γ C s6 ∧
    deriveG56JointPrimDeps Γ' C c5 s6 = deriveG56JointPrimDeps Γ C c5 s6 ∧
    checkG5DischargeBool fuel5 Γ' C c5 = checkG5DischargeBool fuel5 Γ C c5 ∧
    checkG6Suite fuel6 Γ' C s6 = checkG6Suite fuel6 Γ C s6 :=
  OmegaCellC1P1B2BB3.T_I0_A3_04_OutsideJointPremiseFormulaNonInterference
    fuel5 fuel6 Γ C c5 s6 p_out newFormula hEnv hCont hOut

theorem Pin_16_T_I0_A4_01 :
    (∀ (w : G56LossEquivWitness) (nid : String),
       IsReferencedLossEquivNodeId w nid →
       nid ∈ collectLossEquivRootIds w) ∧
    (∀ (Γ : PrimPremiseEnv) (C : G7DagContainer)
       (Φ : ExcisedLocus) (itemBinds : List G56ItemLossBinding)
       (bind : G56ItemLossBinding) (w : G56LossEquivWitness) (nid : String),
       bind ∈ itemBinds →
       bind.mode = .l1CertifiedEq w →
       IsReferencedLossEquivNodeId w nid →
         nid ∈ collectScopeCompatLossRootIds (.retreatExactSharedLoss Φ itemBinds) ∧
         (∀ pid ∈ extractTransitivePrimDeps Γ C nid,
           pid ∈ deriveScopeCompatL1PrimDeps Γ C (.retreatExactSharedLoss Φ itemBinds))) :=
  OmegaCellC1P1B2BB3.T_I0_A4_01_RootCollectionCompleteness_NonCircular

theorem Pin_17_T_I0_A4_02
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (invId : String) (L5 L6i : ExcisedLocus) (w : G56LossEquivWitness) (D56 : List String)
    (hCont : ValidContainer C)
    (hChk  : checkSingleL1LossEquivConstrainedBool fuel Γ C D_old Γ_old specNewId
               invId L5 L6i w D56 = true)
    (hPrem : ∀ p ∈ D56, SemValidPrimId Γ p) :
    w.boundInvariantId = invId ∧
    w.boundG5Locus = L5 ∧
    w.boundItemLocus = L6i ∧
    (∀ p ∈ multiRootTransitivePrimDeps Γ C (collectLossEquivRootIds w), p ∈ D56) ∧
    (∀ ρ : Env2, InEffDom D_old Γ_old ρ →
      (ModelsExcised L5 ρ ↔ ModelsExcised L6i ρ)) :=
  OmegaCellC1P1B2BB3.T_I0_A4_02_SingleItemL1LossEquiv_Conditional_Sound
    fuel Γ C D_old Γ_old specNewId invId L5 L6i w D56 hCont hChk hPrem

theorem Pin_18_T_I0_A4_03
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus) (items : List G6ProtectedInvariantSpec)
    (itemBinds : List G56ItemLossBinding) (D56 : List String)
    (hCont : ValidContainer C)
    (hChk  : checkAllItemsRetreatLossConstrainedBool fuel Γ C D_old Γ_old specNewId
               Φ_shared items itemBinds D56 = true)
    (hPrem : ∀ p ∈ D56, SemValidPrimId Γ p) :
    itemBinds.map (·.invariantId) = items.map (·.invariantId) ∧
    (∀ p ∈ deriveScopeCompatL1PrimDeps Γ C (.retreatExactSharedLoss Φ_shared itemBinds), p ∈ D56) ∧
    (∀ item ∈ items,
      item.oldNewState.scopePolicy = .retreatWithLossAccounting ∧
      ∃ lr6 : G6ScopeLossRecord,
        item.scopeLossRecord? = some lr6 ∧
        (∃ bind ∈ itemBinds,
          bind.invariantId = item.invariantId ∧
          bind.itemLocus = lr6.excisedBranches) ∧
        ∀ ρ : Env2, InEffDom D_old Γ_old ρ →
          (ModelsExcised Φ_shared ρ ↔ ModelsExcised lr6.excisedBranches ρ)) :=
  OmegaCellC1P1B2BB3.T_I0_A4_03_MultiItemConstrainedLossEquiv_CompleteSuiteSound
    fuel Γ C D_old Γ_old specNewId Φ_shared items itemBinds D56 hCont hChk hPrem

theorem Pin_19_T_I0_A4_04
    (c5 : G5DischargeCert) (st : G6OldNewStateBinding) (lossOpt : Option G6ScopeLossRecord)
    (hG5      : SemValidG5Discharge c5)
    (hRet     : c5.reflexKind = .retreat)
    (hNonShk  : IsNonShrinkingG6Policy st.scopePolicy)
    (hCarrier : st.domOld = c5.domOld ∧ st.guardsOld = c5.guardsOld ∧
                st.domNew = c5.domNew ∧ st.guardsNew = c5.guardsNew) :
    ¬ SemValidG6ScopeRelation st lossOpt :=
  OmegaCellC1P1B2BB3.T_I0_A4_04_RetreatIncompatibleWithNonShrinkingG6Policy
    c5 st lossOpt hG5 hRet hNonShk hCarrier

theorem Pin_20_T_I0_A4_05
    (ctx : G56SharedContext) (c56 : G56CouplingCert)
    (hVer : isG56CouplingVerifiedBool ctx c56 = true)
    (hRet : c56.transitionBinding.reflexKind = .retreat) :
    ∃ (Φ_shared : ExcisedLocus) (itemBinds : List G56ItemLossBinding)
      (rt5 : G5RetreatPartitionCert),
      c56.scopeCompatibility = .retreatExactSharedLoss Φ_shared itemBinds ∧
      c56.g5Cert.retreatCert? = some rt5 ∧
      rt5.excisedBranches = Φ_shared ∧
      checkAllItemsRetreatLossConstrainedBool ctx.fuelG6 ctx.primEnv ctx.dagCont
        c56.transitionBinding.domOld c56.transitionBinding.guardsOld
        c56.transitionBinding.specNewId Φ_shared c56.g6Suite.items itemBinds
        (deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite) = true :=
  OmegaCellC1P1B2BB3.T_I0_A4_05_TopLevelForcesConstrainedL1Path ctx c56 hVer hRet

theorem Pin_21_T_I0_A5_01
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (chk : G56CheckId) :
    obsPassOfCheckId (evalG56DetailedR1 ctx c56) chk = .notApplicable ↔
      ¬ IsCheckApplicable chk ctx c56 :=
  OmegaCellC1P1B2BB3.T_I0_A5_01_EvalDetailedNotApplicableIffNotApplicable ctx c56 chk

theorem Pin_22_T_I0_A5_02
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (det : G56DetailedResultR1)
    (chk : G56CheckId) :
    (isCoupledVerdictVerifiedBool (projectCoupledVerdictR1 ctx c56 det) = true →
      IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .evaluated true) ∧
    (IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .notApplicable →
      isCoupledVerdictVerifiedBool (projectCoupledVerdictR1 ctx c56 det) = false) ∧
    (∀ r : DiagnosticBlockingReason,
      IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .blocked r →
      isCoupledVerdictVerifiedBool (projectCoupledVerdictR1 ctx c56 det) = false) :=
  OmegaCellC1P1B2BB3.T_I0_A5_02_ProjectedVerdictEnforcesApplicableEvaluatedPass ctx c56 det chk

theorem Pin_23_T_I0_A5_03
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (chk : G56CheckId) :
    let det := evalG56DetailedR1 ctx c56
    (isG56CouplingVerifiedBool ctx c56 = true →
      IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .evaluated true) ∧
    (obsPassOfCheckId det chk = .notApplicable ↔ ¬ IsCheckApplicable chk ctx c56) ∧
    (∀ r : DiagnosticBlockingReason,
      IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .blocked r →
      isG56CouplingVerifiedBool ctx c56 = false) :=
  OmegaCellC1P1B2BB3.T_I0_A5_03_CheckG56DiagnosticReflection ctx c56 chk

theorem Pin_24_T_I0_A5_04
    (ctx : G56SharedContext) (c56 : G56CouplingCert)
    (vIds uIds : List String) (g5Ok : Bool)
    (hViol : checkG56Coupling ctx c56 = .g6Violated vIds uIds g5Ok) :
    (allViolationsPointBasedBool c56.g6Suite = true →
      SemPointCounterexampleOnNewDom c56.g6Suite vIds) ∧
    ((∀ p ∈ deriveG6PrimDeps ctx.primEnv ctx.dagCont c56.g6Suite, SemValidPrimId ctx.primEnv p) →
      SemViolatedG6ProtectedSuite c56.g6Suite vIds) :=
  OmegaCellC1P1B2BB3.T_I0_A5_04_CoupledViolationSoundnessPreserved ctx c56 vIds uIds g5Ok hViol

theorem Pin_25_T_I0_A6_Master
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (hasLoss reqRet : Bool)
    (hVer  : checkG56Coupling ctx c56 = .g56Verified hasLoss reqRet)
    (hPrem : ∀ p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite,
               SemValidPrimId ctx.primEnv p) :
    let D5  := deriveG5PrimDeps ctx.primEnv ctx.dagCont c56.g5Cert
    let D6  := deriveG6PrimDeps ctx.primEnv ctx.dagCont c56.g6Suite
    let D56 := deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite
    let D7  := deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont c56.scopeCompatibility
    SyntacticValidPrimEnv ctx.primEnv ∧
    ValidContainer ctx.dagCont ∧
    c56.g6Suite.items ≠ [] ∧
    c56.claimedJointPrimDeps.g5PrimDepIds = D5 ∧
    c56.claimedJointPrimDeps.g6PrimDepIds = D6 ∧
    c56.claimedJointPrimDeps.jointPrimDepIds = D56 ∧
    (∀ p ∈ D7, p ∈ D56) ∧
    reqRet = c56.g5Cert.requiresRetreatHistory ∧
    hasLoss = c56.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) ∧
    reqRet = hasLoss ∧
    SemValidG56Coupling c56 :=
  OmegaCellC1P1B2BB3.T_I0_A6_G56_MasterConditionalSoundness ctx c56 hasLoss reqRet hVer hPrem

theorem Pin_26_T_I0_A7_EXISTENCE (ctx : G56SharedContext) (rec : G56QualifiedRecord ctx) :
    (∃ v : VerifiedG56Object ctx,
       v = extractVerifiedObject rec ∧
       v.1 = extractVerifiedG56 rec.verifiedG56Slot) ∧
    extractVerifiedG5 rec.verifiedG5Slot =
      (extractVerifiedG56 rec.verifiedG56Slot).g5Cert ∧
    extractVerifiedG6Suite rec.verifiedG6Slot =
      (extractVerifiedG56 rec.verifiedG56Slot).g6Suite ∧
    rec.transitionBinding =
      (extractVerifiedG56 rec.verifiedG56Slot).transitionBinding ∧
    rec.jointPrimDeps =
      (extractVerifiedG56 rec.verifiedG56Slot).claimedJointPrimDeps :=
  OmegaCellC1P1B2BB3.T_I0_A7_EXISTENCE ctx rec

theorem Pin_27_T_I0_A7_TOTALITY (ctx : G56SharedContext) (c56 : G56CouplingCert) :
    ((qualifyG56Coupled? ctx c56).isSome = true ↔
      isG56CouplingVerifiedBool ctx c56 = true) ∧
    (∀ hVer : isG56CouplingVerifiedBool ctx c56 = true,
      qualifyG56Coupled? ctx c56 = some (reifyVerifiedG56 ctx ⟨c56, hVer⟩)) :=
  OmegaCellC1P1B2BB3.T_I0_A7_TOTALITY ctx c56

theorem Pin_28_T_I0_A7_UNIQUENESS (ctx : G56SharedContext)
    (r1 r2 : G56QualifiedRecord ctx)
    (hSameCert : extractVerifiedG56 r1.verifiedG56Slot =
                 extractVerifiedG56 r2.verifiedG56Slot) :
    r1 = r2 :=
  OmegaCellC1P1B2BB3.T_I0_A7_UNIQUENESS ctx r1 r2 hSameCert

theorem Pin_29_T_I0_A7_ROUNDTRIP (ctx : G56SharedContext) :
    (∀ v : VerifiedG56Object ctx,
       extractVerifiedObject (reifyVerifiedG56 ctx v) = v) ∧
    (∀ r : G56QualifiedRecord ctx,
       reifyVerifiedG56 ctx (extractVerifiedObject r) = r) :=
  OmegaCellC1P1B2BB3.T_I0_A7_ROUNDTRIP ctx

theorem Pin_30_T_I0_A7_CE01 (ctx : G56SharedContext) (v : VerifiedG56Object ctx) :
    let r1 : UncanonicalTaggedRecord ctx := ⟨v, "tag_alpha"⟩
    let r2 : UncanonicalTaggedRecord ctx := ⟨v, "tag_beta"⟩
    (∃ u : VerifiedG56Object ctx, u.1 = r1.verifiedObj.1) ∧
    (∃ u : VerifiedG56Object ctx, u.1 = r2.verifiedObj.1) ∧
    r1.verifiedObj = r2.verifiedObj ∧
    r1 ≠ r2 :=
  OmegaCellC1P1B2BB3.T_I0_A7_CE01_ExistenceDoesNotImplyUniquenessOnUncanonicalRecord ctx v

theorem Pin_31_T_I0_A7_ZeroAuthority (ctx : G56SharedContext) :
    (∀ rec : G56QualifiedRecord ctx,
       0 < rec.verifiedInvariantCount ∧
       rec.submittedSuiteComplete = true ∧
       rec.officialProtectionRegistryAuthenticated = false ∧
       rec.officialRegistryBindingSlot = .mkUnchecked ∧
       rec.g1IntegritySlot = .mkUnchecked ∧
       rec.b4CompositeSlot = .mkUnchecked ∧
       rec.grantFlag = .noGrantFromMathCheck) ∧
    ¬ Nonempty (FullReflexAdmitted
        checkUnauthStageCertBool
        (isG56CouplingVerifiedBool ctx)
        checkCertifiedG7BundleBool) :=
  OmegaCellC1P1B2BB3.T_I0_A7_ZeroAuthorityAndNoFullReflex ctx

theorem Pin_32_T_I0_A8_01
    (st : StructuralLedgerState) (ev : StructuralLedgerEvent) (p : String)
    (hMem : p ∈ retractedOfState st) :
    p ∈ retractedOfState (stepStructuralLedger st ev) :=
  OmegaCellC1P1B2BB3.T_I0_A8_01_StepRetractionMonotone st ev p hMem

theorem Pin_33_T_I0_A8_02
    (L ΔL : List StructuralLedgerEvent) (p : String)
    (hMem : p ∈ retractedOfLedger L) :
    p ∈ retractedOfLedger (L ++ ΔL) :=
  OmegaCellC1P1B2BB3.T_I0_A8_02_FoldAppendRetractionSubset L ΔL p hMem

theorem Pin_34_T_I0_A8_03
    (L ΔL : List StructuralLedgerEvent)
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (p : String)
    (hDep : p ∈ c56.claimedJointPrimDeps.jointPrimDepIds)
    (hRet : p ∈ retractedOfLedger L) :
    checkActiveG56CouplingBool (L ++ ΔL) ctx c56 = false :=
  OmegaCellC1P1B2BB3.T_I0_A8_03_CoupledActiveMonotoneInvalidation L ΔL ctx c56 p hDep hRet

theorem Pin_35_T_I0_A8_04
    (L ΔL : List StructuralLedgerEvent)
    {ctx : G56SharedContext} (rec : G56QualifiedRecord ctx) (p : String)
    (hIn5Or6 :
      p ∈ deriveG5PrimDeps ctx.primEnv ctx.dagCont (extractVerifiedG5 rec.verifiedG5Slot) ∨
      p ∈ deriveG6PrimDeps ctx.primEnv ctx.dagCont (extractVerifiedG6Suite rec.verifiedG6Slot))
    (hRet : p ∈ retractedOfLedger L) :
    checkActiveG56RecordBool (L ++ ΔL) rec = false :=
  OmegaCellC1P1B2BB3.T_I0_A8_04_RecordActiveMonotoneInvalidation L ΔL rec p hIn5Or6 hRet

theorem Pin_36_T_I0_A9_R0_Pos :
    (checkG56Coupling ctx_posG56_01 cert_posG56_01 = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_01) ∧
    (checkG56Coupling ctx_posG56_02A cert_posG56_02A = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_02A) ∧
    (checkG56Coupling ctx_posG56_02B cert_posG56_02B = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_02B) ∧
    (checkG56Coupling ctx_posG56_03 cert_posG56_03 = .g56Verified true true ∧
     SemValidG56Coupling cert_posG56_03) ∧
    (checkG56Coupling ctx_posG56_04 cert_posG56_04 = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_04) ∧
    (checkG56Coupling ctx_posG56_05 cert_posG56_05 = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_05) ∧
    (checkG56Coupling ctx_posG56_06 cert_posG56_06 = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_06) ∧
    (checkG56Coupling ctx_posG56_07 cert_posG56_07 = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_07) ∧
    (checkG56Coupling ctx_posG56_08 cert_posG56_08 = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_08) ∧
    (checkG56Coupling ctx_posG56_09 cert_posG56_09 = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_09) ∧
    (checkG56Coupling ctx_posG56_10 cert_posG56_10 = .g56Verified false false ∧
     SemValidG56Coupling cert_posG56_10) :=
  OmegaCellC1P1B2BB3.T_I0_A9_R0_PositiveSuite_All11VerifiedAndSound

theorem Pin_37_T_I0_A9_R0_CE :
    checkG56Coupling ctx_ceG56_01 cert_ceG56_01 = .invalidBinding .g6TransitionIdMismatch ∧
    checkG56Coupling ctx_posG56_01 cert_ceG56_02 = .invalidBinding .g6TransitionIdMismatch ∧
    checkG56Coupling ctx_posG56_01 cert_ceG56_03A = .invalidBinding .g6TransitionIdMismatch ∧
    checkG56Coupling ctx_posG56_01 cert_ceG56_03B = .invalidBinding .evaluationEpochMismatch ∧
    checkG56PacketWithContext ctx_ceG56_04 pkt_ceG56_04A cert_ceG56_04 = .invalidBinding .mismatchedPrimEnv ∧
    checkG56Coupling ctx_ceG56_04 cert_ceG56_04 =
      .invalidEvidence (.g6SuiteInvalid (.forgedVerificationProof "inv_ce04")) ∧
    checkG56PacketWithContext ctx_posG56_04 pkt_ceG56_05A cert_posG56_04 = .invalidBinding .mismatchedDagContainer ∧
    checkG56Coupling ctx_ceG56_05B cert_ceG56_05B =
      .invalidEvidence (.g6SuiteInvalid (.forgedVerificationProof "inv_04")) ∧
    (checkG56Coupling ctx_ceG56_06 cert_ceG56_06 = .g6Violated ["inv_pos05"] [] true ∧
     (qualifyG56Coupled? ctx_ceG56_06 cert_ceG56_06).isNone = true) ∧
    (checkG56Coupling ctx_posG56_01 cert_ceG56_07 = .g6Unresolved ["inv_ce07_unres"] ∧
     (qualifyG56Coupled? ctx_posG56_01 cert_ceG56_07).isNone = true) ∧
    checkG56Coupling ctx_posG56_01 cert_ceG56_08A =
      .invalidEvidence (.g6SuiteInvalid .unauthorizedEmptySuite) ∧
    (checkG56Coupling ctx_posG56_01 cert_ceG56_08B = .g6Empty "pol_empty_unauth_v1" ∧
     (qualifyG56Coupled? ctx_posG56_01 cert_ceG56_08B).isNone = true) ∧
    checkG56Coupling ctx_posG56_01 cert_ceG56_09 = .g5NotDischarged (.g6AlsoVerified false) ∧
    checkG56Coupling ctx_posG56_03 cert_ceG56_10A =
      .invalidBinding (.g5RetreatForbiddenByG6Pol "inv_10a") ∧
    checkG56Coupling ctx_posG56_03 cert_ceG56_10B =
      .invalidBinding (.prePostCarrierMismatch "inv_10b") ∧
    checkG56Coupling ctx_posG56_03 cert_ceG56_11 =
      .invalidBinding (.scopeLossLocusMismatch "inv_11") ∧
    checkG56Coupling ctx_posG56_09 cert_ceG56_12 = .invalidEvidence .jointPrimDepsMismatch ∧
    checkG56Coupling ctx_posG56_09 cert_ceG56_13 = .invalidEvidence .jointPrimDepsMismatch ∧
    checkActiveG56SplitLedgerPacketBool ledger_ce14_clean ledger_ce14_retG5
      ctx_posG56_09 cert_posG56_09 = false ∧
    (∀ ΔL : List StructuralLedgerEvent,
      checkActiveG56CouplingBool (ledger_ce14_retG5 ++ ΔL) ctx_posG56_09 cert_posG56_09 = false) ∧
    (checkOfficialG56SuiteIdsMatchBool ["inv_pos56_01", "inv_missing_official"] cert_posG56_01 = false ∧
     (reifyVerifiedG56 ctx_posG56_01 ⟨cert_posG56_01, by decide⟩).officialProtectionRegistryAuthenticated = false) ∧
    (¬ Nonempty (FullReflexAdmitted checkUnauthStageCertBool
        (isG56CouplingVerifiedBool ctx_posG56_01) checkCertifiedG7BundleBool) ∧
     (reifyVerifiedG56 ctx_posG56_01 ⟨cert_posG56_01, by decide⟩).grantFlag = .noGrantFromMathCheck) ∧
    checkG56Coupling ctx_ceG56_17A cert_posG56_09 = .g56Verified false false ∧
    checkG56Coupling ctx_ceG56_17B cert_posG56_09 = .g5NotDischarged (.g6AlsoVerified false) ∧
    checkG56Coupling ctx_ceG56_17C cert_posG56_09 = .invalidEvidence .malformedSharedPrimEnv ∧
    checkG56Coupling ctx_ceG56_18A cert_posG56_04 = .invalidEvidence .malformedSharedContainer ∧
    checkG56Coupling ctx_posG56_04 cert_ceG56_18B =
      .invalidEvidence (.g6SuiteInvalid (.forgedVerificationProof "inv_04")) :=
  OmegaCellC1P1B2BB3.T_I0_A9_R0_CounterexampleSuite_All27Verified

theorem Pin_38_T_I0_A9_R1_All17 :
    checkG56Coupling ctx_posG56_01 cert_posG56_01 = .g56Verified false false ∧
    ((extractVerifiedG5 (reifyVerifiedG56 ctx_posG56_09 ⟨cert_posG56_09, by decide⟩).verifiedG5Slot =
        g5_posG56_09) ∧
     (reifyVerifiedG56 ctx_posG56_09 ⟨cert_posG56_09, by decide⟩).jointPrimDeps.jointPrimDepIds =
        ["p_common", "p_g5_only", "p_g6_only"]) ∧
    (∃ p56 : G56RelationalPullback,
      pullbackProjG5 p56 = ⟨posG5Retreat_BaseDomNz, 10⟩ ∧
      projectG5Transition (pullbackProjG5 p56) = projectRelBoundG6 (pullbackProjG6 p56)) ∧
    (checkG56Coupling ctx_r1_07 cert_posR1_04 = .g56Verified true true ∧
     SemValidG56Coupling cert_posR1_04 ∧
     (evalG56DetailedR1 ctx_r1_07 cert_posR1_04).depsDiag.l1LossEquivDepsSubsetD56Obs =
       .evaluated (true, [])) ∧
    (evalG56DetailedR1 ctx_posG56_01 cert_posG56_01).scopeDiag.lossAgreementCheckObs = .notApplicable ∧
    (checkActiveG56CouplingBool ledger_r1_active10 ctx_posG56_05 cert_posG56_05 = true ∧
     checkActiveG56RecordBool ledger_r1_active10
       (reifyVerifiedG56 ctx_posG56_05 ⟨cert_posG56_05, by decide⟩) = true) ∧
    ((⟨g5_posG56_01, 10⟩ : G5ContextAssignedEpochCert) ≠ ⟨g5_posG56_01, 25⟩ ∧
     checkG56Coupling ctx_posG56_01 cert_ceR1_01_ep25 = .g56Verified false false ∧
     checkG56Coupling ctx_posG56_01 cert_ceR1_01_mismatch = .invalidBinding .evaluationEpochMismatch) ∧
    (∀ rec : G56QualifiedRecord ctx_posG56_05,
      extractVerifiedG56 rec.verifiedG56Slot = cert_posG56_05 →
      extractVerifiedG5 rec.verifiedG5Slot ≠ g5_posG56_04 ∧
      rec.jointPrimDeps.jointPrimDepIds = ["p_shared"]) ∧
    (a1BindingRepair ≠ a1BindingRefinement ∧
     G6TransitionCompatibleRel a1AmbiguousSameScopeSuite a1BindingRepair ∧
     G6TransitionCompatibleRel a1AmbiguousSameScopeSuite a1BindingRefinement) ∧
    (∀ s6 : G6ProtectedSuite, ¬ G6TransitionCompatibleRel s6 inconsistentRepairRetreatBinding) ∧
    ((evalG56DetailedR1 ctx_posG56_09 cert_ceR1_05).depsDiag.g5ClaimedMatchesDerivedObs =
       .evaluated (false, [], ["p_common", "p_g5_only"]) ∧
     (evalG56DetailedR1 ctx_posG56_09 cert_ceR1_05).depsDiag.g6ClaimedMatchesDerivedObs =
       .evaluated (false, ["p_common"], ["p_common", "p_g6_only"]) ∧
     (evalG56DetailedR1 ctx_posG56_09 cert_ceR1_05).depsDiag.jointClaimedMatchesUnionObs =
       .evaluated (false, ["p_bogus"], ["p_common", "p_g5_only", "p_g6_only"]) ∧
     checkG56Coupling ctx_posG56_09 cert_ceR1_05 = .invalidEvidence .jointPrimDepsMismatch) ∧
    ((evalG56DetailedR1 ctx_ceG56_18A cert_posG56_04).contextStatus = .malformedContainer ∧
     (evalG56DetailedR1 ctx_ceG56_18A cert_posG56_04).depsDiag.g5ClaimedMatchesDerivedObs =
       .blocked .malformedSharedContainer ∧
     checkG56Coupling ctx_ceG56_18A cert_posG56_04 = .invalidEvidence .malformedSharedContainer) ∧
    checkG56Coupling ctx_r1_07 cert_ceR1_07A =
      .invalidBinding (.scopeLossLocusMismatch "inv_r1_07") ∧
    checkG56Coupling ctx_r1_07 cert_posR1_04 = .g56Verified true true ∧
    ((evalG56DetailedR1 ctx_ceR1_08 cert_ceR1_08).depsDiag.l1LossEquivDepsSubsetD56Obs =
       .evaluated (false, ["p_aux_l1"]) ∧
     checkG56Coupling ctx_ceR1_08 cert_ceR1_08 =
       .invalidEvidence .lossEquivExtraPremiseNotInD56) ∧
    ((∀ ΔL, checkActiveG56CouplingBool (ledger_r1_retractShared ++ ΔL) ctx_posG56_05 cert_posG56_05 = false) ∧
     checkPrimEnvIntegrityBool env_ceR1_09_dup = false) ∧
    (checkActiveG56CouplingBool ledger_r1_retractShared ctx_posG56_05 cert_posG56_05 = false ∧
     checkActiveG56CouplingBool ledger_r1_active10 ctx_posG56_05 cert_posG56_05 = true) :=
  OmegaCellC1P1B2BB3.T_I0_A9_R1_Suite_All17Verified

theorem Pin_39_T_I0_A9_I0_All16 :
    (let v01 : VerifiedG56Object ctx_posG56_01 := ⟨cert_posG56_01, by decide⟩
     let r01 := reifyVerifiedG56 ctx_posG56_01 v01
     extractVerifiedObject r01 = v01 ∧ reifyVerifiedG56 ctx_posG56_01 (extractVerifiedObject r01) = r01) ∧
    checkG56Coupling ctx_r1_07 cert_posI0_02 = .g56Verified true true ∧
    (checkG56Coupling ctx_posI0_03 cert_posI0_03 = .g56Verified true true ∧
     deriveScopeCompatL1PrimDeps env_posI0_03 cont_posI0_03 cert_posI0_03.scopeCompatibility =
       ["p_shared_ret"]) ∧
    (obsPassOfCheckId (evalG56DetailedR1 ctx_posG56_01 cert_posG56_01) .retreatLossAgreement =
       .notApplicable ∧
     checkG56Coupling ctx_posG56_01 cert_posG56_01 = .g56Verified false false) ∧
    (checkActiveG56CouplingBool [.advanceEpoch 10] ctx_posG56_09 cert_posG56_09 = true ∧
     checkActiveG56CouplingBool [.advanceEpoch 10, .retractPremise "p_g5_only"]
       ctx_posG56_09 cert_posG56_09 = false ∧
     checkActiveG56CouplingBool [.advanceEpoch 10, .retractPremise "p_g5_only", .advanceEpoch 15]
       ctx_posG56_09 cert_posG56_09 = false) ∧
    compareAssetSetsExtensionalBool sampleAssetSetBaseline sampleAssetSetPermutedIdentical = true ∧
    ((⟨⟨cert_posG56_01, by decide⟩, "tag_alpha"⟩ : UncanonicalTaggedRecord ctx_posG56_01) ≠
       ⟨⟨cert_posG56_01, by decide⟩, "tag_beta"⟩) ∧
    checkG56Coupling ctx_r1_07 cert_ceI0_02 =
      .invalidBinding (.scopeLossLocusMismatch "inv_i0_02_b") ∧
    checkG56Coupling ctx_r1_07 cert_ceI0_03 =
      .invalidBinding (.scopeLossLocusMismatch "inv_i0_03_b") ∧
    checkG56Coupling ctx_r1_07 cert_ceI0_04 =
      .invalidBinding (.scopeLossLocusMismatch "inv_i0_04") ∧
    checkG56Coupling ctx_r1_07 cert_ceI0_05 =
      .invalidBinding (.scopeLossLocusMismatch "inv_i0_05") ∧
    (IsReferencedLossEquivNodeId witness_ceI0_06_bwdHidden "ni0_06_bwd_hidden" ∧
     "ni0_06_bwd_hidden" ∈ collectLossEquivRootIds witness_ceI0_06_bwdHidden ∧
     checkG56Coupling ctx_ceI0_06 cert_ceI0_06 = .invalidEvidence .lossEquivExtraPremiseNotInD56) ∧
    (checkSingleL1LossEquivBool 12 env_ceR1_08 cont_ceR1_08 .domQ [] "spec_r1_07_new"
       "inv_r1_07" [[formNegXNonneg]] [[formZeroSubXNonneg]] witness_ceR1_08_extraPrem = true ∧
     checkG56Coupling ctx_ceR1_08 cert_ceR1_08 = .invalidEvidence .lossEquivExtraPremiseNotInD56) ∧
    projectCoupledVerdictR1 ctx_posG56_01 cert_posG56_01 det_ceI0_08_forgedNA =
      .invalidEvidence .invalidDiagnosticObservation ∧
    projectCoupledVerdictR1 ctx_posG56_01 cert_posG56_01 det_ceI0_09_blockedMandatory =
      .invalidEvidence .invalidDiagnosticObservation ∧
    (sampleAssetSetBaseline.length = sampleAssetSetSameCardCorrupted.length ∧
     compareAssetSetsExtensionalBool sampleAssetSetBaseline sampleAssetSetSameCardCorrupted = false) :=
  OmegaCellC1P1B2BB3.T_I0_A9_I0_Suite_All16Verified

theorem Pin_40_T_I0_A9_Mutants12 :
    (mutant01_dropG6CoreKey ctx_ceG56_01 cert_ceG56_01 = true ∧
     isG56CouplingVerifiedBool ctx_ceG56_01 cert_ceG56_01 = false) ∧
    (mutant02_dropEpochCheck ctx_posG56_01 cert_ceG56_03B = true ∧
     isG56CouplingVerifiedBool ctx_posG56_01 cert_ceG56_03B = false) ∧
    (mutant03_retreatHeadItemOnly ctx_r1_07 cert_ceI0_02 = true ∧
     isG56CouplingVerifiedBool ctx_r1_07 cert_ceI0_02 = false) ∧
    (mutant04_skipL1BoundInvId 12 [] cont_r1_07_L1 .domQ [] "spec_r1_07_new"
       "inv_i0_03_b" [[formNegXNonneg]] [[formZeroSubXNonneg]] witness_ceI0_03_wrongId = true ∧
     isG56CouplingVerifiedBool ctx_r1_07 cert_ceI0_03 = false) ∧
    (mutant05_skipSourceBranchMap 12 [] cont_r1_07_L1 .domQ [] "spec_r1_07_new"
       [[formNegXNonneg]] [[formZeroSubXNonneg]] witness_ceI0_04_omittedSrcBranch.l5ImpliesL6 = true ∧
     isG56CouplingVerifiedBool ctx_r1_07 cert_ceI0_04 = false) ∧
    (mutant06_skipTargetBranchMembership 12 [] cont_r1_07_L1 .domQ [] "spec_r1_07_new"
       [[formNegXNonneg]] [[formZeroSubXNonneg]] witness_ceI0_05_foreignTargetBranch.l5ImpliesL6 = true ∧
     isG56CouplingVerifiedBool ctx_r1_07 cert_ceI0_05 = false) ∧
    (mutant07_acceptsExtraBwdPremise ctx_ceI0_06 cert_ceI0_06 witness_ceI0_06_bwdHidden = true ∧
     isG56CouplingVerifiedBool ctx_ceI0_06 cert_ceI0_06 = false) ∧
    (mutant08_skipD7SubsetD56 ctx_ceR1_08 cert_ceR1_08 = true ∧
     isG56CouplingVerifiedBool ctx_ceR1_08 cert_ceR1_08 = false) ∧
    (mutant09_notApplicableTreatedAsPass det_ceI0_08_forgedNA = true ∧
     isCoupledVerdictVerifiedBool
       (projectCoupledVerdictR1 ctx_posG56_01 cert_posG56_01 det_ceI0_08_forgedNA) = false) ∧
    (mutant10_blockedTreatedAsPass det_ceI0_09_blockedMandatory = true ∧
     isCoupledVerdictVerifiedBool
       (projectCoupledVerdictR1 ctx_posG56_01 cert_posG56_01 det_ceI0_09_blockedMandatory) = false) ∧
    (mutant11_promoteEmptySuiteToVerified ctx_posG56_01 cert_ceG56_08B = true ∧
     isG56CouplingVerifiedBool ctx_posG56_01 cert_ceG56_08B = false) ∧
    (mutant12_activeChecksD6Only ledger_ce14_retG5 ctx_posG56_09 cert_posG56_09 = true ∧
     checkActiveG56CouplingBool ledger_ce14_retG5 ctx_posG56_09 cert_posG56_09 = false) :=
  OmegaCellC1P1B2BB3.T_I0_A9_MutationFuzzSuite_All12Killed

theorem Pin_41_T_I0_A9_Complete :
    evaluateAll71SoundnessCases.length = 71 ∧
    evaluateAll12Mutants.length = 12 ∧
    evaluateAll12Mutants.all (fun m => m.killed) = true :=
  OmegaCellC1P1B2BB3.T_I0_A9_All71AndAll12TablesComplete

def all41PinnedTheoremPairs : List (Lean.Name × Lean.Name) := [
  (`OmegaCellC1P1B2BB3.T_I0_A1_01_G5TransitionProjectionExact, `ExternalSpecPinB3I1.Pin_01_T_I0_A1_01),
  (`OmegaCellC1P1B2BB3.T_I0_A1_02_G6RelationalWitnessBinding, `ExternalSpecPinB3I1.Pin_02_T_I0_A1_02),
  (`OmegaCellC1P1B2BB3.T_I0_A1_03_PullbackCoupledTransitionCoherence, `ExternalSpecPinB3I1.Pin_03_T_I0_A1_03),
  (`OmegaCellC1P1B2BB3.T_I0_A1_04_ContextAssignedEpochSemantics, `ExternalSpecPinB3I1.Pin_04_T_I0_A1_04),
  (`OmegaCellC1P1B2BB3.T_I0_A1_05_G6ReflexKindNonUniquenessCounterexample, `ExternalSpecPinB3I1.Pin_05_T_I0_A1_05),
  (`OmegaCellC1P1B2BB3.T_I0_A2_01_PacketContextExactSharedIdentity, `ExternalSpecPinB3I1.Pin_06_T_I0_A2_01),
  (`OmegaCellC1P1B2BB3.T_I0_A2_02_SyntacticEnvDoesNotImplySemValidPrim, `ExternalSpecPinB3I1.Pin_07_T_I0_A2_02),
  (`OmegaCellC1P1B2BB3.nodup_of_pairwise_strStrictLt, `ExternalSpecPinB3I1.Pin_08_nodup_of_pairwise_strStrictLt),
  (`OmegaCellC1P1B2BB3.pairwise_strStrictLt_ext, `ExternalSpecPinB3I1.Pin_09_pairwise_strStrictLt_ext),
  (`OmegaCellC1P1B2BB3.canonSortStrs_eq_iff_mem, `ExternalSpecPinB3I1.Pin_10_canonSortStrs_eq_iff_mem),
  (`OmegaCellC1P1B2BB3.multiRootTransitivePrimDeps_append_eq, `ExternalSpecPinB3I1.Pin_11_multiRootTransitivePrimDeps_append_eq),
  (`OmegaCellC1P1B2BB3.T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure, `ExternalSpecPinB3I1.Pin_12_T_I0_A3_01),
  (`OmegaCellC1P1B2BB3.T_I0_A3_02_SemanticPremiseDistributionAndConfinement, `ExternalSpecPinB3I1.Pin_13_T_I0_A3_02),
  (`OmegaCellC1P1B2BB3.T_I0_A3_03_JointProofRootsContainAllSubRoots, `ExternalSpecPinB3I1.Pin_14_T_I0_A3_03),
  (`OmegaCellC1P1B2BB3.T_I0_A3_04_OutsideJointPremiseFormulaNonInterference, `ExternalSpecPinB3I1.Pin_15_T_I0_A3_04),
  (`OmegaCellC1P1B2BB3.T_I0_A4_01_RootCollectionCompleteness_NonCircular, `ExternalSpecPinB3I1.Pin_16_T_I0_A4_01),
  (`OmegaCellC1P1B2BB3.T_I0_A4_02_SingleItemL1LossEquiv_Conditional_Sound, `ExternalSpecPinB3I1.Pin_17_T_I0_A4_02),
  (`OmegaCellC1P1B2BB3.T_I0_A4_03_MultiItemConstrainedLossEquiv_CompleteSuiteSound, `ExternalSpecPinB3I1.Pin_18_T_I0_A4_03),
  (`OmegaCellC1P1B2BB3.T_I0_A4_04_RetreatIncompatibleWithNonShrinkingG6Policy, `ExternalSpecPinB3I1.Pin_19_T_I0_A4_04),
  (`OmegaCellC1P1B2BB3.T_I0_A4_05_TopLevelForcesConstrainedL1Path, `ExternalSpecPinB3I1.Pin_20_T_I0_A4_05),
  (`OmegaCellC1P1B2BB3.T_I0_A5_01_EvalDetailedNotApplicableIffNotApplicable, `ExternalSpecPinB3I1.Pin_21_T_I0_A5_01),
  (`OmegaCellC1P1B2BB3.T_I0_A5_02_ProjectedVerdictEnforcesApplicableEvaluatedPass, `ExternalSpecPinB3I1.Pin_22_T_I0_A5_02),
  (`OmegaCellC1P1B2BB3.T_I0_A5_03_CheckG56DiagnosticReflection, `ExternalSpecPinB3I1.Pin_23_T_I0_A5_03),
  (`OmegaCellC1P1B2BB3.T_I0_A5_04_CoupledViolationSoundnessPreserved, `ExternalSpecPinB3I1.Pin_24_T_I0_A5_04),
  (`OmegaCellC1P1B2BB3.T_I0_A6_G56_MasterConditionalSoundness, `ExternalSpecPinB3I1.Pin_25_T_I0_A6_Master),
  (`OmegaCellC1P1B2BB3.T_I0_A7_EXISTENCE, `ExternalSpecPinB3I1.Pin_26_T_I0_A7_EXISTENCE),
  (`OmegaCellC1P1B2BB3.T_I0_A7_TOTALITY, `ExternalSpecPinB3I1.Pin_27_T_I0_A7_TOTALITY),
  (`OmegaCellC1P1B2BB3.T_I0_A7_UNIQUENESS, `ExternalSpecPinB3I1.Pin_28_T_I0_A7_UNIQUENESS),
  (`OmegaCellC1P1B2BB3.T_I0_A7_ROUNDTRIP, `ExternalSpecPinB3I1.Pin_29_T_I0_A7_ROUNDTRIP),
  (`OmegaCellC1P1B2BB3.T_I0_A7_CE01_ExistenceDoesNotImplyUniquenessOnUncanonicalRecord, `ExternalSpecPinB3I1.Pin_30_T_I0_A7_CE01),
  (`OmegaCellC1P1B2BB3.T_I0_A7_ZeroAuthorityAndNoFullReflex, `ExternalSpecPinB3I1.Pin_31_T_I0_A7_ZeroAuthority),
  (`OmegaCellC1P1B2BB3.T_I0_A8_01_StepRetractionMonotone, `ExternalSpecPinB3I1.Pin_32_T_I0_A8_01),
  (`OmegaCellC1P1B2BB3.T_I0_A8_02_FoldAppendRetractionSubset, `ExternalSpecPinB3I1.Pin_33_T_I0_A8_02),
  (`OmegaCellC1P1B2BB3.T_I0_A8_03_CoupledActiveMonotoneInvalidation, `ExternalSpecPinB3I1.Pin_34_T_I0_A8_03),
  (`OmegaCellC1P1B2BB3.T_I0_A8_04_RecordActiveMonotoneInvalidation, `ExternalSpecPinB3I1.Pin_35_T_I0_A8_04),
  (`OmegaCellC1P1B2BB3.T_I0_A9_R0_PositiveSuite_All11VerifiedAndSound, `ExternalSpecPinB3I1.Pin_36_T_I0_A9_R0_Pos),
  (`OmegaCellC1P1B2BB3.T_I0_A9_R0_CounterexampleSuite_All27Verified, `ExternalSpecPinB3I1.Pin_37_T_I0_A9_R0_CE),
  (`OmegaCellC1P1B2BB3.T_I0_A9_R1_Suite_All17Verified, `ExternalSpecPinB3I1.Pin_38_T_I0_A9_R1_All17),
  (`OmegaCellC1P1B2BB3.T_I0_A9_I0_Suite_All16Verified, `ExternalSpecPinB3I1.Pin_39_T_I0_A9_I0_All16),
  (`OmegaCellC1P1B2BB3.T_I0_A9_MutationFuzzSuite_All12Killed, `ExternalSpecPinB3I1.Pin_40_T_I0_A9_Mutants12),
  (`OmegaCellC1P1B2BB3.T_I0_A9_All71AndAll12TablesComplete, `ExternalSpecPinB3I1.Pin_41_T_I0_A9_Complete)
]

/-! ## Section 2 (`I1-A9` & `F-B3-T19-01`): Provenance-Bound Consumer Entrypoint & Spoof Blocking -/

/-- Type-level provenance binding guaranteeing `det` was produced by `evalG56DetailedR1 ctx c56`
    (`F-B3-T19-01`: prevents arbitrary externally forged `G56DetailedResultR1` from masquerading
    as an evaluated coupling verdict). -/
def ProvenanceBoundG56Diagnostic (ctx : G56SharedContext) (c56 : G56CouplingCert) : Type :=
  { det : G56DetailedResultR1 // det = evalG56DetailedR1 ctx c56 }

/-- Canonical provenance-bound evaluator producing `ProvenanceBoundG56Diagnostic ctx c56`. -/
def evalProvenanceBoundG56 (ctx : G56SharedContext) (c56 : G56CouplingCert) :
    ProvenanceBoundG56Diagnostic ctx c56 :=
  ⟨evalG56DetailedR1 ctx c56, rfl⟩

/-- Downstream verdict consumer accepting ONLY a provenance-bound diagnostic (`F-B3-T19-01`). -/
def consumeProvenanceBoundVerdict {ctx : G56SharedContext} {c56 : G56CouplingCert}
    (pb : ProvenanceBoundG56Diagnostic ctx c56) : G56CoupledVerdict :=
  projectCoupledVerdictR1 ctx c56 pb.1

/-- Downstream qualification consumer bound directly to `qualifyG56Coupled? ctx c56`. -/
def consumeProvenanceBoundQualifiedRecord? (ctx : G56SharedContext) (c56 : G56CouplingCert) :
    Option (G56QualifiedRecord ctx) :=
  qualifyG56Coupled? ctx c56

/-- Spoofed `det` taken from valid `cert_posG56_01` and fed to invalid `cert_ceG56_01` (`F-B3-T19-01`). -/
def det_t19_01_spoofedFromValid : G56DetailedResultR1 :=
  evalG56DetailedR1 ctx_posG56_01 cert_posG56_01

/-- **`T_I1_A9_01_UnboundDetProjectionCanSpoofInvalidCoupling` (`F-B3-T19-01` Contrast Proof)**:
    Demonstrates constructively why `projectCoupledVerdictR1 ctx c56 det` on an arbitrary unbound `det`
    is a pure diagnostic projection and MUST NOT be treated as qualification:
    (1) `projectCoupledVerdictR1 ctx_ceG56_01 cert_ceG56_01 det_t19_01_spoofedFromValid = .g56Verified false false`;
    (2) Yet provenance-bound `consumeProvenanceBoundVerdict` and `checkG56Coupling` reject `cert_ceG56_01`
        with `.invalidBinding .g6TransitionIdMismatch`;
    (3) `consumeProvenanceBoundQualifiedRecord? ctx_ceG56_01 cert_ceG56_01 = none`;
    (4) No `G56QualifiedRecord ctx_ceG56_01` can ever carry `cert_ceG56_01`! -/
theorem T_I1_A9_01_UnboundDetProjectionCanSpoofInvalidCoupling :
    projectCoupledVerdictR1 ctx_ceG56_01 cert_ceG56_01 det_t19_01_spoofedFromValid =
      .g56Verified false false ∧
    consumeProvenanceBoundVerdict (evalProvenanceBoundG56 ctx_ceG56_01 cert_ceG56_01) =
      .invalidBinding .g6TransitionIdMismatch ∧
    checkG56Coupling ctx_ceG56_01 cert_ceG56_01 =
      .invalidBinding .g6TransitionIdMismatch ∧
    consumeProvenanceBoundQualifiedRecord? ctx_ceG56_01 cert_ceG56_01 = none ∧
    (∀ r : G56QualifiedRecord ctx_ceG56_01,
      extractVerifiedG56 r.verifiedG56Slot ≠ cert_ceG56_01) := by
  refine ⟨by decide, by decide, by decide, by decide, ?_⟩
  intro r hEq
  rcases T_I0_A7_EXISTENCE ctx_ceG56_01 r with ⟨⟨v, _, hvEq⟩, _⟩
  have hVer : isG56CouplingVerifiedBool ctx_ceG56_01 cert_ceG56_01 = true := by
    rw [← hEq, ← hvEq]
    exact v.2
  have hFalse : isG56CouplingVerifiedBool ctx_ceG56_01 cert_ceG56_01 = false := by decide
  rw [hVer] at hFalse
  nomatch hFalse

/-- **`T_I1_A9_02_ProvenanceBoundConsumerExactAndSound` (`I1-A9` Consumer Safety Theorem)**:
    Every verdict consumed via `ProvenanceBoundG56Diagnostic` equals `checkG56Coupling ctx c56`,
    inherits `T_I0_A6_G56_MasterConditionalSoundness`, and `consumeProvenanceBoundQualifiedRecord?`
    succeeds iff `checkG56Coupling` verifies `c56`. -/
theorem T_I1_A9_02_ProvenanceBoundConsumerExactAndSound
    (ctx : G56SharedContext) (c56 : G56CouplingCert)
    (pb : ProvenanceBoundG56Diagnostic ctx c56) :
    consumeProvenanceBoundVerdict pb = checkG56Coupling ctx c56 ∧
    (∀ hasLoss reqRet : Bool,
      consumeProvenanceBoundVerdict pb = .g56Verified hasLoss reqRet →
      (∀ p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite,
         SemValidPrimId ctx.primEnv p) →
      SemValidG56Coupling c56) ∧
    ((consumeProvenanceBoundQualifiedRecord? ctx c56).isSome = true ↔
      isG56CouplingVerifiedBool ctx c56 = true) := by
  have hEq : consumeProvenanceBoundVerdict pb = checkG56Coupling ctx c56 := by
    unfold consumeProvenanceBoundVerdict checkG56Coupling
    rw [pb.2]
  refine ⟨hEq, ?_, (T_I0_A7_TOTALITY ctx c56).1⟩
  intro hasLoss reqRet hVer hPrem
  rw [hEq] at hVer
  exact (T_I0_A6_G56_MasterConditionalSoundness ctx c56 hasLoss reqRet hVer hPrem).2.2.2.2.2.2.2.2.2.2

/-! ## Section 3 (`I1-A7`, `F-B3-T19-02`, `Q-B3-I1-03`): Separated `M_registered` vs `M_end_to_end` -/

/-- Explicit mutation-testing layer taxonomy (`F-B3-T19-02`). -/
inductive MutantLayerCategory where
  | diagnosticRecordProbe      -- Mutates pre-computed `G56DetailedResultR1` fields
  | subCheckerFunctionProbe    -- Mutates a helper/sub-checker function directly
  | verdictProjectionProbe     -- Mutates projection/verdict mapping directly
  | multiClauseActiveProbe     -- Mutates `D56 -> D6` while also omitting epoch clauses
  | isolatedEndToEndSingleFault -- Full top-level pipeline with strictly 1 atomic fault
  deriving DecidableEq, Repr

/-- Layer classification of the 12 registered `I0` probes (`M_registered`, `Q-B3-I1-03`). -/
def registered12ProbeLayerMap : List (String × MutantLayerCategory) := [
  ("MUT-I0-01", .diagnosticRecordProbe),
  ("MUT-I0-02", .diagnosticRecordProbe),
  ("MUT-I0-03", .subCheckerFunctionProbe),
  ("MUT-I0-04", .subCheckerFunctionProbe),
  ("MUT-I0-05", .subCheckerFunctionProbe),
  ("MUT-I0-06", .subCheckerFunctionProbe),
  ("MUT-I0-07", .subCheckerFunctionProbe),
  ("MUT-I0-08", .diagnosticRecordProbe),
  ("MUT-I0-09", .verdictProjectionProbe),
  ("MUT-I0-10", .verdictProjectionProbe),
  ("MUT-I0-11", .verdictProjectionProbe),
  ("MUT-I0-12", .multiClauseActiveProbe)
]

/-- Single-fault selector for the 11 isolated end-to-end coupling mutants (`E2E-I1-01..11`).
    `none` runs the exact unmutated `checkG56Coupling` pipeline (`T_I1_A7_01`). -/
inductive E2ECouplingFaultId where
  | f01_g6CoreKey
  | f02_g6Epoch
  | f03_retreatTailItems
  | f04_l1BoundInvId
  | f05_l1SrcBranchMap
  | f06_l1DstBranchMem
  | f07_bwdCoverRootsInL1Deps
  | f08_l1DepsGate
  | f09_jointDepsUnionEq
  | f10_ignoreG5NotDischarged
  | f11_emptySuitePromotion
  deriving DecidableEq, Repr

def e2eDirectionalCover (flt : Option E2ECouplingFaultId)
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (L_src L_dst : ExcisedLocus) (cov : G56DirectionalLocusCover) : Bool :=
  (cov.targetDefNodes.map Prod.fst == L_dst) &&
  cov.targetDefNodes.all (fun (B_k, defNid) =>
    checkExactG7SequentBool fuel Γ C defNid D_old specNewId (Γ_old ++ B_k) (.eqZero (.const 0))) &&
  (if flt == some .f05_l1SrcBranchMap then true else (cov.branchCovers.map Prod.fst == L_src)) &&
  cov.branchCovers.all (fun (A_j, B_target, psiNodes) =>
    (if flt == some .f06_l1DstBranchMem then true else L_dst.contains B_target) &&
    checkGuardEntailmentListBool fuel Γ C D_old specNewId (Γ_old ++ A_j) B_target psiNodes)

def e2eSingleL1LossEquiv (flt : Option E2ECouplingFaultId)
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (invId : String) (L5 L6i : ExcisedLocus) (w : G56LossEquivWitness) : Bool :=
  (if flt == some .f04_l1BoundInvId then true else (w.boundInvariantId == invId)) &&
  (w.boundG5Locus == L5) &&
  (w.boundItemLocus == L6i) &&
  e2eDirectionalCover flt fuel Γ C D_old Γ_old specNewId L5 L6i w.l5ImpliesL6 &&
  e2eDirectionalCover flt fuel Γ C D_old Γ_old specNewId L6i L5 w.l6ImpliesL5

def e2eSingleRetreatPair (flt : Option E2ECouplingFaultId)
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus)
    (item : G6ProtectedInvariantSpec) (bind : G56ItemLossBinding) :
    Option G56BindingError :=
  if item.oldNewState.scopePolicy != .retreatWithLossAccounting then
    some (.g5RetreatForbiddenByG6Pol item.invariantId)
  else
    match item.scopeLossRecord? with
    | none => some (.scopePolicyModeMismatch item.invariantId)
    | some lr6 =>
        if (bind.invariantId != item.invariantId) || (bind.itemLocus != lr6.excisedBranches) then
          some (.scopeLossLocusMismatch item.invariantId)
        else
          match bind.mode with
          | .l0SyntacticEq =>
              if lr6.excisedBranches == Φ_shared then none
              else some (.scopeLossLocusMismatch item.invariantId)
          | .l1CertifiedEq w =>
              if e2eSingleL1LossEquiv flt fuel Γ C D_old Γ_old specNewId
                   item.invariantId Φ_shared lr6.excisedBranches w then
                none
              else
                some (.scopeLossLocusMismatch item.invariantId)

def e2eRetreatPairsLoop (flt : Option E2ECouplingFaultId)
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus) :
    List G6ProtectedInvariantSpec → List G56ItemLossBinding →
    List String × Option G56BindingError
  | [], [] => ([], none)
  | item :: restItems, bind :: restBinds =>
      let curErr? := e2eSingleRetreatPair flt fuel Γ C D_old Γ_old specNewId Φ_shared item bind
      let (tailFailedIds, tailErr?) :=
        if flt == some .f03_retreatTailItems then
          ([], none)
        else
          e2eRetreatPairsLoop flt fuel Γ C D_old Γ_old specNewId Φ_shared restItems restBinds
      match curErr? with
      | none     => (tailFailedIds, tailErr?)
      | some err => (item.invariantId :: tailFailedIds, some err)
  | item :: _, [] => ([item.invariantId], some (.scopeLossLocusMismatch item.invariantId))
  | [], bind :: _ => ([bind.invariantId], some (.scopeLossLocusMismatch bind.invariantId))

def e2eCollectScopeLossRoots (flt : Option E2ECouplingFaultId) :
    G56ScopeCompatibility → List String
  | .retreatExactSharedLoss _ itemBinds =>
      canonSortStrs (itemBinds.foldr (fun b acc =>
        match b.mode with
        | .l0SyntacticEq   => acc
        | .l1CertifiedEq w =>
            let wRoots :=
              if flt == some .f07_bwdCoverRootsInL1Deps then
                mutant07_collectLossEquivRootsNoBwdCover w
              else
                collectLossEquivRootIds w
            wRoots ++ acc) [])
  | _ => []

def e2eExtraL1PremisesOutsideD56 (flt : Option E2ECouplingFaultId)
    (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (sc : G56ScopeCompatibility) (D56 : List String) : List String :=
  (multiRootTransitivePrimDeps Γ C (e2eCollectScopeLossRoots flt sc)).filter
    (fun p => !D56.contains p)

def e2eEvalBindingDiag (flt : Option E2ECouplingFaultId) (c56 : G56CouplingCert) :
    G56BindingDiagnosticProduct :=
  let hdrOk := checkG56CouplingHeaderBasicBool c56
  let g5KeyOk := (projectG5CoreKey c56.g5Cert == c56.transitionBinding.toCoreKey)
  let g5CarrOk :=
    (c56.g5Cert.domOld == c56.transitionBinding.domOld) &&
    (c56.g5Cert.guardsOld == c56.transitionBinding.guardsOld) &&
    (c56.g5Cert.domNew == c56.transitionBinding.domNew) &&
    (c56.g5Cert.guardsNew == c56.transitionBinding.guardsNew)
  let g5FullOk :=
    (projectG5Transition ⟨c56.g5Cert, c56.transitionBinding.assignedEvalEpoch⟩ ==
      c56.transitionBinding)
  let g6KeyOk :=
    if flt == some .f01_g6CoreKey then true
    else (projectG6CoreKey c56.g6Suite == c56.transitionBinding.toCoreKey)
  let g6EpochOk :=
    if flt == some .f02_g6Epoch then true
    else (c56.g6Suite.evaluationEpoch == c56.transitionBinding.assignedEvalEpoch)
  let badCarrIds :=
    (c56.g6Suite.items.filter
      (fun it => !checkG6ItemCarrierAlignedBool c56.transitionBinding it)).map (·.invariantId)
  let evOk := checkG56EvidenceManifestBool c56
  let firstErr? : Option G56BindingError :=
    if !hdrOk then some .nonCanonicalCouplingHeader
    else if !g5KeyOk then some .g5TransitionIdMismatch
    else if !g6KeyOk then some .g6TransitionIdMismatch
    else if !g6EpochOk then some .evaluationEpochMismatch
    else if !g5CarrOk then some (.prePostCarrierMismatch "g5_carrier")
    else match badCarrIds with
      | badId :: _ => some (.prePostCarrierMismatch badId)
      | [] =>
          if !g5FullOk then some .reflexRetreatFlagMismatch
          else if !evOk then some .evidenceManifestMismatch
          else none
  { couplingHeaderCanonicalObs := .evaluated hdrOk
    g5TransitionMatchesObs     := .evaluated g5FullOk
    g6CoreKeyMatchesObs        := .evaluated g6KeyOk
    g6EpochMatchesAssignedObs  := .evaluated g6EpochOk
    itemCarrierMismatchIdsObs  := .evaluated badCarrIds
    evidenceRootsMatchObs      := .evaluated evOk
    firstBindingError?         := firstErr? }

def e2eEvalScopeDiag (flt : Option E2ECouplingFaultId)
    (ctx : G56SharedContext) (ctxBlock? : Option DiagnosticBlockingReason)
    (c56 : G56CouplingCert) : G56ScopeDiagnosticProduct :=
  match c56.transitionBinding.reflexKind with
  | .retreat =>
      let flagOk := checkReflexRetreatFlagConsistentBool c56
      let forbidIds := (c56.g6Suite.items.filter (fun it =>
        it.oldNewState.scopePolicy != .retreatWithLossAccounting)).map (·.invariantId)
      let missingLrIds := (c56.g6Suite.items.filter (fun it =>
        (it.oldNewState.scopePolicy == .retreatWithLossAccounting) &&
        it.scopeLossRecord?.isNone)).map (·.invariantId)
      let polBadIds := forbidIds ++ missingLrIds
      match c56.scopeCompatibility with
      | .retreatExactSharedLoss Φ_shared itemBinds =>
          match ctxBlock?, c56.g5Cert.retreatCert? with
          | none, some rt5 =>
              let mapOk := (itemBinds.map (·.invariantId) == c56.g6Suite.items.map (·.invariantId))
              let g5LocOk := (rt5.excisedBranches == Φ_shared)
              let pairRes :=
                e2eRetreatPairsLoop flt ctx.fuelG6 ctx.primEnv ctx.dagCont
                  c56.transitionBinding.domOld c56.transitionBinding.guardsOld
                  c56.transitionBinding.specNewId Φ_shared c56.g6Suite.items itemBinds
              let lossOk := g5LocOk && mapOk && pairRes.2.isNone
              let lossFailedIds :=
                (if g5LocOk then [] else ["g5_shared_locus"]) ++
                (if mapOk then [] else ["item_binds_coverage"]) ++
                pairRes.1
              let err? : Option G56BindingError :=
                if !flagOk then some .reflexRetreatFlagMismatch
                else match forbidIds with
                  | id0 :: _ => some (.g5RetreatForbiddenByG6Pol id0)
                  | [] =>
                      match missingLrIds with
                      | id0 :: _ => some (.scopePolicyModeMismatch id0)
                      | [] =>
                          if !g5LocOk then
                            some (.scopeLossLocusMismatch
                              (match c56.g6Suite.items with | it :: _ => it.invariantId | [] => "g5_shared_locus"))
                          else if !mapOk then
                            some (.scopeLossLocusMismatch
                              (match c56.g6Suite.items with | it :: _ => it.invariantId | [] => "item_binds_coverage"))
                          else
                            pairRes.2
              { reflexRetreatFlagConsistentObs := .evaluated flagOk
                itemPolicyIncompatibleIdsObs   := .evaluated polBadIds
                lossAgreementCheckObs          := .evaluated (lossOk, lossFailedIds)
                firstScopeBindingError?        := err? }
          | _, _ => evalG56ScopeDiag ctx ctxBlock? c56
      | _ => evalG56ScopeDiag ctx ctxBlock? c56
  | _ => evalG56ScopeDiag ctx ctxBlock? c56

def e2eEvalDepsDiagValid (flt : Option E2ECouplingFaultId)
    (ctx : G56SharedContext) (c56 : G56CouplingCert) : G56DependencyDiagnosticProduct :=
  let base := evalG56DepsDiagValid ctx c56
  if c56.transitionBinding.reflexKind == .retreat then
    let d56 := deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite
    let extra := e2eExtraL1PremisesOutsideD56 flt ctx.primEnv ctx.dagCont c56.scopeCompatibility d56
    { base with l1LossEquivDepsSubsetD56Obs := .evaluated (extra.isEmpty, extra) }
  else
    base

def e2eEvalDetailedR1 (flt : Option E2ECouplingFaultId)
    (ctx : G56SharedContext) (c56 : G56CouplingCert) : G56DetailedResultR1 :=
  match checkPrimEnvIntegrityBool ctx.primEnv, checkContainerIntegrityBool ctx.dagCont with
  | true, true =>
      { contextStatus := .contextValid
        bindingDiag   := e2eEvalBindingDiag flt c56
        g5DiagObs     := .evaluated (evalG5StatusValid ctx c56)
        g6DiagObs     := .evaluated (checkG6Suite ctx.fuelG6 ctx.primEnv ctx.dagCont c56.g6Suite)
        depsDiag      := e2eEvalDepsDiagValid flt ctx c56
        scopeDiag     := e2eEvalScopeDiag flt ctx none c56 }
  | false, true =>
      { contextStatus := .malformedPrimEnv
        bindingDiag   := e2eEvalBindingDiag flt c56
        g5DiagObs     := .blocked .malformedSharedPrimEnv
        g6DiagObs     := .blocked .malformedSharedPrimEnv
        depsDiag      := evalG56DepsDiagBlocked .malformedSharedPrimEnv c56
        scopeDiag     := e2eEvalScopeDiag flt ctx (some .malformedSharedPrimEnv) c56 }
  | true, false =>
      { contextStatus := .malformedContainer
        bindingDiag   := e2eEvalBindingDiag flt c56
        g5DiagObs     := .blocked .malformedSharedContainer
        g6DiagObs     := .blocked .malformedSharedContainer
        depsDiag      := evalG56DepsDiagBlocked .malformedSharedContainer c56
        scopeDiag     := e2eEvalScopeDiag flt ctx (some .malformedSharedContainer) c56 }
  | false, false =>
      { contextStatus := .malformedEnvAndContainer
        bindingDiag   := e2eEvalBindingDiag flt c56
        g5DiagObs     := .blocked .malformedEnvAndContainer
        g6DiagObs     := .blocked .malformedEnvAndContainer
        depsDiag      := evalG56DepsDiagBlocked .malformedEnvAndContainer c56
        scopeDiag     := e2eEvalScopeDiag flt ctx (some .malformedEnvAndContainer) c56 }

def e2eProjectCoupledVerdict (flt : Option E2ECouplingFaultId)
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (det : G56DetailedResultR1) :
    G56CoupledVerdict :=
  match det.contextStatus with
  | .malformedPrimEnv         => .invalidEvidence .malformedSharedPrimEnv
  | .malformedEnvAndContainer => .invalidEvidence .malformedSharedPrimEnv
  | .malformedContainer       => .invalidEvidence .malformedSharedContainer
  | .contextValid =>
      if !checkApplicableObservationsConsistentBool ctx c56 det then
        .invalidEvidence .invalidDiagnosticObservation
      else
        match det.bindingDiag.firstBindingError? with
        | some bErr => .invalidBinding bErr
        | none =>
            match det.scopeDiag.firstScopeBindingError? with
            | some sErr => .invalidBinding sErr
            | none =>
                if !checkCore8BindingScopeObsBool det then
                  .invalidBinding .nonCanonicalCouplingHeader
                else
                  match det.depsDiag.jointClaimedMatchesUnionObs,
                        det.depsDiag.g5ClaimedMatchesDerivedObs,
                        det.depsDiag.g6ClaimedMatchesDerivedObs with
                  | .evaluated (jOk, _, _), .evaluated (d5Ok, _, _), .evaluated (d6Ok, _, _) =>
                      if (if flt == some .f09_jointDepsUnionEq then false else !jOk) then
                        .invalidEvidence .jointPrimDepsMismatch
                      else if !d5Ok then
                        .invalidEvidence .g5ClaimedPrimDepsMismatch
                      else if !d6Ok then
                        .invalidEvidence .g6ClaimedPrimDepsMismatch
                      else
                        let l1DepsGate : Option G56EvidenceError :=
                          if c56.transitionBinding.reflexKind == .retreat then
                            match det.depsDiag.l1LossEquivDepsSubsetD56Obs with
                            | .evaluated (true, _)  => none
                            | .evaluated (false, _) =>
                                if flt == some .f08_l1DepsGate then none
                                else some .lossEquivExtraPremiseNotInD56
                            | _                     => some .invalidDiagnosticObservation
                          else
                            none
                        match l1DepsGate with
                        | some eErr => .invalidEvidence eErr
                        | none =>
                            match det.g6DiagObs, det.g5DiagObs with
                            | .evaluated (.invalid r), _ =>
                                .invalidEvidence (.g6SuiteInvalid r)
                            | .evaluated (.violated vIds uIds), .evaluated g5s =>
                                let g5AccBool :=
                                  match g5s with
                                  | .g5Accepted _ _      => true
                                  | .g5NotDischarged _ _ => false
                                .g6Violated vIds uIds g5AccBool
                            | .evaluated (.verified hasLoss), .evaluated (.g5NotDischarged _ _) =>
                                if flt == some .f10_ignoreG5NotDischarged then
                                  .g56Verified hasLoss false
                                else
                                  .g5NotDischarged (.g6AlsoVerified hasLoss)
                            | .evaluated (.unresolved uIds), .evaluated (.g5NotDischarged _ _) =>
                                .g5NotDischarged (.g6AlsoUnresolved uIds)
                            | .evaluated (.emptySuiteAccepted polCid), .evaluated (.g5NotDischarged _ _) =>
                                .g5NotDischarged (.g6AlsoEmpty polCid)
                            | .evaluated (.unresolved uIds), .evaluated (.g5Accepted _ _) =>
                                .g6Unresolved uIds
                            | .evaluated (.emptySuiteAccepted polCid), .evaluated (.g5Accepted _ reqRet) =>
                                if flt == some .f11_emptySuitePromotion then
                                  .g56Verified false reqRet
                                else
                                  .g6Empty polCid
                            | .evaluated (.verified hasLoss), .evaluated (.g5Accepted _ reqRet) =>
                                if c56.transitionBinding.reflexKind == .retreat then
                                  match det.scopeDiag.lossAgreementCheckObs with
                                  | .evaluated (true, _) => .g56Verified hasLoss reqRet
                                  | .evaluated (false, _) =>
                                      .invalidBinding (.scopeLossLocusMismatch "retreat_loss")
                                  | _ => .invalidEvidence .invalidDiagnosticObservation
                                else
                                  .g56Verified hasLoss reqRet
                            | _, _ => .invalidEvidence .invalidDiagnosticObservation
                  | _, _, _ => .invalidEvidence .invalidDiagnosticObservation

/-- Full end-to-end single-fault coupling pipeline (`E2E-I1-01..11` when `flt = some _`,
    and exact `checkG56Coupling` when `flt = none`). -/
def e2eCheckG56Coupling (flt : Option E2ECouplingFaultId)
    (ctx : G56SharedContext) (c56 : G56CouplingCert) : G56CoupledVerdict :=
  e2eProjectCoupledVerdict flt ctx c56 (e2eEvalDetailedR1 flt ctx c56)

def e2eIsCouplingVerifiedBool (flt : Option E2ECouplingFaultId)
    (ctx : G56SharedContext) (c56 : G56CouplingCert) : Bool :=
  isCoupledVerdictVerifiedBool (e2eCheckG56Coupling flt ctx c56)

/-- Full end-to-end single-fault active-standing checker (`E2E-I1-12` when `d6OnlyFault = true`):
    Preserves `isG56CouplingVerifiedBool` AND all item `revokedBool` + `effectiveFromEpoch` +
    `expiresAtEpoch` checks (`F-B3-T19-02`!), mutating ONLY `jointPrimDepIds` to `g6PrimDepIds`. -/
def e2eCheckActiveG56CouplingBool (d6OnlyFault : Bool)
    (L : List StructuralLedgerEvent) (ctx : G56SharedContext) (c56 : G56CouplingCert) : Bool :=
  let ep := (foldStructuralLedger L).epistemic
  let depsToCheck :=
    if d6OnlyFault then c56.claimedJointPrimDeps.g6PrimDepIds
    else c56.claimedJointPrimDeps.jointPrimDepIds
  isG56CouplingVerifiedBool ctx c56 &&
  depsToCheck.all (fun p => !ep.retractedPremises.contains p) &&
  c56.g6Suite.items.all (fun it =>
    !it.versionEpoch.revokedBool &&
    decide (it.versionEpoch.effectiveFromEpoch ≤ ep.currentEpoch) &&
    decide (ep.currentEpoch < it.versionEpoch.expiresAtEpoch))

private theorem e2eDirectionalCover_none
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (L_src L_dst : ExcisedLocus) (cov : G56DirectionalLocusCover) :
    e2eDirectionalCover none fuel Γ C D_old Γ_old specNewId L_src L_dst cov =
      checkDirectionalLocusCoverBool fuel Γ C D_old Γ_old specNewId L_src L_dst cov := by
  rfl

private theorem e2eSingleL1LossEquiv_none
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (invId : String) (L5 L6i : ExcisedLocus) (w : G56LossEquivWitness) :
    e2eSingleL1LossEquiv none fuel Γ C D_old Γ_old specNewId invId L5 L6i w =
      checkSingleL1LossEquivBool fuel Γ C D_old Γ_old specNewId invId L5 L6i w := by
  rfl

private theorem e2eSingleRetreatPair_none
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus)
    (item : G6ProtectedInvariantSpec) (bind : G56ItemLossBinding) :
    e2eSingleRetreatPair none fuel Γ C D_old Γ_old specNewId Φ_shared item bind =
      checkSingleRetreatItemLossPair fuel Γ C D_old Γ_old specNewId Φ_shared item bind := by
  unfold e2eSingleRetreatPair checkSingleRetreatItemLossPair
  rfl

private theorem e2eRetreatPairsLoop_none
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus) :
    ∀ (items : List G6ProtectedInvariantSpec) (binds : List G56ItemLossBinding),
      e2eRetreatPairsLoop none fuel Γ C D_old Γ_old specNewId Φ_shared items binds =
        checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared items binds
  | [], [] => rfl
  | _ :: _, [] => rfl
  | [], _ :: _ => rfl
  | item :: restI, bind :: restB => by
      simp only [e2eRetreatPairsLoop, checkRetreatItemPairsLoop,
                 e2eSingleRetreatPair_none]
      have ih := e2eRetreatPairsLoop_none fuel Γ C D_old Γ_old specNewId Φ_shared restI restB
      change (let curErr? := checkSingleRetreatItemLossPair fuel Γ C D_old Γ_old specNewId Φ_shared item bind
              let tail := e2eRetreatPairsLoop none fuel Γ C D_old Γ_old specNewId Φ_shared restI restB
              match curErr? with
              | none => (tail.1, tail.2)
              | some err => (item.invariantId :: tail.1, some err)) = _
      rw [ih]; rfl

private theorem e2eCollectScopeLossRoots_none (sc : G56ScopeCompatibility) :
    e2eCollectScopeLossRoots none sc = collectScopeCompatLossRootIds sc := by
  cases sc <;> rfl

/-- **`T_I1_A7_01_ZeroFaultPipelineExactIdentity` (`F-B3-T19-02` & `Q-B3-I1-03` Foundation)**:
    When `flt = none` (and `d6OnlyFault = false`), the end-to-end mutant harness is
    extensionally identical on EVERY input `(ctx, c56)` and `(L, ctx, c56)` to the canonical
    `I0` checkers `checkG56Coupling` and `checkActiveG56CouplingBool`! -/
theorem T_I1_A7_01_ZeroFaultPipelineExactIdentity :
    (∀ (ctx : G56SharedContext) (c56 : G56CouplingCert),
       e2eCheckG56Coupling none ctx c56 = checkG56Coupling ctx c56) ∧
    (∀ (L : List StructuralLedgerEvent) (ctx : G56SharedContext) (c56 : G56CouplingCert),
       e2eCheckActiveG56CouplingBool false L ctx c56 = checkActiveG56CouplingBool L ctx c56) := by
  refine ⟨?_, fun _ _ _ => rfl⟩
  intro ctx c56
  have hBind : e2eEvalBindingDiag none c56 = evalG56BindingDiag c56 := rfl
  have hDeps : e2eEvalDepsDiagValid none ctx c56 = evalG56DepsDiagValid ctx c56 := by
    unfold e2eEvalDepsDiagValid evalG56DepsDiagValid e2eExtraL1PremisesOutsideD56
           computeExtraL1PremisesOutsideD56 deriveScopeCompatL1PrimDeps
    rw [e2eCollectScopeLossRoots_none]
    cases hRk : (c56.transitionBinding.reflexKind == .retreat) <;> rfl
  have hScope : ∀ blk?, e2eEvalScopeDiag none ctx blk? c56 = evalG56ScopeDiag ctx blk? c56 := by
    intro blk?
    unfold e2eEvalScopeDiag evalG56ScopeDiag
    cases c56.transitionBinding.reflexKind with
    | repair => rfl
    | refinement => rfl
    | retreat =>
        cases c56.scopeCompatibility with
        | retreatExactSharedLoss Φ itemBinds =>
            cases blk? with
            | some _ => rfl
            | none =>
                cases c56.g5Cert.retreatCert? with
                | none => rfl
                | some rt5 =>
                    simp only [e2eRetreatPairsLoop_none]; rfl
        | _ => rfl
  have hDet : e2eEvalDetailedR1 none ctx c56 = evalG56DetailedR1 ctx c56 := by
    unfold e2eEvalDetailedR1 evalG56DetailedR1
    rw [hBind, hDeps, hScope none, hScope (some .malformedSharedPrimEnv),
        hScope (some .malformedSharedContainer), hScope (some .malformedEnvAndContainer)]
    rfl
  unfold e2eCheckG56Coupling checkG56Coupling
  rw [hDet]
  rfl

structure E2ESingleFaultEvalRecord where
  e2eMutantId             : String
  faultDescription        : String
  positiveCaseId          : String
  adversarialCaseId       : String
  mutantAcceptsPositive   : Bool
  canonicalAcceptsPositive : Bool
  mutantFalseAcceptsAdv   : Bool
  canonicalRejectsAdv     : Bool
  killedEndToEnd          : Bool
  deriving DecidableEq, Repr

def mkE2ECouplingRecord (mid desc posId advId : String) (flt : E2ECouplingFaultId)
    (posCtx : G56SharedContext) (posCert : G56CouplingCert)
    (advCtx : G56SharedContext) (advCert : G56CouplingCert) : E2ESingleFaultEvalRecord :=
  let mPos := e2eIsCouplingVerifiedBool (some flt) posCtx posCert
  let cPos := isG56CouplingVerifiedBool posCtx posCert
  let mAdv := e2eIsCouplingVerifiedBool (some flt) advCtx advCert
  let cAdv := isG56CouplingVerifiedBool advCtx advCert
  { e2eMutantId              := mid
    faultDescription         := desc
    positiveCaseId           := posId
    adversarialCaseId        := advId
    mutantAcceptsPositive    := mPos
    canonicalAcceptsPositive := cPos
    mutantFalseAcceptsAdv    := mAdv
    canonicalRejectsAdv      := !cAdv
    killedEndToEnd           := mPos && cPos && mAdv && !cAdv }

def evaluateAll12EndToEndSingleFaultMutants : List E2ESingleFaultEvalRecord :=
  let m12Pos := e2eCheckActiveG56CouplingBool true ledger_ce14_clean ctx_posG56_09 cert_posG56_09
  let c12Pos := checkActiveG56CouplingBool ledger_ce14_clean ctx_posG56_09 cert_posG56_09
  let m12Adv := e2eCheckActiveG56CouplingBool true ledger_ce14_retG5 ctx_posG56_09 cert_posG56_09
  let c12Adv := checkActiveG56CouplingBool ledger_ce14_retG5 ctx_posG56_09 cert_posG56_09
  [ mkE2ECouplingRecord "E2E-I1-01" "Single-clause bypass of g6KeyOk in full coupling pipeline"
      "POS-G56-01" "CE-G56-02" .f01_g6CoreKey ctx_posG56_01 cert_posG56_01 ctx_posG56_01 cert_ceG56_02
  , mkE2ECouplingRecord "E2E-I1-02" "Single-clause bypass of g6EpochOk in full coupling pipeline"
      "POS-G56-01" "CE-G56-03B" .f02_g6Epoch ctx_posG56_01 cert_posG56_01 ctx_posG56_01 cert_ceG56_03B
  , mkE2ECouplingRecord "E2E-I1-03" "Single-clause stop-after-head in checkRetreatItemPairsLoop"
      "POS-I0-02" "CE-I0-02" .f03_retreatTailItems ctx_r1_07 cert_posI0_02 ctx_r1_07 cert_ceI0_02
  , mkE2ECouplingRecord "E2E-I1-04" "Single-clause bypass of w.boundInvariantId == invId"
      "POS-I0-02" "CE-I0-03" .f04_l1BoundInvId ctx_r1_07 cert_posI0_02 ctx_r1_07 cert_ceI0_03
  , mkE2ECouplingRecord "E2E-I1-05" "Single-clause bypass of source-branch map equality in L1 cover"
      "POS-I0-02" "CE-I0-04" .f05_l1SrcBranchMap ctx_r1_07 cert_posI0_02 ctx_r1_07 cert_ceI0_04
  , mkE2ECouplingRecord "E2E-I1-06" "Single-clause bypass of target-branch membership in L1 cover"
      "POS-I0-02" "CE-I0-05" .f06_l1DstBranchMem ctx_r1_07 cert_posI0_02 ctx_r1_07 cert_ceI0_05
  , mkE2ECouplingRecord "E2E-I1-07" "Single-clause omission of backward cover roots in L1 D7 closure"
      "POS-R1-04" "CE-I0-06" .f07_bwdCoverRootsInL1Deps ctx_r1_07 cert_posR1_04 ctx_ceI0_06 cert_ceI0_06
  , mkE2ECouplingRecord "E2E-I1-08" "Single-clause bypass of l1DepsGate (D7 <= D56) in verdict projection"
      "POS-R1-04" "CE-R1-08" .f08_l1DepsGate ctx_r1_07 cert_posR1_04 ctx_ceR1_08 cert_ceR1_08
  , mkE2ECouplingRecord "E2E-I1-09" "Single-clause bypass of jointPrimDeps == D56 (keeping D5 & D6 checks)"
      "POS-G56-09" "CE-G56-12" .f09_jointDepsUnionEq ctx_posG56_09 cert_posG56_09 ctx_posG56_09 cert_ceG56_12
  , mkE2ECouplingRecord "E2E-I1-10" "Single-clause acceptance of G6 verified when G5 is not discharged"
      "POS-G56-01" "CE-G56-09" .f10_ignoreG5NotDischarged ctx_posG56_01 cert_posG56_01 ctx_posG56_01 cert_ceG56_09
  , mkE2ECouplingRecord "E2E-I1-11" "Single-clause promotion of G6 emptySuiteAccepted to g56Verified"
      "POS-G56-01" "CE-G56-08B" .f11_emptySuitePromotion ctx_posG56_01 cert_posG56_01 ctx_posG56_01 cert_ceG56_08B
  , { e2eMutantId              := "E2E-I1-12"
      faultDescription         := "Single-clause D56 -> D6 substitution in checkActiveG56CouplingBool (epoch checks intact)"
      positiveCaseId           := "POS-I0-05-CLEAN"
      adversarialCaseId        := "CE-G56-14B"
      mutantAcceptsPositive    := m12Pos
      canonicalAcceptsPositive := c12Pos
      mutantFalseAcceptsAdv    := m12Adv
      canonicalRejectsAdv      := !c12Adv
      killedEndToEnd           := m12Pos && c12Pos && m12Adv && !c12Adv }
  ]

/-- **`T_I1_A7_02_All12EndToEndSingleFaultMutantsPreservePosAndKilled` (`I1-A7`)**:
    Every one of the 12 isolated end-to-end single-fault mutants agrees with the canonical
    pipeline on its positive witness AND is killed (`mutant = true ≠ false = canonical`) on its
    dedicated adversarial witness! -/
theorem T_I1_A7_02_All12EndToEndSingleFaultMutantsPreservePosAndKilled :
    evaluateAll12EndToEndSingleFaultMutants.length = 12 ∧
    evaluateAll12EndToEndSingleFaultMutants.all (fun r => r.killedEndToEnd) = true := by
  exact ⟨rfl, by decide⟩

/-- **`T_I1_A7_03_EQ01_CommutedUnionIsProvablyEquivalentMutant` (`Q-B3-I1-03` Equivalent Mutant)**:
    Commuting `D5 ++ D6` to `D6 ++ D5` inside canonical `canonSortStrs` yields an extensionally
    identical joint dependency closure on ALL inputs `(Γ, C, c5, s6)`, so no input can distinguish
    them (explicit separation of provably equivalent mutants from killable mutants). -/
theorem T_I1_A7_03_EQ01_CommutedUnionIsProvablyEquivalentMutant
    (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite) :
    canonSortStrs (deriveG6PrimDeps Γ C s6 ++ deriveG5PrimDeps Γ C c5) =
      deriveG56JointPrimDeps Γ C c5 s6 := by
  unfold deriveG56JointPrimDeps
  rw [canonSortStrs_eq_iff_mem]
  intro x
  simp only [List.mem_append, or_comm]

/-! ## Section 4 (`I1-A6` & `F-B3-T19-03`): Live 71-Case Execution & Qualification Observation -/

structure LiveI1CaseObservation where
  caseId                  : String
  suiteGroup              : String
  actualVerdict           : String
  liveQualifyOptionStatus : String -- `"some"` | `"none"` | `"not_cert_case"`
  deriving DecidableEq, Repr

def liveQualStatusOf (ctx : G56SharedContext) (c56 : G56CouplingCert) : String :=
  if (qualifyG56Coupled? ctx c56).isSome then "some" else "none"

/-- Map each of the 71 cases in `evaluateAll71SoundnessCases` to its live-computed verdict AND
    dynamically executed `qualifyG56Coupled?` status (`0` hardcoded qualification booleans!). -/
def liveQualifyLookup : String → String
  | "POS-G56-01"  => liveQualStatusOf ctx_posG56_01 cert_posG56_01
  | "POS-G56-02A" => liveQualStatusOf ctx_posG56_02A cert_posG56_02A
  | "POS-G56-02B" => liveQualStatusOf ctx_posG56_02B cert_posG56_02B
  | "POS-G56-03"  => liveQualStatusOf ctx_posG56_03 cert_posG56_03
  | "POS-G56-04"  => liveQualStatusOf ctx_posG56_04 cert_posG56_04
  | "POS-G56-05"  => liveQualStatusOf ctx_posG56_05 cert_posG56_05
  | "POS-G56-06"  => liveQualStatusOf ctx_posG56_06 cert_posG56_06
  | "POS-G56-07"  => liveQualStatusOf ctx_posG56_07 cert_posG56_07
  | "POS-G56-08"  => liveQualStatusOf ctx_posG56_08 cert_posG56_08
  | "POS-G56-09"  => liveQualStatusOf ctx_posG56_09 cert_posG56_09
  | "POS-G56-10"  => liveQualStatusOf ctx_posG56_10 cert_posG56_10
  | "CE-G56-01"   => liveQualStatusOf ctx_ceG56_01 cert_ceG56_01
  | "CE-G56-02"   => liveQualStatusOf ctx_posG56_01 cert_ceG56_02
  | "CE-G56-03A"  => liveQualStatusOf ctx_posG56_01 cert_ceG56_03A
  | "CE-G56-03B"  => liveQualStatusOf ctx_posG56_01 cert_ceG56_03B
  | "CE-G56-04B"  => liveQualStatusOf ctx_ceG56_04 cert_ceG56_04
  | "CE-G56-05B"  => liveQualStatusOf ctx_ceG56_05B cert_ceG56_05B
  | "CE-G56-06"   => liveQualStatusOf ctx_ceG56_06 cert_ceG56_06
  | "CE-G56-07"   => liveQualStatusOf ctx_posG56_01 cert_ceG56_07
  | "CE-G56-08A"  => liveQualStatusOf ctx_posG56_01 cert_ceG56_08A
  | "CE-G56-08B"  => liveQualStatusOf ctx_posG56_01 cert_ceG56_08B
  | "CE-G56-09"   => liveQualStatusOf ctx_posG56_01 cert_ceG56_09
  | "CE-G56-10A"  => liveQualStatusOf ctx_posG56_03 cert_ceG56_10A
  | "CE-G56-10B"  => liveQualStatusOf ctx_posG56_03 cert_ceG56_10B
  | "CE-G56-11"   => liveQualStatusOf ctx_posG56_03 cert_ceG56_11
  | "CE-G56-12"   => liveQualStatusOf ctx_posG56_09 cert_ceG56_12
  | "CE-G56-13"   => liveQualStatusOf ctx_posG56_09 cert_ceG56_13
  | "CE-G56-17A"  => liveQualStatusOf ctx_ceG56_17A cert_posG56_09
  | "CE-G56-17B"  => liveQualStatusOf ctx_ceG56_17B cert_posG56_09
  | "CE-G56-17C"  => liveQualStatusOf ctx_ceG56_17C cert_posG56_09
  | "CE-G56-18A"  => liveQualStatusOf ctx_ceG56_18A cert_posG56_04
  | "CE-G56-18B"  => liveQualStatusOf ctx_posG56_04 cert_ceG56_18B
  | "POS-R1-01"   => liveQualStatusOf ctx_posG56_01 cert_posG56_01
  | "POS-R1-02"   => liveQualStatusOf ctx_posG56_09 cert_posG56_09
  | "POS-R1-03"   => liveQualStatusOf ctx_posG56_03 cert_posG56_03
  | "POS-R1-04"   => liveQualStatusOf ctx_r1_07 cert_posR1_04
  | "POS-R1-05"   => liveQualStatusOf ctx_posG56_01 cert_posG56_01
  | "POS-R1-06"   => liveQualStatusOf ctx_posG56_05 cert_posG56_05
  | "CE-R1-01"    => liveQualStatusOf ctx_posG56_01 cert_ceR1_01_mismatch
  | "CE-R1-05"    => liveQualStatusOf ctx_posG56_09 cert_ceR1_05
  | "CE-R1-06"    => liveQualStatusOf ctx_ceG56_18A cert_posG56_04
  | "CE-R1-07A"   => liveQualStatusOf ctx_r1_07 cert_ceR1_07A
  | "CE-R1-07B"   => liveQualStatusOf ctx_r1_07 cert_posR1_04
  | "CE-R1-08"    => liveQualStatusOf ctx_ceR1_08 cert_ceR1_08
  | "POS-I0-01"   => liveQualStatusOf ctx_posG56_01 cert_posG56_01
  | "POS-I0-02"   => liveQualStatusOf ctx_r1_07 cert_posI0_02
  | "POS-I0-03"   => liveQualStatusOf ctx_posI0_03 cert_posI0_03
  | "POS-I0-04"   => liveQualStatusOf ctx_posG56_01 cert_posG56_01
  | "POS-I0-05"   => liveQualStatusOf ctx_posG56_09 cert_posG56_09
  | "CE-I0-02"    => liveQualStatusOf ctx_r1_07 cert_ceI0_02
  | "CE-I0-03"    => liveQualStatusOf ctx_r1_07 cert_ceI0_03
  | "CE-I0-04"    => liveQualStatusOf ctx_r1_07 cert_ceI0_04
  | "CE-I0-05"    => liveQualStatusOf ctx_r1_07 cert_ceI0_05
  | "CE-I0-06"    => liveQualStatusOf ctx_ceI0_06 cert_ceI0_06
  | "CE-I0-07"    => liveQualStatusOf ctx_ceR1_08 cert_ceR1_08
  | _             => "not_cert_case"

def evaluateAll71CasesLiveI1 : List LiveI1CaseObservation :=
  evaluateAll71SoundnessCases.map (fun c =>
    { caseId                  := c.caseId
      suiteGroup              := c.suiteGroup
      actualVerdict           := c.actualVerdict
      liveQualifyOptionStatus := liveQualifyLookup c.caseId })

theorem T_I1_A6_All71LiveObservationsComplete :
    evaluateAll71CasesLiveI1.length = 71 ∧
    (evaluateAll71CasesLiveI1.filter (fun x => x.liveQualifyOptionStatus != "not_cert_case")).length = 55 ∧
    (evaluateAll71CasesLiveI1.filter (fun x => x.liveQualifyOptionStatus == "not_cert_case")).length = 16 := by
  exact ⟨rfl, by decide, by decide⟩

end ExternalSpecPinB3I1
