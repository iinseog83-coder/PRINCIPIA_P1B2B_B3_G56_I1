# PRINCIPIA Ω-CELL-C1-P1B2B-B3 G56 — Detached External Verification Kit (`KitB3I1`)

## 1. Purpose & Epistemic Scope
`KitB3I1` (`research/principia_omega_cell_c1_p1b2b_b3_g56_i1_verify_kit_r0/`) is the standalone, zero-mutation external verification kit for **`PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_I1_INDEPENDENT_EXTERNAL_REPLAY_ACT`** (Method A).

- **Zero Source Mutation (`Q-B3-I1-02`)**: Neither `run_verify_b3_i1.py` nor `run_calibration_b3_i1.py` ever writes inside `--source-root`. Every clean replay copies ONLY the `62` active pure source files (`50` frozen files across all `6` ancestor packages `P1A0` .. `P1B2B-B2` + `12` `B3 I0` files, with unmodified `lakefile.toml` relative paths) plus `KitB3I1` into a brand-new, zero-cache OS temporary directory.
- **Double Clean Replay & Pre-Declared `CanSem` Identity (`I1-A4`, Article 5)**: `R1` and `R2` build all `7` Lake packages + `KitB3I1` from scratch in completely separate temporary directories sharing zero `.olean` or `.lake` artifacts, and compare `CanSem(R1) == CanSem(R2)` using `i1_environment_and_cansem_spec.json` (`H_E`).
- **Five-Tuple Evidence Lineage**: Binds $\mathcal{E}_{\mathrm{I1}} = (H_S, H_E, H_O, H_W, H_R)$ in `i1_local_double_clean_replay_receipt.json` (and `external_b3_g56_i1_replay_receipt.json` upon future authorized GitHub Actions execution).

## 2. Kit File Inventory (`14` Files)
1. `lean-toolchain` — Pins `leanprover/lean4:v4.33.1`.
2. `lakefile.toml` — Detached Lake package requiring unmodified sibling `../principia_omega_cell_c1_..._lean4` packages.
3. `lake-manifest.json` — Deterministic Lake `1.2.0` path manifest.
4. `manifest_workspace_186_baseline.json` — Full baseline of `186` tracked workspace assets (`N_canonical = 105`) + `3` submission ZIPs.
5. `manifest_active_replay_62_sources.json` — Self-contained `62`-file active build closure (`H_S`).
6. `i1_environment_and_cansem_spec.json` — Pinned environment & pre-declared `CanSem` comparison spec (`H_E`).
7. `i1_precommitted_oracle_71.json` — Pre-committed `I1` `71`-case oracle (`H_O`, `Q-B3-I1-01`).
8. `ExternalSpecPinB3I1.lean` — `41/41` `isDefEq` theorem pins (`I1-A5`), provenance-bound consumer & spoof contrast proofs (`I1-A9`, `F-B3-T19-01`), `12` isolated end-to-end single-fault mutants + zero-fault identity + equivalent mutant theorem (`I1-A7`, `F-B3-T19-02`, `Q-B3-I1-03`), and `71`-case dynamic `qualifyG56Coupled?` table (`I1-A6`, `F-B3-T19-03`).
9. `ExternalObsAndTcbAuditB3I1.lean` — Whitebox kernel signature/axiom auditor, live `71`-case observer, exhaustive declaration classifier (`|U| = 0`, `I1-A8`, `F-B3-T19-04`, `Q-B3-I1-04`), and barrier-stopped transitive lookup auditor.
10. `audit_b3_i1_core.py` — Cross-platform Double Clean Replay & `CanSem` comparison primitives.
11. `run_calibration_b3_i1.py` — `6/6` isolated fault-injection calibration suite (`CAL-B3-I1-01..06`).
12. `run_verify_b3_i1.py` — CLI entrypoint supporting `LOCAL_DOUBLE_CLEAN_REPLAY` and `EXTERNAL_CI_REPRODUCED`.
13. `principia_p1b2b_b3_g56_i1_external_replay_r0.yml` — Hardened GitHub Actions `ubuntu-latest` workflow (`H_W`, prepared for T20 review; NOT uploaded or executed under Method A).
14. `README_VERIFY_KIT_B3_I1.md` — This guide.
