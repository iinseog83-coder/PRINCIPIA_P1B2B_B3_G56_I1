"""
PRINCIPIA Ω-CELL-C1-P1B2B-B3 G56 — I1 Independent External Replay Act (`KitB3I1`)
Module: audit_b3_i1_core.py

Detached, zero-mutation Double Clean Replay & 5-tuple lineage (`H_S, H_E, H_O, H_W, H_R`) engine.
Never writes inside `source_root` or `kit_dir`; every replay runs in its own fresh, zero-cache
OS temporary directory with all 6 frozen ancestors + B3 I0 + VerifyKit compiled from scratch.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import os
import platform
import shutil
import subprocess
import tempfile
import time
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple


KIT_LEAN_FILES = [
    "lean-toolchain",
    "lakefile.toml",
    "lake-manifest.json",
    "ExternalSpecPinB3I1.lean",
    "ExternalObsAndTcbAuditB3I1.lean",
]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest().upper()


def sha256_file(path: Path) -> Tuple[int, str]:
    raw = path.read_bytes()
    return len(raw), sha256_bytes(raw)


def canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def resolve_source_file(source_root: Path, row: Dict[str, Any]) -> Path:
    """
    Supports both:
      (a) Full workspace root (`<root>/research/principia_omega_cell_c1_...`), and
      (b) Unpacked self-contained bundle root (`<root>/self_contained_sources/principia_omega_cell_c1_...`
          or `<root>/principia_omega_cell_c1_...`).
    """
    ws_cand = source_root / Path(*row["workspaceRelPath"].split("/"))
    if ws_cand.is_file():
        return ws_cand
    sc_cand = source_root / "self_contained_sources" / Path(*row["mirrorRelPath"].split("/"))
    if sc_cand.is_file():
        return sc_cand
    direct_cand = source_root / Path(*row["mirrorRelPath"].split("/"))
    return direct_cand


def verify_active_62_sources(source_root: Path, m62: Dict[str, Any]) -> Tuple[bool, List[Dict[str, Any]]]:
    mismatches: List[Dict[str, Any]] = []
    for row in m62["sources"]:
        fp = resolve_source_file(source_root, row)
        if not fp.is_file():
            mismatches.append({"mirrorRelPath": row["mirrorRelPath"], "error": "MISSING_FILE"})
            continue
        sz, dig = sha256_file(fp)
        if sz != row["byteLength"] or dig != row["sha256"]:
            mismatches.append(
                {
                    "mirrorRelPath": row["mirrorRelPath"],
                    "expectedBytes": row["byteLength"],
                    "actualBytes": sz,
                    "expectedSha256": row["sha256"],
                    "actualSha256": dig,
                }
            )
    return len(mismatches) == 0, mismatches


def build_sanitized_lean_env() -> Tuple[Optional[Dict[str, str]], Dict[str, Any]]:
    env = os.environ.copy()
    for var in ["LEAN_PATH", "LEAN_SRC_PATH", "LAKE_HOME", "LAKE_CACHE_DIR", "LAKE_OVERRIDE"]:
        env.pop(var, None)

    home = env.get("USERPROFILE") or env.get("HOME") or ""
    elan_bin = Path(home) / ".elan" / "bin"
    if elan_bin.is_dir():
        env["PATH"] = str(elan_bin) + os.pathsep + env.get("PATH", "")
    env["ELAN_TOOLCHAIN"] = "leanprover/lean4:v4.33.1"

    lean_exe = shutil.which("lean", path=env.get("PATH"))
    lake_exe = shutil.which("lake", path=env.get("PATH"))
    elan_exe = shutil.which("elan", path=env.get("PATH"))
    if not lean_exe or not lake_exe:
        return None, {"error": "LEAN_OR_LAKE_NOT_FOUND_ON_PATH"}

    ver_proc = subprocess.run(
        [lean_exe, "--version"],
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    ver_out = (ver_proc.stdout or "").strip()
    if ver_proc.returncode != 0 or "4.33.1" not in ver_out:
        return None, {"error": "TOOLCHAIN_VERSION_MISMATCH", "versionOutput": ver_out}

    lake_proc = subprocess.run(
        [lake_exe, "--version"],
        env=env,
        capture_output=True,
        text=True,
        encoding="utf-8",
    )
    lake_ver_out = (lake_proc.stdout or "").strip()

    _, shim_lean_sha = sha256_file(Path(lean_exe))
    resolved_lean_path = lean_exe
    resolved_lean_sha = shim_lean_sha
    resolved_lake_path = lake_exe
    _, resolved_lake_sha = sha256_file(Path(lake_exe))

    if elan_exe:
        for tool_name in ("lean", "lake"):
            w = subprocess.run(
                [elan_exe, "which", tool_name],
                env=env,
                capture_output=True,
                text=True,
                encoding="utf-8",
            )
            if w.returncode == 0 and w.stdout.strip():
                rp = Path(w.stdout.strip())
                if rp.is_file():
                    _, rsha = sha256_file(rp)
                    if tool_name == "lean":
                        resolved_lean_path = str(rp)
                        resolved_lean_sha = rsha
                    else:
                        resolved_lake_path = str(rp)
                        resolved_lake_sha = rsha

    meta = {
        "hostPlatformString": platform.platform(),
        "leanVersionOutput": ver_out,
        "lakeVersionOutput": lake_ver_out,
        "elanShimLeanSha256": shim_lean_sha,
        "resolvedLeanBinaryPath": resolved_lean_path,
        "resolvedLeanBinarySha256": resolved_lean_sha,
        "resolvedLakeBinaryPath": resolved_lake_path,
        "resolvedLakeBinarySha256": resolved_lake_sha,
    }
    return env, meta


def extract_canonical_semantic_projection(
    obs_json: Dict[str, Any],
    h_s: str,
    pre_oracle_sha: str,
    post_oracle_sha: str,
) -> Dict[str, Any]:
    """
    Deterministic `CanSem(R)` projection fixed BEFORE execution in `i1_environment_and_cansem_spec.json`.
    Excludes only non-semantic timing/path/host metadata; retains all 41 kernel signatures + axiom
    closures, all 71 live verdicts & dynamic qualification observations, both 12-mutant suites,
    exhaustive declaration classification counts (`|U| = 0`), anti-circularity & barrier confinement,
    and provenance-bound consumer checks.
    """
    return {
        "leanVersionExact": obs_json["leanVersion"],
        "sourceManifestSha256_H_S": h_s,
        "oraclePreRunSha256_H_O": pre_oracle_sha,
        "oraclePostRunSha256MatchesPreRun": (pre_oracle_sha == post_oracle_sha),
        "headline41TypePinsVerified": (
            obs_json["gate_I1_A5_TheoremSignatureAndAxiomAudit"]["pinFailures"] == []
        ),
        "headline41AxiomClosures": obs_json["gate_I1_A5_TheoremSignatureAndAxiomAudit"][
            "headline41PinsAndSignatures"
        ],
        "i1Kit6TheoremAxiomClosures": obs_json["gate_I1_A5_TheoremSignatureAndAxiomAudit"][
            "i1Kit6Theorems"
        ],
        "live71CaseObservations": obs_json["gate_I1_A6_Live71OracleAndQualificationObservation"][
            "cases"
        ],
        "registered12MutantObservations": obs_json["gate_I1_A7_SeparatedMutationTesting"][
            "registered12Probes"
        ],
        "endToEnd12SingleFaultMutantObservations": obs_json["gate_I1_A7_SeparatedMutationTesting"][
            "endToEnd12SingleFaultMutants"
        ],
        "exhaustiveDeclarationClassificationCounts": {
            "totalB3OwnedConstants": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["totalB3OwnedConstants"],
            "bucketS": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["bucketS_DeclarativeSemanticsCount"],
            "bucketS_Names": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["bucketS_DeclarativeSemanticsNames"],
            "bucketK": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["bucketK_ExecutableEvaluatorsAndProjectionsCount"],
            "bucketK_PureCheckersOnly": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["bucketK_PureCheckersOnlyCount"],
            "bucketD": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["bucketD_DatatypesAndCtorsCount"],
            "bucketT": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["bucketT_TheoremsCount"],
            "bucketF": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["bucketF_SuiteFixturesAndMutantsCount"],
            "bucketA": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["bucketA_CompilerAndPrivateAuxCount"],
            "ancestorAutoCollectedCheckerCount": obs_json[
                "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
            ]["ancestorAutoCollectedCheckerCount"],
        },
        "unclassifiedRelevantDeclarationCount": obs_json[
            "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
        ]["unclassifiedRelevantDeclarationCount"],
        "fullClassifiedSemanticCheckerDisjoint": (
            obs_json["gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"][
                "classifiedSemanticCheckerCircularHits"
            ]
            == []
        ),
        "transitiveLookupBypassHits": obs_json[
            "gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit"
        ]["transitiveLookupBypassHits"],
        "provenanceBoundConsumerChecks": obs_json[
            "gate_I1_A9_ProvenanceBoundConsumerVerification"
        ],
    }


def run_single_isolated_clean_replay(
    replay_id: str,
    source_root: Path,
    kit_dir: Path,
    m62: Dict[str, Any],
    h_s: str,
    oracle_path: Path,
    lean_env: Dict[str, str],
    log_out_path: Optional[Path] = None,
    obs_out_path: Optional[Path] = None,
    keep_compiled_observer_copy: Optional[Path] = None,
) -> Tuple[bool, Dict[str, Any], Optional[Dict[str, Any]]]:
    """
    Executes one completely isolated zero-cache clean replay in a fresh temporary directory.
    """
    lake_exe = shutil.which("lake", path=lean_env.get("PATH"))
    assert lake_exe is not None

    _, pre_oracle_sha = sha256_file(oracle_path)
    ts_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()

    with tempfile.TemporaryDirectory(prefix=f"principia_b3_i1_{replay_id}_") as tmp_str:
        tmp_root = Path(tmp_str)

        # 1. Stage ONLY the 62 pure source files (0 `.lake` caches!)
        for row in m62["sources"]:
            src_fp = resolve_source_file(source_root, row)
            dst_fp = tmp_root / Path(*row["mirrorRelPath"].split("/"))
            dst_fp.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src_fp, dst_fp)
            # Confirm zero `.lake` directories exist
            assert not (tmp_root / row["packageDir"] / ".lake").exists()

        # 2. Stage detached VerifyKit Lean package files
        tmp_kit = tmp_root / "i1_verify_kit_r0"
        tmp_kit.mkdir(parents=True, exist_ok=True)
        for kfn in KIT_LEAN_FILES:
            shutil.copy2(kit_dir / kfn, tmp_kit / kfn)

        # 3. Clean zero-cache build of ALL 6 ancestors + B3 I0 (`AuditB3G56Axioms`, `RunB3G56SoundnessSuite`) + VerifyKit
        t0 = time.time()
        proc_b3 = subprocess.run(
            [lake_exe, "build"],
            cwd=str(tmp_root / "principia_omega_cell_c1_p1b2b_b3_g56_lean4"),
            env=lean_env,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        proc_kit = subprocess.run(
            [lake_exe, "build"],
            cwd=str(tmp_kit),
            env=lean_env,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        build_secs = round(time.time() - t0, 3)

        combined_log = (
            f"# PRINCIPIA B3 G56 I1 — Isolated Zero-Cache Clean Replay Log ({replay_id})\n"
            f"# Timestamp (UTC): {ts_utc}\n"
            f"# Isolated Temp Root: {tmp_root}\n"
            f"# Step A (`b3_g56_lean4` + 6 Ancestors `lake build`) Exit Code: {proc_b3.returncode}\n"
            f"{proc_b3.stdout}\n"
            + (f"--- B3 STDERR ---\n{proc_b3.stderr}\n" if proc_b3.stderr else "")
            + f"\n# Step B (`i1_verify_kit_r0` `lake build`) Exit Code: {proc_kit.returncode}\n"
            f"{proc_kit.stdout}\n"
            + (f"--- KIT STDERR ---\n{proc_kit.stderr}\n" if proc_kit.stderr else "")
            + f"# Total Build Seconds: {build_secs}\n"
        )
        if log_out_path is not None:
            log_out_path.write_text(combined_log.replace("\r\n", "\n"), encoding="utf-8", newline="\n")
        log_sha = sha256_bytes(combined_log.replace("\r\n", "\n").encode("utf-8"))

        if proc_b3.returncode != 0 or proc_kit.returncode != 0:
            return (
                False,
                {
                    "replayId": replay_id,
                    "error": "CLEAN_BUILD_FAILED",
                    "b3ExitCode": proc_b3.returncode,
                    "kitExitCode": proc_kit.returncode,
                    "rawBuildLogSha256": log_sha,
                },
                None,
            )

        # 4. Execute `ExternalObsAndTcbAuditB3I1` against `oracle_path`
        tmp_obs_json = tmp_kit / f"obs_{replay_id}.json"
        t1 = time.time()
        proc_obs = subprocess.run(
            [
                lake_exe,
                "exe",
                "ExternalObsAndTcbAuditB3I1",
                "--oracle-json",
                str(oracle_path),
                "--out-json",
                str(tmp_obs_json),
            ],
            cwd=str(tmp_kit),
            env=lean_env,
            capture_output=True,
            text=True,
            encoding="utf-8",
        )
        obs_secs = round(time.time() - t1, 3)

        # Re-hash oracle immediately after execution (`F-B3-T19-03`)
        _, post_oracle_sha = sha256_file(oracle_path)

        # Also verify staged 62 source files in `tmp_root` remained byte-identical after build
        staged_unchanged = True
        for row in m62["sources"]:
            st_fp = tmp_root / Path(*row["mirrorRelPath"].split("/"))
            sz, dig = sha256_file(st_fp)
            if sz != row["byteLength"] or dig != row["sha256"]:
                staged_unchanged = False
                break

        if proc_obs.returncode != 0 or not tmp_obs_json.is_file():
            return (
                False,
                {
                    "replayId": replay_id,
                    "error": "OBSERVER_AUDIT_FAILED",
                    "observerExitCode": proc_obs.returncode,
                    "observerStderr": proc_obs.stderr,
                    "preRunOracleSha256": pre_oracle_sha,
                    "postRunOracleSha256": post_oracle_sha,
                },
                None,
            )

        obs_text = tmp_obs_json.read_text(encoding="utf-8").replace("\r\n", "\n")
        if obs_out_path is not None:
            obs_out_path.write_text(obs_text, encoding="utf-8", newline="\n")
        obs_data = json.loads(obs_text)

        # Optionally run a quick fast negative oracle probe right inside `tmp_kit` while compiled binary is warm
        # if requested by caller (`keep_compiled_observer_copy` stores a tiny calibration probe result JSON!)
        if keep_compiled_observer_copy is not None:
            bad_orc = json.loads(oracle_path.read_text(encoding="utf-8"))
            bad_orc["cases"][0]["expectedLiveQualifyOption"] = "none"
            bad_orc_path = tmp_kit / "cal_mutated_oracle.json"
            bad_out_path = tmp_kit / "cal_mutated_out.json"
            bad_orc_path.write_text(json.dumps(bad_orc), encoding="utf-8")
            proc_bad = subprocess.run(
                [
                    lake_exe,
                    "exe",
                    "ExternalObsAndTcbAuditB3I1",
                    "--oracle-json",
                    str(bad_orc_path),
                    "--out-json",
                    str(bad_out_path),
                ],
                cwd=str(tmp_kit),
                env=lean_env,
                capture_output=True,
                text=True,
                encoding="utf-8",
            )
            keep_compiled_observer_copy.write_text(
                json.dumps(
                    {
                        "mutatedOracleRejectedByCompiledLeanObserver": (proc_bad.returncode != 0),
                        "exitCode": proc_bad.returncode,
                        "stderrSnippet": (proc_bad.stderr or "").strip()[:240],
                    },
                    indent=2,
                )
                + "\n",
                encoding="utf-8",
                newline="\n",
            )

        can_sem = extract_canonical_semantic_projection(
            obs_data, h_s, pre_oracle_sha, post_oracle_sha
        )
        can_sem_sha = sha256_bytes(canonical_json_bytes(can_sem))

        warnings_cnt = combined_log.count("warning:")
        errors_cnt = combined_log.count("error:")

        replay_meta = {
            "replayId": replay_id,
            "generatedAtUtc": ts_utc,
            "zeroInitialBuildCache": True,
            "all6AncestorsAndB3AndKitCompiledFromScratch": True,
            "staged62SourcesUnchangedPostBuild": staged_unchanged,
            "buildExitCode": 0,
            "observerExitCode": proc_obs.returncode,
            "warningsCount": warnings_cnt,
            "errorsCount": errors_cnt,
            "buildElapsedSeconds": build_secs,
            "observerElapsedSeconds": obs_secs,
            "rawBuildLogSha256": log_sha,
            "preRunOracleSha256": pre_oracle_sha,
            "postRunOracleSha256": post_oracle_sha,
            "oracleUnchangedAcrossRun": (pre_oracle_sha == post_oracle_sha),
            "canonicalSemanticSha256": can_sem_sha,
        }
        ok = (
            obs_data.get("allChecksPassed", False)
            and staged_unchanged
            and (pre_oracle_sha == post_oracle_sha)
            and (warnings_cnt == 0)
            and (errors_cnt == 0)
        )
        return ok, replay_meta, can_sem


def run_double_clean_replay_pipeline(
    source_root: Path,
    kit_dir: Path,
    evidence_out_dir: Optional[Path] = None,
) -> Tuple[bool, str, Dict[str, Any]]:
    m62_path = kit_dir / "manifest_active_replay_62_sources.json"
    env_spec_path = kit_dir / "i1_environment_and_cansem_spec.json"
    oracle_path = kit_dir / "i1_precommitted_oracle_71.json"

    _, h_s = sha256_file(m62_path)
    _, h_e = sha256_file(env_spec_path)
    _, h_o_initial = sha256_file(oracle_path)

    m62 = json.loads(m62_path.read_text(encoding="utf-8"))
    src_ok, src_mismatches = verify_active_62_sources(source_root, m62)
    if not src_ok:
        return False, "VERIFY_FAILED__ACTIVE_62_SOURCE_MISMATCH", {"mismatches": src_mismatches}

    lean_env, env_meta = build_sanitized_lean_env()
    if lean_env is None:
        return False, "VERIFY_FAILED__LEAN_4_33_1_ENV_ERROR", env_meta

    log_r1 = (evidence_out_dir / "i1_clean_replay_R1.log") if evidence_out_dir else None
    obs_r1 = (evidence_out_dir / "i1_live_observation_R1.json") if evidence_out_dir else None
    cal_probe = (evidence_out_dir / "i1_live_lean_oracle_tamper_probe.json") if evidence_out_dir else None

    log_r2 = (evidence_out_dir / "i1_clean_replay_R2.log") if evidence_out_dir else None
    obs_r2 = (evidence_out_dir / "i1_live_observation_R2.json") if evidence_out_dir else None

    ok1, meta1, can1 = run_single_isolated_clean_replay(
        "R1", source_root, kit_dir, m62, h_s, oracle_path, lean_env, log_r1, obs_r1, cal_probe
    )
    if not ok1 or can1 is None:
        return False, "VERIFY_FAILED__REPLAY_R1_FAILED", {"replayR1": meta1}

    ok2, meta2, can2 = run_single_isolated_clean_replay(
        "R2", source_root, kit_dir, m62, h_s, oracle_path, lean_env, log_r2, obs_r2, None
    )
    if not ok2 or can2 is None:
        return False, "VERIFY_FAILED__REPLAY_R2_FAILED", {"replayR1": meta1, "replayR2": meta2}

    _, h_o_final = sha256_file(oracle_path)
    can_equal = canonical_json_bytes(can1) == canonical_json_bytes(can2)
    can_sha_equal = meta1["canonicalSemanticSha256"] == meta2["canonicalSemanticSha256"]
    oracle_intact = (h_o_initial == meta1["preRunOracleSha256"] == meta1["postRunOracleSha256"] == meta2["postRunOracleSha256"] == h_o_final)

    if evidence_out_dir is not None:
        can_comp = {
            "comparisonSchema": "principia.omega.p1b2b.b3.i1.cansem_double_replay_comparison.v1",
            "workId": "PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_I1_INDEPENDENT_EXTERNAL_REPLAY_ACT",
            "environmentAndCanSemSpecSha256_H_E": h_e,
            "sourceManifestSha256_H_S": h_s,
            "oracleManifestSha256_H_O": h_o_initial,
            "oracleUnchangedAcrossBothReplays": oracle_intact,
            "zeroSharedBuildArtifactsBetweenR1AndR2": True,
            "canonicalSemanticEqual_R1_eq_R2": (can_equal and can_sha_equal),
            "canonicalSemanticSha256_R1": meta1["canonicalSemanticSha256"],
            "canonicalSemanticSha256_R2": meta2["canonicalSemanticSha256"],
            "replayR1Summary": meta1,
            "replayR2Summary": meta2,
            "canonicalSemanticPayload": can1,
        }
        (evidence_out_dir / "i1_cansem_double_replay_comparison.json").write_text(
            json.dumps(can_comp, indent=2, ensure_ascii=False) + "\n",
            encoding="utf-8",
            newline="\n",
        )

    # Re-verify source_root 62 active sources untouched after both replays
    src_ok_post, post_mismatches = verify_active_62_sources(source_root, m62)
    all_ok = src_ok_post and can_equal and can_sha_equal and oracle_intact
    code = (
        "DOUBLE_CLEAN_REPLAY_AND_CANSEM_IDENTITY_VERIFIED"
        if all_ok
        else "VERIFY_FAILED__CANSEM_OR_POST_INTEGRITY_MISMATCH"
    )
    summary = {
        "H_S_active62SourceManifestSha256": h_s,
        "H_E_environmentAndCanSemSpecSha256": h_e,
        "H_O_precommittedOracle71Sha256": h_o_initial,
        "postDoubleReplayOracleSha256": h_o_final,
        "oracleHashIdenticalPreAndPost": oracle_intact,
        "active62SourcesVerifiedPreAndPost": (src_ok and src_ok_post),
        "postSourceMismatches": post_mismatches,
        "environmentMetadata": env_meta,
        "replayR1": meta1,
        "replayR2": meta2,
        "canonicalSemanticR1EqualsR2": (can_equal and can_sha_equal),
        "canonicalSemanticSha256": meta1["canonicalSemanticSha256"],
    }
    return all_ok, code, summary
