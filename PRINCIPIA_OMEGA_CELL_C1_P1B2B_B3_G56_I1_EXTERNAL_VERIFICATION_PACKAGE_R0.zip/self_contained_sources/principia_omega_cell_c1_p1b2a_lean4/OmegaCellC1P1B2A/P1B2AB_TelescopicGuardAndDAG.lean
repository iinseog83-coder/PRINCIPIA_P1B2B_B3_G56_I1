/-
  PRINCIPIA Ω-CELL-C1-P1B2A — Isolated Minimal Guarded Derivation & Certified G7 DAG Kernel
  Module: OmegaCellC1P1B2A.P1B2AB_TelescopicGuardAndDAG

  Authorization Scope (`PRINCIPIA_OMEGA_CELL_C1_P1B2A_R1` Scoped Mechanization Qualification):
    1. Telescopic Sequential Guard Contexts & `GuardedDomainCert` (`Masterstroke B2A-1`, `F-B2A-01`, `T-B2A-02`):
       - `GuardedDomainCert = (domTag, guards, goalForm, guardWfCerts, guardContextEvidence, goalDeriv)`
         requires recursive verification of `goalDeriv` under sequential guards, blocking bogus
         claims under valid guards (`x ≠ 0 ⊢ -x^2 > 0` deterministically rejected).
       - `checkGuardsPrefixDefinedBool` checks each guard `γ_i` relative to its satisfied prefix
         `[γ_1, ..., γ_{i-1}]` (`TelescopicGuardsDefined`), handling `γ_1 : x ≠ 0, γ_2 : 1/x > 0`
         without evaluating `1/x` at `x = 0` and without treating `1/x` as defined when `γ_1` is absent.
    2. Complete Guard-WF & Context Dependency Closure (`Tribunal §3.A`, `__GUARD_WF_DEPENDENCY_CLOSURE_REQUIRED`):
       - `extractStepFootprint (.guardedDomStep cert) =
            unionFootprint (extractDerivFootprint cert.goalDeriv)
              (unionFootprint (extractGuardWfFootprint cert.guardWfCerts)
                              (extractGuardCtxFootprint cert.guardContextEvidence))`
         extracting BOTH primitive premise IDs and parent DAG node IDs.
       - Proves self-contained collapse (`extraRefs = ∅`) when static AND proves counterfactual
         retraction safety when `p ∈ Deps(guardWfCerts)` yet `p ∉ Deps(goalDeriv)`.
    3. 4-Stage Global Container vs Local Causal-Lightcone Verifier (`Masterstroke B2A-2`,
       `Tribunal §3.B`, `__GLOBAL_VS_REACHABLE_DAG_CHECK_SEPARATION_REQUIRED`, `T-B2A-05`, `T-B2A-06`):
       - Stage 1: `checkContainerIntegrityBool` (`ValidContainer` — `NoDup` node IDs + strict
         discrete causal Lyapunov rank `par.topoRank < n.topoRank`).
       - Stage 2: `extractCertifiedReachableClosure` (`ReachableNodes*` & `PrimDeps*` + projections).
       - Stage 3: `verifyReachableDerivation` (local reachable causal-lightcone verifier).
       - Stage 4: `verifyGlobalWithFuel` (global container check + local root verification),
         proving `Verify_global ≠ Verify_reachable` on unreachable duplicate IDs,
         `ResourceHeld` fuel shrinkage on pruned containers, `T1_ReachableInvariance`,
         `T2_DAGMasterSoundness`, `T3_FuelDeterminismAndResourceSafety`, and the 6-vector
         adversarial DAG attack suite (`T-B2A-06`).
-/
import OmegaCellC1P1B2A.P1B2AA_PartialExprPolyCert

namespace OmegaCellC1P1B2A

open OmegaCellC1P1A0
open OmegaCellC1P1B1

/-! ### 1. Duplicate-Free IDs, Filter-Find Invariance, & Primitive Premise Environment `Γ` -/

/-- Computable duplicate-free check on `List String`. -/
def nodupStrsBool : List String → Bool
  | []      => true
  | x :: xs => !(xs.contains x) && nodupStrsBool xs

/-- Filter-lookup invariance: filtering a list by `keep` preserves `find? pred` whenever every
    matching element satisfies `keep = true`. -/
theorem filter_find?_eq_of_pred_imp_keep {α : Type} (L : List α) (keep pred : α → Bool)
    (hImp : ∀ x ∈ L, pred x = true → keep x = true) :
    (L.filter keep).find? pred = L.find? pred := by
  induction L with
  | nil => rfl
  | cons a as ih =>
      have hSub : ∀ x ∈ as, pred x = true → keep x = true :=
        fun x hx hp => hImp x (List.mem_cons_of_mem a hx) hp
      if hp : pred a = true then
        have hk : keep a = true := hImp a (List.mem_cons_self ..) hp
        simp only [List.filter, hk, List.find?, hp]
      else
        have hpf : pred a = false := Bool.eq_false_iff.mpr hp
        cases hk : keep a with
        | true =>
            simp only [List.filter, hk, List.find?, hpf]
            exact ih hSub
        | false =>
            simp only [List.filter, hk, List.find?, hpf]
            exact ih hSub

private theorem nodupStrsBool_sublist_filter {α : Type} (key : α → String) (keep : α → Bool) :
    ∀ (L : List α),
      nodupStrsBool (L.map key) = true →
      nodupStrsBool ((L.filter keep).map key) = true
  | [], _ => rfl
  | a :: as, hN => by
      simp only [List.map_cons, nodupStrsBool, Bool.and_eq_true] at hN
      cases hk : keep a with
      | false =>
          simp only [List.filter, hk]
          exact nodupStrsBool_sublist_filter key keep as hN.2
      | true =>
          simp only [List.filter, hk, List.map_cons, nodupStrsBool, Bool.and_eq_true]
          refine ⟨?_, nodupStrsBool_sublist_filter key keep as hN.2⟩
          cases hc : ((as.filter keep).map key).contains (key a) with
          | false => rfl
          | true =>
              rcases List.mem_map.mp (List.contains_iff_mem.mp hc) with ⟨z, hzF, hzEq⟩
              have hzMem : z ∈ as := (List.mem_filter.mp hzF).1
              have hInMap : key a ∈ as.map key := by
                rw [← hzEq]; exact List.mem_map_of_mem hzMem
              have hBad : (as.map key).contains (key a) = true :=
                List.contains_iff_mem.mpr hInMap
              rw [hBad] at hN
              nomatch hN.1

/-- Primitive premise entry in `Γ` with optional parent premise dependencies (`PremDag` compatible). -/
structure PrimPremiseEntry where
  premId        : String
  domTag        : G7DomTag
  specId        : String
  formula       : StrictForm
  parentPremIds : List String
  deriving DecidableEq, Repr

/-- Primitive premise environment `Γ`. -/
abbrev PrimPremiseEnv : Type := List PrimPremiseEntry

/-- Project `PrimPremiseEnv` to `P1A0`'s `PremDag` for transitive `depsStarCanon` closure. -/
def toPremDag (Γ : PrimPremiseEnv) : PremDag :=
  Γ.map (fun e => (e.premId, e.parentPremIds))

/-- Lookup a primitive premise entry by `premId`. -/
def lookupPrimPrem? (Γ : PrimPremiseEnv) (pid : String) : Option PrimPremiseEntry :=
  Γ.find? (fun e => e.premId == pid)

/-- Restrict `Γ` to premise IDs in `keepIds` (`Γ|_{PrimDeps*}`). -/
def restrictPrimEnv (Γ : PrimPremiseEnv) (keepIds : List String) : PrimPremiseEnv :=
  Γ.filter (fun e => keepIds.contains e.premId)

/-- Global structural integrity check on `PrimPremiseEnv` (`NoDup` IDs & closed parent premise refs). -/
def checkPrimEnvIntegrityBool (Γ : PrimPremiseEnv) : Bool :=
  nodupStrsBool (Γ.map (·.premId)) &&
  Γ.all (fun e =>
    e.premId != "" &&
    e.specId != "" &&
    isStrictCanonStrList e.parentPremIds &&
    e.parentPremIds.all (fun p => (lookupPrimPrem? Γ p).isSome))

/-- Independent declarative semantic validity of a `PrimPremiseEntry` (`0` checker calls). -/
def SemValidPrimEntry (e : PrimPremiseEntry) : Prop :=
  ∀ ρ : Env2, inG7Dom e.domTag ρ → ModelsStrictForm e.formula ρ

/-- Independent declarative semantic validity of `pid` in `Γ` (`0` checker calls). -/
def SemValidPrimId (Γ : PrimPremiseEnv) (pid : String) : Prop :=
  ∀ e : PrimPremiseEntry, lookupPrimPrem? Γ pid = some e → SemValidPrimEntry e

/-! ### 2. Telescopic Guard Well-Formedness, `LocalDeriv`, `GuardedDomainCert`, & Footprints -/

/-- Syntactic expression definedness check relative to verified nonzero denominators `nzDens`. -/
def checkExprDefUnderNzBool (nzDens : List PartExpr) : PartExpr → Bool
  | .const _   => true
  | .varX      => true
  | .varY      => true
  | .neg e     => checkExprDefUnderNzBool nzDens e
  | .add e1 e2 => checkExprDefUnderNzBool nzDens e1 && checkExprDefUnderNzBool nzDens e2
  | .sub e1 e2 => checkExprDefUnderNzBool nzDens e1 && checkExprDefUnderNzBool nzDens e2
  | .mul e1 e2 => checkExprDefUnderNzBool nzDens e1 && checkExprDefUnderNzBool nzDens e2
  | .div e1 e2 =>
      checkExprDefUnderNzBool nzDens e1 &&
      checkExprDefUnderNzBool nzDens e2 &&
      nzDens.contains e2

/-- Syntactic formula definedness check relative to verified nonzero denominators `nzDens`. -/
def checkFormDefUnderNzBool (nzDens : List PartExpr) : StrictForm → Bool
  | .eqZero e      => checkExprDefUnderNzBool nzDens e
  | .nonneg e      => checkExprDefUnderNzBool nzDens e
  | .pos e         => checkExprDefUnderNzBool nzDens e
  | .neqZero e     => checkExprDefUnderNzBool nzDens e
  | .conj φ ψ      => checkFormDefUnderNzBool nzDens φ && checkFormDefUnderNzBool nzDens ψ
  | .impStrict φ ψ => checkFormDefUnderNzBool nzDens φ && checkFormDefUnderNzBool nzDens ψ

theorem checkExprDefUnderNz_sound {nzDens : List PartExpr} {ρ : Env2}
    (hNz : ∀ d ∈ nzDens, ∃ vd : Rat, PartExprEvalRel d ρ vd ∧ vd ≠ 0) :
    ∀ e : PartExpr, checkExprDefUnderNzBool nzDens e = true → PartExprDefined e ρ
  | .const c,   _ => ⟨(c : Rat), .const c ρ⟩
  | .varX,      _ => ⟨ρ.1, .varX ρ⟩
  | .varY,      _ => ⟨ρ.2, .varY ρ⟩
  | .neg e,     h => by
      rcases checkExprDefUnderNz_sound hNz e h with ⟨v, hv⟩
      exact ⟨-v, .neg hv⟩
  | .add e1 e2, h => by
      simp only [checkExprDefUnderNzBool, Bool.and_eq_true] at h
      rcases checkExprDefUnderNz_sound hNz e1 h.1 with ⟨v1, h1⟩
      rcases checkExprDefUnderNz_sound hNz e2 h.2 with ⟨v2, h2⟩
      exact ⟨v1 + v2, .add h1 h2⟩
  | .sub e1 e2, h => by
      simp only [checkExprDefUnderNzBool, Bool.and_eq_true] at h
      rcases checkExprDefUnderNz_sound hNz e1 h.1 with ⟨v1, h1⟩
      rcases checkExprDefUnderNz_sound hNz e2 h.2 with ⟨v2, h2⟩
      exact ⟨v1 - v2, .sub h1 h2⟩
  | .mul e1 e2, h => by
      simp only [checkExprDefUnderNzBool, Bool.and_eq_true] at h
      rcases checkExprDefUnderNz_sound hNz e1 h.1 with ⟨v1, h1⟩
      rcases checkExprDefUnderNz_sound hNz e2 h.2 with ⟨v2, h2⟩
      exact ⟨v1 * v2, .mul h1 h2⟩
  | .div e1 e2, h => by
      simp only [checkExprDefUnderNzBool, Bool.and_eq_true, List.contains_iff_mem] at h
      rcases checkExprDefUnderNz_sound hNz e1 h.1.1 with ⟨v1, h1⟩
      rcases checkExprDefUnderNz_sound hNz e2 h.1.2 with ⟨v2, h2⟩
      rcases hNz e2 h.2 with ⟨vd, hd, hne⟩
      have heq := partExprEvalRel_unique h2 hd
      subst heq
      exact ⟨v1 / v2, .div h1 h2 hne⟩

theorem checkFormDefUnderNz_sound {nzDens : List PartExpr} {ρ : Env2}
    (hNz : ∀ d ∈ nzDens, ∃ vd : Rat, PartExprEvalRel d ρ vd ∧ vd ≠ 0) :
    ∀ φ : StrictForm, checkFormDefUnderNzBool nzDens φ = true → FormDefined φ ρ
  | .eqZero e,      h => checkExprDefUnderNz_sound hNz e h
  | .nonneg e,      h => checkExprDefUnderNz_sound hNz e h
  | .pos e,         h => checkExprDefUnderNz_sound hNz e h
  | .neqZero e,     h => checkExprDefUnderNz_sound hNz e h
  | .conj φ ψ,      h => by
      simp only [checkFormDefUnderNzBool, Bool.and_eq_true] at h
      exact ⟨checkFormDefUnderNz_sound hNz φ h.1, checkFormDefUnderNz_sound hNz ψ h.2⟩
  | .impStrict φ ψ, h => by
      simp only [checkFormDefUnderNzBool, Bool.and_eq_true] at h
      exact ⟨checkFormDefUnderNz_sound hNz φ h.1, checkFormDefUnderNz_sound hNz ψ h.2⟩

/-- Relative well-formedness witness for a single guard `γ_i` in a sequential guard telescope
    (`Masterstroke B2A-1`, `F-B2A-01`, `Tribunal §2 & §3.A`). -/
inductive GuardWfWitness where
  | totalPolyWf            : GuardWfWitness
  | prefixGuardDenomWf     : (den : PartExpr) → GuardWfWitness
  | domainIntrinsicNonzero : GuardWfWitness
  | externalPremiseDenomWf : (premId : String) → (den : PartExpr) → GuardWfWitness
  | parentNodeDenomWf      : (parentNodeId : String) → (den : PartExpr) → GuardWfWitness
  deriving DecidableEq, Repr

/-- Optional contextual justification metadata attached to a `GuardedDomainCert` (`Tribunal §3.A`). -/
inductive GuardContextEvidence where
  | selfContainedCtx   : GuardContextEvidence
  | citedPremiseCtx    : List String → GuardContextEvidence
  | citedParentNodeCtx : List String → GuardContextEvidence
  deriving DecidableEq, Repr

/-- Inductive local goal derivation tree `d_goal` (`F-B2A-01`: mandatory inside `GuardedDomainCert`). -/
inductive LocalDeriv where
  | hypGuard  : (idx : Nat) → (φ : StrictForm) → LocalDeriv
  | primPrem  : (premId : String) → (φ : StrictForm) → LocalDeriv
  | parentRef : (parentNodeId : String) → (φ : StrictForm) → LocalDeriv
  | certStep  : (φ : StrictForm) → (cert : AlgDomCert) → LocalDeriv
  | strictMP  : (φ ψ : StrictForm) → (dAnt : LocalDeriv) → (dImp : LocalDeriv) → LocalDeriv
  | conjIntro : (φ ψ : StrictForm) → (dL : LocalDeriv) → (dR : LocalDeriv) → LocalDeriv
  deriving DecidableEq, Repr

/-- **`F-B2A-01` & `Tribunal §2` `GuardedDomainCert`**:
    Bundles `(domTag, guards, goalForm, guardWfCerts, guardContextEvidence, goalDeriv)`. -/
structure GuardedDomainCert where
  domTag               : G7DomTag
  guards               : List StrictForm
  goalForm             : StrictForm
  guardWfCerts         : List GuardWfWitness
  guardContextEvidence : GuardContextEvidence
  goalDeriv            : LocalDeriv
  deriving DecidableEq, Repr

/-- Step rule of a `G7` derivation DAG node. -/
inductive G7StepRule where
  | directDerivStep : LocalDeriv → G7StepRule
  | guardedDomStep  : GuardedDomainCert → G7StepRule
  deriving DecidableEq, Repr

/-- Dual dependency footprint `(primRefs, parentNodeRefs)` (`Tribunal §3.A`). -/
structure DepFootprint where
  primRefs       : List String
  parentNodeRefs : List String
  deriving DecidableEq, Repr

/-- Canonical deduplicated union of two `DepFootprint`s. -/
def unionFootprint (f1 f2 : DepFootprint) : DepFootprint where
  primRefs       := canonSortStrs (f1.primRefs ++ f2.primRefs)
  parentNodeRefs := canonSortStrs (f1.parentNodeRefs ++ f2.parentNodeRefs)

theorem mem_unionFootprint_prim (f1 f2 : DepFootprint) (p : String) :
    p ∈ (unionFootprint f1 f2).primRefs ↔ p ∈ f1.primRefs ∨ p ∈ f2.primRefs := by
  unfold unionFootprint
  rw [mem_canonSortStrs, List.mem_append]

theorem mem_unionFootprint_parent (f1 f2 : DepFootprint) (n : String) :
    n ∈ (unionFootprint f1 f2).parentNodeRefs ↔ n ∈ f1.parentNodeRefs ∨ n ∈ f2.parentNodeRefs := by
  unfold unionFootprint
  rw [mem_canonSortStrs, List.mem_append]

/-- Extract direct footprint `(primRefs, parentNodeRefs)` from `LocalDeriv`. -/
def extractDerivFootprint : LocalDeriv → DepFootprint
  | .hypGuard _ _        => ⟨[], []⟩
  | .primPrem pid _      => ⟨[pid], []⟩
  | .parentRef nid _     => ⟨[], [nid]⟩
  | .certStep _ _        => ⟨[], []⟩
  | .strictMP _ _ d1 d2  => unionFootprint (extractDerivFootprint d1) (extractDerivFootprint d2)
  | .conjIntro _ _ d1 d2 => unionFootprint (extractDerivFootprint d1) (extractDerivFootprint d2)

/-- Extract direct footprint `(primRefs, parentNodeRefs)` from a single `GuardWfWitness`. -/
def extractSingleGuardWfFootprint : GuardWfWitness → DepFootprint
  | .totalPolyWf                  => ⟨[], []⟩
  | .prefixGuardDenomWf _         => ⟨[], []⟩
  | .domainIntrinsicNonzero       => ⟨[], []⟩
  | .externalPremiseDenomWf pid _ => ⟨[pid], []⟩
  | .parentNodeDenomWf nid _      => ⟨[], [nid]⟩

/-- Extract direct footprint across all `guardWfCerts : List GuardWfWitness`. -/
def extractGuardWfFootprint : List GuardWfWitness → DepFootprint
  | []        => ⟨[], []⟩
  | wf :: wfs => unionFootprint (extractSingleGuardWfFootprint wf) (extractGuardWfFootprint wfs)

/-- Extract direct footprint from `GuardContextEvidence`. -/
def extractGuardCtxFootprint : GuardContextEvidence → DepFootprint
  | .selfContainedCtx        => ⟨[], []⟩
  | .citedPremiseCtx pids    => ⟨canonSortStrs pids, []⟩
  | .citedParentNodeCtx nids => ⟨[], canonSortStrs nids⟩

/-- **`Tribunal §3.A` Exact Dependency Footprint Equation (`extractStepFootprint`)**:
    `Refs(guardedDomStep cert) = Refs(cert.goalDeriv) ∪ Refs(cert.guardWfCerts) ∪ Refs(cert.guardContextEvidence)`
    for BOTH primitive premises and parent DAG nodes! -/
def extractStepFootprint : G7StepRule → DepFootprint
  | .directDerivStep d   => extractDerivFootprint d
  | .guardedDomStep cert =>
      unionFootprint (extractDerivFootprint cert.goalDeriv)
        (unionFootprint (extractGuardWfFootprint cert.guardWfCerts)
                        (extractGuardCtxFootprint cert.guardContextEvidence))

/-- Defective goal-only extractor (`Mutant` omitting `guardWfCerts` & `guardContextEvidence`,
    used strictly as a negative contrast in `T-B2A-06` to prove necessity of `Tribunal §3.A`). -/
def extractStepFootprintGoalOnlyMutant : G7StepRule → DepFootprint
  | .directDerivStep d   => extractDerivFootprint d
  | .guardedDomStep cert => extractDerivFootprint cert.goalDeriv

/-- Computable test whether a `GuardedDomainCert`'s guard well-formedness & context witnesses are
    purely static / self-contained (citing zero external premises or parent nodes). -/
def isSelfContainedGuardWfBool (cert : GuardedDomainCert) : Bool :=
  cert.guardWfCerts.all (fun wf =>
    match wf with
    | .totalPolyWf            => true
    | .prefixGuardDenomWf _   => true
    | .domainIntrinsicNonzero => true
    | _                       => false) &&
  (cert.guardContextEvidence == .selfContainedCtx)

/-- **`Tribunal §3.A` Self-Contained Zero-Extra-Refs Collapse Theorem**:
    Whenever `isSelfContainedGuardWfBool cert = true`, `extractGuardWfFootprint` and
    `extractGuardCtxFootprint` both collapse to `⟨[], []⟩` (`∅`). -/
theorem selfContainedGuardWf_extraRefs_empty (cert : GuardedDomainCert)
    (hSelf : isSelfContainedGuardWfBool cert = true) :
    extractGuardWfFootprint cert.guardWfCerts = ⟨[], []⟩ ∧
    extractGuardCtxFootprint cert.guardContextEvidence = ⟨[], []⟩ := by
  unfold isSelfContainedGuardWfBool at hSelf
  simp only [Bool.and_eq_true] at hSelf
  rcases hSelf with ⟨hWf, hCtx⟩
  refine ⟨?_, ?_⟩
  · have hAux : ∀ (L : List GuardWfWitness),
        L.all (fun wf =>
          match wf with
          | .totalPolyWf            => true
          | .prefixGuardDenomWf _   => true
          | .domainIntrinsicNonzero => true
          | _                       => false) = true →
        extractGuardWfFootprint L = ⟨[], []⟩ := by
      intro L hL
      induction L with
      | nil => rfl
      | cons wf wfs ih =>
          simp only [List.all_cons, Bool.and_eq_true] at hL
          have hTail := ih hL.2
          have hHead : extractSingleGuardWfFootprint wf = ⟨[], []⟩ := by
            cases wf <;> first | rfl | nomatch hL.1
          unfold extractGuardWfFootprint
          rw [hHead, hTail]
          rfl
    exact hAux cert.guardWfCerts hWf
  · rw [eq_of_beq hCtx]
    rfl

/-! ### 3. Certified DAG Container, Causal Lyapunov `topoRank`, & 4-Stage Verifier Architecture -/

/-- Node in a `G7` derivation DAG carrying explicit discrete causal rank `topoRank : Nat`. -/
structure G7DagNode where
  nodeId     : String
  topoRank   : Nat
  domTag     : G7DomTag
  specId     : String
  guards     : List StrictForm
  conclusion : StrictForm
  step       : G7StepRule
  deriving DecidableEq, Repr

/-- Container of `G7DagNode`s. -/
structure G7DagContainer where
  nodes : List G7DagNode
  deriving DecidableEq, Repr

/-- Lookup a `G7DagNode` by `nodeId` in `C`. -/
def lookupDagNode? (C : G7DagContainer) (nid : String) : Option G7DagNode :=
  C.nodes.find? (fun n => n.nodeId == nid)

/-- Maximum `topoRank` occurring in `C`. -/
def maxTopoRank (C : G7DagContainer) : Nat :=
  C.nodes.foldr (fun n acc => Nat.max n.topoRank acc) 0

private theorem topoRank_le_maxTopoRank {C : G7DagContainer} {n : G7DagNode}
    (hMem : n ∈ C.nodes) : n.topoRank ≤ maxTopoRank C := by
  unfold maxTopoRank
  have hAux : ∀ (L : List G7DagNode), n ∈ L →
      n.topoRank ≤ L.foldr (fun x acc => Nat.max x.topoRank acc) 0 := by
    intro L hM
    induction L with
    | nil => nomatch hM
    | cons a as ih =>
        dsimp only [List.foldr]
        rcases List.mem_cons.mp hM with rfl | hRest
        · exact Nat.le_max_left n.topoRank _
        · exact Nat.le_trans (ih hRest) (Nat.le_max_right a.topoRank _)
  exact hAux C.nodes hMem

/-- **Stage 1 (`Tribunal §3.B` `CheckContainerIntegrity`)**:
    Global structural check verifying `NoDup` on `nodeId`s, non-empty identifiers, and strict
    causal Lyapunov ordering `par.topoRank < n.topoRank` on all parent references. -/
def checkContainerIntegrityBool (C : G7DagContainer) : Bool :=
  nodupStrsBool (C.nodes.map (·.nodeId)) &&
  C.nodes.all (fun n =>
    n.nodeId != "" &&
    n.specId != "" &&
    (extractStepFootprint n.step).parentNodeRefs.all (fun parId =>
      match lookupDagNode? C parId with
      | some par => decide (par.topoRank < n.topoRank)
      | none     => false))

/-- Declarative alias `ValidContainer C` (`checkContainerIntegrityBool C = true`, decidable!). -/
abbrev ValidContainer (C : G7DagContainer) : Prop :=
  checkContainerIntegrityBool C = true

/-- Single-hop parent expansion in `C`. -/
def expandNodeStep (C : G7DagContainer) (cur : List String) : List String :=
  cur.foldr (fun nid acc =>
    let pars := match lookupDagNode? C nid with
                | some n => (extractStepFootprint n.step).parentNodeRefs
                | none   => []
    nid :: (pars ++ acc)) []

/-- Outer-first iterated parent expansion `transNodeIter k C cur`. -/
def transNodeIter : Nat → G7DagContainer → List String → List String
  | 0,     _, cur => cur
  | k + 1, C, cur => expandNodeStep C (transNodeIter k C cur)

/-- **Stage 2a (`ExtractCertifiedReachableClosure` — Nodes `ReachableNodes*`)**:
    Canonical root-reachable node ID list bounded by `maxTopoRank C + 1` causal hops. -/
def extractReachableNodeIds (C : G7DagContainer) (rootId : String) : List String :=
  canonSortStrs (transNodeIter (maxTopoRank C + 1) C [rootId])

/-- Restrict `C` to `keepNodeIds` (`C|_{ReachableNodes*}`). -/
def restrictContainer (C : G7DagContainer) (keepNodeIds : List String) : G7DagContainer where
  nodes := C.nodes.filter (fun n => keepNodeIds.contains n.nodeId)

/-- Direct primitive premises referenced anywhere inside `nodeIds` of `C`. -/
def collectDirectPrimRefsOfNodes (C : G7DagContainer) (nodeIds : List String) : List String :=
  canonSortStrs (nodeIds.foldr (fun nid acc =>
    match lookupDagNode? C nid with
    | some n => (extractStepFootprint n.step).primRefs ++ acc
    | none   => acc) [])

/-- **Stage 2b (`ExtractCertifiedReachableClosure` — Transitive Premises `PrimDeps*`)**:
    Collects direct primitive refs across `ReachableNodes*` (from `goalDeriv`, `guardWfCerts`,
    AND `guardContextEvidence`!) and closes transitively over `toPremDag Γ` via `depsStarCanon`. -/
def extractTransitivePrimDeps (Γ : PrimPremiseEnv) (C : G7DagContainer) (rootId : String) :
    List String :=
  let reachNodes := extractReachableNodeIds C rootId
  let directPrims := collectDirectPrimRefsOfNodes C reachNodes
  depsStarCanon (toPremDag Γ) directPrims

/-- Certified reachable closure record bundling `(reachNodeIds, primDepsStar, restrictedC, restrictedΓ)`. -/
structure CertifiedReachableClosure where
  reachNodeIds : List String
  primDepsStar : List String
  restrictedC  : G7DagContainer
  restrictedΓ  : PrimPremiseEnv
  deriving DecidableEq, Repr

/-- **Stage 2 (`ExtractCertifiedReachableClosure`)**: constructs the exact causal lightcone closure. -/
def extractCertifiedReachableClosure (Γ : PrimPremiseEnv) (C : G7DagContainer) (rootId : String) :
    CertifiedReachableClosure :=
  let rNodes := extractReachableNodeIds C rootId
  let pDeps  := depsStarCanon (toPremDag Γ) (collectDirectPrimRefsOfNodes C rNodes)
  { reachNodeIds := rNodes
    primDepsStar := pDeps
    restrictedC  := restrictContainer C rNodes
    restrictedΓ  := restrictPrimEnv Γ pDeps }

private theorem subset_expandNodeStep (C : G7DagContainer) (cur : List String) :
    ∀ x ∈ cur, x ∈ expandNodeStep C cur := by
  induction cur with
  | nil => intro _ h; nomatch h
  | cons a as ih =>
      intro x hx
      unfold expandNodeStep
      simp only [List.foldr_cons, List.mem_cons, List.mem_append]
      rcases List.mem_cons.mp hx with rfl | hRest
      · exact Or.inl rfl
      · exact Or.inr (Or.inr (ih x hRest))

private theorem parent_mem_expandNodeStep (C : G7DagContainer) (cur : List String)
    {nid parId : String} {n : G7DagNode}
    (hMem : nid ∈ cur) (hLook : lookupDagNode? C nid = some n)
    (hPar : parId ∈ (extractStepFootprint n.step).parentNodeRefs) :
    parId ∈ expandNodeStep C cur := by
  induction cur with
  | nil => nomatch hMem
  | cons a as ih =>
      unfold expandNodeStep
      simp only [List.foldr_cons, List.mem_cons, List.mem_append]
      rcases List.mem_cons.mp hMem with rfl | hRest
      · rw [hLook]
        exact Or.inr (Or.inl hPar)
      · exact Or.inr (Or.inr (ih hRest))

private theorem mono_transNodeIter (C : G7DagContainer) (cur : List String) {k : Nat} :
    ∀ (d : Nat) {x : String}, x ∈ transNodeIter k C cur → x ∈ transNodeIter (k + d) C cur
  | 0,     _, hx => hx
  | d + 1, _, hx =>
      subset_expandNodeStep C (transNodeIter (k + d) C cur) _ (mono_transNodeIter C cur d hx)

private theorem mem_transNodeIter_le (C : G7DagContainer) (cur : List String) {k m : Nat}
    (hLe : k ≤ m) {x : String} (hx : x ∈ transNodeIter k C cur) :
    x ∈ transNodeIter m C cur := by
  have hEq : k + (m - k) = m := Nat.add_sub_of_le hLe
  rw [← hEq]
  exact mono_transNodeIter C cur (m - k) hx

private theorem validContainer_parent_rank {C : G7DagContainer} (hVal : ValidContainer C)
    {nid parId : String} {n : G7DagNode}
    (hLook : lookupDagNode? C nid = some n)
    (hPar : parId ∈ (extractStepFootprint n.step).parentNodeRefs) :
    ∃ par : G7DagNode, lookupDagNode? C parId = some par ∧ par.topoRank < n.topoRank := by
  unfold ValidContainer checkContainerIntegrityBool at hVal
  simp only [Bool.and_eq_true] at hVal
  have hMem : n ∈ C.nodes := List.mem_of_find?_eq_some hLook
  have hNodeOk := List.all_eq_true.mp hVal.2 n hMem
  simp only [Bool.and_eq_true] at hNodeOk
  have hParOk := List.all_eq_true.mp hNodeOk.2 parId hPar
  cases hp : lookupDagNode? C parId with
  | none     => rw [hp] at hParOk; nomatch hParOk
  | some par =>
      rw [hp] at hParOk
      exact ⟨par, rfl, of_decide_eq_true hParOk⟩

private theorem prim_mem_collectDirectPrimRefs (C : G7DagContainer) (nodeIds : List String)
    {nid pid : String} {n : G7DagNode}
    (hNodeMem : nid ∈ nodeIds) (hLook : lookupDagNode? C nid = some n)
    (hPrim : pid ∈ (extractStepFootprint n.step).primRefs) :
    pid ∈ collectDirectPrimRefsOfNodes C nodeIds := by
  unfold collectDirectPrimRefsOfNodes
  rw [mem_canonSortStrs]
  induction nodeIds with
  | nil => nomatch hNodeMem
  | cons a as ih =>
      simp only [List.foldr_cons]
      rcases List.mem_cons.mp hNodeMem with rfl | hRest
      · rw [hLook]
        exact List.mem_append_left _ hPrim
      · cases lookupDagNode? C a with
        | none    => exact ih hRest
        | some na => exact List.mem_append_right _ (ih hRest)

/-! ### 4. Sequential Guard Checker (`checkGuardsPrefixDefinedBool`) & Stage 3/4 Verifiers -/

/-- Check a single `(γ_i, wf_i)` pair relative to `prefixGuards`, `Γ`, and `C`. -/
def checkSingleGuardWfBool (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (prefixGuards : List StrictForm)
    (γ : StrictForm) (wf : GuardWfWitness) : Bool :=
  match wf with
  | .totalPolyWf =>
      checkFormDefUnderNzBool [] γ
  | .prefixGuardDenomWf den =>
      (prefixGuards.contains (.neqZero den) || prefixGuards.contains (.pos den)) &&
      checkFormDefUnderNzBool [den] γ
  | .domainIntrinsicNonzero =>
      (domTag == .domQNonzero) && checkFormDefUnderNzBool [.varX] γ
  | .externalPremiseDenomWf pid den =>
      match lookupPrimPrem? Γ pid with
      | some pe =>
          (pe.domTag == domTag) &&
          (pe.specId == specId) &&
          (pe.formula == .neqZero den || pe.formula == .pos den) &&
          checkExprDefUnderNzBool [] den &&
          checkFormDefUnderNzBool [den] γ
      | none => false
  | .parentNodeDenomWf nid den =>
      match lookupDagNode? C nid with
      | some par =>
          decide (par.topoRank < curRank) &&
          (par.domTag == domTag) &&
          (par.specId == specId) &&
          (par.guards == []) &&
          (par.conclusion == .neqZero den || par.conclusion == .pos den) &&
          checkExprDefUnderNzBool [] den &&
          checkFormDefUnderNzBool [den] γ
      | none => false

/-- **`F-B2A-01` & `Tribunal §2` `checkGuardsPrefixDefinedBool`**:
    Verifies sequential guard definedness left-to-right, extending `prefixGuards` with `γ_i`
    only AFTER `γ_i` has been verified well-defined on `prefixGuards`! -/
def checkGuardsPrefixDefinedAux (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (prefixGuards : List StrictForm) :
    List StrictForm → List GuardWfWitness → Bool
  | [],      []        => true
  | γ :: γs, wf :: wfs =>
      checkSingleGuardWfBool domTag specId curRank Γ C prefixGuards γ wf &&
      checkGuardsPrefixDefinedAux domTag specId curRank Γ C (prefixGuards ++ [γ]) γs wfs
  | _,       _         => false

def checkGuardsPrefixDefinedBool (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (guards : List StrictForm) (wfs : List GuardWfWitness) : Bool :=
  checkGuardsPrefixDefinedAux domTag specId curRank Γ C [] guards wfs

/-- Check `GuardContextEvidence` against `(domTag, specId, curRank, Γ, C)`. -/
def checkGuardCtxEvidenceBool (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) : GuardContextEvidence → Bool
  | .selfContainedCtx => true
  | .citedPremiseCtx pids =>
      isStrictCanonStrList pids &&
      pids.all (fun pid =>
        match lookupPrimPrem? Γ pid with
        | some pe => (pe.domTag == domTag) && (pe.specId == specId) &&
                     checkFormDefUnderNzBool [] pe.formula
        | none    => false)
  | .citedParentNodeCtx nids =>
      isStrictCanonStrList nids &&
      nids.all (fun nid =>
        match lookupDagNode? C nid with
        | some par => decide (par.topoRank < curRank) &&
                      (par.domTag == domTag) &&
                      (par.specId == specId) &&
                      (par.guards == [])
        | none     => false)

/-- Declarative telescopic sequential guard definedness (`Masterstroke B2A-1`, `0` checker calls):
    Each `γ_i` is strictly defined on the prefix region where all preceding guards hold. -/
def TelescopicGuardsDefined : List StrictForm → Env2 → Prop
  | [],      _ => True
  | γ :: γs, ρ => FormDefined γ ρ ∧ (ModelsStrictForm γ ρ → TelescopicGuardsDefined γs ρ)

/-- Verified sequent header returned upon successful `G7` acceptance. -/
structure VerifiedSequentOut where
  domTag     : G7DomTag
  specId     : String
  guards     : List StrictForm
  conclusion : StrictForm
  deriving DecidableEq, Repr

/-- Independent declarative semantic validity of a `VerifiedSequentOut` (`0` checker calls!). -/
def SemValidSequent (out : VerifiedSequentOut) : Prop :=
  (∀ ρ : Env2, inG7Dom out.domTag ρ → TelescopicGuardsDefined out.guards ρ) ∧
  (∀ ρ : Env2, inG7Dom out.domTag ρ →
    (∀ γ ∈ out.guards, ModelsStrictForm γ ρ) → ModelsStrictForm out.conclusion ρ)

/-- Rejection error classification inside `G7`. -/
inductive G7RejectErr where
  | containerIntegrityFailed : G7RejectErr
  | nodeNotFound             : String → G7RejectErr
  | causalRankViolation      : String → G7RejectErr
  | guardWfFailed            : G7RejectErr
  | guardCtxFailed           : G7RejectErr
  | headerMismatch           : G7RejectErr
  | localDerivFailed         : G7RejectErr
  deriving DecidableEq, Repr

/-- Polarity-safe 3-branch `G7` check result (`resourceHeld` strictly separated from `rejectInvalid`!). -/
inductive G7CheckResult where
  | accept        : VerifiedSequentOut → G7CheckResult
  | rejectInvalid : G7RejectErr → G7CheckResult
  | resourceHeld  : Nat → G7CheckResult
  deriving DecidableEq, Repr

/-- Boolean test whether `G7CheckResult` is `.accept _`. -/
def isG7AcceptBool : G7CheckResult → Bool
  | .accept _ => true
  | _         => false

/-- Local derivation checker (`checkLocalDerivBool`) checking `d_goal` against `(domTag, specId, curRank, guards)`. -/
def checkLocalDerivBool (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (guards : List StrictForm)
    (d : LocalDeriv) (expectedGoal : StrictForm) : Bool :=
  match d with
  | .hypGuard idx φ =>
      (φ == expectedGoal) && (guards[idx]? == some φ)
  | .primPrem pid φ =>
      (φ == expectedGoal) &&
      match lookupPrimPrem? Γ pid with
      | some pe =>
          (pe.domTag == domTag) &&
          (pe.specId == specId) &&
          (pe.formula == φ) &&
          checkFormDefUnderNzBool [] φ
      | none => false
  | .parentRef nid φ =>
      (φ == expectedGoal) &&
      match lookupDagNode? C nid with
      | some par =>
          decide (par.topoRank < curRank) &&
          (par.domTag == domTag) &&
          (par.specId == specId) &&
          (par.conclusion == φ) &&
          par.guards.all (fun g => guards.contains g)
      | none => false
  | .certStep φ cert =>
      (φ == expectedGoal) && checkAlgDomCertBool domTag guards φ cert
  | .strictMP φ ψ dAnt dImp =>
      (ψ == expectedGoal) &&
      checkLocalDerivBool domTag specId curRank Γ C guards dAnt φ &&
      checkLocalDerivBool domTag specId curRank Γ C guards dImp (.impStrict φ ψ)
  | .conjIntro φ ψ dL dR =>
      (expectedGoal == .conj φ ψ) &&
      checkLocalDerivBool domTag specId curRank Γ C guards dL φ &&
      checkLocalDerivBool domTag specId curRank Γ C guards dR ψ

/-- Verify a single `G7DagNode`'s local step (without recursing into parents yet). -/
def checkNodeStepLocal (Γ : PrimPremiseEnv) (C : G7DagContainer) (n : G7DagNode) :
    Except G7RejectErr Unit :=
  match n.step with
  | .directDerivStep d =>
      if n.guards != [] then
        .error .headerMismatch
      else if checkLocalDerivBool n.domTag n.specId n.topoRank Γ C [] d n.conclusion then
        .ok ()
      else
        .error .localDerivFailed
  | .guardedDomStep cert =>
      if !(cert.domTag == n.domTag && cert.guards == n.guards && cert.goalForm == n.conclusion) then
        .error .headerMismatch
      else if !checkGuardsPrefixDefinedBool cert.domTag n.specId n.topoRank Γ C
                 cert.guards cert.guardWfCerts then
        .error .guardWfFailed
      else if !checkGuardCtxEvidenceBool cert.domTag n.specId n.topoRank Γ C
                 cert.guardContextEvidence then
        .error .guardCtxFailed
      else if checkLocalDerivBool cert.domTag n.specId n.topoRank Γ C
                cert.guards cert.goalDeriv cert.goalForm then
        .ok ()
      else
        .error .localDerivFailed

/-- Non-mutual parent list aggregator parameterized by recursive step `run : String → G7CheckResult`. -/
def verifyParentsAux (run : String → G7CheckResult) (C : G7DagContainer) (childRank : Nat) :
    List String → Except G7RejectErr (Option Nat)
  | [] => .ok none
  | parId :: rest =>
      match lookupDagNode? C parId with
      | none => .error (.nodeNotFound parId)
      | some par =>
          if !(decide (par.topoRank < childRank)) then
            .error (.causalRankViolation parId)
          else
            match run parId with
            | .rejectInvalid e => .error e
            | .resourceHeld k  => .ok (some k)
            | .accept _        => verifyParentsAux run C childRank rest

/-- **Stage 3 (`VerifyReachableDerivation`)**:
    Single structural recursion on `fuel` verifying `nid` and its entire causal parent cone! -/
def verifyNodeFuel : Nat → PrimPremiseEnv → G7DagContainer → String → G7CheckResult
  | 0,     _, _, _   => .resourceHeld 0
  | f + 1, Γ, C, nid =>
      match lookupDagNode? C nid with
      | none => .rejectInvalid (.nodeNotFound nid)
      | some n =>
          if n.nodeId != nid then
            .rejectInvalid .headerMismatch
          else
            match checkNodeStepLocal Γ C n with
            | .error e => .rejectInvalid e
            | .ok () =>
                let pars := (extractStepFootprint n.step).parentNodeRefs
                match verifyParentsAux (verifyNodeFuel f Γ C) C n.topoRank pars with
                | .error e       => .rejectInvalid e
                | .ok (some rem) => .resourceHeld rem
                | .ok none       => .accept ⟨n.domTag, n.specId, n.guards, n.conclusion⟩

/-- Official local reachable causal-lightcone verifier (`verifyReachableDerivation`). -/
def verifyReachableDerivation (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (rootId : String) : G7CheckResult :=
  verifyNodeFuel fuel Γ C rootId

/-- **Stage 4 (`VerifyGlobalWithFuel`)**:
    Spends `C.nodes.length` fuel checking global `checkContainerIntegrityBool C` before running
    `verifyReachableDerivation (fuel - C.nodes.length) Γ C rootId` (`Tribunal §3.B`). -/
def verifyGlobalWithFuel (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (rootId : String) : G7CheckResult :=
  if fuel < C.nodes.length then
    .resourceHeld 0
  else if !checkContainerIntegrityBool C then
    .rejectInvalid .containerIntegrityFailed
  else
    verifyReachableDerivation (fuel - C.nodes.length) Γ C rootId

/-! ### 5. Proofs of `T1_ReachableInvariance`, `T2_DAGMasterSoundness`, & `T3_FuelDeterminism` -/

private theorem checkSingleGuardWf_lookup_inv (domTag : G7DomTag) (specId : String) (curRank : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    (prefixGuards : List StrictForm) (γ : StrictForm) (wf : GuardWfWitness)
    (hPrimEq : ∀ pid ∈ (extractSingleGuardWfFootprint wf).primRefs,
      lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid)
    (hParEq : ∀ nid ∈ (extractSingleGuardWfFootprint wf).parentNodeRefs,
      lookupDagNode? C1 nid = lookupDagNode? C2 nid) :
    checkSingleGuardWfBool domTag specId curRank Γ1 C1 prefixGuards γ wf =
    checkSingleGuardWfBool domTag specId curRank Γ2 C2 prefixGuards γ wf := by
  cases wf with
  | totalPolyWf            => rfl
  | prefixGuardDenomWf _   => rfl
  | domainIntrinsicNonzero => rfl
  | externalPremiseDenomWf pid _ =>
      dsimp only [checkSingleGuardWfBool]
      rw [hPrimEq pid (List.mem_cons_self ..)]
  | parentNodeDenomWf nid _ =>
      dsimp only [checkSingleGuardWfBool]
      rw [hParEq nid (List.mem_cons_self ..)]

private theorem checkGuardsPrefixAux_lookup_inv (domTag : G7DomTag) (specId : String) (curRank : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} :
    ∀ (prefixGuards γs : List StrictForm) (wfs : List GuardWfWitness),
      (∀ pid ∈ (extractGuardWfFootprint wfs).primRefs,
        lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) →
      (∀ nid ∈ (extractGuardWfFootprint wfs).parentNodeRefs,
        lookupDagNode? C1 nid = lookupDagNode? C2 nid) →
      checkGuardsPrefixDefinedAux domTag specId curRank Γ1 C1 prefixGuards γs wfs =
      checkGuardsPrefixDefinedAux domTag specId curRank Γ2 C2 prefixGuards γs wfs
  | _, [], [] => fun _ _ => rfl
  | _, [], _ :: _ => fun _ _ => rfl
  | _, _ :: _, [] => fun _ _ => rfl
  | prefixGuards, γ :: γs, wf :: wfs => by
      intro hPrim hPar
      unfold checkGuardsPrefixDefinedAux
      have hHead := checkSingleGuardWf_lookup_inv domTag specId curRank
        (Γ1 := Γ1) (Γ2 := Γ2) (C1 := C1) (C2 := C2) prefixGuards γ wf
        (fun pid hp => hPrim pid ((mem_unionFootprint_prim _ _ pid).mpr (Or.inl hp)))
        (fun nid hn => hPar nid ((mem_unionFootprint_parent _ _ nid).mpr (Or.inl hn)))
      have hTail := checkGuardsPrefixAux_lookup_inv domTag specId curRank (prefixGuards ++ [γ]) γs wfs
        (fun pid hp => hPrim pid ((mem_unionFootprint_prim _ _ pid).mpr (Or.inr hp)))
        (fun nid hn => hPar nid ((mem_unionFootprint_parent _ _ nid).mpr (Or.inr hn)))
      rw [hHead, hTail]

private theorem list_all_congr_mem {α : Type} {f g : α → Bool} :
    ∀ (L : List α), (∀ x ∈ L, f x = g x) → L.all f = L.all g
  | [], _ => rfl
  | a :: as, h => by
      simp only [List.all_cons]
      rw [h a (List.mem_cons_self ..),
          list_all_congr_mem as (fun x hx => h x (List.mem_cons_of_mem a hx))]

private theorem checkGuardCtx_lookup_inv (domTag : G7DomTag) (specId : String) (curRank : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (ctx : GuardContextEvidence)
    (hPrim : ∀ pid ∈ (extractGuardCtxFootprint ctx).primRefs,
      lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid)
    (hPar : ∀ nid ∈ (extractGuardCtxFootprint ctx).parentNodeRefs,
      lookupDagNode? C1 nid = lookupDagNode? C2 nid) :
    checkGuardCtxEvidenceBool domTag specId curRank Γ1 C1 ctx =
    checkGuardCtxEvidenceBool domTag specId curRank Γ2 C2 ctx := by
  cases ctx with
  | selfContainedCtx => rfl
  | citedPremiseCtx pids =>
      dsimp only [checkGuardCtxEvidenceBool]
      congr 1
      apply list_all_congr_mem
      intro pid hp
      rw [hPrim pid ((mem_canonSortStrs pids pid).mpr hp)]
  | citedParentNodeCtx nids =>
      dsimp only [checkGuardCtxEvidenceBool]
      congr 1
      apply list_all_congr_mem
      intro nid hn
      rw [hPar nid ((mem_canonSortStrs nids nid).mpr hn)]

private theorem checkLocalDeriv_lookup_inv (domTag : G7DomTag) (specId : String) (curRank : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (guards : List StrictForm) :
    ∀ (d : LocalDeriv) (goal : StrictForm),
      (∀ pid ∈ (extractDerivFootprint d).primRefs,
        lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) →
      (∀ nid ∈ (extractDerivFootprint d).parentNodeRefs,
        lookupDagNode? C1 nid = lookupDagNode? C2 nid) →
      checkLocalDerivBool domTag specId curRank Γ1 C1 guards d goal =
      checkLocalDerivBool domTag specId curRank Γ2 C2 guards d goal
  | .hypGuard _ _, _ => fun _ _ => rfl
  | .primPrem pid _, _ => fun hPrim _ => by
      dsimp only [checkLocalDerivBool]
      rw [hPrim pid (List.mem_cons_self ..)]
  | .parentRef nid _, _ => fun _ hPar => by
      dsimp only [checkLocalDerivBool]
      rw [hPar nid (List.mem_cons_self ..)]
  | .certStep _ _, _ => fun _ _ => rfl
  | .strictMP φ ψ d1 d2, _ => fun hPrim hPar => by
      dsimp only [checkLocalDerivBool]
      rw [checkLocalDeriv_lookup_inv domTag specId curRank guards d1 φ
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
            (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu))),
          checkLocalDeriv_lookup_inv domTag specId curRank guards d2 (.impStrict φ ψ)
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
            (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))]
  | .conjIntro φ ψ d1 d2, _ => fun hPrim hPar => by
      dsimp only [checkLocalDerivBool]
      rw [checkLocalDeriv_lookup_inv domTag specId curRank guards d1 φ
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
            (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu))),
          checkLocalDeriv_lookup_inv domTag specId curRank guards d2 ψ
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
            (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))]

private theorem checkNodeStepLocal_lookup_inv {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    (n : G7DagNode)
    (hPrim : ∀ pid ∈ (extractStepFootprint n.step).primRefs,
      lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid)
    (hPar : ∀ nid ∈ (extractStepFootprint n.step).parentNodeRefs,
      lookupDagNode? C1 nid = lookupDagNode? C2 nid) :
    checkNodeStepLocal Γ1 C1 n = checkNodeStepLocal Γ2 C2 n := by
  cases hs : n.step with
  | directDerivStep d =>
      unfold checkNodeStepLocal
      rw [hs]; dsimp only
      rw [hs] at hPrim hPar
      rw [checkLocalDeriv_lookup_inv n.domTag n.specId n.topoRank [] d n.conclusion hPrim hPar]
  | guardedDomStep cert =>
      unfold checkNodeStepLocal
      rw [hs]; dsimp only
      rw [hs] at hPrim hPar
      have hD := checkLocalDeriv_lookup_inv cert.domTag n.specId n.topoRank
        (Γ1 := Γ1) (Γ2 := Γ2) (C1 := C1) (C2 := C2) cert.guards cert.goalDeriv cert.goalForm
        (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
        (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))
      have hW := checkGuardsPrefixAux_lookup_inv cert.domTag n.specId n.topoRank
        (Γ1 := Γ1) (Γ2 := Γ2) (C1 := C1) (C2 := C2) [] cert.guards cert.guardWfCerts
        (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr
          (Or.inr ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))))
        (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr
          (Or.inr ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))))
      have hC := checkGuardCtx_lookup_inv cert.domTag n.specId n.topoRank
        (Γ1 := Γ1) (Γ2 := Γ2) (C1 := C1) (C2 := C2) cert.guardContextEvidence
        (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr
          (Or.inr ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))))
        (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr
          (Or.inr ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))))
      unfold checkGuardsPrefixDefinedBool
      rw [hW, hC, hD]

private theorem lookup_restrictContainer_eq (C : G7DagContainer) (keepIds : List String)
    {nid : String} (hMem : nid ∈ keepIds) :
    lookupDagNode? (restrictContainer C keepIds) nid = lookupDagNode? C nid := by
  unfold lookupDagNode? restrictContainer
  apply filter_find?_eq_of_pred_imp_keep
  intro n _ hEq
  rw [eq_of_beq hEq]
  exact List.contains_iff_mem.mpr hMem

private theorem lookup_restrictPrimEnv_eq (Γ : PrimPremiseEnv) (keepIds : List String)
    {pid : String} (hMem : pid ∈ keepIds) :
    lookupPrimPrem? (restrictPrimEnv Γ keepIds) pid = lookupPrimPrem? Γ pid := by
  unfold lookupPrimPrem? restrictPrimEnv
  apply filter_find?_eq_of_pred_imp_keep
  intro e _ hEq
  rw [eq_of_beq hEq]
  exact List.contains_iff_mem.mpr hMem

private theorem verifyParentsAux_congr {run1 run2 : String → G7CheckResult}
    {C1 C2 : G7DagContainer} (childRank : Nat) :
    ∀ (pars : List String),
      (∀ p ∈ pars, lookupDagNode? C1 p = lookupDagNode? C2 p ∧ run1 p = run2 p) →
      verifyParentsAux run1 C1 childRank pars = verifyParentsAux run2 C2 childRank pars
  | [], _ => rfl
  | parId :: rest, hEq => by
      have hHead := hEq parId (List.mem_cons_self ..)
      have hTail := verifyParentsAux_congr childRank rest
        (fun p hp => hEq p (List.mem_cons_of_mem parId hp))
      unfold verifyParentsAux
      rw [hHead.1]
      cases lookupDagNode? C2 parId with
      | none => rfl
      | some par =>
          dsimp only
          if hRk : (!(decide (par.topoRank < childRank))) = true then
            rw [if_pos hRk, if_pos hRk]
          else
            rw [if_neg hRk, if_neg hRk, hHead.2]
            cases run2 parId with
            | rejectInvalid _ => rfl
            | resourceHeld _  => rfl
            | accept _        => exact hTail

/-- **`T1` Reachable Invariance Theorem (`verifyReachable_restricted_eq`)**:
    Under `ValidContainer C`, for EVERY `fuel : Nat`, local reachable verification on
    `(clo.restrictedΓ, clo.restrictedC)` returns the EXACT SAME `G7CheckResult` as on `(Γ, C)`. -/
theorem verifyReachable_restricted_eq (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (rootId : String) (hVal : ValidContainer C) (fuel : Nat) :
    let clo := extractCertifiedReachableClosure Γ C rootId
    verifyReachableDerivation fuel clo.restrictedΓ clo.restrictedC rootId =
    verifyReachableDerivation fuel Γ C rootId := by
  dsimp only
  let clo := extractCertifiedReachableClosure Γ C rootId
  have hAux : ∀ (f : Nat) (nid : String),
      (∃ k : Nat, k ≤ maxTopoRank C + 1 ∧ nid ∈ transNodeIter k C [rootId] ∧
        (∀ n : G7DagNode, lookupDagNode? C nid = some n → k + n.topoRank ≤ maxTopoRank C)) →
      verifyNodeFuel f clo.restrictedΓ clo.restrictedC nid =
      verifyNodeFuel f Γ C nid := by
    intro f
    induction f with
    | zero => intro _ _; rfl
    | succ f' ih =>
        intro nid ⟨k, hkLe, hIter, hRankBound⟩
        have hInReach : nid ∈ clo.reachNodeIds := by
          show nid ∈ extractReachableNodeIds C rootId
          unfold extractReachableNodeIds
          rw [mem_canonSortStrs]
          exact mem_transNodeIter_le C [rootId] hkLe hIter
        have hLookEq : lookupDagNode? clo.restrictedC nid = lookupDagNode? C nid :=
          lookup_restrictContainer_eq C clo.reachNodeIds hInReach
        unfold verifyNodeFuel
        rw [hLookEq]
        cases hLook : lookupDagNode? C nid with
        | none => rfl
        | some n =>
            dsimp only
            if hId : (n.nodeId != nid) = true then
              rw [if_pos hId, if_pos hId]
            else
              rw [if_neg hId, if_neg hId]
              have hStepInv : checkNodeStepLocal clo.restrictedΓ clo.restrictedC n =
                  checkNodeStepLocal Γ C n := by
                apply checkNodeStepLocal_lookup_inv
                · intro pid hp
                  have hDir : pid ∈ collectDirectPrimRefsOfNodes C clo.reachNodeIds :=
                    prim_mem_collectDirectPrimRefs C clo.reachNodeIds hInReach hLook hp
                  have hDep : pid ∈ clo.primDepsStar :=
                    direct_mem_depsStarCanon (toPremDag Γ) _ hDir
                  exact lookup_restrictPrimEnv_eq Γ clo.primDepsStar hDep
                · intro parId hPar
                  rcases validContainer_parent_rank hVal hLook hPar with ⟨par, _, hLt⟩
                  have hnb := hRankBound n hLook
                  have hk1Le : k + 1 ≤ maxTopoRank C + 1 := by omega
                  have hParIter : parId ∈ transNodeIter (k + 1) C [rootId] :=
                    parent_mem_expandNodeStep C (transNodeIter k C [rootId]) hIter hLook hPar
                  have hParReach : parId ∈ clo.reachNodeIds := by
                    show parId ∈ extractReachableNodeIds C rootId
                    unfold extractReachableNodeIds
                    rw [mem_canonSortStrs]
                    exact mem_transNodeIter_le C [rootId] hk1Le hParIter
                  exact lookup_restrictContainer_eq C clo.reachNodeIds hParReach
              rw [hStepInv]
              cases checkNodeStepLocal Γ C n with
              | error _ => rfl
              | ok _ =>
                  dsimp only
                  have hParsEq :
                      verifyParentsAux (verifyNodeFuel f' clo.restrictedΓ clo.restrictedC)
                        clo.restrictedC n.topoRank (extractStepFootprint n.step).parentNodeRefs =
                      verifyParentsAux (verifyNodeFuel f' Γ C)
                        C n.topoRank (extractStepFootprint n.step).parentNodeRefs := by
                    apply verifyParentsAux_congr n.topoRank
                    intro parId hPar
                    rcases validContainer_parent_rank hVal hLook hPar with ⟨par, hLookPar, hLt⟩
                    have hnb := hRankBound n hLook
                    have hk1Le : k + 1 ≤ maxTopoRank C + 1 := by omega
                    have hParIter : parId ∈ transNodeIter (k + 1) C [rootId] :=
                      parent_mem_expandNodeStep C (transNodeIter k C [rootId]) hIter hLook hPar
                    have hParReach : parId ∈ clo.reachNodeIds := by
                      show parId ∈ extractReachableNodeIds C rootId
                      unfold extractReachableNodeIds
                      rw [mem_canonSortStrs]
                      exact mem_transNodeIter_le C [rootId] hk1Le hParIter
                    refine ⟨lookup_restrictContainer_eq C clo.reachNodeIds hParReach, ?_⟩
                    apply ih parId
                    refine ⟨k + 1, hk1Le, hParIter, ?_⟩
                    intro par' hLookPar'
                    rw [hLookPar] at hLookPar'
                    injection hLookPar' with hpEq; subst hpEq
                    omega
                  rw [hParsEq]
  exact hAux fuel rootId ⟨0, Nat.zero_le _, List.mem_cons_self ..,
    fun n hL => by rw [Nat.zero_add]; exact topoRank_le_maxTopoRank (List.mem_of_find?_eq_some hL)⟩

/-- Preservation of `ValidContainer` under `extractCertifiedReachableClosure` when `rootId` exists in `C`. -/
theorem validContainer_restricted_of_root (Γ : PrimPremiseEnv) (C : G7DagContainer)
    {rootId : String} {nRoot : G7DagNode}
    (hVal : ValidContainer C) (hRoot : lookupDagNode? C rootId = some nRoot) :
    ValidContainer (extractCertifiedReachableClosure Γ C rootId).restrictedC := by
  let clo := extractCertifiedReachableClosure Γ C rootId
  have hIterBound : ∀ (k : Nat) (u : String),
      u ∈ transNodeIter k C [rootId] →
      ∃ (j : Nat) (nu : G7DagNode),
        j ≤ maxTopoRank C ∧
        u ∈ transNodeIter j C [rootId] ∧
        lookupDagNode? C u = some nu ∧
        j + nu.topoRank ≤ maxTopoRank C := by
    intro k
    induction k with
    | zero =>
        intro u hu
        rcases List.mem_cons.mp hu with rfl | hNil
        · exact ⟨0, nRoot, Nat.zero_le _, List.mem_cons_self .., hRoot,
            by rw [Nat.zero_add]; exact topoRank_le_maxTopoRank (List.mem_of_find?_eq_some hRoot)⟩
        · nomatch hNil
    | succ k' ih =>
        intro u hu
        have hStep : ∀ (cur : List String),
            (∀ w ∈ cur, ∃ (j : Nat) (nw : G7DagNode),
              j ≤ maxTopoRank C ∧ w ∈ transNodeIter j C [rootId] ∧
              lookupDagNode? C w = some nw ∧ j + nw.topoRank ≤ maxTopoRank C) →
            ∀ v ∈ expandNodeStep C cur,
              ∃ (j : Nat) (nv : G7DagNode),
                j ≤ maxTopoRank C ∧ v ∈ transNodeIter j C [rootId] ∧
                lookupDagNode? C v = some nv ∧ j + nv.topoRank ≤ maxTopoRank C := by
          intro cur hCur
          induction cur with
          | nil => intro _ hv; nomatch hv
          | cons a as ihCur =>
              intro v hv
              unfold expandNodeStep at hv
              simp only [List.foldr_cons, List.mem_cons, List.mem_append] at hv
              rcases hv with rfl | hPar | hRest
              · exact hCur v (List.mem_cons_self ..)
              · rcases hCur a (List.mem_cons_self ..) with ⟨ja, na, _, haIter, haLook, haBnd⟩
                rw [haLook] at hPar
                rcases validContainer_parent_rank hVal haLook hPar with ⟨par, hParLook, hLt⟩
                refine ⟨ja + 1, par, by omega,
                  parent_mem_expandNodeStep C (transNodeIter ja C [rootId]) haIter haLook hPar,
                  hParLook, by omega⟩
              · exact ihCur (fun w hw => hCur w (List.mem_cons_of_mem a hw)) v hRest
        exact hStep (transNodeIter k' C [rootId]) ih u hu
  have hValOrig : ValidContainer C := hVal
  unfold ValidContainer checkContainerIntegrityBool at hVal ⊢
  simp only [Bool.and_eq_true] at hVal ⊢
  refine ⟨nodupStrsBool_sublist_filter G7DagNode.nodeId
            (fun n => clo.reachNodeIds.contains n.nodeId) C.nodes hVal.1, ?_⟩
  apply List.all_eq_true.mpr
  intro n hn
  rcases List.mem_filter.mp hn with ⟨hnC, hnKeep⟩
  have hnOrig := List.all_eq_true.mp hVal.2 n hnC
  simp only [Bool.and_eq_true] at hnOrig ⊢
  refine ⟨hnOrig.1, ?_⟩
  apply List.all_eq_true.mpr
  intro parId hPar
  have hnInReach : n.nodeId ∈ clo.reachNodeIds := List.contains_iff_mem.mp hnKeep
  have hnIter : n.nodeId ∈ transNodeIter (maxTopoRank C + 1) C [rootId] := by
    have h := hnInReach
    unfold clo extractCertifiedReachableClosure extractReachableNodeIds at h
    exact (mem_canonSortStrs _ _).mp h
  rcases hIterBound (maxTopoRank C + 1) n.nodeId hnIter with ⟨jn, nu, _, hjnIter, hnuLook, hjnBnd⟩
  have hnLookSelf : lookupDagNode? C n.nodeId = some n := by
    unfold lookupDagNode?
    have hNodup : ∀ (L : List G7DagNode),
        nodupStrsBool (L.map (·.nodeId)) = true → n ∈ L →
        L.find? (fun y => y.nodeId == n.nodeId) = some n := by
      intro L hN hM
      induction L with
      | nil => nomatch hM
      | cons a as ihL =>
          simp only [List.map_cons, nodupStrsBool, Bool.and_eq_true] at hN
          rcases List.mem_cons.mp hM with rfl | hRest
          · simp [List.find?]
          · have hNe : (a.nodeId == n.nodeId) = false := by
              cases hb : (a.nodeId == n.nodeId) with
              | false => rfl
              | true =>
                  have hIn : a.nodeId ∈ as.map (·.nodeId) := by
                    rw [eq_of_beq hb]; exact List.mem_map_of_mem hRest
                  have hCont : (as.map (·.nodeId)).contains a.nodeId = true :=
                    List.contains_iff_mem.mpr hIn
                  rw [hCont] at hN; nomatch hN.1
            simp [List.find?, hNe]
            exact ihL hN.2 hRest
    exact hNodup C.nodes hVal.1 hnC
  rw [hnLookSelf] at hnuLook
  injection hnuLook with hnuEq; subst hnuEq
  rcases validContainer_parent_rank hValOrig hnLookSelf hPar with
    ⟨par, hParLook, hLt⟩
  have hParIter : parId ∈ transNodeIter (jn + 1) C [rootId] :=
    parent_mem_expandNodeStep C (transNodeIter jn C [rootId]) hjnIter hnLookSelf hPar
  have hjn1Le : jn + 1 ≤ maxTopoRank C + 1 := by omega
  have hParReach : parId ∈ clo.reachNodeIds := by
    show parId ∈ extractReachableNodeIds C rootId
    unfold extractReachableNodeIds
    rw [mem_canonSortStrs]
    exact mem_transNodeIter_le C [rootId] hjn1Le hParIter
  have hCloLook : lookupDagNode? (extractCertifiedReachableClosure Γ C rootId).restrictedC parId =
      lookupDagNode? C parId :=
    lookup_restrictContainer_eq C clo.reachNodeIds hParReach
  rw [hCloLook, hParLook]
  exact decide_eq_true hLt

private theorem verifyNodeFuel_accept_header {f : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    {nid : String} {out : VerifiedSequentOut}
    (hAcc : verifyNodeFuel f Γ C nid = .accept out) :
    ∃ n : G7DagNode, lookupDagNode? C nid = some n ∧
      out = ⟨n.domTag, n.specId, n.guards, n.conclusion⟩ := by
  cases f with
  | zero => nomatch hAcc
  | succ f' =>
      unfold verifyNodeFuel at hAcc
      cases hL : lookupDagNode? C nid with
      | none => rw [hL] at hAcc; nomatch hAcc
      | some n =>
          rw [hL] at hAcc; dsimp only at hAcc
          if hId : (n.nodeId != nid) = true then
            rw [if_pos hId] at hAcc; nomatch hAcc
          else
            rw [if_neg hId] at hAcc
            cases hS : checkNodeStepLocal Γ C n with
            | error _ => rw [hS] at hAcc; nomatch hAcc
            | ok _ =>
                rw [hS] at hAcc; dsimp only at hAcc
                cases hP : verifyParentsAux (verifyNodeFuel f' Γ C) C n.topoRank
                    (extractStepFootprint n.step).parentNodeRefs with
                | error _ => rw [hP] at hAcc; nomatch hAcc
                | ok opt =>
                    rw [hP] at hAcc
                    cases opt with
                    | some _ => nomatch hAcc
                    | none =>
                        injection hAcc with ho
                        exact ⟨n, rfl, ho.symm⟩

private theorem verifyParentsAux_all_accept {run : String → G7CheckResult}
    {C : G7DagContainer} {childRank : Nat} :
    ∀ (pars : List String),
      verifyParentsAux run C childRank pars = .ok none →
      ∀ parId ∈ pars, ∃ (par : G7DagNode) (parOut : VerifiedSequentOut),
        lookupDagNode? C parId = some par ∧
        par.topoRank < childRank ∧
        run parId = .accept parOut
  | [], _, _, hMem => nomatch hMem
  | p :: rest, hOk, parId, hMem => by
      unfold verifyParentsAux at hOk
      cases hL : lookupDagNode? C p with
      | none => rw [hL] at hOk; nomatch hOk
      | some par =>
          rw [hL] at hOk; dsimp only at hOk
          if hRk : (!(decide (par.topoRank < childRank))) = true then
            rw [if_pos hRk] at hOk; nomatch hOk
          else
            rw [if_neg hRk] at hOk
            have hLt : par.topoRank < childRank := by
              cases hd : decide (par.topoRank < childRank) with
              | true  => exact of_decide_eq_true hd
              | false => simp [hd] at hRk
            cases hRun : run p with
            | rejectInvalid _ => rw [hRun] at hOk; nomatch hOk
            | resourceHeld _  => rw [hRun] at hOk; nomatch hOk
            | accept pOut =>
                rw [hRun] at hOk
                rcases List.mem_cons.mp hMem with rfl | hTail
                · exact ⟨par, pOut, hL, hLt, hRun⟩
                · exact verifyParentsAux_all_accept rest hOk parId hTail

private theorem checkSingleGuardWf_sound {domTag : G7DomTag} {specId : String} {curRank : Nat}
    {Γ : PrimPremiseEnv} {C : G7DagContainer} {prefixGuards : List StrictForm}
    {γ : StrictForm} {wf : GuardWfWitness} {ρ : Env2}
    (hChk : checkSingleGuardWfBool domTag specId curRank Γ C prefixGuards γ wf = true)
    (hDom : inG7Dom domTag ρ)
    (hPref : ∀ g ∈ prefixGuards, ModelsStrictForm g ρ)
    (hPrimValid : ∀ pid ∈ (extractSingleGuardWfFootprint wf).primRefs, SemValidPrimId Γ pid)
    (hParValid : ∀ nid ∈ (extractSingleGuardWfFootprint wf).parentNodeRefs,
      ∀ par : G7DagNode, lookupDagNode? C nid = some par →
        SemValidSequent ⟨par.domTag, par.specId, par.guards, par.conclusion⟩) :
    FormDefined γ ρ := by
  cases wf with
  | totalPolyWf =>
      exact checkFormDefUnderNz_sound (fun _ h => False.elim (List.not_mem_nil h)) γ hChk
  | prefixGuardDenomWf den =>
      unfold checkSingleGuardWfBool at hChk
      simp only [Bool.and_eq_true] at hChk
      have hNz : ∀ d ∈ [den], ∃ vd : Rat, PartExprEvalRel d ρ vd ∧ vd ≠ 0 := by
        intro d hd
        rcases List.mem_cons.mp hd with rfl | hNil
        · simp only [Bool.or_eq_true, List.contains_iff_mem] at hChk
          rcases hChk.1 with hNeq | hPos
          · exact (hPref (.neqZero d) hNeq).2
          · rcases (hPref (.pos d) hPos).2 with ⟨vd, hr, hlt⟩
            exact ⟨vd, hr, Rat.ne_of_gt hlt⟩
        · nomatch hNil
      exact checkFormDefUnderNz_sound hNz γ hChk.2
  | domainIntrinsicNonzero =>
      unfold checkSingleGuardWfBool at hChk
      simp only [Bool.and_eq_true] at hChk
      have hdEq : domTag = .domQNonzero := eq_of_beq hChk.1
      subst hdEq
      have hNz : ∀ d ∈ [PartExpr.varX], ∃ vd : Rat, PartExprEvalRel d ρ vd ∧ vd ≠ 0 := by
        intro d hd
        rcases List.mem_cons.mp hd with rfl | hNil
        · exact ⟨ρ.1, .varX ρ, hDom.1⟩
        · nomatch hNil
      exact checkFormDefUnderNz_sound hNz γ hChk.2
  | externalPremiseDenomWf pid den =>
      dsimp only [checkSingleGuardWfBool] at hChk
      cases hPe : lookupPrimPrem? Γ pid with
      | none => rw [hPe] at hChk; nomatch hChk
      | some pe =>
          rw [hPe] at hChk; dsimp only at hChk
          simp only [Bool.and_eq_true] at hChk
          rcases hChk with ⟨⟨⟨⟨hDomEq, _⟩, hFormOr⟩, _⟩, hDefγ⟩
          have hSemPe := hPrimValid pid (List.mem_cons_self ..) pe hPe ρ
            (by rwa [eq_of_beq hDomEq])
          have hNz : ∀ d ∈ [den], ∃ vd : Rat, PartExprEvalRel d ρ vd ∧ vd ≠ 0 := by
            intro d hd
            rcases List.mem_cons.mp hd with rfl | hNil
            · simp only [Bool.or_eq_true] at hFormOr
              rcases hFormOr with hFNeq | hFPos
              · rw [eq_of_beq hFNeq] at hSemPe
                exact hSemPe.2
              · rw [eq_of_beq hFPos] at hSemPe
                rcases hSemPe.2 with ⟨vd, hr, hlt⟩
                exact ⟨vd, hr, Rat.ne_of_gt hlt⟩
            · nomatch hNil
          exact checkFormDefUnderNz_sound hNz γ hDefγ
  | parentNodeDenomWf nid den =>
      dsimp only [checkSingleGuardWfBool] at hChk
      cases hPar : lookupDagNode? C nid with
      | none => rw [hPar] at hChk; nomatch hChk
      | some par =>
          rw [hPar] at hChk; dsimp only at hChk
          simp only [Bool.and_eq_true] at hChk
          rcases hChk with ⟨⟨⟨⟨⟨⟨_, hDomEq⟩, _⟩, hGuardsNil⟩, hConcOr⟩, _⟩, hDefγ⟩
          have hSemPar := (hParValid nid (List.mem_cons_self ..) par hPar).2 ρ
            (by rwa [eq_of_beq hDomEq])
            (by rw [eq_of_beq hGuardsNil]; intro _ h; nomatch h)
          have hNz : ∀ d ∈ [den], ∃ vd : Rat, PartExprEvalRel d ρ vd ∧ vd ≠ 0 := by
            intro d hd
            rcases List.mem_cons.mp hd with rfl | hNil
            · simp only [Bool.or_eq_true] at hConcOr
              rcases hConcOr with hCNeq | hCPos
              · rw [eq_of_beq hCNeq] at hSemPar
                exact hSemPar.2
              · rw [eq_of_beq hCPos] at hSemPar
                rcases hSemPar.2 with ⟨vd, hr, hlt⟩
                exact ⟨vd, hr, Rat.ne_of_gt hlt⟩
            · nomatch hNil
          exact checkFormDefUnderNz_sound hNz γ hDefγ

/-- Soundness of sequential guard telescope checking (`checkGuardsPrefixDefinedAux_sound`). -/
theorem checkGuardsPrefixDefinedAux_sound {domTag : G7DomTag} {specId : String} {curRank : Nat}
    {Γ : PrimPremiseEnv} {C : G7DagContainer} {ρ : Env2} (hDom : inG7Dom domTag ρ) :
    ∀ (prefixGuards γs : List StrictForm) (wfs : List GuardWfWitness),
      checkGuardsPrefixDefinedAux domTag specId curRank Γ C prefixGuards γs wfs = true →
      (∀ g ∈ prefixGuards, ModelsStrictForm g ρ) →
      (∀ pid ∈ (extractGuardWfFootprint wfs).primRefs, SemValidPrimId Γ pid) →
      (∀ nid ∈ (extractGuardWfFootprint wfs).parentNodeRefs,
        ∀ par : G7DagNode, lookupDagNode? C nid = some par →
          SemValidSequent ⟨par.domTag, par.specId, par.guards, par.conclusion⟩) →
      TelescopicGuardsDefined γs ρ
  | _, [], [], _, _, _, _ => trivial
  | _, [], _ :: _, hChk, _, _, _ => nomatch hChk
  | _, _ :: _, [], hChk, _, _, _ => nomatch hChk
  | prefixGuards, γ :: γs, wf :: wfs, hChk, hPref, hPrim, hPar => by
      unfold checkGuardsPrefixDefinedAux at hChk
      simp only [Bool.and_eq_true] at hChk
      have hDefγ : FormDefined γ ρ :=
        checkSingleGuardWf_sound hChk.1 hDom hPref
          (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
          (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))
      refine ⟨hDefγ, ?_⟩
      intro hSatγ
      apply checkGuardsPrefixDefinedAux_sound hDom (prefixGuards ++ [γ]) γs wfs hChk.2
      · intro g hg
        rcases List.mem_append.mp hg with hgOld | hgNew
        · exact hPref g hgOld
        · rcases List.mem_cons.mp hgNew with rfl | hNil
          · exact hSatγ
          · nomatch hNil
      · exact fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp))
      · exact fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu))

/-- Soundness of `checkLocalDerivBool` (`F-B2A-01` & `F-B2A-03`). -/
theorem checkLocalDeriv_sound {domTag : G7DomTag} {specId : String} {curRank : Nat}
    {Γ : PrimPremiseEnv} {C : G7DagContainer} {guards : List StrictForm} {ρ : Env2}
    (hDom : inG7Dom domTag ρ)
    (hSatGuards : ∀ γ ∈ guards, ModelsStrictForm γ ρ) :
    ∀ (d : LocalDeriv) (goal : StrictForm),
      checkLocalDerivBool domTag specId curRank Γ C guards d goal = true →
      (∀ pid ∈ (extractDerivFootprint d).primRefs, SemValidPrimId Γ pid) →
      (∀ nid ∈ (extractDerivFootprint d).parentNodeRefs,
        ∀ par : G7DagNode, lookupDagNode? C nid = some par →
          SemValidSequent ⟨par.domTag, par.specId, par.guards, par.conclusion⟩) →
      ModelsStrictForm goal ρ
  | .hypGuard idx φ, goal, hChk, _, _ => by
      unfold checkLocalDerivBool at hChk
      simp only [Bool.and_eq_true] at hChk
      rw [← eq_of_beq hChk.1]
      have hGet : guards[idx]? = some φ := eq_of_beq hChk.2
      have hMem : φ ∈ guards := by
        have hAux : ∀ (L : List StrictForm) (i : Nat), L[i]? = some φ → φ ∈ L := by
          intro L
          induction L with
          | nil => intro _ h; nomatch h
          | cons a as ihL =>
              intro i h
              cases i with
              | zero => injection h with ha; subst ha; exact List.mem_cons_self ..
              | succ k => exact List.mem_cons_of_mem a (ihL k h)
        exact hAux guards idx hGet
      exact hSatGuards φ hMem
  | .primPrem pid φ, goal, hChk, hPrim, _ => by
      unfold checkLocalDerivBool at hChk
      simp only [Bool.and_eq_true] at hChk
      rw [← eq_of_beq hChk.1]
      cases hPe : lookupPrimPrem? Γ pid with
      | none => rw [hPe] at hChk; nomatch hChk.2
      | some pe =>
          rw [hPe] at hChk
          simp only [Bool.and_eq_true] at hChk
          rcases hChk.2 with ⟨⟨⟨hDomEq, _⟩, hFormEq⟩, _⟩
          have hValid := hPrim pid (List.mem_cons_self ..) pe hPe ρ (by rwa [eq_of_beq hDomEq])
          rwa [← eq_of_beq hFormEq]
  | .parentRef nid φ, goal, hChk, _, hPar => by
      unfold checkLocalDerivBool at hChk
      simp only [Bool.and_eq_true] at hChk
      rw [← eq_of_beq hChk.1]
      cases hLook : lookupDagNode? C nid with
      | none => rw [hLook] at hChk; nomatch hChk.2
      | some par =>
          rw [hLook] at hChk
          simp only [Bool.and_eq_true] at hChk
          rcases hChk.2 with ⟨⟨⟨⟨_, hDomEq⟩, _⟩, hConcEq⟩, hGuardsSub⟩
          have hParSem := (hPar nid (List.mem_cons_self ..) par hLook).2 ρ
            (by rwa [eq_of_beq hDomEq])
          rw [← eq_of_beq hConcEq]
          apply hParSem
          intro g hg
          have hCont := List.all_eq_true.mp hGuardsSub g hg
          exact hSatGuards g (List.contains_iff_mem.mp hCont)
  | .certStep φ cert, goal, hChk, _, _ => by
      unfold checkLocalDerivBool at hChk
      simp only [Bool.and_eq_true] at hChk
      rw [← eq_of_beq hChk.1]
      exact checkAlgDomCert_sound hChk.2 hDom hSatGuards
  | .strictMP φ ψ d1 d2, goal, hChk, hPrim, hPar => by
      unfold checkLocalDerivBool at hChk
      simp only [Bool.and_eq_true] at hChk
      rcases hChk with ⟨⟨hEq, h1⟩, h2⟩
      rw [← eq_of_beq hEq]
      have hm1 := checkLocalDeriv_sound hDom hSatGuards d1 φ h1
        (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
        (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))
      have hm2 := checkLocalDeriv_sound hDom hSatGuards d2 (.impStrict φ ψ) h2
        (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
        (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))
      exact strictMPStep_sound hm1 hm2
  | .conjIntro φ ψ d1 d2, goal, hChk, hPrim, hPar => by
      unfold checkLocalDerivBool at hChk
      simp only [Bool.and_eq_true] at hChk
      rcases hChk with ⟨⟨hEq, h1⟩, h2⟩
      rw [eq_of_beq hEq]
      have hm1 := checkLocalDeriv_sound hDom hSatGuards d1 φ h1
        (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
        (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))
      have hm2 := checkLocalDeriv_sound hDom hSatGuards d2 ψ h2
        (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
        (fun u hu => hPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))
      exact And.intro ⟨hm1.1, hm2.1⟩ ⟨hm1.2, hm2.2⟩

/-- **`T2` Non-Circular DAG Master Soundness Theorem (`verifyReachable_master_sound`)**:
    Under `ValidContainer C`, whenever `verifyReachableDerivation fuel Γ C rootId = .accept out`
    and every transitive primitive premise `p ∈ extractTransitivePrimDeps Γ C rootId` satisfies
    `SemValidPrimId Γ p`, `SemValidSequent out` holds! -/
theorem verifyReachable_master_sound (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (rootId : String) (out : VerifiedSequentOut)
    (_hVal : ValidContainer C)
    (hAcc : verifyReachableDerivation fuel Γ C rootId = .accept out)
    (hPrimSem : ∀ p ∈ extractTransitivePrimDeps Γ C rootId, SemValidPrimId Γ p) :
    SemValidSequent out := by
  let reachIds := extractReachableNodeIds C rootId
  have hInd : ∀ (f : Nat) (nid : String) (o : VerifiedSequentOut),
      (∃ k : Nat, k ≤ maxTopoRank C + 1 ∧ nid ∈ transNodeIter k C [rootId] ∧
        (∀ n : G7DagNode, lookupDagNode? C nid = some n → k + n.topoRank ≤ maxTopoRank C)) →
      verifyNodeFuel f Γ C nid = .accept o →
      SemValidSequent o := by
    intro f
    induction f with
    | zero => intro _ _ _ hA; nomatch hA
    | succ f' ih =>
        intro nid o ⟨k, hkLe, hIter, hRankBnd⟩ hA
        have hInReach : nid ∈ reachIds := by
          unfold reachIds extractReachableNodeIds
          rw [mem_canonSortStrs]
          exact mem_transNodeIter_le C [rootId] hkLe hIter
        unfold verifyNodeFuel at hA
        cases hLook : lookupDagNode? C nid with
        | none => rw [hLook] at hA; nomatch hA
        | some n =>
            rw [hLook] at hA; dsimp only at hA
            if hId : (n.nodeId != nid) = true then
              rw [if_pos hId] at hA; nomatch hA
            else
              rw [if_neg hId] at hA
              cases hLoc : checkNodeStepLocal Γ C n with
              | error _ => rw [hLoc] at hA; nomatch hA
              | ok _ =>
                  rw [hLoc] at hA; dsimp only at hA
                  cases hPars : verifyParentsAux (verifyNodeFuel f' Γ C) C n.topoRank
                      (extractStepFootprint n.step).parentNodeRefs with
                  | error _ => rw [hPars] at hA; nomatch hA
                  | ok opt =>
                      rw [hPars] at hA
                      cases opt with
                      | some _ => dsimp only at hA; nomatch hA
                      | none =>
                          dsimp only at hA
                          injection hA with hoEq; subst hoEq
                          have hAllPrim : ∀ pid ∈ (extractStepFootprint n.step).primRefs,
                              SemValidPrimId Γ pid := by
                            intro pid hp
                            have hDir := prim_mem_collectDirectPrimRefs C reachIds hInReach hLook hp
                            exact hPrimSem pid (direct_mem_depsStarCanon (toPremDag Γ) _ hDir)
                          have hAllPar : ∀ parId ∈ (extractStepFootprint n.step).parentNodeRefs,
                              ∀ par : G7DagNode, lookupDagNode? C parId = some par →
                                SemValidSequent ⟨par.domTag, par.specId, par.guards, par.conclusion⟩ := by
                            intro parId hParMem par hParLook
                            rcases verifyParentsAux_all_accept _ hPars parId hParMem with
                              ⟨par0, parOut, hParLook0, hLt, hRunAcc⟩
                            rcases verifyNodeFuel_accept_header hRunAcc with ⟨par1, hParLook1, hOutEq⟩
                            rw [hParLook] at hParLook0 hParLook1
                            injection hParLook0 with heq0; subst heq0
                            injection hParLook1 with heq1; subst heq1
                            have hnb := hRankBnd n hLook
                            have hk1Le : k + 1 ≤ maxTopoRank C + 1 := by omega
                            have hParIter : parId ∈ transNodeIter (k + 1) C [rootId] :=
                              parent_mem_expandNodeStep C (transNodeIter k C [rootId]) hIter hLook hParMem
                            have hSemOut := ih parId parOut ⟨k + 1, hk1Le, hParIter, fun p' hp' => by
                              rw [hParLook] at hp'; injection hp' with hpe; subst hpe; omega⟩ hRunAcc
                            rwa [hOutEq] at hSemOut
                          unfold checkNodeStepLocal at hLoc
                          cases hs : n.step with
                          | directDerivStep d =>
                              rw [hs] at hLoc hAllPrim hAllPar; dsimp only at hLoc
                              if hG : (n.guards != []) = true then
                                rw [if_pos hG] at hLoc; nomatch hLoc
                              else
                                rw [if_neg hG] at hLoc
                                have hNil : n.guards = [] := by
                                  cases hb : (n.guards == []) with
                                  | true  => exact eq_of_beq hb
                                  | false => simp [bne, hb] at hG
                                if hD : checkLocalDerivBool n.domTag n.specId n.topoRank Γ C [] d n.conclusion = true then
                                  refine ⟨?_, ?_⟩
                                  · intro ρ _; rw [hNil]; trivial
                                  · intro ρ hDom _
                                    exact checkLocalDeriv_sound hDom
                                      (fun _ h => False.elim (List.not_mem_nil h))
                                      d n.conclusion hD hAllPrim hAllPar
                                else
                                  rw [if_neg hD] at hLoc; nomatch hLoc
                          | guardedDomStep cert =>
                              rw [hs] at hLoc hAllPrim hAllPar; dsimp only at hLoc
                              if hHdr : (!(cert.domTag == n.domTag && cert.guards == n.guards &&
                                          cert.goalForm == n.conclusion)) = true then
                                rw [if_pos hHdr] at hLoc; nomatch hLoc
                              else
                                rw [if_neg hHdr] at hLoc
                                have hHdrOk : (cert.domTag == n.domTag && cert.guards == n.guards &&
                                    cert.goalForm == n.conclusion) = true := by
                                  cases hb : (cert.domTag == n.domTag && cert.guards == n.guards &&
                                      cert.goalForm == n.conclusion) with
                                  | true  => rfl
                                  | false => simp [hb] at hHdr
                                simp only [Bool.and_eq_true] at hHdrOk
                                rcases hHdrOk with ⟨⟨hDomEq, hGuardsEq⟩, hGoalEq⟩
                                if hGWf : (!checkGuardsPrefixDefinedBool cert.domTag n.specId n.topoRank
                                            Γ C cert.guards cert.guardWfCerts) = true then
                                  rw [if_pos hGWf] at hLoc; nomatch hLoc
                                else
                                  rw [if_neg hGWf] at hLoc
                                  have hGWfOk : checkGuardsPrefixDefinedBool cert.domTag n.specId n.topoRank
                                      Γ C cert.guards cert.guardWfCerts = true := by
                                    cases hb : checkGuardsPrefixDefinedBool cert.domTag n.specId n.topoRank
                                        Γ C cert.guards cert.guardWfCerts with
                                    | true  => rfl
                                    | false => simp [hb] at hGWf
                                  if hGCtx : (!checkGuardCtxEvidenceBool cert.domTag n.specId n.topoRank
                                               Γ C cert.guardContextEvidence) = true then
                                    rw [if_pos hGCtx] at hLoc; nomatch hLoc
                                  else
                                    rw [if_neg hGCtx] at hLoc
                                    if hGoal : checkLocalDerivBool cert.domTag n.specId n.topoRank Γ C
                                                cert.guards cert.goalDeriv cert.goalForm = true then
                                      rw [← eq_of_beq hDomEq, ← eq_of_beq hGuardsEq, ← eq_of_beq hGoalEq]
                                      refine ⟨?_, ?_⟩
                                      · intro ρ hDom
                                        exact checkGuardsPrefixDefinedAux_sound hDom [] cert.guards
                                          cert.guardWfCerts hGWfOk
                                          (fun _ h => False.elim (List.not_mem_nil h))
                                          (fun p hp => hAllPrim p ((mem_unionFootprint_prim _ _ p).mpr
                                            (Or.inr ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))))
                                          (fun u hu => hAllPar u ((mem_unionFootprint_parent _ _ u).mpr
                                            (Or.inr ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))))
                                      · intro ρ hDom hSatG
                                        exact checkLocalDeriv_sound hDom hSatG cert.goalDeriv cert.goalForm hGoal
                                          (fun p hp => hAllPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
                                          (fun u hu => hAllPar u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))
                                    else
                                      rw [if_neg hGoal] at hLoc; nomatch hLoc
  exact hInd fuel rootId out ⟨0, Nat.zero_le _, List.mem_cons_self ..,
    fun n hL => by rw [Nat.zero_add]; exact topoRank_le_maxTopoRank (List.mem_of_find?_eq_some hL)⟩ hAcc

private theorem verifyParentsAux_mono_accept {run1 run2 : String → G7CheckResult}
    {C : G7DagContainer} {childRank : Nat}
    (hMono : ∀ p, ∀ out, run1 p = .accept out → run2 p = .accept out) :
    ∀ pars, verifyParentsAux run1 C childRank pars = .ok none →
            verifyParentsAux run2 C childRank pars = .ok none
  | [], _ => rfl
  | parId :: rest, h1 => by
      unfold verifyParentsAux at h1 ⊢
      cases hL : lookupDagNode? C parId with
      | none => rw [hL] at h1; nomatch h1
      | some par =>
          rw [hL] at h1; dsimp only at h1 ⊢
          if hRk : (!(decide (par.topoRank < childRank))) = true then
            rw [if_pos hRk] at h1; nomatch h1
          else
            rw [if_neg hRk] at h1 ⊢
            cases hR1 : run1 parId with
            | rejectInvalid _ => rw [hR1] at h1; nomatch h1
            | resourceHeld _  => rw [hR1] at h1; nomatch h1
            | accept pOut =>
                rw [hR1] at h1
                rw [hMono parId pOut hR1]
                exact verifyParentsAux_mono_accept hMono rest h1

/-- **`T3` Fuel Monotonicity Stability (`verifyReachable_fuel_monotone_accept`)**:
    Once `verifyReachableDerivation f1 Γ C rootId = .accept out`, increasing fuel to any `f2 ≥ f1`
    yields the exact same `.accept out` (`ResourceHeld` is a pure bottom approximation!). -/
theorem verifyReachable_fuel_monotone_accept {f1 f2 : Nat} (hLe : f1 ≤ f2)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (rootId : String) (out : VerifiedSequentOut)
    (hAcc : verifyReachableDerivation f1 Γ C rootId = .accept out) :
    verifyReachableDerivation f2 Γ C rootId = .accept out := by
  have hNodeMono : ∀ (a b : Nat), a ≤ b → ∀ (nid : String) (o : VerifiedSequentOut),
      verifyNodeFuel a Γ C nid = .accept o → verifyNodeFuel b Γ C nid = .accept o := by
    intro a
    induction a with
    | zero => intro _ _ _ _ hA; nomatch hA
    | succ a' ih =>
        intro b hab nid o hA
        cases b with
        | zero => omega
        | succ b' =>
            have hab' : a' ≤ b' := by omega
            unfold verifyNodeFuel at hA ⊢
            cases hL : lookupDagNode? C nid with
            | none => rw [hL] at hA; nomatch hA
            | some n =>
                rw [hL] at hA; dsimp only at hA ⊢
                if hId : (n.nodeId != nid) = true then
                  rw [if_pos hId] at hA; nomatch hA
                else
                  rw [if_neg hId] at hA ⊢
                  cases hS : checkNodeStepLocal Γ C n with
                  | error _ => rw [hS] at hA; nomatch hA
                  | ok _ =>
                      rw [hS] at hA; dsimp only at hA ⊢
                      cases hP : verifyParentsAux (verifyNodeFuel a' Γ C) C n.topoRank
                          (extractStepFootprint n.step).parentNodeRefs with
                      | error _ => rw [hP] at hA; nomatch hA
                      | ok opt =>
                          rw [hP] at hA
                          cases opt with
                          | some _ => nomatch hA
                          | none =>
                              have hP2 := verifyParentsAux_mono_accept
                                (fun p po hp => ih b' hab' p po hp)
                                (extractStepFootprint n.step).parentNodeRefs hP
                              rw [hP2]
                              exact hA
  exact hNodeMono f1 f2 hLe rootId out hAcc

/-! ### 6. Concrete Guarded & DAG Fixtures + Theorems `T-B2A-02`, `T-B2A-05`, & `T-B2A-06` -/

/-- Sequential guard certificate (`Tribunal §2`): `γ₁ : x ≠ 0, γ₂ : 1/x > 0 ⊢ x > 0` on `ℚ`. -/
def certSeqRecipPos : GuardedDomainCert where
  domTag               := .domQ
  guards               := [.neqZero .varX, .pos (.div (.const 1) .varX)]
  goalForm             := .pos .varX
  guardWfCerts         := [.totalPolyWf, .prefixGuardDenomWf .varX]
  guardContextEvidence := .selfContainedCtx
  goalDeriv            := .certStep (.pos .varX)
                            (.guardedReciprocal (.posOfNeqZeroAndRecipPos .varX))

/-- Adversarial bogus-goal guarded certificate (`F-B2A-01`): `x ≠ 0 ⊢ -x^2 > 0` on `ℚ`. -/
def certBogusNegSqPos : GuardedDomainCert where
  domTag               := .domQ
  guards               := [.neqZero .varX]
  goalForm             := .pos (.neg (.mul .varX .varX))
  guardWfCerts         := [.totalPolyWf]
  guardContextEvidence := .selfContainedCtx
  goalDeriv            := .certStep (.pos (.neg (.mul .varX .varX)))
                            (.polyPositivstellensatz ⟨1, 0, [(1, .pVarX)], [], [], []⟩)

/-- Adversarial out-of-order guard certificate (`Tribunal §2`): `γ₁ : 1/x > 0` without prior `x ≠ 0`! -/
def certUnorderedBadGuard : GuardedDomainCert where
  domTag               := .domQ
  guards               := [.pos (.div (.const 1) .varX)]
  goalForm             := .nonneg (.mul .varX .varX)
  guardWfCerts         := [.prefixGuardDenomWf .varX]
  guardContextEvidence := .selfContainedCtx
  goalDeriv            := .certStep (.nonneg (.mul .varX .varX))
                            (.polyPositivstellensatz ⟨1, 0, [(1, .pVarX)], [], [], []⟩)

/-- **`Tribunal §3.A` Spotlight Certificate (`certExtPremGuardWf`)**:
    Guard `γ₁ : 1/x > 0` has definedness certified by external premise `"p_nz"` (`x ≠ 0`),
    while `goalDeriv` proves `x^2 ≥ 0` WITHOUT referencing `"p_nz"`! -/
def certExtPremGuardWf : GuardedDomainCert where
  domTag               := .domQ
  guards               := [.pos (.div (.const 1) .varX)]
  goalForm             := .nonneg (.mul .varX .varX)
  guardWfCerts         := [.externalPremiseDenomWf "p_nz" .varX]
  guardContextEvidence := .citedPremiseCtx ["p_ctx"]
  goalDeriv            := .certStep (.nonneg (.mul .varX .varX))
                            (.polyPositivstellensatz ⟨1, 0, [(1, .pVarX)], [], [], []⟩)

/-- Premise environment for `Tribunal §3.A` & `T-B2A-06` tests. -/
def stdG7PrimEnv : PrimPremiseEnv :=
  [ ⟨"p0_anc", .domQ, "spec_v1", .nonneg (.const 1), []⟩
  , ⟨"p1_leaf", .domQ, "spec_v1", .pos (.const 1), ["p0_anc"]⟩
  , ⟨"p_nz", .domQ, "spec_v1", .neqZero .varX, []⟩
  , ⟨"p_ctx", .domQ, "spec_v1", .nonneg (.const 0), []⟩ ]

/-- **`T-B2A-02` — `GuardedDomainCert` `goalDeriv` Soundness, Sequential Prefix Guard Definedness,
    & Complete `guardWfCerts ∪ guardContextEvidence` Dependency Closure (`Tribunal §2 & §3.A`)**:
    (1) `certSeqRecipPos` (`γ₁ : x ≠ 0, γ₂ : 1/x > 0 ⊢ x > 0`) is accepted by `verifyReachableDerivation`,
        is purely self-contained (`extraRefs = ⟨[], []⟩`), satisfies `TelescopicGuardsDefined` on ALL `ℚ`
        (including `x = 0` without evaluating `1/0`!), and guarantees `ModelsStrictForm (.pos .varX)`
        on every `x ∈ ℚ` satisfying `x ≠ 0 ∧ 1/x > 0`;
    (2) Bogus-goal `certBogusNegSqPos` (`x ≠ 0 ⊢ -x^2 > 0`) and unguarded-reciprocal `certUnorderedBadGuard`
        (`γ₁ : 1/x > 0` without prior `x ≠ 0`) are both deterministically rejected;
    (3) **Exact `Tribunal §3.A` Equation**: for EVERY `cert : GuardedDomainCert`,
        `extractStepFootprint (.guardedDomStep cert) =
          unionFootprint (extractDerivFootprint cert.goalDeriv)
            (unionFootprint (extractGuardWfFootprint cert.guardWfCerts)
                            (extractGuardCtxFootprint cert.guardContextEvidence))`,
        capturing BOTH `"p_nz"` (`guardWfCerts`) and `"p_ctx"` (`guardContextEvidence`) in
        `certExtPremGuardWf` even though `(extractDerivFootprint certExtPremGuardWf.goalDeriv).primRefs = []`! -/
theorem T_B2A_02_guarded_goalDeriv_soundness_and_full_wf_dependency_closure :
    let C_seq : G7DagContainer :=
      ⟨[⟨"n_seq", 0, .domQ, "spec_v1", certSeqRecipPos.guards, certSeqRecipPos.goalForm,
         .guardedDomStep certSeqRecipPos⟩]⟩
    let C_bogus : G7DagContainer :=
      ⟨[⟨"n_bogus", 0, .domQ, "spec_v1", certBogusNegSqPos.guards, certBogusNegSqPos.goalForm,
         .guardedDomStep certBogusNegSqPos⟩]⟩
    let C_bad_ord : G7DagContainer :=
      ⟨[⟨"n_bad_ord", 0, .domQ, "spec_v1", certUnorderedBadGuard.guards, certUnorderedBadGuard.goalForm,
         .guardedDomStep certUnorderedBadGuard⟩]⟩
    let C_ext_wf : G7DagContainer :=
      ⟨[⟨"n_ext_wf", 0, .domQ, "spec_v1", certExtPremGuardWf.guards, certExtPremGuardWf.goalForm,
         .guardedDomStep certExtPremGuardWf⟩]⟩
    -- (1) Sequential guard acceptance + semantic soundness + self-contained empty extra refs
    (verifyReachableDerivation 3 [] C_seq "n_seq" =
       .accept ⟨.domQ, "spec_v1", certSeqRecipPos.guards, certSeqRecipPos.goalForm⟩ ∧
     SemValidSequent ⟨.domQ, "spec_v1", certSeqRecipPos.guards, certSeqRecipPos.goalForm⟩ ∧
     extractGuardWfFootprint certSeqRecipPos.guardWfCerts = ⟨[], []⟩ ∧
     extractGuardCtxFootprint certSeqRecipPos.guardContextEvidence = ⟨[], []⟩) ∧
    -- (2) Bogus goal under valid guard & unguarded partial division in guard both rejected
    (verifyReachableDerivation 3 [] C_bogus "n_bogus" = .rejectInvalid .localDerivFailed ∧
     verifyReachableDerivation 3 [] C_bad_ord "n_bad_ord" = .rejectInvalid .guardWfFailed) ∧
    -- (3) Exact Tribunal §3.A union law + external guard-WF & context premise capture
    (∀ cert : GuardedDomainCert,
      extractStepFootprint (.guardedDomStep cert) =
        unionFootprint (extractDerivFootprint cert.goalDeriv)
          (unionFootprint (extractGuardWfFootprint cert.guardWfCerts)
                          (extractGuardCtxFootprint cert.guardContextEvidence))) ∧
    ((extractDerivFootprint certExtPremGuardWf.goalDeriv).primRefs = [] ∧
     "p_nz" ∈ extractTransitivePrimDeps stdG7PrimEnv C_ext_wf "n_ext_wf" ∧
     "p_ctx" ∈ extractTransitivePrimDeps stdG7PrimEnv C_ext_wf "n_ext_wf") := by
  dsimp only
  let C_seq : G7DagContainer :=
    ⟨[⟨"n_seq", 0, .domQ, "spec_v1", certSeqRecipPos.guards, certSeqRecipPos.goalForm,
       .guardedDomStep certSeqRecipPos⟩]⟩
  have hValSeq : ValidContainer C_seq := by decide
  have hAccSeq : verifyReachableDerivation 3 [] C_seq "n_seq" =
      .accept ⟨.domQ, "spec_v1", certSeqRecipPos.guards, certSeqRecipPos.goalForm⟩ := by decide
  have hSemSeq : SemValidSequent ⟨.domQ, "spec_v1", certSeqRecipPos.guards, certSeqRecipPos.goalForm⟩ :=
    verifyReachable_master_sound 3 [] C_seq "n_seq" _ hValSeq hAccSeq
      (fun _ h => False.elim (List.not_mem_nil h))
  have hEmpty := selfContainedGuardWf_extraRefs_empty certSeqRecipPos (by decide)
  exact ⟨⟨hAccSeq, hSemSeq, hEmpty.1, hEmpty.2⟩,
         ⟨by decide, by decide⟩,
         fun _ => rfl,
         ⟨rfl, by decide, by decide⟩⟩

/-- Multi-node DAG fixture with unreachable nodes (`T-B2A-05` `T1` separation & fuel tests). -/
def dagMultiWithUnreachGood : G7DagContainer where
  nodes :=
    [ ⟨"n_lem", 0, .domQ, "spec_v1", [], .pos (.const 1),
        .directDerivStep (.primPrem "p1_leaf" (.pos (.const 1)))⟩
    , ⟨"n_root", 1, .domQ, "spec_v1", [],
        .conj (.pos (.const 1)) (.nonneg (.mul .varX .varX)),
        .directDerivStep (.conjIntro (.pos (.const 1)) (.nonneg (.mul .varX .varX))
          (.parentRef "n_lem" (.pos (.const 1)))
          (.certStep (.nonneg (.mul .varX .varX))
            (.polyPositivstellensatz ⟨1, 0, [(1, .pVarX)], [], [], []⟩)))⟩
    , ⟨"n_unreach_1", 0, .domQ, "spec_v1", [], .nonneg (.const 0),
        .directDerivStep (.primPrem "p_ctx" (.nonneg (.const 0)))⟩
    , ⟨"n_unreach_2", 0, .domQ, "spec_v1", [], .nonneg (.const 0),
        .directDerivStep (.primPrem "p_ctx" (.nonneg (.const 0)))⟩
    , ⟨"n_unreach_3", 0, .domQ, "spec_v1", [], .nonneg (.const 0),
        .directDerivStep (.primPrem "p_ctx" (.nonneg (.const 0)))⟩ ]

/-- Container with duplicate IDs `"n_dup_unreach"` strictly outside `"n_root"`'s reachable closure
    (`Tribunal §3.B` constructive witness for `Verify_global ≠ Verify_reachable`!). -/
def dagWithUnreachDupBad : G7DagContainer where
  nodes :=
    dagMultiWithUnreachGood.nodes ++
    [ ⟨"n_dup_unreach", 0, .domQ, "spec_v1", [], .nonneg (.const 0),
        .directDerivStep (.certStep (.nonneg (.const 0))
          (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩))⟩
    , ⟨"n_dup_unreach", 0, .domQ, "spec_v1", [], .pos (.const 1),
        .directDerivStep (.certStep (.pos (.const 1))
          (.polyPositivstellensatz ⟨1, 1, [], [], [], []⟩))⟩ ]

/-- **`T-B2A-05` — `G7` `T1` (Global-vs-Reachable Separation & `T1_ReachableInvariance`),
    `T2` (Non-Circular DAG Induction Master Soundness), & `T3` (Fuel Monotonicity & Resource Safety)**:
    (1) **`T1a` (`Verify_global ≠ Verify_reachable` when `ValidContainer` fails outside lightcone)**:
        On `dagWithUnreachDupBad`, `verifyGlobalWithFuel` rejects with `.containerIntegrityFailed`,
        whereas restricting to `ReachableNodes*` removes the unreachable duplicate IDs and passes
        BOTH `ValidContainer` and `verifyGlobalWithFuel` (`= .accept _`);
    (2) **`T1b` (`ResourceHeld` fuel shrinkage on pruned containers)**:
        On valid `dagMultiWithUnreachGood` (`5` nodes vs `2` reachable nodes), at `fuel = 5`,
        `verifyGlobalWithFuel 5` on full `C` returns `.resourceHeld 0` (`5 - 5 = 0` root fuel),
        whereas on `C|_{ReachableNodes*}` (`2` nodes, `5 - 2 = 3` root fuel) it returns `.accept _`;
    (3) **`T1c` (`T1_ReachableInvariance` — `Tribunal §3.B` Boxed Law)**:
        For ANY `Γ`, `C`, `rootId`, `fuel1`, `fuel2` with `ValidContainer C` and sufficient fuel
        (`fuel1 ≥ C.nodes.length + reqFuel`, `fuel2 ≥ clo.restrictedC.nodes.length + reqFuel`),
        `verifyReachableDerivation` is IDENTICAL on `(Γ, C)` and `(Γ|_{PrimDeps*}, C|_{ReachableNodes*})`,
        and `verifyGlobalWithFuel` root acceptance (`= .accept out`) is strictly equivalent (`↔`)!
    (4) **`T2` (`T2_DAGMasterSoundness`)**: `ValidContainer C` + `verifyReachableDerivation = .accept out`
        + `SemValidPrimId Γ` on `PrimDeps*` implies `SemValidSequent out`;
    (5) **`T3` (`T3_FuelDeterminismAndResourceSafety`)**: `verifyReachableDerivation` is deterministic,
        monotone-stable on `.accept out` for all `f2 ≥ f1`, and `.resourceHeld` never implies semantic falsehood. -/
theorem T_B2A_05_G7_T1_reachable_invariance_T2_master_soundness_T3_fuel_laws :
    let cloBad := extractCertifiedReachableClosure stdG7PrimEnv dagWithUnreachDupBad "n_root"
    let cloGood := extractCertifiedReachableClosure stdG7PrimEnv dagMultiWithUnreachGood "n_root"
    -- (1) T1a: Global != Reachable when unreachable nodes have duplicate IDs
    (verifyGlobalWithFuel 12 stdG7PrimEnv dagWithUnreachDupBad "n_root" =
       .rejectInvalid .containerIntegrityFailed ∧
     ValidContainer cloBad.restrictedC ∧
     isG7AcceptBool (verifyGlobalWithFuel 12 cloBad.restrictedΓ cloBad.restrictedC "n_root") = true) ∧
    -- (2) T1b: Legitimate ResourceHeld difference at intermediate fuel = 5 on valid container
    (ValidContainer dagMultiWithUnreachGood ∧
     verifyGlobalWithFuel 5 stdG7PrimEnv dagMultiWithUnreachGood "n_root" = .resourceHeld 0 ∧
     isG7AcceptBool (verifyGlobalWithFuel 5 cloGood.restrictedΓ cloGood.restrictedC "n_root") = true) ∧
    -- (3) T1c: Universal T1_ReachableInvariance (both local exact equality & global Accept iff)
    (∀ (Γ : PrimPremiseEnv) (C : G7DagContainer) (rootId : String) (reqFuel : Nat),
      ValidContainer C →
      let clo := extractCertifiedReachableClosure Γ C rootId
      verifyReachableDerivation reqFuel clo.restrictedΓ clo.restrictedC rootId =
        verifyReachableDerivation reqFuel Γ C rootId ∧
      ∀ (out : VerifiedSequentOut),
        (verifyGlobalWithFuel (C.nodes.length + reqFuel) Γ C rootId = .accept out ↔
         verifyGlobalWithFuel (clo.restrictedC.nodes.length + reqFuel)
           clo.restrictedΓ clo.restrictedC rootId = .accept out)) ∧
    -- (4) T2: Universal Non-Circular DAG Induction Master Soundness
    (∀ (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (rootId : String)
       (out : VerifiedSequentOut),
      ValidContainer C →
      verifyReachableDerivation fuel Γ C rootId = .accept out →
      (∀ p ∈ extractTransitivePrimDeps Γ C rootId, SemValidPrimId Γ p) →
        SemValidSequent out) ∧
    -- (5) T3: Universal Monotone Fuel Stability on Acceptance
    (∀ (f1 f2 : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (rootId : String)
       (out : VerifiedSequentOut),
      f1 ≤ f2 →
      verifyReachableDerivation f1 Γ C rootId = .accept out →
        verifyReachableDerivation f2 Γ C rootId = .accept out) := by
  dsimp only
  refine ⟨⟨by decide, by decide, by decide⟩,
          ⟨by decide, by decide, by decide⟩,
          ?_, ?_, ?_⟩
  · intro Γ C rootId reqFuel hVal
    let clo := extractCertifiedReachableClosure Γ C rootId
    have hLocEq : verifyReachableDerivation reqFuel clo.restrictedΓ clo.restrictedC rootId =
        verifyReachableDerivation reqFuel Γ C rootId :=
      verifyReachable_restricted_eq Γ C rootId hVal reqFuel
    refine ⟨hLocEq, ?_⟩
    intro out
    unfold verifyGlobalWithFuel
    have hLt1 : ¬ (C.nodes.length + reqFuel < C.nodes.length) := by omega
    have hLt2 : ¬ (clo.restrictedC.nodes.length + reqFuel < clo.restrictedC.nodes.length) := by omega
    have hSub1 : C.nodes.length + reqFuel - C.nodes.length = reqFuel := by omega
    have hSub2 : clo.restrictedC.nodes.length + reqFuel - clo.restrictedC.nodes.length = reqFuel := by omega
    rw [if_neg hLt1, if_neg hLt2, hSub1, hSub2]
    have hNotBad1 : ¬ ((!checkContainerIntegrityBool C) = true) := by
      rw [hVal]; decide
    rw [if_neg hNotBad1]
    constructor
    · intro hAcc
      rcases verifyNodeFuel_accept_header hAcc with ⟨nRoot, hRootLook, _⟩
      have hValClo : ValidContainer clo.restrictedC :=
        validContainer_restricted_of_root Γ C hVal hRootLook
      have hNotBad2 : ¬ ((!checkContainerIntegrityBool clo.restrictedC) = true) := by
        rw [hValClo]; decide
      rw [if_neg hNotBad2]
      rwa [hLocEq]
    · intro hAccClo
      if hBad2 : (!checkContainerIntegrityBool clo.restrictedC) = true then
        rw [if_pos hBad2] at hAccClo; nomatch hAccClo
      else
        rw [if_neg hBad2] at hAccClo
        rwa [← hLocEq]
  · exact fun f Γ C r o hV hA hP => verifyReachable_master_sound f Γ C r o hV hA hP
  · exact fun _ _ Γ C r o hLe hA => verifyReachable_fuel_monotone_accept hLe Γ C r o hA

/-- **`T-B2A-06` — Adversarial DAG, Premise-Hiding, `guardWfCerts` Retraction, Duplicate-ID,
    Domain-Spoofing, & Causal-Cycle Suite**:
    (1) **Hidden Leaf Premise Attack**: claiming `claimedDeps = []` when leaf uses `"p1_leaf"` fails
        `claimedDeps == extractTransitivePrimDeps` (`["p0_anc", "p1_leaf"]`);
    (2) **Hidden Parent Transitive Ancestor Retraction**: `"n_root"` cites `"n_lem"` (`"p1_leaf" → "p0_anc"`),
        never mentioning `"p0_anc"` directly, yet `"p0_anc" ∈ extractTransitivePrimDeps` so retracting
        `"p0_anc"` triggers premise-survival failure;
    (3) **`Tribunal §3.A` Hidden `guardWfCerts` Premise Attack + Mutant Contrast**:
        On `certExtPremGuardWf` (`γ₁ : 1/x > 0` certified via `"p_nz"`, `goalDeriv` proving `x^2 ≥ 0`),
        the defective mutant `extractStepFootprintGoalOnlyMutant` returns `primRefs = []` (MISSING `"p_nz"`!),
        whereas official `extractTransitivePrimDeps` captures `"p_nz"`, deactivating the witness upon
        retracting `"p_nz"`;
    (4) **Duplicate Node-ID Equivocation Attack**: two nodes sharing `"n_lem"` (one honest, one bogus)
        are deterministically rejected by `checkContainerIntegrityBool = false`;
    (5) **Parent Domain / Conclusion Spoofing Attack**: child on `.domQ` attempting to import a parent
        proved only on `.domQNonzero` (`ℚ \ {0} → ℚ` laundering) or dropping parent's guard `[x ≠ 0]`
        is deterministically rejected (`= .rejectInvalid .localDerivFailed`);
    (6) **Causal Rank Cycle / Self-Loop Attack**: node citing itself (`topoRank 0 < 0` false) fails
        BOTH `checkContainerIntegrityBool` (`false`) AND `verifyReachableDerivation` (`.causalRankViolation`). -/
theorem T_B2A_06_adversarial_dag_premise_guardwf_and_dup_id_suite :
    let C_ext_wf : G7DagContainer :=
      ⟨[⟨"n_ext_wf", 0, .domQ, "spec_v1", certExtPremGuardWf.guards, certExtPremGuardWf.goalForm,
         .guardedDomStep certExtPremGuardWf⟩]⟩
    let C_dup_shadow : G7DagContainer :=
      ⟨[ ⟨"n_lem", 0, .domQ, "spec_v1", [], .nonneg (.const 0),
           .directDerivStep (.certStep (.nonneg (.const 0))
             (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩))⟩
       , ⟨"n_lem", 0, .domQ, "spec_v1", [], .pos (.neg (.const 1)),
           .directDerivStep (.certStep (.pos (.neg (.const 1)))
             (.polyPositivstellensatz ⟨1, 0, [], [], [], []⟩))⟩ ]⟩
    let C_dom_spoof : G7DagContainer :=
      ⟨[ ⟨"n_nz_parent", 0, .domQNonzero, "spec_v1", [.neqZero .varX], .pos (.mul .varX .varX),
           .guardedDomStep ⟨.domQNonzero, [.neqZero .varX], .pos (.mul .varX .varX),
             [.totalPolyWf], .selfContainedCtx,
             .certStep (.pos (.mul .varX .varX)) (.guardedReciprocal (.nonzeroSqStrictPos .varX))⟩⟩
       , ⟨"n_q_child", 1, .domQ, "spec_v1", [], .pos (.mul .varX .varX),
           .directDerivStep (.parentRef "n_nz_parent" (.pos (.mul .varX .varX)))⟩ ]⟩
    let C_self_cycle : G7DagContainer :=
      ⟨[ ⟨"n_cyc", 0, .domQ, "spec_v1", [], .pos (.const 1),
           .directDerivStep (.parentRef "n_cyc" (.pos (.const 1)))⟩ ]⟩
    -- (1) Leaf & (2) Parent-transitive ancestor `"p0_anc"` captured in PrimDeps*
    ("p1_leaf" ∈ extractTransitivePrimDeps stdG7PrimEnv dagMultiWithUnreachGood "n_root" ∧
     "p0_anc" ∈ extractTransitivePrimDeps stdG7PrimEnv dagMultiWithUnreachGood "n_root" ∧
     extractTransitivePrimDeps stdG7PrimEnv dagMultiWithUnreachGood "n_root" ≠ []) ∧
    -- (3) Tribunal §3.A Mutant misses `"p_nz"` while official extractor catches `"p_nz"`
    ("p_nz" ∉ (extractStepFootprintGoalOnlyMutant (.guardedDomStep certExtPremGuardWf)).primRefs ∧
     "p_nz" ∈ (extractStepFootprint (.guardedDomStep certExtPremGuardWf)).primRefs ∧
     "p_nz" ∈ extractTransitivePrimDeps stdG7PrimEnv C_ext_wf "n_ext_wf" ∧
     (let retracted := ["p_nz"]
      (extractTransitivePrimDeps stdG7PrimEnv C_ext_wf "n_ext_wf").all
        (fun p => !retracted.contains p) = false)) ∧
    -- (4) Duplicate ID shadowing rejected by CheckContainerIntegrity
    (checkContainerIntegrityBool C_dup_shadow = false) ∧
    -- (5) Narrow-to-wide domain / guard-dropping parent spoofing rejected
    (verifyReachableDerivation 4 stdG7PrimEnv C_dom_spoof "n_q_child" =
       .rejectInvalid .localDerivFailed) ∧
    -- (6) Causal self-cycle rejected by both container integrity and local rank check
    (checkContainerIntegrityBool C_self_cycle = false ∧
     verifyReachableDerivation 4 stdG7PrimEnv C_self_cycle "n_cyc" =
       .rejectInvalid .localDerivFailed) := by
  exact ⟨⟨by decide, by decide, by decide⟩,
         ⟨by decide, by decide, by decide, by decide⟩,
         by decide,
         by decide,
         ⟨by decide, by decide⟩⟩

end OmegaCellC1P1B2A
