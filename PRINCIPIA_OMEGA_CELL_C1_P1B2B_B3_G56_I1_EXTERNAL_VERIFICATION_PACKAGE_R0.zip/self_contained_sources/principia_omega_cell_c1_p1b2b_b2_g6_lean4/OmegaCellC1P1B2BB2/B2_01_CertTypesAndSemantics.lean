/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B2 — Isolated G6 Protected Invariant Kernel
  Module: OmegaCellC1P1B2BB2.B2_01_CertTypesAndSemantics

  Authorization: Scoped Human Execution Approval for `P1B2B-B2 G6 Isolated Lean Proof Core R0`
  Normative Specification: `B2 G6 Static Contract R0` + `Static Corrigendum 01` + `F-B2-T12-01..04`

  Scope:
    1. All 10 mandatory `G6` syntactic structures & 5-branch `G6CheckVerdict` (`F-B2-T11-01`):
       - `G6EmptySuitePolicy`, `G6VersionEpoch`, `G6RegistryOrigin`, `G6ScopePolicy`,
         `G6UnresolvedReason`, `G6RefutationCert`
       - `G6ParameterBinding` (`B2-04`)
       - `G6OldNewStateBinding` (`B2-03`, including explicit `newGuardsDefNodeId?` for guarded
         post-domains across all item outcomes)
       - `G6ScopeLossRecord` (`B2-03` & `Gate A8`)
       - `G6ItemEvidence`, `G6EvidenceRoots`
       - `G6ProtectedInvariantSpec` (`B2-01`)
       - `G6DerivedPrimDeps` (`B2-05`), `G6ProtectedSuite`
       - `G6InvalidReason`, 5-branch `G6CheckVerdict` (`.invalid`, `.violated`, `.unresolved`,
         `.emptySuiteAccepted`, `.verified` — keeping empty suites disjoint from `.verified`!)
    2. Pure non-circular declarative `G6` semantics (`S_sem_B2` — ZERO executable checker calls!):
       - `SemValidG6ParamBinding` (1D spatial restriction, `.varY`-free spatial guards, positive
         denominators, and `ModelsStrictForm` substitution biconditional)
       - `SemValidG6ScopeRelation` (`.globalPostSameDom`, `.oldScopeInclusion`,
         `.retreatWithLossAccounting`)
       - `SemValidG6InvariantItem`
       - `SemValidG6ProtectedSuite` (strictly non-empty: `suite.items ≠ []`)
       - `SemValidEmptyG6Notice` (zero-authority administrative empty-suite state)
       - `SemPointCounterexampleOnNewDom` (`CounterexampleSound` target — `F-B2-T11-03`)
       - `SemViolatedG6ProtectedSuite` (`FullViolationRecordSound` target — `F-B2-T11-03`)
-/
import OmegaCellC1P1A0
import OmegaCellC1P1B1
import OmegaCellC1P1B2A
import OmegaCellC1P1B2BA0
import OmegaCellC1P1B2BB1

namespace OmegaCellC1P1B2BB2

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1

/-! ### 1. Auxiliary Policy, Version/Epoch, Registry Origin, & Refutation Certificate Types -/

/-- Explicit governance policy for empty protected suites (`F-B2-T11-01`). -/
inductive G6EmptySuitePolicy where
  | forbidEmptySuite   : G6EmptySuitePolicy
  | allowExplicitEmpty : (policyCid : String) → G6EmptySuitePolicy
  deriving DecidableEq, Repr

/-- Specification version and epoch validity window (`B2-01`, `CE-G6-09`). -/
structure G6VersionEpoch where
  specVersion        : String
  effectiveFromEpoch : Nat
  expiresAtEpoch     : Nat
  revokedBool        : Bool
  deriving DecidableEq, Repr

/-- Registry provenance metadata (`B2-01`).
    `claimedApprovedFlag` is an untrusted self-assertion and NEVER establishes external
    human/registry authentication inside `B2` (`F-B2-T11-02`, `Gate A10`). -/
structure G6RegistryOrigin where
  registryId          : String
  originCellCid       : String
  originRecordCid     : String
  claimedApprovedFlag : Bool
  deriving DecidableEq, Repr

/-- Protection scope retention policy (`B2-03`), separating domain-retention compliance
    orthogonally from post-state formula truth. -/
inductive G6ScopePolicy where
  /-- Exact bidirectional effective-domain equality (`D_old,eff = D_new,eff`). -/
  | globalPostSameDom : RepairDomEqCert → G6ScopePolicy
  /-- Conservative old-scope inclusion (`D_old,eff ⊆ D_new,eff`) with explicit expansion flag. -/
  | oldScopeInclusion :
      (baseExpandStep : BaseDomExpandStep) →
      (oldGuardsDefNodeId? : Option String) →
      (oldEntailsNewGuardNodes : List (StrictForm × String)) →
      (newEntailsOldGuardNodes : List (StrictForm × String)) →
      (scopeExpanded : Bool) →
      (expansionWitness? : Option RatCoord2) →
      G6ScopePolicy
  /-- Retreat-permitting policy requiring mandatory `G6ScopeLossRecord` exact partition. -/
  | retreatWithLossAccounting : G6ScopePolicy
  deriving DecidableEq, Repr

/-- Epistemic hold reasons for `Unresolved` items (`B2-02`). -/
inductive G6UnresolvedReason where
  | insufficientProofSearch        : G6UnresolvedReason
  | uncertifiedNonlinearGoal       : G6UnresolvedReason
  | externalOracleUnavailable      : G6UnresolvedReason
  | undefinedSingularityUnresolved : G6UnresolvedReason
  deriving DecidableEq, Repr

/-- Violation evidence schema (`B2-02`, `Gate A4`):
    - `counterexamplePoint`: concrete rational point in `D_new,eff` where `formNewInst` is
      defined and false (`0` primitive premise assumptions needed for `CounterexampleSound`!).
    - `derivedRefutationNode`: `G7` proof of `atomicComplement formNewInst` + non-empty point
      in `D_new,eff` (premise-conditional under `Deps_G6`). -/
inductive G6RefutationCert where
  | counterexamplePoint   : (violPt : RatCoord2) → G6RefutationCert
  | derivedRefutationNode : (refutNodeId : String) → (witnessPt : RatCoord2) → G6RefutationCert
  deriving DecidableEq, Repr

/-! ### 2. Mandatory Core G6 Specification Types (`Section IV.1` .. `IV.8`) -/

/-- **`G6ParameterBinding` (`IV.4`, `B2-04`)**:
    Binds parameter-free `.fixedStateForm` to `.noParam` and 1D `.cellParamForm` templates
    to explicit old/new rational parameters `(θOldNum / θOldDenPos, θNewNum / θNewDenPos)`. -/
inductive G6ParameterBinding where
  | noParam : G6ParameterBinding
  | boundCellParam :
      (θOldNum : Int) → (θOldDenPos : Nat) →
      (θNewNum : Int) → (θNewDenPos : Nat) →
      G6ParameterBinding
  deriving DecidableEq, Repr

/-- **`G6OldNewStateBinding` (`IV.3`, `B2-03`)**:
    Explicitly separates `I_i^old = (domOld, guardsOld, formOldInst)` and
    `I_i^new = (domNew, guardsNew, formNewInst)`, post-domain non-emptiness witness,
    optional `newGuardsDefNodeId?` (certifying `TelescopicGuardsDefined guardsNew` on `domNew`
    when `guardsNew ≠ []`), and `scopePolicy`. -/
structure G6OldNewStateBinding where
  specOldId               : String
  domOld                  : G7DomTag
  guardsOld               : List StrictForm
  formOldInst             : StrictForm
  oldBaselineProofNodeId? : Option String
  specNewId               : String
  domNew                  : G7DomTag
  guardsNew               : List StrictForm
  newGuardsDefNodeId?     : Option String
  formNewInst             : StrictForm
  postDomNonEmptyWitness  : RatCoord2
  scopePolicy             : G6ScopePolicy
  deriving DecidableEq, Repr

/-- **`G6ScopeLossRecord` (`IV.7`, `B2-03`, `Gate A8`)**:
    Certifies exact disjoint partition `D_old,eff = (D_old,eff ∩ D_new,eff) ⊔̇ E_lost` via
    frozen `OmegaCellC1P1B2BA0.L_B2B_TelescopicPartition_from_G7`. -/
structure G6ScopeLossRecord where
  baseStep                : BaseDomRetreatStep
  deltaGuards             : List StrictForm
  prefixDefNodeId         : String
  guardConn               : GuardConnCert
  excisedBranches         : ExcisedLocus
  reexprCert?             : Option ExcisedReexprCert
  strictLossWitness       : RatCoord2
  claimedRetentionAnchors : List RatCoord2
  deriving DecidableEq, Repr

/-- Per-invariant truth/refutation/hold evidence claim. -/
inductive G6ItemEvidence where
  | claimVerified   : (verifyRootNodeId : String) → G6ItemEvidence
  | claimViolated   : G6RefutationCert → G6ItemEvidence
  | claimUnresolved : G6UnresolvedReason → G6ItemEvidence
  deriving DecidableEq, Repr

/-- **`G6EvidenceRoots` (`IV.5`, `B2-01`)**:
    Pairs the invariant's epistemic evidence with its canonical list of all `G7` proof root IDs
    referenced anywhere in the item. -/
structure G6EvidenceRoots where
  itemEvidence          : G6ItemEvidence
  declaredItemProofNids : List String
  deriving DecidableEq, Repr

/-- **`G6ProtectedInvariantSpec` (`IV.1`, `B2-01`)**:
    Formal protected invariant specification `I_i = (id_i, D_i, Γ_i, φ_i, θ_i, version_i, origin_i)`
    coupled with `oldNewState` and optional `scopeLossRecord?`. -/
structure G6ProtectedInvariantSpec where
  invariantId      : String
  specId           : String
  protectedDomain  : G7DomTag
  protectedGuards  : List StrictForm
  protectedFormula : ProtectedInvariantKind
  parameterBinding : G6ParameterBinding
  versionEpoch     : G6VersionEpoch
  evidenceRoots    : G6EvidenceRoots
  registryOrigin   : G6RegistryOrigin
  oldNewState      : G6OldNewStateBinding
  scopeLossRecord? : Option G6ScopeLossRecord
  deriving DecidableEq, Repr

/-- **`G6DerivedPrimDeps` (`IV.6`, `B2-05`)**:
    Canonical deduplicated transitive primitive premise closure `Deps_G6`, computed strictly
    from `G6` roots and completely independent of `G5DerivedPrimDeps`. -/
structure G6DerivedPrimDeps where
  primDepIds : List String
  deriving DecidableEq, Repr

/-- **`G6ProtectedSuite` (`IV.2`, `CE-G6-07A/B`, `CE-G6-09`)**:
    Protected invariant suite container binding header metadata, `evaluationEpoch`,
    `emptySuitePolicy`, `declaredInvariantIds`, `items`, and `claimedPrimDeps`. -/
structure G6ProtectedSuite where
  suiteVersion         : String
  suiteCid             : String
  rflxCid              : String
  cellOldCid           : String
  cellNewCid           : String
  baseId               : String
  specOldId            : String
  specNewId            : String
  evaluationEpoch      : Nat
  emptySuitePolicy     : G6EmptySuitePolicy
  declaredInvariantIds : List String
  items                : List G6ProtectedInvariantSpec
  claimedPrimDeps      : G6DerivedPrimDeps
  deriving DecidableEq, Repr

/-- Fine-grained top-level certificate / structural input error reasons (`Invalid`). -/
inductive G6InvalidReason where
  | malformedEnvOrContainer        : G6InvalidReason
  | nonCanonicalSuiteHeader        : G6InvalidReason
  | unauthorizedEmptySuite         : G6InvalidReason
  | duplicateOrEmptyInvariantId    : G6InvalidReason
  | suiteCoverageMismatch          : G6InvalidReason
  | staleOrRevokedSpecVersion      : (invId : String) → G6InvalidReason
  | illFormedParameterBinding      : (invId : String) → G6InvalidReason
  | itemProofRootManifestMismatch  : (invId : String) → G6InvalidReason
  | uncertifiedScopeShrinkOrPolicy : (invId : String) → G6InvalidReason
  | forgedVerificationProof        : (invId : String) → G6InvalidReason
  | undefinedPointTreatedAsTrue    : (invId : String) → G6InvalidReason
  | outOfDomainCounterexample      : (invId : String) → G6InvalidReason
  | invalidRefutationEvidence      : (invId : String) → G6InvalidReason
  | primDepsClosureMismatch        : G6InvalidReason
  deriving DecidableEq, Repr

/-- **`G6CheckVerdict` (`IV.8`, `B2-02`, `Corrigendum 01` §1.1 `F-B2-T11-01`)**:
    5-branch deterministic verdict separating:
    - `.invalid`: top-level input/certificate error (NOT a proof of invariant falsity),
    - `.violated`: genuine counterexample / sound refutation (`Violated > Unresolved`),
    - `.unresolved`: conservative hold (`Unresolved` NEVER promotes to `Verified`),
    - `.emptySuiteAccepted`: explicit-policy zero-invariant administrative notice (NEVER `Verified`
      and NEVER eligible for `G6QualifiedRecord`),
    - `.verified`: non-empty protected suite (`suite.items ≠ []`) with all invariants verified. -/
inductive G6CheckVerdict where
  | invalid            : G6InvalidReason → G6CheckVerdict
  | violated           : (violatedInvIds : List String) → (unresolvedInvIds : List String) → G6CheckVerdict
  | unresolved         : (unresolvedInvIds : List String) → G6CheckVerdict
  | emptySuiteAccepted : (unauthPolicyCid : String) → G6CheckVerdict
  | verified           : (hasCertifiedScopeLoss : Bool) → G6CheckVerdict
  deriving DecidableEq, Repr

/-- Severity rank ordering on non-empty suite outcomes (`Invalid (3) > Violated (2) > Unresolved (1) > Verified (0)`). -/
def g6VerdictSeverityRank : G6CheckVerdict → Nat
  | .invalid _            => 3
  | .violated _ _         => 2
  | .unresolved _         => 1
  | .emptySuiteAccepted _ => 1
  | .verified _           => 0

/-! ### 3. Pure Non-Circular Declarative Semantics (`S_sem_B2` — `0` Executable Checker Calls!) -/

/-- Pure syntax check whether `γ` is free of `.varY` (`0` checker calls; uses syntactic AST walk
    `formUsesVarYBool` only? Wait: to keep `AuditB2G6Axioms` 100% transparent, let us define
    pure `Prop` `FormFreeOfVarY` & `ExprFreeOfVarY` directly in `S_sem_B2` with ZERO Bool calls!). -/
def ExprFreeOfVarY : PartExpr → Prop
  | .const _   => True
  | .varX      => True
  | .varY      => False
  | .neg e     => ExprFreeOfVarY e
  | .add e1 e2 => ExprFreeOfVarY e1 ∧ ExprFreeOfVarY e2
  | .sub e1 e2 => ExprFreeOfVarY e1 ∧ ExprFreeOfVarY e2
  | .mul e1 e2 => ExprFreeOfVarY e1 ∧ ExprFreeOfVarY e2
  | .div e1 e2 => ExprFreeOfVarY e1 ∧ ExprFreeOfVarY e2

def FormFreeOfVarY : StrictForm → Prop
  | .eqZero e      => ExprFreeOfVarY e
  | .nonneg e      => ExprFreeOfVarY e
  | .pos e         => ExprFreeOfVarY e
  | .neqZero e     => ExprFreeOfVarY e
  | .conj φ ψ      => FormFreeOfVarY φ ∧ FormFreeOfVarY ψ
  | .impStrict φ ψ => FormFreeOfVarY φ ∧ FormFreeOfVarY ψ

theorem exprUsesVarYBool_false_iff_free (e : PartExpr) :
    exprUsesVarYBool e = false ↔ ExprFreeOfVarY e := by
  induction e with
  | const _ => exact ⟨fun _ => trivial, fun _ => rfl⟩
  | varX    => exact ⟨fun _ => trivial, fun _ => rfl⟩
  | varY    => exact Iff.intro (fun h => nomatch h) (fun h => False.elim h)
  | neg e1 ih => exact ih
  | add e1 e2 ih1 ih2 =>
      dsimp [exprUsesVarYBool, ExprFreeOfVarY]
      rw [Bool.or_eq_false_iff, ih1, ih2]
  | sub e1 e2 ih1 ih2 =>
      dsimp [exprUsesVarYBool, ExprFreeOfVarY]
      rw [Bool.or_eq_false_iff, ih1, ih2]
  | mul e1 e2 ih1 ih2 =>
      dsimp [exprUsesVarYBool, ExprFreeOfVarY]
      rw [Bool.or_eq_false_iff, ih1, ih2]
  | div e1 e2 ih1 ih2 =>
      dsimp [exprUsesVarYBool, ExprFreeOfVarY]
      rw [Bool.or_eq_false_iff, ih1, ih2]

theorem formUsesVarYBool_false_iff_free (φ : StrictForm) :
    formUsesVarYBool φ = false ↔ FormFreeOfVarY φ := by
  induction φ with
  | eqZero e  => exact exprUsesVarYBool_false_iff_free e
  | nonneg e  => exact exprUsesVarYBool_false_iff_free e
  | pos e     => exact exprUsesVarYBool_false_iff_free e
  | neqZero e => exact exprUsesVarYBool_false_iff_free e
  | conj φ1 φ2 ih1 ih2 =>
      dsimp [formUsesVarYBool, FormFreeOfVarY]
      rw [Bool.or_eq_false_iff, ih1, ih2]
  | impStrict φ1 φ2 ih1 ih2 =>
      dsimp [formUsesVarYBool, FormFreeOfVarY]
      rw [Bool.or_eq_false_iff, ih1, ih2]

/-- Pure declarative parameter-binding semantics (`0` executable checker calls). -/
def SemValidG6ParamBinding
    (domOld : G7DomTag) (guardsOld : List StrictForm) (formOldInst : StrictForm)
    (domNew : G7DomTag) (guardsNew : List StrictForm) (formNewInst : StrictForm)
    (formulaKind : ProtectedInvariantKind) (binding : G6ParameterBinding) : Prop :=
  match formulaKind, binding with
  | .fixedStateForm φ, .noParam =>
      formOldInst = φ ∧ formNewInst = φ
  | .cellParamForm tpl, .boundCellParam θOldNum θOldDenPos θNewNum θNewDenPos =>
      let θOldRat : Rat := (θOldNum : Rat) / ((θOldDenPos : Int) : Rat)
      let θNewRat : Rat := (θNewNum : Rat) / ((θNewDenPos : Int) : Rat)
      0 < θOldDenPos ∧ 0 < θNewDenPos ∧
      (domOld = .domQ ∨ domOld = .domQNonzero) ∧
      (domNew = .domQ ∨ domNew = .domQNonzero) ∧
      (∀ γ ∈ guardsOld, FormFreeOfVarY γ) ∧
      (∀ γ ∈ guardsNew, FormFreeOfVarY γ) ∧
      formOldInst = instantiateInvariantAtParam θOldNum θOldDenPos (.cellParamForm tpl) ∧
      formNewInst = instantiateInvariantAtParam θNewNum θNewDenPos (.cellParamForm tpl) ∧
      (∀ ρ : Env2, inG7Dom domOld ρ →
        ρ.2 = 0 ∧
        (FormDefined formOldInst ρ ↔ FormDefined tpl (ρ.1, θOldRat)) ∧
        (ModelsStrictForm formOldInst ρ ↔ ModelsStrictForm tpl (ρ.1, θOldRat))) ∧
      (∀ ρ : Env2, inG7Dom domNew ρ →
        ρ.2 = 0 ∧
        (FormDefined formNewInst ρ ↔ FormDefined tpl (ρ.1, θNewRat)) ∧
        (ModelsStrictForm formNewInst ρ ↔ ModelsStrictForm tpl (ρ.1, θNewRat)))
  | _, _ => False

/-- Pure declarative scope-retention & scope-loss partition semantics (`0` checker calls). -/
def SemValidG6ScopeRelation (st : G6OldNewStateBinding)
    (lossRec? : Option G6ScopeLossRecord) : Prop :=
  match st.scopePolicy, lossRec? with
  | .globalPostSameDom _, none =>
      SemSameEffDom st.domOld st.guardsOld st.domNew st.guardsNew
  | .oldScopeInclusion _ _ _ _ scopeExpanded expWit?, none =>
      (∀ ρ : Env2, InEffDom st.domOld st.guardsOld ρ → InEffDom st.domNew st.guardsNew ρ) ∧
      (if scopeExpanded then
        ∃ pt_exp : RatCoord2,
          expWit? = some pt_exp ∧
          0 < pt_exp.xDenPos ∧ 0 < pt_exp.yDenPos ∧
          InEffDom st.domNew st.guardsNew (ratCoordToEnv2 pt_exp) ∧
          ¬ InEffDom st.domOld st.guardsOld (ratCoordToEnv2 pt_exp)
       else
        expWit? = none ∧ SemSameEffDom st.domOld st.guardsOld st.domNew st.guardsNew)
  | .retreatWithLossAccounting, some lr =>
      let ρ_loss := ratCoordToEnv2 lr.strictLossWitness
      0 < lr.strictLossWitness.xDenPos ∧ 0 < lr.strictLossWitness.yDenPos ∧
      SemExactScopeLossPartition st.domOld st.guardsOld st.domNew st.guardsNew lr.excisedBranches ∧
      InEffDom st.domOld st.guardsOld ρ_loss ∧
      ModelsExcised lr.excisedBranches ρ_loss ∧
      ¬ InEffDom st.domNew st.guardsNew ρ_loss ∧
      (∀ pt_a ∈ lr.claimedRetentionAnchors,
        0 < pt_a.xDenPos ∧ 0 < pt_a.yDenPos ∧
        InEffDom st.domNew st.guardsNew (ratCoordToEnv2 pt_a))
  | _, _ => False

/-- Pure declarative preservation (`Verified`) semantics for a single invariant item (`0` checker calls). -/
structure SemValidG6InvariantItem (evalEpoch : Nat) (item : G6ProtectedInvariantSpec) : Prop where
  nonEmptyIds :
    item.invariantId ≠ "" ∧ item.specId ≠ "" ∧
    item.specId = item.oldNewState.specNewId ∧
    item.protectedDomain = item.oldNewState.domNew ∧
    item.protectedGuards = item.oldNewState.guardsNew
  activeVersionEpoch :
    item.versionEpoch.revokedBool = false ∧
    item.versionEpoch.effectiveFromEpoch ≤ evalEpoch ∧
    evalEpoch < item.versionEpoch.expiresAtEpoch
  validParamBinding :
    SemValidG6ParamBinding
      item.oldNewState.domOld item.oldNewState.guardsOld item.oldNewState.formOldInst
      item.oldNewState.domNew item.oldNewState.guardsNew item.oldNewState.formNewInst
      item.protectedFormula item.parameterBinding
  validScopeRelation :
    SemValidG6ScopeRelation item.oldNewState item.scopeLossRecord?
  nonEmptyPostDomain :
    0 < item.oldNewState.postDomNonEmptyWitness.xDenPos ∧
    0 < item.oldNewState.postDomNonEmptyWitness.yDenPos ∧
    InEffDom item.oldNewState.domNew item.oldNewState.guardsNew
      (ratCoordToEnv2 item.oldNewState.postDomNonEmptyWitness)
  oldBaselineHoldsIfClaimed :
    item.oldNewState.oldBaselineProofNodeId?.isSome = true →
      ∀ ρ : Env2, InEffDom item.oldNewState.domOld item.oldNewState.guardsOld ρ →
        ModelsStrictForm item.oldNewState.formOldInst ρ
  postInvariantHolds :
    ∀ ρ : Env2, InEffDom item.oldNewState.domNew item.oldNewState.guardsNew ρ →
      ModelsStrictForm item.oldNewState.formNewInst ρ

/-- **`SemValidG6ProtectedSuite` (`IV.10` & `Corrigendum 01` §1.3 — `F-B2-T11-01` & `F-B2-T11-02`)**:
    Top-level non-circular declarative preservation semantics for a **submitted non-empty**
    protected suite (`suite.items ≠ []`).
    Contains **ZERO** calls to any executable checker (`Cone*(SemValidG6ProtectedSuite) ∩ K_exec = ∅`). -/
structure SemValidG6ProtectedSuite (suite : G6ProtectedSuite) : Prop where
  canonicalSuiteHeader :
    suite.suiteVersion = "g6_b2_v1" ∧
    suite.suiteCid ≠ "" ∧
    suite.rflxCid ≠ "" ∧
    suite.cellOldCid ≠ "" ∧
    suite.cellNewCid ≠ "" ∧
    suite.baseId = "base_Q" ∧
    suite.specOldId ≠ "" ∧
    suite.specNewId ≠ ""
  nonEmptyProtectedSuite :
    suite.items ≠ [] ∧ suite.declaredInvariantIds ≠ []
  submittedSuiteCoverage :
    suite.declaredInvariantIds.Nodup ∧
    (∀ id ∈ suite.declaredInvariantIds, id ≠ "") ∧
    suite.items.map (·.invariantId) = suite.declaredInvariantIds ∧
    (∀ item ∈ suite.items,
      item.oldNewState.specOldId = suite.specOldId ∧
      item.oldNewState.specNewId = suite.specNewId)
  allItemsSemanticallyPreserved :
    ∀ item ∈ suite.items, SemValidG6InvariantItem suite.evaluationEpoch item

/-- Pure declarative administrative empty-suite notice semantics (`F-B2-T11-01`: makes ZERO
    claim of invariant preservation and grants ZERO qualification). -/
structure SemValidEmptyG6Notice (suite : G6ProtectedSuite) (unauthPolCid : String) : Prop where
  canonicalSuiteHeader :
    suite.suiteVersion = "g6_b2_v1" ∧
    suite.suiteCid ≠ "" ∧
    suite.rflxCid ≠ "" ∧
    suite.cellOldCid ≠ "" ∧
    suite.cellNewCid ≠ "" ∧
    suite.baseId = "base_Q" ∧
    suite.specOldId ≠ "" ∧
    suite.specNewId ≠ ""
  emptyItemsAndDeps :
    suite.items = [] ∧ suite.declaredInvariantIds = [] ∧ suite.claimedPrimDeps.primDepIds = []
  unauthenticatedPolicyTag :
    unauthPolCid ≠ "" ∧ suite.emptySuitePolicy = .allowExplicitEmpty unauthPolCid

/-- **`SemPointCounterexampleOnNewDom` (`Corrigendum 01` §3.1 `CounterexampleSound` — `F-B2-T11-03`)**:
    Pure point-counterexample violation target requiring ZERO `G7` derivation or primitive
    premise assumptions (`0` checker calls). -/
structure SemPointCounterexampleOnNewDom (suite : G6ProtectedSuite) (vIds : List String) : Prop where
  nonEmptyViolatedIds :
    vIds ≠ []
  allPointCounterexamplesGenuine :
    ∀ vid ∈ vIds,
      ∃ item ∈ suite.items, ∃ pt : RatCoord2,
        item.invariantId = vid ∧
        0 < pt.xDenPos ∧ 0 < pt.yDenPos ∧
        SemValidG6ParamBinding
          item.oldNewState.domOld item.oldNewState.guardsOld item.oldNewState.formOldInst
          item.oldNewState.domNew item.oldNewState.guardsNew item.oldNewState.formNewInst
          item.protectedFormula item.parameterBinding ∧
        InEffDom item.oldNewState.domNew item.oldNewState.guardsNew (ratCoordToEnv2 pt) ∧
        FormDefined item.oldNewState.formNewInst (ratCoordToEnv2 pt) ∧
        ¬ ModelsStrictForm item.oldNewState.formNewInst (ratCoordToEnv2 pt)

/-- **`SemViolatedG6ProtectedSuite` (`Corrigendum 01` §3.1 `FullViolationRecordSound` — `F-B2-T11-03`)**:
    Full violation record semantics conjoining canonical suite coverage, parameter binding,
    `SemValidG6ScopeRelation`, optional old-state baseline validity, and genuine post-domain
    violation (`0` checker calls). -/
structure SemViolatedG6ProtectedSuite (suite : G6ProtectedSuite) (vIds : List String) : Prop where
  canonicalHeaderAndCoverage :
    suite.suiteVersion = "g6_b2_v1" ∧
    suite.items ≠ [] ∧
    suite.declaredInvariantIds.Nodup ∧
    suite.items.map (·.invariantId) = suite.declaredInvariantIds
  nonEmptyViolatedIds :
    vIds ≠ []
  allViolatedRecordsSound :
    ∀ vid ∈ vIds,
      ∃ item ∈ suite.items,
        item.invariantId = vid ∧
        SemValidG6ParamBinding
          item.oldNewState.domOld item.oldNewState.guardsOld item.oldNewState.formOldInst
          item.oldNewState.domNew item.oldNewState.guardsNew item.oldNewState.formNewInst
          item.protectedFormula item.parameterBinding ∧
        SemValidG6ScopeRelation item.oldNewState item.scopeLossRecord? ∧
        (item.oldNewState.oldBaselineProofNodeId?.isSome = true →
          ∀ ρ : Env2, InEffDom item.oldNewState.domOld item.oldNewState.guardsOld ρ →
            ModelsStrictForm item.oldNewState.formOldInst ρ) ∧
        ∃ ρ_viol : Env2,
          InEffDom item.oldNewState.domNew item.oldNewState.guardsNew ρ_viol ∧
          FormDefined item.oldNewState.formNewInst ρ_viol ∧
          ¬ ModelsStrictForm item.oldNewState.formNewInst ρ_viol

end OmegaCellC1P1B2BB2
