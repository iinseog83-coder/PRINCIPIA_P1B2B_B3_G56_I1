/-
  PRINCIPIA Ω-CELL-C1-P1B2B — Isolated Proof Core A0
  Root Library Module: OmegaCellC1P1B2BA0

  Strictly isolated proof core covering ONLY A0-01 .. A0-06:
    - A0-01 (`L_B2B_DomNz`) & A0-02 (`L_B2B_ImpNorm`)
    - A0-03 (`L_B2B_TelescopicPartition`)
    - A0-04 (`L_B2B_ParamSubst`) & A0-06 (`F-B2B-05` SOS Witness on Frozen G7)
    - A0-05 (`OutputCongruence`, `ActualLookupConfinement`, `RestrictionInvariance`,
             `SemanticDependencyClosure`, and `OutputCongruence ⇏ ActualLookupConfinement`)
  Zero G56 full bundle, zero ledger coupling, zero P1C/G1/GPED integration, zero authority minting.
-/
import OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm
import OmegaCellC1P1B2BA0.A0_03_TelescopicPartition
import OmegaCellC1P1B2BA0.A0_04_06_ParamSubstAndSosWitness
import OmegaCellC1P1B2BA0.A0_05_ProofDependencyClosure
