/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B2 — Isolated G6 Protected Invariant Kernel
  File: AuditB2G6Axioms.lean (Full Whitebox `Lean.Environment` & Non-Circularity Auditor for B2)

  Audits 100% of `OmegaCellC1P1B2BB2` module-owned constants (including `private` helpers):
    1. Zero `sorryAx`, zero `Lean.ofReduceBool` / `Lean.trustCompiler`, and zero custom `axiom`
       declarations (`{propext, Classical.choice, Quot.sound}` standard Lean kernel upper bound),
       reporting exact axioms used by all 39 `B2` headline theorems.
    2. Zero `unsafe`, zero `opaque`, and zero unjustified `partial` declarations across `B2`.
    3. Zero `GPED` or unauthorized `B3` / `B4` / `P1C` modules loaded.
    4. Anti-circularity check (`Cone*(S_sem_B2) ∩ K_exec_all = ∅`): verifies that all 9 declarative
       `S_sem_B2` predicates contain ZERO references to any executable checker in `P1B1..B2`.
    5. Direct-lookup bypass ban: verifies that `B2` core evaluators (`checkG6ParamBindingWfBool`,
       `checkG6ScopeLossRecordBool`, `checkG6ItemScopeBool`, `evalSingleG6Item`, `evalG6ItemsList`,
       `evalG6SuiteCore`, `checkG6Suite`, `qualifyG6Isolated?`) contain ZERO direct calls to
       `lookupDagNode?` or `lookupPrimPrem?` (all proof verification goes through `verifyReachableDerivation`).
    6. Private constructor sealing check (`F-B2-T12-01`): verifies at the `Lean.Environment` level
       that `G6QualifiedRecord` and `G6EmptySuiteNotice` have `private` constructors (`isPrivateName = true`).
-/
import Lean
import OmegaCellC1P1B2BB2

open Lean
open OmegaCellC1P1B2BB2

abbrev AuditEnvM := StateT Environment IO

instance : MonadEnv AuditEnvM where
  getEnv := get
  modifyEnv f := modify f

def b2Modules5 : List Name := [
  `OmegaCellC1P1B2BB2.B2_01_CertTypesAndSemantics,
  `OmegaCellC1P1B2BB2.B2_02_SuiteCheckersAndQualification,
  `OmegaCellC1P1B2BB2.B2_03_SoundnessPriorityAndClosure,
  `OmegaCellC1P1B2BB2.B2_04_WitnessesAndCounterexamples,
  `OmegaCellC1P1B2BB2
]

def ancestorModules21 : List Name := [
  `OmegaCellC1P1A0.P1A0A_BaseChartGuard,
  `OmegaCellC1P1A0.P1A0B_TransportScopeLoss,
  `OmegaCellC1P1A0.P1A0C_CheckerQualification,
  `OmegaCellC1P1A0,
  `OmegaCellC1P1B1.P1B1A_VerdictSlotReifier,
  `OmegaCellC1P1B1.P1B1B_LineageCommitSoundness,
  `OmegaCellC1P1B1,
  `OmegaCellC1P1B2A.P1B2AA_PartialExprPolyCert,
  `OmegaCellC1P1B2A.P1B2AB_TelescopicGuardAndDAG,
  `OmegaCellC1P1B2A.P1B2AC_ConservativeRefinementAndBundle,
  `OmegaCellC1P1B2A,
  `OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm,
  `OmegaCellC1P1B2BA0.A0_03_TelescopicPartition,
  `OmegaCellC1P1B2BA0.A0_04_06_ParamSubstAndSosWitness,
  `OmegaCellC1P1B2BA0.A0_05_ProofDependencyClosure,
  `OmegaCellC1P1B2BA0,
  `OmegaCellC1P1B2BB1.B1_01_CertTypesAndSemantics,
  `OmegaCellC1P1B2BB1.B1_02_RatCoordEvalAndCheckers,
  `OmegaCellC1P1B2BB1.B1_03_SoundnessAndClosure,
  `OmegaCellC1P1B2BB1.B1_04_WitnessesAndCounterexamples,
  `OmegaCellC1P1B2BB1
]

def b2HeadlineTheorems : List Name := [
  -- B2_01 & B2_02 Structural Foundations
  `OmegaCellC1P1B2BB2.exprUsesVarYBool_false_iff_free,
  `OmegaCellC1P1B2BB2.formUsesVarYBool_false_iff_free,
  `OmegaCellC1P1B2BB2.isG6SuiteVerifiedBool_implies_nonEmpty,
  -- B2_03 Gates A0..A10 & F-B2-T12-01..04
  `OmegaCellC1P1B2BB2.itemRoot_mem_suiteRoots,
  `OmegaCellC1P1B2BB2.T_B2_A0_AncestorLineageAndSlotCompatibility,
  `OmegaCellC1P1B2BB2.T_B2_A1_SuiteWellFormed_UniqueIds_And_CompleteCoverage,
  `OmegaCellC1P1B2BB2.T_B2_A2_ProtectedDomain_Guards_And_ParamSubst_Sound,
  `OmegaCellC1P1B2BB2.T_B2_A8_ItemScopeRetention_And_ExactLossPartition_Sound,
  `OmegaCellC1P1B2BB2.T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness,
  `OmegaCellC1P1B2BB2.T_B2_A3b_EmptySuiteAccepted_NoticeSound,
  `OmegaCellC1P1B2BB2.T_B2_A4a_CounterexampleSound_Unconditional,
  `OmegaCellC1P1B2BB2.T_B2_A4b_FullViolationRecordSound_Conditional,
  `OmegaCellC1P1B2BB2.T_B2_A4c_PremiseFreeViolation_BridgeViaA4b,
  `OmegaCellC1P1B2BB2.T_B2_A5_Unresolved_ConservativeHold_And_NonPromotion,
  `OmegaCellC1P1B2BB2.T_B2_F12_02A_EmptySuite_FunctionNeverIssues,
  `OmegaCellC1P1B2BB2.T_B2_F12_02B_EmptySuite_TypeForbidsRecord,
  `OmegaCellC1P1B2BB2.T_B2_A6_VerdictPriorityLattice_And_ExactClassification,
  `OmegaCellC1P1B2BB2.evalG6SuiteCore_congr_on_roots,
  `OmegaCellC1P1B2BB2.T_B2_A7_0_PrimDepsEquation_And_PermanentRetraction,
  `OmegaCellC1P1B2BB2.T_B2_A7_1_OutputCongruence,
  `OmegaCellC1P1B2BB2.T_B2_A7_2_RestrictionInvariance,
  `OmegaCellC1P1B2BB2.T_B2_A7_3_ActualLookupConfinement,
  `OmegaCellC1P1B2BB2.T_B2_A7_4_OutsidePremise_FullNonInterference,
  `OmegaCellC1P1B2BB2.T_B2_A10_RecordSealing_ZeroLedgerMutation_And_NoFullReflex,
  -- B2_04 Positive Witnesses (POS-G6-01..07), Gate A8.(2), Gate A9, & CE-G6-01..12 + 07B + NEG-G6-EMPTY-01
  `OmegaCellC1P1B2BB2.T_B2_A11_PositiveWitnessSuite_NonVacuous,
  `OmegaCellC1P1B2BB2.T_B2_A8_2_RetreatTruthOrthogonality,
  `OmegaCellC1P1B2BB2.B2_CE01_And_GateA9_G5_G6_EpistemicOrthogonality,
  `OmegaCellC1P1B2BB2.B2_CE02_ForgedProofWithoutPremise_Rejected,
  `OmegaCellC1P1B2BB2.B2_CE03_CrossFormulaProofReuse_And_DupId_Rejected,
  `OmegaCellC1P1B2BB2.B2_CE04_ParamThetaAndSpatialYCollision_Rejected,
  `OmegaCellC1P1B2BB2.B2_CE05_UndefinedReciprocalPointLaundering_FixedVerdict,
  `OmegaCellC1P1B2BB2.B2_CE06_OutOfDomainCounterexample_And_F12_03_NegativeCompanion,
  `OmegaCellC1P1B2BB2.B2_CE07A_And_CE07B_PartialSuite_And_UpfrontOfficialTruncation,
  `OmegaCellC1P1B2BB2.B2_CE08_OmittedIntermediatePrimPremise_Rejected,
  `OmegaCellC1P1B2BB2.B2_CE09_RevokedOrStaleSpecAndRetractedPremise_Rejected,
  `OmegaCellC1P1B2BB2.B2_CE10_UnresolvedToVerifiedPromotion_And_PriorityLattice,
  `OmegaCellC1P1B2BB2.B2_CE11_SilentPostDomainShrinkage_Blocked,
  `OmegaCellC1P1B2BB2.B2_CE12_G5AndG6Alone_CannotAdmitFullReflex_Or_MintGrant,
  `OmegaCellC1P1B2BB2.B2_Neg_EmptySuite_NeverIssues_G6QualifiedRecord
]

def b2SemanticAnchors : List Name := [
  `OmegaCellC1P1B2BB2.ExprFreeOfVarY,
  `OmegaCellC1P1B2BB2.FormFreeOfVarY,
  `OmegaCellC1P1B2BB2.SemValidG6ParamBinding,
  `OmegaCellC1P1B2BB2.SemValidG6ScopeRelation,
  `OmegaCellC1P1B2BB2.SemValidG6InvariantItem,
  `OmegaCellC1P1B2BB2.SemValidG6ProtectedSuite,
  `OmegaCellC1P1B2BB2.SemValidEmptyG6Notice,
  `OmegaCellC1P1B2BB2.SemPointCounterexampleOnNewDom,
  `OmegaCellC1P1B2BB2.SemViolatedG6ProtectedSuite
]

def allExecutableCheckers : List Name := [
  `OmegaCellC1P1B1.checkG3Matrix,
  `OmegaCellC1P1B1.reifyTransportCode,
  `OmegaCellC1P1B2A.evalPartExprFuel,
  `OmegaCellC1P1B2A.evalStrictFormFuel,
  `OmegaCellC1P1B2A.evalPartExprGrid,
  `OmegaCellC1P1B2A.evalStrictFormGrid,
  `OmegaCellC1P1B2A.checkAlgDomCertBool,
  `OmegaCellC1P1B2A.checkExprDefUnderNzBool,
  `OmegaCellC1P1B2A.checkFormDefUnderNzBool,
  `OmegaCellC1P1B2A.checkGuardsPrefixDefinedAux,
  `OmegaCellC1P1B2A.verifyReachableDerivation,
  `OmegaCellC1P1B2A.checkCertifiedG7BundleBool,
  `OmegaCellC1P1B2BA0.intrinsicNzOfDom,
  `OmegaCellC1P1B2BA0.checkGuardsAndGoalDomDefBool,
  `OmegaCellC1P1B2BA0.isAtomicStrictFormBool,
  `OmegaCellC1P1B2BA0.checkBaseDomRetreatStepBool,
  `OmegaCellC1P1B2BA0.checkWellFormedParamSpecBool,
  `OmegaCellC1P1B2BA0.verifyMultiRootTraced,
  `OmegaCellC1P1B2BA0.exprUsesVarYBool,
  `OmegaCellC1P1B2BA0.formUsesVarYBool,
  `OmegaCellC1P1B2BB1.checkRatCoordWfBool,
  `OmegaCellC1P1B2BB1.evalPartExprRatCoord,
  `OmegaCellC1P1B2BB1.evalStrictFormRatCoord,
  `OmegaCellC1P1B2BB1.checkInG7DomRatCoordBool,
  `OmegaCellC1P1B2BB1.checkGuardsSatRatCoordBool,
  `OmegaCellC1P1B2BB1.checkInEffDomRatCoordBool,
  `OmegaCellC1P1B2BB1.checkNotInEffDomRatCoordBool,
  `OmegaCellC1P1B2BB1.checkModelsExcisedRatCoordBool,
  `OmegaCellC1P1B2BB1.collectG5ProofRootIds,
  `OmegaCellC1P1B2BB1.deriveG5PrimDeps,
  `OmegaCellC1P1B2BB1.checkVerifiedObstructionBool,
  `OmegaCellC1P1B2BB1.checkRepairDomEqBool,
  `OmegaCellC1P1B2BB1.checkRetreatExactPartitionBool,
  `OmegaCellC1P1B2BB1.checkRefinementBool,
  `OmegaCellC1P1B2BB1.checkG5CoreProofsBool,
  `OmegaCellC1P1B2BB1.checkG5DischargeBool,
  `OmegaCellC1P1B2BB2.collectItemG6ProofRootIds,
  `OmegaCellC1P1B2BB2.collectG6ProofRootIds,
  `OmegaCellC1P1B2BB2.deriveG6PrimDeps,
  `OmegaCellC1P1B2BB2.checkG6ParamBindingWfBool,
  `OmegaCellC1P1B2BB2.checkG6ScopeLossRecordBool,
  `OmegaCellC1P1B2BB2.checkG6ItemScopeBool,
  `OmegaCellC1P1B2BB2.evalSingleG6Item,
  `OmegaCellC1P1B2BB2.evalG6ItemsList,
  `OmegaCellC1P1B2BB2.checkG6SuiteHeaderBasicBool,
  `OmegaCellC1P1B2BB2.evalG6SuiteCore,
  `OmegaCellC1P1B2BB2.checkG6Suite,
  `OmegaCellC1P1B2BB2.isG6SuiteVerifiedBool,
  `OmegaCellC1P1B2BB2.hasAnyG6StructuralOrCertDefectBool,
  `OmegaCellC1P1B2BB2.qualifyG6Isolated?,
  `OmegaCellC1P1B2BB2.inspectG6EmptySuiteNotice?,
  `OmegaCellC1P1B2BB2.checkOfficialSuiteIdsMatchBool,
  `OmegaCellC1P1B2BB2.checkActiveG6SuiteBool
]

def b2CoreEvaluators : List Name := [
  `OmegaCellC1P1B2BB2.checkG6ParamBindingWfBool,
  `OmegaCellC1P1B2BB2.checkG6ScopeLossRecordBool,
  `OmegaCellC1P1B2BB2.checkG6ItemScopeBool,
  `OmegaCellC1P1B2BB2.evalSingleG6Item,
  `OmegaCellC1P1B2BB2.evalG6ItemsList,
  `OmegaCellC1P1B2BB2.checkG6SuiteHeaderBasicBool,
  `OmegaCellC1P1B2BB2.evalG6SuiteCore,
  `OmegaCellC1P1B2BB2.checkG6Suite,
  `OmegaCellC1P1B2BB2.isG6SuiteVerifiedBool,
  `OmegaCellC1P1B2BB2.qualifyG6Isolated?
]

def isCoreMod (m : Name) : Bool :=
  let r := m.getRoot
  r == `Init || r == `Std || r == `Lean

def directDeps (env : Environment) (c : Name) : Array Name :=
  match env.find? c with
  | none => #[]
  | some ci =>
      let base := ci.type.getUsedConstants
      match ci with
      | .defnInfo v   => base ++ v.value.getUsedConstants
      | .thmInfo v    => base ++ v.value.getUsedConstants
      | .opaqueInfo v => base ++ v.value.getUsedConstants
      | .inductInfo v =>
          v.ctors.foldl (fun acc ctor =>
            match env.find? ctor with
            | some cci => acc ++ cci.type.getUsedConstants
            | none     => acc) base
      | .recInfo v =>
          v.rules.foldl (fun acc r => acc ++ r.rhs.getUsedConstants) base
      | _ => base

def transitiveCone (env : Environment) (seeds : List Name) : Std.HashSet Name := Id.run do
  let mut visited : Std.HashSet Name := {}
  let mut q : Array Name := seeds.toArray
  let mut idx : Nat := 0
  while idx < q.size do
    let cur := q[idx]!
    idx := idx + 1
    if !visited.contains cur then
      visited := visited.insert cur
      for nxt in directDeps env cur do
        if !visited.contains nxt then
          q := q.push nxt
  return visited

def isStructCtorPrivate (env : Environment) (indName : Name) : Bool :=
  match env.find? indName with
  | some (.inductInfo v) =>
      (!v.ctors.isEmpty) && v.ctors.all isPrivateName
  | _ => false

def toJsonStrArr (xs : List String) : Json :=
  Json.arr (xs.toArray.map Json.str)

def main : IO UInt32 := do
  initSearchPath (← findSysroot)
  let pubEnv ← importModules #[{ module := `OmegaCellC1P1B2BB2 }] {}
  let rawEnv ← importModules #[{ module := `OmegaCellC1P1B2BB2, importAll := true }] {}
  let env := rawEnv.setExporting false

  let allowedMods := b2Modules5 ++ ancestorModules21
  let mut unexpectedMods : List String := []
  let mut gpedMods : List String := []
  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    let ms := m.toString
    if ms.startsWith "Gped" || ms.startsWith "Principia" then
      gpedMods := ms :: gpedMods
    if !(isCoreMod m || allowedMods.contains m) then
      unexpectedMods := ms :: unexpectedMods

  let mut pubB2Decls : List String := []
  for i in [:pubEnv.header.moduleNames.size] do
    if b2Modules5.contains pubEnv.header.moduleNames[i]! then
      for c in pubEnv.header.moduleData[i]!.constNames do
        match c with
        | .str (`OmegaCellC1P1B2BB2) nm =>
            if !(nm.startsWith "instDecidableEq" || nm.startsWith "instRepr" || nm.startsWith "_private") then
              pubB2Decls := c.toString :: pubB2Decls
        | _ => pure ()
  let sortedPubB2 := pubB2Decls.mergeSort (· < ·)

  let allowedAx : List Name := [`propext, `Classical.choice, `Quot.sound]
  let mut b2OwnedConstCount : Nat := 0
  let mut badAxiomRefs : List String := []
  let mut customAxiomDefs : List String := []
  let mut unsafeConsts : List String := []
  let mut opaqueConsts : List String := []
  let mut unjustifiedPartialConsts : List String := []
  let mut justifiedUnsafeRecCount : Nat := 0

  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    if b2Modules5.contains m then
      let md := env.header.moduleData[i]!
      b2OwnedConstCount := b2OwnedConstCount + md.constNames.size
      for c in md.constNames do
        let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) c) env
        for a in axs do
          if !allowedAx.contains a then
            badAxiomRefs := s!"{c} -> {a}" :: badAxiomRefs
        match env.find? c with
        | none => badAxiomRefs := s!"MISSING:{c}" :: badAxiomRefs
        | some ci =>
            if ci.isUnsafe then
              unsafeConsts := c.toString :: unsafeConsts
            match ci with
            | .axiomInfo _  => customAxiomDefs := c.toString :: customAxiomDefs
            | .opaqueInfo _ => opaqueConsts := c.toString :: opaqueConsts
            | .defnInfo v   =>
                if v.safety == .partial then
                  match c with
                  | .str parent "_unsafe_rec" =>
                      match env.find? parent with
                      | some (.defnInfo pv) =>
                          if pv.safety == .safe then
                            justifiedUnsafeRecCount := justifiedUnsafeRecCount + 1
                          else
                            unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
                      | _ => unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
                  | _ => unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
            | _ => pure ()

  let mut missingHeadline : List String := []
  let mut headlineAxiomReport : List (String × Json) := []
  let mut nativeDecideTrustRefs : List String := []
  for thm in b2HeadlineTheorems do
    match env.find? thm with
    | none => missingHeadline := thm.toString :: missingHeadline
    | some _ =>
        let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) thm) env
        if axs.contains `Lean.ofReduceBool || axs.contains `Lean.trustCompiler then
          nativeDecideTrustRefs := thm.toString :: nativeDecideTrustRefs
        headlineAxiomReport := headlineAxiomReport ++
          [(thm.toString, toJsonStrArr (axs.toList.map Name.toString))]

  let semCone := transitiveCone env b2SemanticAnchors
  let mut semCircularHits : List String := []
  for k in allExecutableCheckers do
    if semCone.contains k then
      semCircularHits := k.toString :: semCircularHits

  let mut directLookupBypassHits : List String := []
  for evFn in b2CoreEvaluators do
    let ddeps := directDeps env evFn
    if ddeps.contains `OmegaCellC1P1B2A.lookupDagNode? then
      directLookupBypassHits := s!"{evFn} -> lookupDagNode?" :: directLookupBypassHits
    if ddeps.contains `OmegaCellC1P1B2A.lookupPrimPrem? then
      directLookupBypassHits := s!"{evFn} -> lookupPrimPrem?" :: directLookupBypassHits

  let recordPrivateSealed := isStructCtorPrivate env `OmegaCellC1P1B2BB2.G6QualifiedRecord
  let noticePrivateSealed := isStructCtorPrivate env `OmegaCellC1P1B2BB2.G6EmptySuiteNotice

  let allOk :=
    unexpectedMods.isEmpty &&
    gpedMods.isEmpty &&
    badAxiomRefs.isEmpty &&
    customAxiomDefs.isEmpty &&
    nativeDecideTrustRefs.isEmpty &&
    unsafeConsts.isEmpty &&
    opaqueConsts.isEmpty &&
    unjustifiedPartialConsts.isEmpty &&
    missingHeadline.isEmpty &&
    semCircularHits.isEmpty &&
    directLookupBypassHits.isEmpty &&
    recordPrivateSealed &&
    noticePrivateSealed

  let report := Json.mkObj [
    ("auditSchema", Json.str "principia.omega.p1b2b.b2.g6_env_audit.v1"),
    ("allChecksPassed", Json.bool allOk),
    ("b2OwnedConstantCount", Json.num b2OwnedConstCount),
    ("b2PublicDeclCount", Json.num sortedPubB2.length),
    ("b2PublicDecls", toJsonStrArr sortedPubB2),
    ("headlineTheoremCount", Json.num b2HeadlineTheorems.length),
    ("missingHeadlineTheorems", toJsonStrArr missingHeadline),
    ("nativeDecideOrTrustCompilerRefs", toJsonStrArr nativeDecideTrustRefs),
    ("headlineTheoremAxioms", Json.mkObj headlineAxiomReport),
    ("unexpectedModules", toJsonStrArr unexpectedMods),
    ("gpedModulesDetected", toJsonStrArr gpedMods),
    ("badAxiomRefs", toJsonStrArr badAxiomRefs),
    ("customAxiomDefs", toJsonStrArr customAxiomDefs),
    ("unsafeConsts", toJsonStrArr unsafeConsts),
    ("opaqueConsts", toJsonStrArr opaqueConsts),
    ("unjustifiedPartialConsts", toJsonStrArr unjustifiedPartialConsts),
    ("justifiedCompilerUnsafeRecCount", Json.num justifiedUnsafeRecCount),
    ("b2SemanticConeSize", Json.num semCone.size),
    ("semanticCheckerCircularHits", toJsonStrArr semCircularHits),
    ("directLookupBypassHits", toJsonStrArr directLookupBypassHits),
    ("qualifiedRecordPrivateCtorSealed", Json.bool recordPrivateSealed),
    ("emptyNoticePrivateCtorSealed", Json.bool noticePrivateSealed),
    ("officialRegistryBindingStatus", Json.str "HELD_FOR_B4_AND_P1C")
  ]
  IO.println report.pretty
  return (if allOk then 0 else 1)
