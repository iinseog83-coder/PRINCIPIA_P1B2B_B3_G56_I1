/-
  PRINCIPIA Ω-CELL-C1-P1B1 — Zero-Gap Public Declaration Axiom Audit
  File: AuditC1P1B1Axioms.lean

  Audits 100% of public non-theorem declarations (`41 + 42 = 83`) and 100% of public
  theorems (`6 + 7 = 13`), totaling `96/96` public declarations (`GAP = 0`), across:
    - `OmegaCellC1P1B1.P1B1A_VerdictSlotReifier`
    - `OmegaCellC1P1B1.P1B1B_LineageCommitSoundness`
-/
import OmegaCellC1P1B1

open OmegaCellC1P1B1

-- ============================================================================
-- 1A. Module P1B1A: 41/41 Public Non-Theorem Declarations (`P1B1A_VerdictSlotReifier.lean`)
-- ============================================================================
#print axioms StructuralPathKey
#print axioms AuditSlot
#print axioms SlotWitness
#print axioms CheckDerivesNoGrant
#print axioms StructuralGateId
#print axioms StructuralRejectErr
#print axioms RawRefutationCert
#print axioms checkRawRefutationBool
#print axioms VerifiedRefutationPacket
#print axioms NonAcceptOutcome
#print axioms CheckedG2348Summary
#print axioms checkG2348SummaryBool
#print axioms ReflexQualification
#print axioms UnauthorizedStageCert
#print axioms checkUnauthStageCertBool
#print axioms StructuralQualification
#print axioms FullReflexAdmitted
#print axioms extractSummary
#print axioms upgradeStructuralToFull
#print axioms StructuralVerdict6
#print axioms nonAcceptToVerdict6
#print axioms isStructuralAcceptBool
#print axioms hasVerifiedRefutationBool
#print axioms KernelObstKindV1
#print axioms ExplorerObstInput
#print axioms ReflexKind
#print axioms ObstReflexMatrixAllowed
#print axioms checkG3Matrix
#print axioms KernelDomTagV1
#print axioms domTagToId
#print axioms parseDomTagV1?
#print axioms DomTagCarrier
#print axioms domTagCanonicalAnchor
#print axioms KindDomainLaw
#print axioms TransportCode
#print axioms ReifiedTransportMode
#print axioms ReifiedRawTransport
#print axioms reifyRawTransport
#print axioms CertifiedTransportPackage
#print axioms extractKindDomainLaw
#print axioms reifyTransportCode

-- ============================================================================
-- 1B. Module P1B1A: 6/6 Public Theorems (`P1B1A_VerdictSlotReifier.lean`)
-- ============================================================================
#print axioms verified_slot_has_checked_cert
#print axioms verifiedRefutationPacket_sound
#print axioms T_B1_01_proof_bearing_slots_and_verdict_polarity
#print axioms T_B1_03_obstruction_matrix_and_env_misuse_separation
#print axioms parseDomTagV1?_sound
#print axioms T_B1_02_reifyTransportCode_sound_and_seq_checked

-- ============================================================================
-- 2A. Module P1B1B: 42/42 Public Non-Theorem Declarations (`P1B1B_LineageCommitSoundness.lean`)
-- ============================================================================
#print axioms StoredCellHeader
#print axioms StoredObstHeader
#print axioms StructuralStore
#print axioms RegistryContextValid
#print axioms StoreLookupConsistent
#print axioms StructuralReflexAST
#print axioms derivePathKey
#print axioms CommittedLineageEntry
#print axioms InstitutionalGrantRec
#print axioms EpistemicStructState
#print axioms GrantLedgerState
#print axioms StructuralLedgerState
#print axioms StructuralLedgerEvent
#print axioms ledgerEventSummaryTag
#print axioms stepEpistemicState
#print axioms stepGrantLedgerState
#print axioms stepStructuralLedger
#print axioms initStructuralLedger
#print axioms foldStructuralLedger
#print axioms lookupCellGrantsInLedger
#print axioms isGrantCurrentlyEligibleBool
#print axioms checkStructuralReflex
#print axioms ExactHistoryCommitPacket
#print axioms StructuralCommitErr
#print axioms tryCommitStructural
#print axioms SemStructuralValid
#print axioms stdStructStore
#print axioms GateNecessityCert
#print axioms checkMutantSkipG2
#print axioms checkMutantSkipG3
#print axioms checkMutantSkipG4
#print axioms checkMutantSkipG8
#print axioms astPosRepair
#print axioms astPosRetreat
#print axioms astPosRefinementStep2
#print axioms astAttackCEC101
#print axioms entryCommittedRetreatStep1
#print axioms astAttackCEC102
#print axioms astAttackCEC104
#print axioms astAttackCEC106
#print axioms astAttackWrongObstCell
#print axioms sampleGrantG2

-- ============================================================================
-- 2B. Module P1B1B: 7/7 Public Theorems (`P1B1B_LineageCommitSoundness.lean`)
-- ============================================================================
#print axioms domTagCanonicalAnchor_injective
#print axioms T_B1_04_pathKey_injective_and_lineage_scopeLoss_monotone
#print axioms stdStructCtx_consistent
#print axioms T_B1_05_structural_master_soundness_and_consistency
#print axioms T_B1_05b_four_gate_drop_necessity_suite
#print axioms T_B1_06_tri_phase_zero_mint_snapshot_pathKey_and_eligibility_sep
#print axioms T_B1_08_positive_structural_accepts_and_adversarial_suite
