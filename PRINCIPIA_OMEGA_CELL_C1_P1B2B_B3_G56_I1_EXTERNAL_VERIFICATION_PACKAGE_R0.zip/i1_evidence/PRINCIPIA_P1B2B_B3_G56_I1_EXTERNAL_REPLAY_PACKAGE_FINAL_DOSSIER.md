# PRINCIPIA Ω-CELL-C1-P1B2B-B3 G56 — I1 Independent External Replay Act (Method A) Final Dossier

- **Work Identifier:** `PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_I1_INDEPENDENT_EXTERNAL_REPLAY_ACT`
- **Authorized Scope:** **Method A (`I1-P0` Self-Contained Package + `I1-P1` Local Double Clean Replay + Workflow Preparation)** under Human L4 Directive Articles 1–8.
- **Target Review:** **20th Independent Tribunal** (Pre-Execution Qualification Review prior to separate GitHub upload / GitHub Actions Linux replay `I1-P2`).
- **Toolchain (Pinned & Verified):** `leanprover/lean4:v4.33.1` (`Lean 4.33.1, commit 819816b2e0a3bf405af45ae5c7af2491d8f5bee6`, `Lake 5.0.0-src+819816b`).
- **Authority Escalation:** `0` (`GitHub Upload = NOT AUTHORIZED`, `External CI Execution = HELD`, `I0 Permanent Canonical Promotion = HELD`, `B4 / P1C / G1 / GPED / B-Series = 0`).

---

## 1. Five-Tuple Replay Evidence Lineage $\mathcal{E}_{\mathrm{I1}} = (H_S, H_E, H_O, H_W, H_R)$

Every replay artifact in `i1_local_double_clean_replay_receipt.json` and `i1_cansem_double_replay_comparison.json` is cryptographically bound to the same five-tuple lineage:

| Symbol | Bound Artifact | Byte Size | Verified `SHA-256` |
| :---: | :--- | ---: | :--- |
| $H_S$ | `manifest_active_replay_62_sources.json` (`50` across 6 frozen ancestors + `12` `B3 I0`) | `29,599 B` | `6E9CEEFFBBD400AB052A7F76DA7BFD1F35EEBD07AF1AF939FB09728AB4BD01DE` |
| $H_E$ | `i1_environment_and_cansem_spec.json` (Toolchain & pre-declared `CanSem` rules) | `1,744 B` | `6E4781190E1430C059513AEFB1B6CBE7955EC84A26988ECEA87E69F4A221E270` |
| $H_O$ | `i1_precommitted_oracle_71.json` (Pre-run & post-run verified `R1` + `R2`) | `18,505 B` | `33B7679D90435EE70B6257D1FF344977ECCAD55A5311BB9A846D6CE103E00956` |
| $H_W$ | `principia_p1b2b_b3_g56_i1_external_replay_r0.yml` (Pinned `ubuntu-latest` workflow) | `10,715 B` | `DF7E8D9719F4C1499A438B0519833F94D3C10098D1BD68103FFCDE1B90C1B4D8` |
| $H_R$ | Canonical JSON digest of `coreExecutionBody` (`R1`, `R2`, `CanSem`, `6/6` Calibration) | — | `0F067F1D5D972B5CAC9F08CB1D260B6C5B0BB4CC19411EF57E6A62E858001865` |

### Independent Zero-Cache Local Double Clean Replay (`R1` vs `R2`)
- **Zero Cache & Zero Shared Build Artifacts:** `Replay R1` and `Replay R2` were staged in completely separate fresh OS temporary directories (`principia_b3_i1_R1_*` and `principia_b3_i1_R2_*`), copying **only** the `62` pure source files (`0` `.lake` directories copied) + `5` `KitB3I1` Lean package files.
- **Full 7-Package + VerifyKit Compilation From Scratch Per Replay:**
  - `Replay R1`: `buildExitCode = 0`, `observerExitCode = 0`, `warnings = 0`, `errors = 0`, build `131.782s`, observer `53.305s` (`rawBuildLogSha256 = F5780FA409D9B6273ED02A2338340B2646D98297CC5CA459C6C04E3DA8C39B5E`).
  - `Replay R2`: `buildExitCode = 0`, `observerExitCode = 0`, `warnings = 0`, `errors = 0`, build `140.485s`, observer `45.896s` (`rawBuildLogSha256 = 918319B9812F38B29E670C5E679164074D10391F297A3A86570F41EC25D64049`).
- **Canonical Semantic Equivalence ($\mathrm{CanSem}(R_1) = \mathrm{CanSem}(R_2)$):**
  $$\mathrm{SHA256}(\mathrm{CanSem}(R_1)) = \mathrm{SHA256}(\mathrm{CanSem}(R_2)) = \mathtt{FDC88FD01F818E4C7A1CDD16188F5D8680C5E9CECCD4BC246D1BAC0C2A40E4B2}$$
  Comparing all `41` kernel-pretty-printed theorem signatures + transitive axiom closures, `6` `KitB3I1` theorem axiom closures, all `71` live verdicts + dynamic qualification statuses, `12` `M_registered` + `12` `M_end_to_end` observations, all `2,081` constant classification counts (`|U| = 0`), anti-circularity & barrier confinement results, and provenance-bound consumer checks.
- **Isolated Fault-Sensitivity Calibration (`CAL-B3-I1-01` .. `06`):** `6/6` injected faults deterministically caught (`caughtCount = 6`, including live rejection of a tampered oracle by the compiled `ExternalObsAndTcbAuditB3I1` binary).

---

## 2. Detached `KitB3I1` Inventory (`14` Files, `288,781` Bytes, `5,957` Lines)

| File Name | Lines | Bytes | UTF-8 / LF | SHA-256 |
| :--- | ---: | ---: | :---: | :--- |
| `lean-toolchain` | `1` | `25` | `PASS` | `3AAC669C7A910EC2389F4E4F921B605ADF6EBF2D1E0C9B9CD0BE4D33F3F5DB71` |
| `lakefile.toml` | `39` | `974` | `PASS` | `AEE0B8D330DE6916677AA094902A01811371C3428D554C31522201DEB15C8D6F` |
| `lake-manifest.json` | `55` | `1,753` | `PASS` | `8234729F06FCC15BA95F00F7BEFB563CF978F487A9675AB43CE99E8BF2D863B5` |
| `manifest_workspace_186_baseline.json` | `1,530` | `72,567` | `PASS` | `9D445C5322F451ABA54284F5F8CABFBBF498F5C943969FDA8FC38AF7C5DD17CC` |
| `manifest_active_replay_62_sources.json` ($H_S$) | `551` | `29,599` | `PASS` | `6E9CEEFFBBD400AB052A7F76DA7BFD1F35EEBD07AF1AF939FB09728AB4BD01DE` |
| `i1_environment_and_cansem_spec.json` ($H_E$) | `52` | `1,744` | `PASS` | `6E4781190E1430C059513AEFB1B6CBE7955EC84A26988ECEA87E69F4A221E270` |
| `i1_precommitted_oracle_71.json` ($H_O$) | `571` | `18,505` | `PASS` | `33B7679D90435EE70B6257D1FF344977ECCAD55A5311BB9A846D6CE103E00956` |
| `ExternalSpecPinB3I1.lean` | `1,382` | `80,510` | `PASS` | `6861148B4D3D55BEB95CB476A2D0FDC825D1551C35A8783BEBAE2D048A0DA87D` |
| `ExternalObsAndTcbAuditB3I1.lean` | `648` | `32,208` | `PASS` | `89914F6BFA9A6731877D09E6CF18729911D215279820A8FC1B683ECC987E2DD6` |
| `audit_b3_i1_core.py` | `551` | `22,597` | `PASS` | `29EB7F7D370D29B002DC8DDAA7107EB3A437EE2AE0632E9D4AF562D1C226836B` |
| `run_calibration_b3_i1.py` | `154` | `6,720` | `PASS` | `E9650B147EF998724ABC7A14D6531EF5FB9091F9C72B2F9C849F5817C1BEA823` |
| `run_verify_b3_i1.py` | `198` | `7,631` | `PASS` | `2DB542C09CC87F9708E7A808F5638388294263AE61D5BA264C9EC0A082DD7400` |
| `principia_p1b2b_b3_g56_i1_external_replay_r0.yml` ($H_W$) | `201` | `10,715` | `PASS` | `DF7E8D9719F4C1499A438B0519833F94D3C10098D1BD68103FFCDE1B90C1B4D8` |
| `README_VERIFY_KIT_B3_I1.md` | `24` | `3,233` | `PASS` | `DF102A912370F323E23D40FF7CBE8D5C187C9D4DC290187AD415923E603DD8A3` |
| **Total (`14` files)** | **`5,957`** | **`288,781`** | **`14/14 PASS`** | Recorded in `i1_kit_14_manifest.json` |

---

## 3. Resolution & Scoping of the 26 Binding Conditions (`15` Prior + `6` `T19` + `5` `I1`)

| Condition | Requirement | `I1` Implementation & Verification Evidence | Status |
| :--- | :--- | :--- | :---: |
| `T17/R1/T18` (`15`) | Inherited `B3` static & formal binding conditions | All `41` `I0` theorems preserved untouched (`0 B` diff) & pinned via standalone `isDefEq` signatures (`Pin_01..41`) | `PRESERVED & PINNED` |
| `F-B3-T19-01` | Separate unbound `projectCoupledVerdictR1` from `evalG56DetailedR1` provenance | `ProvenanceBoundG56Diagnostic`, `T_I1_A9_01_UnboundDetProjectionCanSpoofInvalidCoupling`, `T_I1_A9_02_ProvenanceBoundConsumerExactAndSound` | `DISCHARGED IN KIT` |
| `F-B3-T19-02` | Distinguish mutation probe layers vs isolated end-to-end single-fault mutants | `registered12ProbeLayerMap` + `12` new full-pipeline single-fault mutants (`E2E-I1-01..12`, `T_I1_A7_01`, `T_I1_A7_02`) | `DISCHARGED IN KIT` |
| `F-B3-T19-03` | Oracle temporal binding & runtime execution of qualification | Pre/post `H_O` verified across `R1` & `R2`; `qualifyG56Coupled?` dynamically invoked on all `55/55` coupled-cert cases (`16/16` non-cert target evals explicit) | `DISCHARGED FOR I1` |
| `F-B3-T19-04` | Semantic-checker classification completeness & transitive lookup confinement | All `2,081` `B3` constants partitioned ($7 + 86 + 218 + 109 + 197 + 1464 = 2081$, $|U| = 0$); `Cone*(S_7) ∩ K_170 = ∅`; `0` bypasses in `1,677`-node barrier-stopped cone | `DISCHARGED IN KIT` |
| `F-B3-T19-05` | Separate manifest identity from per-file physical workspace measurement | Full per-file pre-replay (`i1_gate0_physical_186_pre_measurement.json`) & post-replay (`i1_post_replay_physical_186_measurement.json`) SHA-256 tables (`186/186` `0` diff) + `62` bundled sources | `DISCHARGED LOCALLY` |
| `F-B3-T19-06` | Self-contained 6-ancestor + `B3` zero-cache build & external Linux replay | All `6` ancestors (`50` files) + `B3 I0` (`12` files) bundled in `self_contained_sources/` & zero-cache built twice locally (`R1`, `R2`); external Linux CI replay `HELD` for `I1-P2` | `LOCAL DONE / EXT HELD` |
| `Q-B3-I1-01` | Do not retroactively claim historical `I0` oracle pre-commitment | `I0` historical oracle status explicitly kept `HELD`; `H_O` pre/post proof claimed strictly for `I1` replays | `ENFORCED` |
| `Q-B3-I1-02` | Never modify frozen/`I0` `lakefile.toml`; mirror relative sibling layout | `0` edits to any `lakefile.toml`; `self_contained_sources/` mirrors exact `../principia_omega_cell_c1_*` paths | `ENFORCED` |
| `Q-B3-I1-03` | Separate `M_registered`, `M_end_to_end`, equivalent, and non-constructible mutants | `12` `M_registered` + `12` `M_end_to_end` + `T_I1_A7_03_EQ01_CommutedUnionIsProvablyEquivalentMutant` + `NC-I1-01` private-ctor class | `ENFORCED` |
| `Q-B3-I1-04` | Separate raw constant enumeration from rule-audited classification (`U`) | Explicit partition rules audited in `ExternalObsAndTcbAuditB3I1.lean`; `unclassifiedRelevantDeclarationSet_U = []` (`0`) | `ENFORCED` |
| `Q-B3-I1-05` | Separate 5 epistemic tiers (`LOCAL`, `EXTERNAL_CI`, `TRIBUNAL_SOURCE`, `TRIBUNAL_REPLAY`, `HUMAN_L4`) | Explicitly recorded in `i1_26_binding_conditions_and_authority_ledger.json` and `run_verify_b3_i1.py` | `ENFORCED` |

---

## 4. Gate-by-Gate Completion vs External Execution Hold (`Article 8` Honesty Table)

| Gate | Scope | Current Status Under Method A |
| :---: | :--- | :--- |
| `I1-G0` | `186` workspace files + `3` prior ZIPs + `26` binding conditions | **COMPLETED LOCALLY (`PASS`)** |
| `I1-A1` | Self-contained `62`-file source closure (`50` ancestors + `12` `B3 I0`) | **COMPLETED & BUNDLED (`H_S`)** |
| `I1-A2` | Detached `KitB3I1` (`14` files, `0` bytes mutated in baseline) | **COMPLETED (`PASS`)** |
| `I1-A3` | Lean `4.33.1` & Linux `ubuntu-latest` workflow specification | **PINNED (`H_E`, `H_W`) — EXTERNAL EXECUTION `HELD`** |
| `I1-A4` | Zero-cache full-lineage Double Clean Replay (`CanSem(R1) = CanSem(R2)`) | **LOCAL DOUBLE REPLAY VERIFIED — EXTERNAL LINUX REPLAY `HELD`** |
| `I1-A5` | `41/41` `isDefEq` kernel theorem signature pins & axiom closures | **LOCAL REPLAY VERIFIED (`0` `sorryAx`, `0` `native_decide`)** |
| `I1-A6` | Pre/post `H_O` oracle hash binding & `71/71` live qualification observation | **LOCAL REPLAY VERIFIED (`I0` historical status `HELD`)** |
| `I1-A7` | Separated `12` `M_registered` + `12` `M_end_to_end` + `EQ-I1-01` + `NC-I1-01` | **LOCAL REPLAY VERIFIED (`12/12` + `12/12` killed)** |
| `I1-A8` | `2,081`-constant classification (`|U|=0`), `0` circularity, `0` barrier bypass | **LOCAL REPLAY VERIFIED (`PASS`)** |
| `I1-A9` | Provenance-bound consumer & spoofed `det` blocking (`T_I1_A9_01`, `02`) | **LOCAL REPLAY VERIFIED (`PASS`)** |
| `I1-A10` | Pre/post `186`-file physical measurements, preserved dev logs, `E_I1` 5-tuple | **COMPLETED LOCALLY (`0` byte diffs)** |
| `I1-A11` | 20th Independent Tribunal pre-execution package submission | **SUBMITTED — AWAITING T20 & SEPARATE HUMAN L4 FOR `I1-P2`** |

> [!IMPORTANT]
> **Preservation of Initial Kit-Authoring Logs (`Execution Discipline`):** During initial authoring of `KitB3I1` (`ExternalSpecPinB3I1.lean` & `ExternalObsAndTcbAuditB3I1.lean`, with `0` edits to `I0` or ancestors), three intermediate kit-development logs (`i1_kit_dev_attempt1_preserved.log`, `i1_kit_dev_attempt2_preserved.log`, `i1_kit_dev_attempt3_preserved.json`) were generated before final `KitB3I1` completion and are preserved verbatim inside `i1_evidence/` (`0` logs deleted).

---

**Mandatory Terminal Status:**
`PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_I1_PACKAGE_SUBMITTED_FOR_TWENTIETH_TRIBUNAL__EXTERNAL_EXECUTION_HELD — HARD STOP`
