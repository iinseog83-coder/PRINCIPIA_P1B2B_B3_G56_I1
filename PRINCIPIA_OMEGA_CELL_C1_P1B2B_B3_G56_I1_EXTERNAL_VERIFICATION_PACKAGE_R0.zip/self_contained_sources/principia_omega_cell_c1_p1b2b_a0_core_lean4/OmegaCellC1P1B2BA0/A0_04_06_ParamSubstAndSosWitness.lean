/-
  PRINCIPIA Ω-CELL-C1-P1B2B — Isolated Proof Core A0
  Module: OmegaCellC1P1B2BA0.A0_04_06_ParamSubstAndSosWitness

  Authorized Scope (`A0_ISOLATED_LEAN_MECHANIZATION_APPROVED`, `A0-GUARD-03`):
    - `A0-04` (`L_B2B_ParamSubst`):
      1. Syntactic `.varY`-occurrence detector (`exprUsesVarYBool`, `formUsesVarYBool`) and
         spatial-coordinate invariance theorem (`L_B2B_NoVarYSpatialInvariance`).
      2. `ProtectedInvariantKind` (`.fixedStateForm`, `.cellParamForm`) +
         `checkWellFormedParamSpecBool` enforcing 1D spatial carrier (`.domQ`/`.domQNonzero`,
         where `ρ.2 = 0` identically), `.varY`-free spatial guards, and positive denominator
         `0 < θDenPos` — preventing any collision between spatial `y` and parameter `θ`.
      3. Exact semantic substitution biconditional (`L_B2B_ParamSubst`) for both `FormDefined`
         and `ModelsStrictForm`.
    - `A0-06` (`A0_06_F_B2B_05_SOS_Witness_Accepted_By_Frozen_G7`):
      1. Constructs the `F-B2B-05` `x^2 + 4 > 0` `PolyPositivstellensatzCert`
         `⟨1, 4, [(1, .pVarX)], [], [], []⟩`, full `G7DagContainer`, and `CertifiedG7Bundle`.
      2. Proves in the Lean 4.33.1 kernel that unmodified frozen `P1B2A` checkers
         `checkAlgDomCertBool`, `verifyReachableDerivation`, and `checkCertifiedG7BundleBool`
         all return `true` / `.accept`!
      3. Proves the full `F-B2B-05` cross-term semantic triad:
         - Old invariant `I(x; 2) : x^2 + 2 ≥ 0` holds across ALL of `.domQ` (and is G7-certified!),
         - Repaired target `P_new(x) : x^2 + 4 > 0` holds at obstruction `(1, 0)` and across ALL `.domQ`,
         - Instantiated post-repair invariant `I(x; -2) : x^2 + (-2) ≥ 0` is strictly defined and
           FALSE at `(0, 0) ∈ .domQ` (`evalStrictFormFuel = .satDefinedFalse`), while a bogus SOS
           certificate for `x^2 - 2 ≥ 0` is deterministically rejected (`= false`) by frozen `P1B2A`!
-/
import OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm

namespace OmegaCellC1P1B2BA0

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A

/-! ### 1. `.varY` Syntax Firewall & Spatial Coordinate Invariance -/

/-- Computable check testing whether `PartExpr` syntactically mentions `.varY`. -/
def exprUsesVarYBool : PartExpr → Bool
  | .const _   => false
  | .varX      => false
  | .varY      => true
  | .neg e     => exprUsesVarYBool e
  | .add e1 e2 => exprUsesVarYBool e1 || exprUsesVarYBool e2
  | .sub e1 e2 => exprUsesVarYBool e1 || exprUsesVarYBool e2
  | .mul e1 e2 => exprUsesVarYBool e1 || exprUsesVarYBool e2
  | .div e1 e2 => exprUsesVarYBool e1 || exprUsesVarYBool e2

/-- Computable check testing whether `StrictForm` syntactically mentions `.varY`. -/
def formUsesVarYBool : StrictForm → Bool
  | .eqZero e      => exprUsesVarYBool e
  | .nonneg e      => exprUsesVarYBool e
  | .pos e         => exprUsesVarYBool e
  | .neqZero e     => exprUsesVarYBool e
  | .conj φ ψ      => formUsesVarYBool φ || formUsesVarYBool ψ
  | .impStrict φ ψ => formUsesVarYBool φ || formUsesVarYBool ψ

private theorem exprNoVarY_evalRel_iff {e : PartExpr} (hNoY : exprUsesVarYBool e = false)
    (x y1 y2 : Rat) (v : Rat) :
    PartExprEvalRel e (x, y1) v ↔ PartExprEvalRel e (x, y2) v := by
  induction e generalizing v with
  | const c =>
      constructor <;> (intro h; cases h; exact .const c _)
  | varX =>
      constructor <;> (intro h; cases h; exact .varX _)
  | varY =>
      nomatch hNoY
  | neg e1 ih =>
      dsimp [exprUsesVarYBool] at hNoY
      constructor
      · intro h; cases h with | neg ha => exact .neg ((ih hNoY _).mp ha)
      · intro h; cases h with | neg ha => exact .neg ((ih hNoY _).mpr ha)
  | add e1 e2 ih1 ih2 =>
      dsimp [exprUsesVarYBool] at hNoY
      simp only [Bool.or_eq_false_iff] at hNoY
      constructor
      · intro h; cases h with | add ha hb => exact .add ((ih1 hNoY.1 _).mp ha) ((ih2 hNoY.2 _).mp hb)
      · intro h; cases h with | add ha hb => exact .add ((ih1 hNoY.1 _).mpr ha) ((ih2 hNoY.2 _).mpr hb)
  | sub e1 e2 ih1 ih2 =>
      dsimp [exprUsesVarYBool] at hNoY
      simp only [Bool.or_eq_false_iff] at hNoY
      constructor
      · intro h; cases h with | sub ha hb => exact .sub ((ih1 hNoY.1 _).mp ha) ((ih2 hNoY.2 _).mp hb)
      · intro h; cases h with | sub ha hb => exact .sub ((ih1 hNoY.1 _).mpr ha) ((ih2 hNoY.2 _).mpr hb)
  | mul e1 e2 ih1 ih2 =>
      dsimp [exprUsesVarYBool] at hNoY
      simp only [Bool.or_eq_false_iff] at hNoY
      constructor
      · intro h; cases h with | mul ha hb => exact .mul ((ih1 hNoY.1 _).mp ha) ((ih2 hNoY.2 _).mp hb)
      · intro h; cases h with | mul ha hb => exact .mul ((ih1 hNoY.1 _).mpr ha) ((ih2 hNoY.2 _).mpr hb)
  | div e1 e2 ih1 ih2 =>
      dsimp [exprUsesVarYBool] at hNoY
      simp only [Bool.or_eq_false_iff] at hNoY
      constructor
      · intro h; cases h with | div ha hb hne => exact .div ((ih1 hNoY.1 _).mp ha) ((ih2 hNoY.2 _).mp hb) hne
      · intro h; cases h with | div ha hb hne => exact .div ((ih1 hNoY.1 _).mpr ha) ((ih2 hNoY.2 _).mpr hb) hne

/-- Spatial `.varY`-independence theorem: any `StrictForm` with `formUsesVarYBool φ = false`
    has identical definedness and truth across `(x, y₁)` and `(x, y₂)`. -/
theorem L_B2B_NoVarYSpatialInvariance {φ : StrictForm} (hNoY : formUsesVarYBool φ = false)
    (x y1 y2 : Rat) :
    (FormDefined φ (x, y1) ↔ FormDefined φ (x, y2)) ∧
    (FormRawSat φ (x, y1) ↔ FormRawSat φ (x, y2)) ∧
    (ModelsStrictForm φ (x, y1) ↔ ModelsStrictForm φ (x, y2)) := by
  have hCore : (FormDefined φ (x, y1) ↔ FormDefined φ (x, y2)) ∧
               (FormRawSat φ (x, y1) ↔ FormRawSat φ (x, y2)) := by
    induction φ with
    | eqZero e =>
        dsimp [formUsesVarYBool] at hNoY
        refine ⟨⟨fun ⟨v, h⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mp h⟩,
                 fun ⟨v, h⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mpr h⟩⟩,
                ⟨fun ⟨v, h, hz⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mp h, hz⟩,
                 fun ⟨v, h, hz⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mpr h, hz⟩⟩⟩
    | nonneg e =>
        dsimp [formUsesVarYBool] at hNoY
        refine ⟨⟨fun ⟨v, h⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mp h⟩,
                 fun ⟨v, h⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mpr h⟩⟩,
                ⟨fun ⟨v, h, hn⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mp h, hn⟩,
                 fun ⟨v, h, hn⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mpr h, hn⟩⟩⟩
    | pos e =>
        dsimp [formUsesVarYBool] at hNoY
        refine ⟨⟨fun ⟨v, h⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mp h⟩,
                 fun ⟨v, h⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mpr h⟩⟩,
                ⟨fun ⟨v, h, hp⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mp h, hp⟩,
                 fun ⟨v, h, hp⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mpr h, hp⟩⟩⟩
    | neqZero e =>
        dsimp [formUsesVarYBool] at hNoY
        refine ⟨⟨fun ⟨v, h⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mp h⟩,
                 fun ⟨v, h⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mpr h⟩⟩,
                ⟨fun ⟨v, h, hne⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mp h, hne⟩,
                 fun ⟨v, h, hne⟩ => ⟨v, (exprNoVarY_evalRel_iff hNoY x y1 y2 v).mpr h, hne⟩⟩⟩
    | conj φ1 φ2 ih1 ih2 =>
        dsimp [formUsesVarYBool] at hNoY
        simp only [Bool.or_eq_false_iff] at hNoY
        rcases ih1 hNoY.1 with ⟨hd1, hr1⟩
        rcases ih2 hNoY.2 with ⟨hd2, hr2⟩
        exact ⟨⟨fun h => ⟨hd1.mp h.1, hd2.mp h.2⟩, fun h => ⟨hd1.mpr h.1, hd2.mpr h.2⟩⟩,
               ⟨fun h => ⟨hr1.mp h.1, hr2.mp h.2⟩, fun h => ⟨hr1.mpr h.1, hr2.mpr h.2⟩⟩⟩
    | impStrict φ1 φ2 ih1 ih2 =>
        dsimp [formUsesVarYBool] at hNoY
        simp only [Bool.or_eq_false_iff] at hNoY
        rcases ih1 hNoY.1 with ⟨hd1, hr1⟩
        rcases ih2 hNoY.2 with ⟨hd2, hr2⟩
        exact ⟨⟨fun h => ⟨hd1.mp h.1, hd2.mp h.2⟩, fun h => ⟨hd1.mpr h.1, hd2.mpr h.2⟩⟩,
               ⟨fun h ha2 => hr2.mp (h (hr1.mpr ha2)), fun h ha1 => hr2.mpr (h (hr1.mp ha1))⟩⟩
  exact ⟨hCore.1, hCore.2,
    ⟨fun h => ⟨hCore.1.mp h.1, hCore.2.mp h.2⟩, fun h => ⟨hCore.1.mpr h.1, hCore.2.mpr h.2⟩⟩⟩

/-! ### 2. `A0-04` — `L_B2B_ParamSubst` (`WellFormedParamTemplate` & Exact Substitution) -/

/-- Syntactic substitution replacing `.varY` by `θExpr` inside a `PartExpr`. -/
def substExprVarY (θExpr : PartExpr) : PartExpr → PartExpr
  | .const c   => .const c
  | .varX      => .varX
  | .varY      => θExpr
  | .neg e     => .neg (substExprVarY θExpr e)
  | .add e1 e2 => .add (substExprVarY θExpr e1) (substExprVarY θExpr e2)
  | .sub e1 e2 => .sub (substExprVarY θExpr e1) (substExprVarY θExpr e2)
  | .mul e1 e2 => .mul (substExprVarY θExpr e1) (substExprVarY θExpr e2)
  | .div e1 e2 => .div (substExprVarY θExpr e1) (substExprVarY θExpr e2)

/-- Syntactic substitution replacing `.varY` by `θExpr` inside a `StrictForm`. -/
def substFormVarY (θExpr : PartExpr) : StrictForm → StrictForm
  | .eqZero e      => .eqZero (substExprVarY θExpr e)
  | .nonneg e      => .nonneg (substExprVarY θExpr e)
  | .pos e         => .pos (substExprVarY θExpr e)
  | .neqZero e     => .neqZero (substExprVarY θExpr e)
  | .conj φ ψ      => .conj (substFormVarY θExpr φ) (substFormVarY θExpr ψ)
  | .impStrict φ ψ => .impStrict (substFormVarY θExpr φ) (substFormVarY θExpr ψ)

/-- Protected invariant specification separating parameter-free predicates from cell-parameterized
    templates (`F-B2B-T2-04`). -/
inductive ProtectedInvariantKind where
  | fixedStateForm : StrictForm → ProtectedInvariantKind
  | cellParamForm  : StrictForm → ProtectedInvariantKind
  deriving DecidableEq, Repr

/-- **`WellFormedParamTemplate` Guard (`checkWellFormedParamSpecBool` — `F-B2B-T2-04`)**:
    `.cellParamForm` is ONLY permitted on 1D domains (`.domQ`, `.domQNonzero`, where `inG7Dom`
    fixes the second spatial coordinate `ρ.2 = 0` identically!) AND when no spatial guard in
    `cellGuards` references `.varY`, preventing any collision between spatial `y` and `θ`. -/
def checkWellFormedParamSpecBool (cellDom : G7DomTag) (cellGuards : List StrictForm)
    (inv : ProtectedInvariantKind) : Bool :=
  match inv with
  | .fixedStateForm _ => true
  | .cellParamForm _  =>
      (cellDom == .domQ || cellDom == .domQNonzero) &&
      cellGuards.all (fun γ => !formUsesVarYBool γ)

/-- Canonical `PartExpr` representation of rational parameter `θ = θNum / θDenPos` (`0 < θDenPos`).
    Uses division-free `.const θNum` when `θDenPos == 1` so integer parameters preserve
    polynomial `promoteToPolyExpr?` compatibility! -/
def paramRatioExpr (θNum : Int) (θDenPos : Nat) : PartExpr :=
  if θDenPos == 1 then .const θNum
  else .div (.const θNum) (.const (θDenPos : Int))

/-- Instantiate a `ProtectedInvariantKind` at rational cell parameter `θ = θNum / θDenPos`. -/
def instantiateInvariantAtParam (θNum : Int) (θDenPos : Nat) :
    ProtectedInvariantKind → StrictForm
  | .fixedStateForm φ => φ
  | .cellParamForm tpl => substFormVarY (paramRatioExpr θNum θDenPos) tpl

private theorem substExprVarY_evalRel_iff {θExpr : PartExpr} {x y θVal : Rat}
    (hθ : PartExprEvalRel θExpr (x, y) θVal) (e : PartExpr) (v : Rat) :
    PartExprEvalRel (substExprVarY θExpr e) (x, y) v ↔
      PartExprEvalRel e (x, θVal) v := by
  induction e generalizing v with
  | const c =>
      constructor <;> (intro h; cases h; exact .const c _)
  | varX =>
      constructor <;> (intro h; cases h; exact .varX _)
  | varY =>
      dsimp [substExprVarY]
      constructor
      · intro hv
        have heq := partExprEvalRel_unique hθ hv
        subst heq
        exact .varY (x, θVal)
      · intro hv
        cases hv
        exact hθ
  | neg e1 ih =>
      dsimp [substExprVarY]
      constructor
      · intro h; cases h with | neg ha => exact .neg ((ih _).mp ha)
      · intro h; cases h with | neg ha => exact .neg ((ih _).mpr ha)
  | add e1 e2 ih1 ih2 =>
      dsimp [substExprVarY]
      constructor
      · intro h; cases h with | add ha hb => exact .add ((ih1 _).mp ha) ((ih2 _).mp hb)
      · intro h; cases h with | add ha hb => exact .add ((ih1 _).mpr ha) ((ih2 _).mpr hb)
  | sub e1 e2 ih1 ih2 =>
      dsimp [substExprVarY]
      constructor
      · intro h; cases h with | sub ha hb => exact .sub ((ih1 _).mp ha) ((ih2 _).mp hb)
      · intro h; cases h with | sub ha hb => exact .sub ((ih1 _).mpr ha) ((ih2 _).mpr hb)
  | mul e1 e2 ih1 ih2 =>
      dsimp [substExprVarY]
      constructor
      · intro h; cases h with | mul ha hb => exact .mul ((ih1 _).mp ha) ((ih2 _).mp hb)
      · intro h; cases h with | mul ha hb => exact .mul ((ih1 _).mpr ha) ((ih2 _).mpr hb)
  | div e1 e2 ih1 ih2 =>
      dsimp [substExprVarY]
      constructor
      · intro h; cases h with | div ha hb hne => exact .div ((ih1 _).mp ha) ((ih2 _).mp hb) hne
      · intro h; cases h with | div ha hb hne => exact .div ((ih1 _).mpr ha) ((ih2 _).mpr hb) hne

private theorem substFormVarY_sem_iff {θExpr : PartExpr} {x y θVal : Rat}
    (hθ : PartExprEvalRel θExpr (x, y) θVal) (φ : StrictForm) :
    (FormDefined (substFormVarY θExpr φ) (x, y) ↔ FormDefined φ (x, θVal)) ∧
    (FormRawSat (substFormVarY θExpr φ) (x, y) ↔ FormRawSat φ (x, θVal)) ∧
    (ModelsStrictForm (substFormVarY θExpr φ) (x, y) ↔ ModelsStrictForm φ (x, θVal)) := by
  have hCore : (FormDefined (substFormVarY θExpr φ) (x, y) ↔ FormDefined φ (x, θVal)) ∧
               (FormRawSat (substFormVarY θExpr φ) (x, y) ↔ FormRawSat φ (x, θVal)) := by
    induction φ with
    | eqZero e =>
        exact ⟨⟨fun ⟨v, h⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mp h⟩,
                fun ⟨v, h⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mpr h⟩⟩,
               ⟨fun ⟨v, h, hz⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mp h, hz⟩,
                fun ⟨v, h, hz⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mpr h, hz⟩⟩⟩
    | nonneg e =>
        exact ⟨⟨fun ⟨v, h⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mp h⟩,
                fun ⟨v, h⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mpr h⟩⟩,
               ⟨fun ⟨v, h, hn⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mp h, hn⟩,
                fun ⟨v, h, hn⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mpr h, hn⟩⟩⟩
    | pos e =>
        exact ⟨⟨fun ⟨v, h⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mp h⟩,
                fun ⟨v, h⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mpr h⟩⟩,
               ⟨fun ⟨v, h, hp⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mp h, hp⟩,
                fun ⟨v, h, hp⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mpr h, hp⟩⟩⟩
    | neqZero e =>
        exact ⟨⟨fun ⟨v, h⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mp h⟩,
                fun ⟨v, h⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mpr h⟩⟩,
               ⟨fun ⟨v, h, hne⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mp h, hne⟩,
                fun ⟨v, h, hne⟩ => ⟨v, (substExprVarY_evalRel_iff hθ e v).mpr h, hne⟩⟩⟩
    | conj φ1 φ2 ih1 ih2 =>
        exact ⟨⟨fun h => ⟨ih1.1.mp h.1, ih2.1.mp h.2⟩, fun h => ⟨ih1.1.mpr h.1, ih2.1.mpr h.2⟩⟩,
               ⟨fun h => ⟨ih1.2.mp h.1, ih2.2.mp h.2⟩, fun h => ⟨ih1.2.mpr h.1, ih2.2.mpr h.2⟩⟩⟩
    | impStrict φ1 φ2 ih1 ih2 =>
        exact ⟨⟨fun h => ⟨ih1.1.mp h.1, ih2.1.mp h.2⟩, fun h => ⟨ih1.1.mpr h.1, ih2.1.mpr h.2⟩⟩,
               ⟨fun h ha2 => ih2.2.mp (h (ih1.2.mpr ha2)),
                fun h ha1 => ih2.2.mpr (h (ih1.2.mp ha1))⟩⟩
  exact ⟨hCore.1, hCore.2,
    ⟨fun h => ⟨hCore.1.mp h.1, hCore.2.mp h.2⟩, fun h => ⟨hCore.1.mpr h.1, hCore.2.mpr h.2⟩⟩⟩

private theorem paramRatioExpr_evalRel (θNum : Int) {θDenPos : Nat}
    (hPos : 0 < θDenPos) (ρ : Env2) :
    PartExprEvalRel (paramRatioExpr θNum θDenPos) ρ
      ((θNum : Rat) / (((θDenPos : Int)) : Rat)) := by
  unfold paramRatioExpr
  if h1 : (θDenPos == 1) = true then
    rw [if_pos h1]
    have hd1 : θDenPos = 1 := eq_of_beq h1
    subst hd1
    have hDivOne : (θNum : Rat) / (((1 : Nat) : Int) : Rat) = (θNum : Rat) := by
      have hOne : (((1 : Nat) : Int) : Rat) = 1 := rfl
      have h1Ne : (1 : Rat) ≠ 0 := by
        have hp1 : (0 : Rat) < ((1 : Int) : Rat) := Rat.intCast_pos.mpr (by decide)
        exact Rat.ne_of_gt hp1
      have hInv1 : (1 : Rat)⁻¹ = 1 := by
        have hm := Rat.mul_inv_cancel 1 h1Ne
        rwa [Rat.one_mul] at hm
      rw [hOne, Rat.div_def, hInv1, Rat.mul_one]
    rw [hDivOne]
    exact .const θNum ρ
  else
    rw [if_neg h1]
    have hDenIntPos : (0 : Int) < (θDenPos : Int) := by omega
    have hDenRatPos : (0 : Rat) < (((θDenPos : Int)) : Rat) := Rat.intCast_pos.mpr hDenIntPos
    have hDenNe : (((θDenPos : Int)) : Rat) ≠ 0 := Rat.ne_of_gt hDenRatPos
    exact .div (.const θNum ρ) (.const (θDenPos : Int) ρ) hDenNe

/-- **`A0-04` (`L_B2B_ParamSubst`) — Well-Formed Parameter Substitution Equivalence**:
    Whenever `checkWellFormedParamSpecBool cellDom cellGuards (.cellParamForm tpl) = true` and
    `0 < θDenPos`:
    (1) Every point `ρ ∈ inG7Dom cellDom` has fixed second spatial coordinate `ρ.2 = 0`, and
        every spatial guard `γ ∈ cellGuards` is invariant in `.varY` (`formUsesVarYBool γ = false`);
    (2) `instantiateInvariantAtParam θNum θDenPos (.cellParamForm tpl)` evaluated at `ρ` is
        strictly equivalent (`↔`) in BOTH `FormDefined` and `ModelsStrictForm` to evaluating
        `tpl` at `(ρ.1, θNum / θDenPos)`! -/
theorem L_B2B_ParamSubst {cellDom : G7DomTag} {cellGuards : List StrictForm}
    {tpl : StrictForm} {θNum : Int} {θDenPos : Nat}
    (hWf  : checkWellFormedParamSpecBool cellDom cellGuards (.cellParamForm tpl) = true)
    (hDen : 0 < θDenPos) :
    let θRat : Rat := (θNum : Rat) / (((θDenPos : Int)) : Rat)
    (∀ γ ∈ cellGuards, formUsesVarYBool γ = false) ∧
    (∀ ρ : Env2, inG7Dom cellDom ρ →
      ρ.2 = 0 ∧
      (FormDefined (instantiateInvariantAtParam θNum θDenPos (.cellParamForm tpl)) ρ ↔
        FormDefined tpl (ρ.1, θRat)) ∧
      (ModelsStrictForm (instantiateInvariantAtParam θNum θDenPos (.cellParamForm tpl)) ρ ↔
        ModelsStrictForm tpl (ρ.1, θRat))) := by
  unfold checkWellFormedParamSpecBool at hWf
  simp only [Bool.and_eq_true, Bool.or_eq_true] at hWf
  rcases hWf with ⟨hDom1D, hGuardsNoY⟩
  refine ⟨?_, ?_⟩
  · intro γ hMem
    have hb := List.all_eq_true.mp hGuardsNoY γ hMem
    cases hf : formUsesVarYBool γ with
    | false => rfl
    | true  => rw [hf] at hb; nomatch hb
  · intro ρ hInDom
    have hy0 : ρ.2 = 0 := by
      rcases hDom1D with hQ | hQNz
      · rw [eq_of_beq hQ] at hInDom; exact hInDom
      · rw [eq_of_beq hQNz] at hInDom; exact hInDom.2
    have hρ : ρ = (ρ.1, 0) := by
      cases ρ
      dsimp at hy0 ⊢
      rw [hy0]
    rw [hρ]
    have hEvalθ := paramRatioExpr_evalRel θNum hDen (ρ.1, 0)
    have hSub := substFormVarY_sem_iff hEvalθ tpl
    exact ⟨rfl, hSub.1, hSub.2.2⟩

/-- Negative guard-collision checks confirming `checkWellFormedParamSpecBool` rejects 2D `.domQ2`
    and `.varY`-dependent spatial guards. -/
theorem A0_04_paramSpec_collision_rejected :
    let tpl : StrictForm := .nonneg (.add (.mul .varX .varX) .varY)
    checkWellFormedParamSpecBool .domQ [] (.cellParamForm tpl) = true ∧
    checkWellFormedParamSpecBool .domQNonzero [.pos .varX] (.cellParamForm tpl) = true ∧
    checkWellFormedParamSpecBool .domQ2 [] (.cellParamForm tpl) = false ∧
    checkWellFormedParamSpecBool (.domFiniteGrid [(1, 0)]) [] (.cellParamForm tpl) = false ∧
    checkWellFormedParamSpecBool .domQ [.pos .varY] (.cellParamForm tpl) = false := by
  decide

/-! ### 3. `A0-06` — `F-B2B-05` SOS Witness Accepted by Unmodified Frozen `G7` (`A0-GUARD-03`) -/

/-- `F-B2B-05` Protected invariant template `I(x; θ) : x^2 + θ ≥ 0`. -/
def f05_invTemplate : ProtectedInvariantKind :=
  .cellParamForm (.nonneg (.add (.mul .varX .varX) .varY))

/-- `F-B2B-05` Old goal `P_old(x) : (x - 1)^2 > 0` (fails at obstruction `(1, 0)`). -/
def f05_goalOld : StrictForm :=
  .pos (.mul (.sub .varX (.const 1)) (.sub .varX (.const 1)))

/-- `F-B2B-05` Post-repair goal `P_new(x) : x^2 + 4 > 0` (`θ_new = -2`). -/
def f05_goalNew : StrictForm :=
  .pos (.add (.mul .varX .varX) (.const 4))

/-- Exact `PolyPositivstellensatzCert` for `x^2 + 4 > 0`: `1 * (x^2 + 4) ≡ 4 + 1 * x^2` (`4 > 0`). -/
def f05_sosCertGoalNew : PolyPositivstellensatzCert where
  lhsScale   := 1
  constTerm  := 4
  sqTerms    := [(1, .pVarX)]
  nonnegMult := []
  posMult    := []
  eqMult     := []

/-- Exact `PolyPositivstellensatzCert` for old invariant `I(x; 2) : x^2 + 2 ≥ 0` (`1 * (x^2 + 2) ≡ 2 + 1 * x^2`). -/
def f05_sosCertOldInv : PolyPositivstellensatzCert where
  lhsScale   := 1
  constTerm  := 2
  sqTerms    := [(1, .pVarX)]
  nonnegMult := []
  posMult    := []
  eqMult     := []

/-- Official frozen `G7DagContainer` proving `f05_goalNew` (`x^2 + 4 > 0`) on `.domQ`. -/
def f05_dagContainerGoalNew : G7DagContainer where
  nodes := [
    { nodeId     := "n_f05_goal_new"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_f05_new"
      guards     := []
      conclusion := f05_goalNew
      step       := .directDerivStep
                      (.certStep f05_goalNew (.polyPositivstellensatz f05_sosCertGoalNew)) }
  ]

/-- Official frozen `CertifiedG7Bundle` for `f05_goalNew` (`x^2 + 4 > 0`) on `.domQ`. -/
def f05_certifiedG7BundleGoalNew : CertifiedG7Bundle where
  bundleCid       := "b7_f05_repair_xsq_plus_4"
  subjectKey      := {
    rflxCid       := "rflx_f05_param_shift"
    pathKey       := .root "cell_f05_old" "obst_f05_x1" "cell_f05_new" "rflx_f05_param_shift"
    targetCellCid := "cell_f05_new"
    baseId        := "base_Q"
    targetDomId   := "dom_Q"
    targetSpecId  := "spec_f05_new"
  }
  primEnvSnapshot := []
  dagSnapshot     := f05_dagContainerGoalNew
  rootNodeId      := "n_f05_goal_new"
  claimedDomTag   := .domQ
  claimedGoal     := f05_goalNew
  claimedPrimDeps := []
  fuelCert        := 4
  expiresEpoch    := 100

/-- Official frozen `G7DagContainer` proving old invariant `I(x; 2) : x^2 + 2 ≥ 0` on `.domQ`. -/
def f05_dagContainerOldInv : G7DagContainer where
  nodes := [
    { nodeId     := "n_f05_inv_old"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_f05_old"
      guards     := []
      conclusion := instantiateInvariantAtParam 2 1 f05_invTemplate
      step       := .directDerivStep
                      (.certStep (instantiateInvariantAtParam 2 1 f05_invTemplate)
                        (.polyPositivstellensatz f05_sosCertOldInv)) }
  ]

/-- **`A0-06` (`A0_06_F_B2B_05_SOS_Witness_Proven`) — Mechanical Acceptance & Cross-Term Proof**:
    Proves in Lean 4.33.1 with unmodified frozen `OmegaCellC1P1B2A` verifiers:
    (1) Frozen `checkAlgDomCertBool`, `verifyReachableDerivation`, and `checkCertifiedG7BundleBool`
        all ACCEPT `f05_sosCertGoalNew` (`x^2 + 4 > 0` on `.domQ` = `true` / `.accept`)!
    (2) Old invariant `I(x; 2) : x^2 + 2 ≥ 0` is ALSO accepted by `verifyReachableDerivation` and
        holds semantically for EVERY `ρ ∈ inG7Dom .domQ`;
    (3) Old target `(x - 1)^2 > 0` fails at `(1, 0)`, whereas repaired target `x^2 + 4 > 0` holds
        at `(1, 0)` and across EVERY `ρ ∈ inG7Dom .domQ`;
    (4) New invariant `I(x; -2) : x^2 + (-2) ≥ 0` evaluates to `.satDefinedFalse` at `(0, 0)`,
        proving `FormDefined ... (0, 0) ∧ ¬ ModelsStrictForm ... (0, 0)`, while a bogus SOS
        attempt `⟨1, -2, [(1, .pVarX)], [], [], []⟩` is rejected (`= false`) by frozen `P1B2A`! -/
theorem A0_06_F_B2B_05_SOS_Witness_Proven :
    let invOldForm := instantiateInvariantAtParam 2 1 f05_invTemplate
    let invNewForm := instantiateInvariantAtParam (-2) 1 f05_invTemplate
    -- (1) Mechanical acceptance by frozen P1B2A G7 verifiers:
    checkAlgDomCertBool .domQ [] f05_goalNew (.polyPositivstellensatz f05_sosCertGoalNew) = true ∧
    verifyReachableDerivation 4 [] f05_dagContainerGoalNew "n_f05_goal_new" =
      .accept ⟨.domQ, "spec_f05_new", [], f05_goalNew⟩ ∧
    checkCertifiedG7BundleBool f05_certifiedG7BundleGoalNew = true ∧
    verifyReachableDerivation 4 [] f05_dagContainerOldInv "n_f05_inv_old" =
      .accept ⟨.domQ, "spec_f05_old", [], invOldForm⟩ ∧
    -- (2) Universal semantic validity of old invariant I(x; 2) and repaired goal x^2 + 4 > 0 on .domQ:
    (∀ ρ : Env2, inG7Dom .domQ ρ → ModelsStrictForm invOldForm ρ) ∧
    (∀ ρ : Env2, inG7Dom .domQ ρ → ModelsStrictForm f05_goalNew ρ) ∧
    -- (3) Old goal fails at (1, 0), repaired goal succeeds at (1, 0):
    evalStrictFormGrid 5 f05_goalOld (1, 0) = .satDefinedFalse ∧
    ¬ ModelsStrictForm f05_goalOld (1, 0) ∧
    ModelsStrictForm f05_goalNew (1, 0) ∧
    -- (4) Post-repair invariant I(x; -2) violated at (0, 0) + bogus SOS rejected:
    evalStrictFormGrid 5 invNewForm (0, 0) = .satDefinedFalse ∧
    (FormDefined invNewForm (0, 0) ∧ ¬ ModelsStrictForm invNewForm (0, 0)) ∧
    checkAlgDomCertBool .domQ [] invNewForm
      (.polyPositivstellensatz ⟨1, -2, [(1, .pVarX)], [], [], []⟩) = false := by
  have hNewAll : ∀ ρ : Env2, inG7Dom .domQ ρ → ModelsStrictForm f05_goalNew ρ :=
    certifiedG7Bundle_whitebox_sound f05_certifiedG7BundleGoalNew (by decide) (fun _ h => nomatch h)
  have hOldInvSem : SemValidSequent ⟨.domQ, "spec_f05_old", [],
      instantiateInvariantAtParam 2 1 f05_invTemplate⟩ :=
    verifyReachable_master_sound 4 [] f05_dagContainerOldInv "n_f05_inv_old" _
      (by decide) (by decide) (fun _ h => nomatch h)
  have hOldInvAll : ∀ ρ : Env2, inG7Dom .domQ ρ →
      ModelsStrictForm (instantiateInvariantAtParam 2 1 f05_invTemplate) ρ :=
    fun ρ hDom => hOldInvSem.2 ρ hDom (fun _ h => nomatch h)
  have hOldGoalFail : ¬ ModelsStrictForm f05_goalOld (1, 0) := by
    rintro ⟨_, ⟨v, hv, hpos⟩⟩
    have hSub1 : PartExprEvalRel (.sub .varX (.const 1)) (1, 0) ((1 : Rat) - 1) :=
      .sub (.varX (1, 0)) (.const 1 (1, 0))
    have hMul0 : PartExprEvalRel (.mul (.sub .varX (.const 1)) (.sub .varX (.const 1))) (1, 0)
        (((1 : Rat) - 1) * ((1 : Rat) - 1)) := .mul hSub1 hSub1
    have heq := partExprEvalRel_unique hMul0 hv
    rw [← heq, Rat.sub_self, Rat.mul_zero] at hpos
    exact Rat.lt_irrefl hpos
  have hNewInvDef : FormDefined (instantiateInvariantAtParam (-2) 1 f05_invTemplate) (0, 0) :=
    ⟨(0 : Rat) * 0 + ((-2 : Int) : Rat),
     .add (.mul (.varX (0, 0)) (.varX (0, 0))) (.const (-2) (0, 0))⟩
  have hNewInvFail : ¬ ModelsStrictForm (instantiateInvariantAtParam (-2) 1 f05_invTemplate) (0, 0) := by
    rintro ⟨_, ⟨v, hv, hnn⟩⟩
    have hEv : PartExprEvalRel (.add (.mul .varX .varX) (.const (-2))) (0, 0)
        ((0 : Rat) * 0 + ((-2 : Int) : Rat)) :=
      .add (.mul (.varX (0, 0)) (.varX (0, 0))) (.const (-2) (0, 0))
    have heq := partExprEvalRel_unique hEv hv
    rw [← heq, Rat.mul_zero, Rat.zero_add] at hnn
    exact absurd (Rat.intCast_nonneg.mp hnn) (by decide)
  exact ⟨by decide, by decide, by decide, by decide,
         hOldInvAll, hNewAll,
         by decide, hOldGoalFail, hNewAll (1, 0) rfl,
         by decide, ⟨hNewInvDef, hNewInvFail⟩, by decide⟩

end OmegaCellC1P1B2BA0
