/-
  PRINCIPIA Ω-CELL-C1-P1B2B — Isolated Proof Core A0
  File: AuditA0CoreAxioms.lean (Full Whitebox `Lean.Environment` & Axiom Auditor for A0)

  Audits 100% of `OmegaCellC1P1B2BA0` module-owned constants (including `private` helpers):
    1. Zero `sorryAx` and zero custom `axiom` declarations (`{propext, Classical.choice, Quot.sound}`
       upper bound, and reports exact axioms actually used by each A0 headline theorem!).
    2. Zero `unsafe`, zero `opaque`, and zero unjustified `partial` declarations across A0.
    3. Zero `GPED` or unauthorized `G56` / `P1C` modules loaded.
    4. Anti-circularity check (`Cone*(S_sem_A0) ∩ K_exec_all = ∅`): verifies that A0 semantic
       definitions (`InEffDom`, `SemSameEffDom`, `ModelsExcisedBranch`, `ModelsExcised`,
       `SemExactScopeLossPartition`, `LogConfinedTo`) never call any executable checker.
-/
import Lean
import OmegaCellC1P1B2BA0

open Lean
open OmegaCellC1P1B2BA0

abbrev AuditEnvM := StateT Environment IO

instance : MonadEnv AuditEnvM where
  getEnv := get
  modifyEnv f := modify f

def a0Modules5 : List Name := [
  `OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm,
  `OmegaCellC1P1B2BA0.A0_03_TelescopicPartition,
  `OmegaCellC1P1B2BA0.A0_04_06_ParamSubstAndSosWitness,
  `OmegaCellC1P1B2BA0.A0_05_ProofDependencyClosure,
  `OmegaCellC1P1B2BA0
]

def ancestorModules11 : List Name := [
  `OmegaCellC1P1A0.P1A0A_BaseChartGuard,
  `OmegaCellC1P1A0.P1A0B_TransportScopeLoss,
  `OmegaCellC1P1A0.P1A0C_CheckerQualification,
  `OmegaCellC1P1A0,
  `OmegaCellC1P1B1.P1B1A_VerdictSlotReifier,
  `OmegaCellC1P1B1.P1B1B_LineageCommitSoundness,
  `OmegaCellC1P1B1,
  `OmegaCellC1P1B2A.P1B2AA_PartialExprPolyCert,
  `OmegaCellC1P1B2A.P1B2AB_TelescopicGuardAndDAG,
  `OmegaCellC1P1B2A.P1B2AC_ConservativeRefinementAndBundle,
  `OmegaCellC1P1B2A
]

def a0HeadlineTheorems : List Name := [
  `OmegaCellC1P1B2BA0.L_B2B_DomNz,
  `OmegaCellC1P1B2BA0.L_B2B_DomIntrinsicDef_sound,
  `OmegaCellC1P1B2BA0.A0_01_domNz_positive_and_negative_checks,
  `OmegaCellC1P1B2BA0.L_B2B_ImpNorm,
  `OmegaCellC1P1B2BA0.F_A0_02_ImpNorm_WithoutDefGuard_Fails,
  `OmegaCellC1P1B2BA0.atomicComplement_defined_xor,
  `OmegaCellC1P1B2BA0.baseDomRetreat_exact_partition,
  `OmegaCellC1P1B2BA0.L_B2B_TelescopicPartition,
  `OmegaCellC1P1B2BA0.L_B2B_TelescopicPartition_from_G7,
  `OmegaCellC1P1B2BA0.A0_03a_seqRecip_exact_partition_and_point_classification,
  `OmegaCellC1P1B2BA0.A0_03b_partition_counterexamples_rejected,
  `OmegaCellC1P1B2BA0.L_B2B_NoVarYSpatialInvariance,
  `OmegaCellC1P1B2BA0.L_B2B_ParamSubst,
  `OmegaCellC1P1B2BA0.A0_04_paramSpec_collision_rejected,
  `OmegaCellC1P1B2BA0.A0_06_F_B2B_05_SOS_Witness_Proven,
  `OmegaCellC1P1B2BA0.verifyMultiRootTraced_eq_frozen,
  `OmegaCellC1P1B2BA0.A0_05_1_OutputCongruence,
  `OmegaCellC1P1B2BA0.A0_05_2_ActualLookupConfinement,
  `OmegaCellC1P1B2BA0.A0_05_2b_OutputCongruence_DoesNotImply_ActualLookupConfinement,
  `OmegaCellC1P1B2BA0.A0_05_3_RestrictionInvariance,
  `OmegaCellC1P1B2BA0.A0_05_4_SemanticDependencyClosure,
  `OmegaCellC1P1B2BA0.A0_05_4b_PoisonOutsideClosureWitness
]

def a0SemanticAnchors : List Name := [
  `OmegaCellC1P1B2BA0.InEffDom,
  `OmegaCellC1P1B2BA0.SemSameEffDom,
  `OmegaCellC1P1B2BA0.ModelsExcisedBranch,
  `OmegaCellC1P1B2BA0.ModelsExcised,
  `OmegaCellC1P1B2BA0.SemExactScopeLossPartition,
  `OmegaCellC1P1B2BA0.LogConfinedTo
]

def a0AndAncestorExecutableCheckers : List Name := [
  `OmegaCellC1P1B2A.evalPartExprFuel,
  `OmegaCellC1P1B2A.evalStrictFormFuel,
  `OmegaCellC1P1B2A.checkAlgDomCertBool,
  `OmegaCellC1P1B2A.checkExprDefUnderNzBool,
  `OmegaCellC1P1B2A.checkFormDefUnderNzBool,
  `OmegaCellC1P1B2A.checkGuardsPrefixDefinedBool,
  `OmegaCellC1P1B2A.verifyReachableDerivation,
  `OmegaCellC1P1B2A.checkCertifiedG7BundleBool,
  `OmegaCellC1P1B2BA0.intrinsicNzOfDom,
  `OmegaCellC1P1B2BA0.checkGuardsAndGoalDomDefBool,
  `OmegaCellC1P1B2BA0.isAtomicStrictFormBool,
  `OmegaCellC1P1B2BA0.checkBaseDomRetreatStepBool,
  `OmegaCellC1P1B2BA0.checkWellFormedParamSpecBool,
  `OmegaCellC1P1B2BA0.verifyMultiRootTraced
]

def isCoreMod (m : Name) : Bool :=
  let r := m.getRoot
  r == `Init || r == `Std || r == `Lean

def directDeps (env : Environment) (c : Name) : Array Name :=
  match env.find? c with
  | none => #[]
  | some ci =>
      let base := ci.type.getUsedConstants
      match ci with
      | .defnInfo v   => base ++ v.value.getUsedConstants
      | .thmInfo v    => base ++ v.value.getUsedConstants
      | .opaqueInfo v => base ++ v.value.getUsedConstants
      | .inductInfo v =>
          v.ctors.foldl (fun acc ctor =>
            match env.find? ctor with
            | some cci => acc ++ cci.type.getUsedConstants
            | none     => acc) base
      | .recInfo v =>
          v.rules.foldl (fun acc r => acc ++ r.rhs.getUsedConstants) base
      | _ => base

def transitiveCone (env : Environment) (seeds : List Name) : Std.HashSet Name := Id.run do
  let mut visited : Std.HashSet Name := {}
  let mut q : Array Name := seeds.toArray
  let mut idx : Nat := 0
  while idx < q.size do
    let cur := q[idx]!
    idx := idx + 1
    if !visited.contains cur then
      visited := visited.insert cur
      for nxt in directDeps env cur do
        if !visited.contains nxt then
          q := q.push nxt
  return visited

def toJsonStrArr (xs : List String) : Json :=
  Json.arr (xs.toArray.map Json.str)

def main : IO UInt32 := do
  initSearchPath (← findSysroot)
  let pubEnv ← importModules #[{ module := `OmegaCellC1P1B2BA0 }] {}
  let rawEnv ← importModules #[{ module := `OmegaCellC1P1B2BA0, importAll := true }] {}
  let env := rawEnv.setExporting false

  let allowedMods := a0Modules5 ++ ancestorModules11
  let mut unexpectedMods : List String := []
  let mut gpedMods : List String := []
  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    let ms := m.toString
    if ms.startsWith "Gped" || ms.startsWith "Principia" then
      gpedMods := ms :: gpedMods
    if !(isCoreMod m || allowedMods.contains m) then
      unexpectedMods := ms :: unexpectedMods

  let mut pubA0Decls : List String := []
  for i in [:pubEnv.header.moduleNames.size] do
    if a0Modules5.contains pubEnv.header.moduleNames[i]! then
      for c in pubEnv.header.moduleData[i]!.constNames do
        match c with
        | .str (`OmegaCellC1P1B2BA0) nm =>
            if !(nm.startsWith "instDecidableEq" || nm.startsWith "instRepr" || nm.startsWith "_private") then
              pubA0Decls := c.toString :: pubA0Decls
        | _ => pure ()
  let sortedPubA0 := pubA0Decls.mergeSort (· < ·)

  let allowedAx : List Name := [`propext, `Classical.choice, `Quot.sound]
  let mut a0OwnedConstCount : Nat := 0
  let mut badAxiomRefs : List String := []
  let mut customAxiomDefs : List String := []
  let mut unsafeConsts : List String := []
  let mut opaqueConsts : List String := []
  let mut unjustifiedPartialConsts : List String := []
  let mut justifiedUnsafeRecCount : Nat := 0

  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    if a0Modules5.contains m then
      let md := env.header.moduleData[i]!
      a0OwnedConstCount := a0OwnedConstCount + md.constNames.size
      for c in md.constNames do
        let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) c) env
        for a in axs do
          if !allowedAx.contains a then
            badAxiomRefs := s!"{c} -> {a}" :: badAxiomRefs
        match env.find? c with
        | none => badAxiomRefs := s!"MISSING:{c}" :: badAxiomRefs
        | some ci =>
            if ci.isUnsafe then
              unsafeConsts := c.toString :: unsafeConsts
            match ci with
            | .axiomInfo _  => customAxiomDefs := c.toString :: customAxiomDefs
            | .opaqueInfo _ => opaqueConsts := c.toString :: opaqueConsts
            | .defnInfo v   =>
                if v.safety == .partial then
                  match c with
                  | .str parent "_unsafe_rec" =>
                      match env.find? parent with
                      | some (.defnInfo pv) =>
                          if pv.safety == .safe then
                            justifiedUnsafeRecCount := justifiedUnsafeRecCount + 1
                          else
                            unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
                      | _ => unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
                  | _ => unjustifiedPartialConsts := c.toString :: unjustifiedPartialConsts
            | _ => pure ()

  let mut missingHeadline : List String := []
  let mut headlineAxiomReport : List (String × Json) := []
  for thm in a0HeadlineTheorems do
    match env.find? thm with
    | none => missingHeadline := thm.toString :: missingHeadline
    | some _ =>
        let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) thm) env
        headlineAxiomReport := headlineAxiomReport ++
          [(thm.toString, toJsonStrArr (axs.toList.map Name.toString))]

  let semCone := transitiveCone env a0SemanticAnchors
  let mut semCircularHits : List String := []
  for k in a0AndAncestorExecutableCheckers do
    if semCone.contains k then
      semCircularHits := k.toString :: semCircularHits

  let allOk :=
    unexpectedMods.isEmpty &&
    gpedMods.isEmpty &&
    badAxiomRefs.isEmpty &&
    customAxiomDefs.isEmpty &&
    unsafeConsts.isEmpty &&
    opaqueConsts.isEmpty &&
    unjustifiedPartialConsts.isEmpty &&
    missingHeadline.isEmpty &&
    semCircularHits.isEmpty

  let report := Json.mkObj [
    ("auditSchema", Json.str "principia.omega.p1b2b.a0.env_audit.v1"),
    ("allChecksPassed", Json.bool allOk),
    ("a0OwnedConstantCount", Json.num a0OwnedConstCount),
    ("a0PublicDeclCount", Json.num sortedPubA0.length),
    ("a0PublicDecls", toJsonStrArr sortedPubA0),
    ("headlineTheoremCount", Json.num a0HeadlineTheorems.length),
    ("missingHeadlineTheorems", toJsonStrArr missingHeadline),
    ("headlineTheoremAxioms", Json.mkObj headlineAxiomReport),
    ("unexpectedModules", toJsonStrArr unexpectedMods),
    ("gpedModulesDetected", toJsonStrArr gpedMods),
    ("badAxiomRefs", toJsonStrArr badAxiomRefs),
    ("customAxiomDefs", toJsonStrArr customAxiomDefs),
    ("unsafeConsts", toJsonStrArr unsafeConsts),
    ("opaqueConsts", toJsonStrArr opaqueConsts),
    ("unjustifiedPartialConsts", toJsonStrArr unjustifiedPartialConsts),
    ("justifiedCompilerUnsafeRecCount", Json.num justifiedUnsafeRecCount),
    ("a0SemanticConeSize", Json.num semCone.size),
    ("semanticCheckerCircularHits", toJsonStrArr semCircularHits)
  ]
  IO.println report.pretty
  return (if allOk then 0 else 1)
