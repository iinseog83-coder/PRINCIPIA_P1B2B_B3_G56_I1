/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B3 G56 — I1 Independent External Replay Act (`KitB3I1`)
  Executable: ExternalObsAndTcbAuditB3I1.lean
  Scope: Detached Whitebox Kernel Auditor, Live 71-Case Qualification Observer,
         Separated Mutant Observer, Exhaustive Declaration Classifier & Consumer Verifier.

  Addresses:
    - `I1-A5`: Kernel `isDefEq` verification + pretty-printed `ConstantInfo.type` signatures +
      `Lean.collectAxioms` transitive closures across all `41` B3 headline theorems and `6` I1 theorems.
    - `I1-A6` & `F-B3-T19-03` & `Q-B3-I1-01`: Live runtime evaluation of all `71` cases with dynamic
      `qualifyG56Coupled?` invocation on all `55` coupled-certificate cases (zero hardcoded
      `postHocOracleEdits` self-assertions inside Lean; pre/post oracle SHA-256 is verified externally).
    - `I1-A7` & `F-B3-T19-02` & `Q-B3-I1-03`: Separated observation of `M_registered` (`12` probes with
      explicit layer tags) and `M_end_to_end` (`12` isolated single-fault full-pipeline mutants).
    - `I1-A8` & `F-B3-T19-04` & `Q-B3-I1-04`: Exhaustive classification of all `B3`-owned constants
      (`U = C_relevant \ (S ∪ K ∪ D ∪ T ∪ F ∪ A)` verified empty under explicit rules), full classified
      anti-circularity `Cone*(S_classified_B3) ∩ K_classified_all = ∅`, and barrier-stopped transitive
      lookup confinement from top-level `B3` entrypoints.
    - `I1-A9` & `F-B3-T19-01`: Live verification of provenance-bound consumer entrypoints blocking
      unbound `projectCoupledVerdictR1` spoofing.
-/
import Lean
import OmegaCellC1P1B2BB3
import ExternalSpecPinB3I1

open Lean
open Lean.Meta
open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2
open OmegaCellC1P1B2BB3
open ExternalSpecPinB3I1

abbrev AuditEnvM := StateT Environment IO

instance : MonadEnv AuditEnvM where
  getEnv := get
  modifyEnv f := modify f

def b3Modules7 : List Name := [
  `OmegaCellC1P1B2BB3.B3_01_TransitionTypesAndPullback,
  `OmegaCellC1P1B2BB3.B3_02_SharedContextAndJointClosure,
  `OmegaCellC1P1B2BB3.B3_03_G7L1LossEquivalence,
  `OmegaCellC1P1B2BB3.B3_04_DiagnosticsAndMasterSoundness,
  `OmegaCellC1P1B2BB3.B3_05_ReificationAndTemporalInvalidation,
  `OmegaCellC1P1B2BB3.B3_06_SoundnessSuiteAndMutants,
  `OmegaCellC1P1B2BB3
]

def ancestorAndB2Modules26 : List Name := [
  `OmegaCellC1P1A0.P1A0A_BaseChartGuard,
  `OmegaCellC1P1A0.P1A0B_TransportScopeLoss,
  `OmegaCellC1P1A0.P1A0C_CheckerQualification,
  `OmegaCellC1P1A0,
  `OmegaCellC1P1B1.P1B1A_VerdictSlotReifier,
  `OmegaCellC1P1B1.P1B1B_LineageCommitSoundness,
  `OmegaCellC1P1B1,
  `OmegaCellC1P1B2A.P1B2AA_PartialExprPolyCert,
  `OmegaCellC1P1B2A.P1B2AB_TelescopicGuardAndDAG,
  `OmegaCellC1P1B2A.P1B2AC_ConservativeRefinementAndBundle,
  `OmegaCellC1P1B2A,
  `OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm,
  `OmegaCellC1P1B2BA0.A0_03_TelescopicPartition,
  `OmegaCellC1P1B2BA0.A0_04_06_ParamSubstAndSosWitness,
  `OmegaCellC1P1B2BA0.A0_05_ProofDependencyClosure,
  `OmegaCellC1P1B2BA0,
  `OmegaCellC1P1B2BB1.B1_01_CertTypesAndSemantics,
  `OmegaCellC1P1B2BB1.B1_02_RatCoordEvalAndCheckers,
  `OmegaCellC1P1B2BB1.B1_03_SoundnessAndClosure,
  `OmegaCellC1P1B2BB1.B1_04_WitnessesAndCounterexamples,
  `OmegaCellC1P1B2BB1,
  `OmegaCellC1P1B2BB2.B2_01_CertTypesAndSemantics,
  `OmegaCellC1P1B2BB2.B2_02_SuiteCheckersAndQualification,
  `OmegaCellC1P1B2BB2.B2_03_SoundnessPriorityAndClosure,
  `OmegaCellC1P1B2BB2.B2_04_WitnessesAndCounterexamples,
  `OmegaCellC1P1B2BB2
]

def i1KitTheorems6 : List Name := [
  `ExternalSpecPinB3I1.T_I1_A9_01_UnboundDetProjectionCanSpoofInvalidCoupling,
  `ExternalSpecPinB3I1.T_I1_A9_02_ProvenanceBoundConsumerExactAndSound,
  `ExternalSpecPinB3I1.T_I1_A7_01_ZeroFaultPipelineExactIdentity,
  `ExternalSpecPinB3I1.T_I1_A7_02_All12EndToEndSingleFaultMutantsPreservePosAndKilled,
  `ExternalSpecPinB3I1.T_I1_A7_03_EQ01_CommutedUnionIsProvablyEquivalentMutant,
  `ExternalSpecPinB3I1.T_I1_A6_All71LiveObservationsComplete
]

def isCoreMod (m : Name) : Bool :=
  let r := m.getRoot
  r == `Init || r == `Std || r == `Lean

def hasSubstr (s sub : String) : Bool :=
  (s.splitOn sub).length > 1

def toJsonStrArr (xs : List String) : Json :=
  Json.arr (xs.toArray.map Json.str)

def directDeps (env : Environment) (c : Name) : Array Name :=
  match env.find? c with
  | none => #[]
  | some ci =>
      let base := ci.type.getUsedConstants
      match ci with
      | .defnInfo v   => base ++ v.value.getUsedConstants
      | .thmInfo v    => base ++ v.value.getUsedConstants
      | .opaqueInfo v => base ++ v.value.getUsedConstants
      | .inductInfo v =>
          v.ctors.foldl (fun acc ctor =>
            match env.find? ctor with
            | some cci => acc ++ cci.type.getUsedConstants
            | none     => acc) base
      | .recInfo v =>
          v.rules.foldl (fun acc r => acc ++ r.rhs.getUsedConstants) base
      | _ => base

def transitiveCone (env : Environment) (seeds : List Name) : Std.HashSet Name := Id.run do
  let mut visited : Std.HashSet Name := {}
  let mut q : Array Name := seeds.toArray
  let mut idx : Nat := 0
  while idx < q.size do
    let cur := q[idx]!
    idx := idx + 1
    if !visited.contains cur then
      visited := visited.insert cur
      for nxt in directDeps env cur do
        if !visited.contains nxt then
          q := q.push nxt
  return visited

/-- Computational call-graph dependencies (traverses `.defnInfo` values only, skipping erased `.thmInfo` proofs). -/
def computationalDirectDeps (env : Environment) (c : Name) : Array Name :=
  match env.find? c with
  | some (.defnInfo v) => v.value.getUsedConstants
  | _                  => #[]

/-- Barrier-stopped computational call-graph cone from executable `B3` entrypoints. -/
def computationalBarrierStoppedCone (env : Environment) (seeds : List Name) (barriers : List Name) :
    Std.HashSet Name := Id.run do
  let barrierSet : Std.HashSet Name := barriers.foldl (fun s b => s.insert b) {}
  let mut visited : Std.HashSet Name := {}
  let mut q : Array Name := seeds.toArray
  let mut idx : Nat := 0
  while idx < q.size do
    let cur := q[idx]!
    idx := idx + 1
    if !visited.contains cur then
      visited := visited.insert cur
      if !barrierSet.contains cur then
        for nxt in computationalDirectDeps env cur do
          if !visited.contains nxt then
            q := q.push nxt
  return visited

/-- Strip outer `forallE` binders to inspect the result expression of a constant's type. -/
partial def stripForalls : Expr → Expr
  | .forallE _ _ body _ => stripForalls body
  | .mdata _ e          => stripForalls e
  | e                   => e

/-- True iff `e` is a `Prop`-returning type (`∀ ..., Prop`), i.e., terminal sort `Sort 0`. -/
def isPropReturningType (t : Expr) : Bool :=
  match stripForalls t with
  | .sort .zero => true
  | _           => false

/-- True iff `e` returns `Bool` or `Option _` or a Verdict/Diagnostic/Record/Key/Object computational result. -/
def isExecutableCheckerReturnType (t : Expr) : Bool :=
  let res := (stripForalls t).getAppFn
  match res with
  | .const nm _ =>
      let s := nm.toString
      nm == `Bool || nm == `Option || nm == `Prod || nm == `List ||
      hasSubstr s "Verdict" || hasSubstr s "Diagnostic" || hasSubstr s "Result" ||
      hasSubstr s "Status" || hasSubstr s "Error" || hasSubstr s "Record" ||
      hasSubstr s "Witness" || hasSubstr s "Pullback" || hasSubstr s "Binding" ||
      hasSubstr s "Deps" || hasSubstr s "Cert" || hasSubstr s "Suite" ||
      hasSubstr s "Key" || hasSubstr s "Object" ||
      hasSubstr s "State" || nm == `Nat || nm == `String || nm == `Rat
  | _ => false

def isCompilerOrElabAuxName (c : Name) : Bool :=
  let s := c.toString
  isPrivateName c ||
  hasSubstr s "._cstage" || hasSubstr s "._eq_" || hasSubstr s "._sunfold" ||
  hasSubstr s ".match_" || hasSubstr s "._proof_" || hasSubstr s "._simp_" ||
  hasSubstr s "._unsafe_rec" || hasSubstr s "._sparseCasesOn_" || hasSubstr s "._sizeOf_inst" ||
  hasSubstr s "._flat_ctor" || hasSubstr s ".instDecidableEq" || hasSubstr s ".instRepr" ||
  s.endsWith "._f" || s.endsWith ".ctorElim" || s.endsWith ".ctorElimType" ||
  s.endsWith ".elim" || s.endsWith ".ofNat" ||
  s.endsWith ".rec" || s.endsWith ".recOn" || s.endsWith ".casesOn" ||
  s.endsWith ".brecOn" || s.endsWith ".below" || s.endsWith ".ibelow" ||
  s.endsWith ".noConfusion" || s.endsWith ".noConfusionType" ||
  s.endsWith ".inj" || s.endsWith ".injEq" || s.endsWith ".sizeOf_spec" ||
  s.endsWith ".ctorIdx" || s.endsWith ".toCtorIdx"

def isIllustrativeContrastFixture (c : Name) : Bool :=
  let s := c.toString
  s == "OmegaCellC1P1B2BB3.inconsistentRepairRetreatBinding" ||
  s == "OmegaCellC1P1B2BB3.a1AmbiguousItem" ||
  s == "OmegaCellC1P1B2BB3.a1AmbiguousSameScopeSuite" ||
  s == "OmegaCellC1P1B2BB3.a1BindingRepair" ||
  s == "OmegaCellC1P1B2BB3.a1BindingRefinement" ||
  s == "OmegaCellC1P1B2BB3.a2FalsePremiseEnv" ||
  hasSubstr s ".slotWitness_" ||
  s == "OmegaCellC1P1B2BB3.allG56CheckIds"

def isStructCtorPrivate (env : Environment) (indName : Name) : Bool :=
  match env.find? indName with
  | some (.inductInfo v) => (!v.ctors.isEmpty) && v.ctors.all isPrivateName
  | _ => false

/-- Check `isDefEq` and pretty-print `origCi.type` inside `MetaM`. -/
def checkPinAndPrettyType (env : Environment) (origName pinName : Name) :
    IO (Bool × String) := do
  match env.find? origName, env.find? pinName with
  | some ciOrig, some ciPin =>
      let ctxCore : Core.Context := { fileName := "<I1Audit>", fileMap := default }
      let stCore  : Core.State   := { env := env }
      let act : MetaM (Bool × String) := do
        let eqOk ← isDefEq ciOrig.type ciPin.type
        let fmt ← ppExpr ciOrig.type
        let flat := String.intercalate " " ((fmt.pretty.splitOn "\n").map (fun s => s.trimAscii.toString) |>.filter (· != ""))
        return (eqOk, flat)
      let ((res, _), _) ← (act.run {}).toIO ctxCore stCore
      return res
  | _, _ => return (false, "<MISSING_CONSTANT>")

def parseCliArgs : List String → String → String → (String × String)
  | "--oracle-json" :: v :: rest, _, outP => parseCliArgs rest v outP
  | "--out-json" :: v :: rest, orcP, _    => parseCliArgs rest orcP v
  | _ :: rest, orcP, outP                 => parseCliArgs rest orcP outP
  | [], orcP, outP                        => (orcP, outP)

def main (args : List String) : IO UInt32 := do
  let (oraclePathStr, outPathStr) :=
    parseCliArgs args "i1_precommitted_oracle_71.json" "i1_live_replay_observation.json"

  initSearchPath (← findSysroot)
  let rawEnv ← importModules #[
    { module := `OmegaCellC1P1B2BB3, importAll := true },
    { module := `ExternalSpecPinB3I1, importAll := true }
  ] {}
  let env := rawEnv.setExporting false
  let allowedAx : List Name := [`propext, `Classical.choice, `Quot.sound]

  -- 1. Verify all 41 B3 headline theorem pins (isDefEq + pretty-printed kernel type + axiom closure)
  let mut pinFailures : List String := []
  let mut badAxiomRefs : List String := []
  let mut sorryRefs : List String := []
  let mut nativeDecideRefs : List String := []
  let mut theoremPinRows : Array Json := #[]

  for (origThm, pinThm) in all41PinnedTheoremPairs do
    let (defEqOk, ppSig) ← checkPinAndPrettyType env origThm pinThm
    if !defEqOk then
      pinFailures := s!"{origThm} != {pinThm}" :: pinFailures
    let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) origThm) env
    let axStrs := (axs.toList.map Name.toString).mergeSort (· < ·)
    for a in axs do
      if a == `sorryAx then sorryRefs := origThm.toString :: sorryRefs
      if a == `Lean.ofReduceBool || a == `Lean.trustCompiler then
        nativeDecideRefs := s!"{origThm}->{a}" :: nativeDecideRefs
      if !allowedAx.contains a then
        badAxiomRefs := s!"{origThm}->{a}" :: badAxiomRefs
    let isThm := match env.find? origThm with | some (.thmInfo _) => true | _ => false
    if !isThm then pinFailures := s!"NOT_THM:{origThm}" :: pinFailures
    theoremPinRows := theoremPinRows.push (Json.mkObj [
      ("theoremName", Json.str origThm.toString),
      ("pinTheoremName", Json.str pinThm.toString),
      ("kernelIsDefEqVerified", Json.bool defEqOk),
      ("isTheoremInfo", Json.bool isThm),
      ("kernelPrettySignature", Json.str ppSig),
      ("transitiveAxioms", toJsonStrArr axStrs)
    ])

  -- Also verify the 6 I1 VerifyKit theorems have zero sorry / zero native_decide / zero custom axioms
  let mut i1KitThmRows : Array Json := #[]
  for kth in i1KitTheorems6 do
    let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) kth) env
    let axStrs := (axs.toList.map Name.toString).mergeSort (· < ·)
    for a in axs do
      if a == `sorryAx then sorryRefs := kth.toString :: sorryRefs
      if a == `Lean.ofReduceBool || a == `Lean.trustCompiler then
        nativeDecideRefs := s!"{kth}->{a}" :: nativeDecideRefs
      if !allowedAx.contains a then
        badAxiomRefs := s!"{kth}->{a}" :: badAxiomRefs
    i1KitThmRows := i1KitThmRows.push (Json.mkObj [
      ("kitTheoremName", Json.str kth.toString),
      ("transitiveAxioms", toJsonStrArr axStrs)
    ])

  -- 2. Exhaustive Declaration Classification across all 7 B3 modules (`I1-A8`, `F-B3-T19-04`, `Q-B3-I1-04`)
  let mut totalB3Owned : Nat := 0
  let mut bucketS_Sem : List Name := []
  let mut bucketK_Exec : List Name := []
  let mut bucketD_Data : List Name := []
  let mut bucketT_Thms : List Name := []
  let mut bucketF_Fixt : List Name := []
  let mut bucketA_Aux  : List Name := []
  let mut bucketU_Unclassified : List String := []
  let mut b3UnsafeOrOpaqueOrBadPartial : List String := []

  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    if b3Modules7.contains m then
      let md := env.header.moduleData[i]!
      totalB3Owned := totalB3Owned + md.constNames.size
      for c in md.constNames do
        let (axs, _) ← StateT.run (Lean.collectAxioms (m := AuditEnvM) c) env
        for a in axs do
          if a == `sorryAx then sorryRefs := c.toString :: sorryRefs
          if a == `Lean.ofReduceBool || a == `Lean.trustCompiler then
            nativeDecideRefs := s!"{c}->{a}" :: nativeDecideRefs
          if !allowedAx.contains a then badAxiomRefs := s!"{c}->{a}" :: badAxiomRefs
        match env.find? c with
        | none => bucketU_Unclassified := s!"MISSING:{c}" :: bucketU_Unclassified
        | some ci =>
            if ci.isUnsafe then b3UnsafeOrOpaqueOrBadPartial := s!"UNSAFE:{c}" :: b3UnsafeOrOpaqueOrBadPartial
            match ci with
            | .opaqueInfo _ => b3UnsafeOrOpaqueOrBadPartial := s!"OPAQUE:{c}" :: b3UnsafeOrOpaqueOrBadPartial
            | .axiomInfo _  => b3UnsafeOrOpaqueOrBadPartial := s!"AXIOM:{c}" :: b3UnsafeOrOpaqueOrBadPartial
            | .defnInfo dv  =>
                if dv.safety == .partial then
                  match c with
                  | .str parent "_unsafe_rec" =>
                      match env.find? parent with
                      | some (.defnInfo pv) =>
                          if pv.safety != .safe then
                            b3UnsafeOrOpaqueOrBadPartial := s!"PARTIAL:{c}" :: b3UnsafeOrOpaqueOrBadPartial
                      | _ => b3UnsafeOrOpaqueOrBadPartial := s!"PARTIAL:{c}" :: b3UnsafeOrOpaqueOrBadPartial
                  | _ => b3UnsafeOrOpaqueOrBadPartial := s!"PARTIAL:{c}" :: b3UnsafeOrOpaqueOrBadPartial
            | _ => pure ()

            -- Deterministic Partition of `C_owned_B3` into `(A, T, D, F, S, K)` vs `U`:
            if isCompilerOrElabAuxName c then
              bucketA_Aux := c :: bucketA_Aux
            else if m == `OmegaCellC1P1B2BB3.B3_06_SoundnessSuiteAndMutants then
              match ci with
              | .thmInfo _ => bucketT_Thms := c :: bucketT_Thms
              | .inductInfo _ | .ctorInfo _ | .recInfo _ => bucketD_Data := c :: bucketD_Data
              | _ => bucketF_Fixt := c :: bucketF_Fixt
            else if isIllustrativeContrastFixture c then
              bucketF_Fixt := c :: bucketF_Fixt
            else
              match ci with
              | .thmInfo _ => bucketT_Thms := c :: bucketT_Thms
              | .inductInfo _ =>
                  if isPropReturningType ci.type then
                    bucketS_Sem := c :: bucketS_Sem
                  else
                    bucketD_Data := c :: bucketD_Data
              | .ctorInfo _ =>
                  if isPropReturningType ci.type then
                    bucketS_Sem := c :: bucketS_Sem
                  else
                    bucketD_Data := c :: bucketD_Data
              | .recInfo _ => bucketA_Aux := c :: bucketA_Aux
              | .defnInfo _ =>
                  if c == `OmegaCellC1P1B2BB3.SyntacticValidPrimEnv then
                    -- Syntactic structural env wrapper (`checkPrimEnvIntegrityBool Γ = true`, contrasted with `SemValidPrimId` in `T_I0_A2_02`)
                    bucketK_Exec := c :: bucketK_Exec
                  else if env.isProjectionFn c then
                    if isPropReturningType ci.type then
                      bucketS_Sem := c :: bucketS_Sem
                    else
                      bucketD_Data := c :: bucketD_Data
                  else if isPropReturningType ci.type then
                    bucketS_Sem := c :: bucketS_Sem
                  else if (stripForalls ci.type).isSort then
                    -- Type alias / parameterized subtype carrier (`G5EpochAdaptedCert`, `G56RelationalPullback`, `VerifiedG56Object`)
                    bucketD_Data := c :: bucketD_Data
                  else if isExecutableCheckerReturnType ci.type then
                    bucketK_Exec := c :: bucketK_Exec
                  else
                    bucketU_Unclassified := c.toString :: bucketU_Unclassified
              | _ => bucketU_Unclassified := c.toString :: bucketU_Unclassified

  -- Also programmatically collect ALL non-Prop executable `.defnInfo` checkers across ancestor evaluator modules!
  let ancestorExecModules : List Name := [
    `OmegaCellC1P1B1.P1B1A_VerdictSlotReifier,
    `OmegaCellC1P1B2A.P1B2AA_PartialExprPolyCert,
    `OmegaCellC1P1B2A.P1B2AB_TelescopicGuardAndDAG,
    `OmegaCellC1P1B2A.P1B2AC_ConservativeRefinementAndBundle,
    `OmegaCellC1P1B2BA0.A0_01_02_DomNzAndImpNorm,
    `OmegaCellC1P1B2BA0.A0_03_TelescopicPartition,
    `OmegaCellC1P1B2BA0.A0_04_06_ParamSubstAndSosWitness,
    `OmegaCellC1P1B2BA0.A0_05_ProofDependencyClosure,
    `OmegaCellC1P1B2BB1.B1_02_RatCoordEvalAndCheckers,
    `OmegaCellC1P1B2BB2.B2_02_SuiteCheckersAndQualification
  ]
  let allowedPureSyntaxAstHelpersInSem : List Name := [
    `OmegaCellC1P1B2A.PartExpr,
    `OmegaCellC1P1B2A.StrictForm,
    `OmegaCellC1P1B2A.evalPolyExpr,
    `OmegaCellC1P1B2A.lookupPrimPrem?,
    `OmegaCellC1P1B2BA0.substParamInExpr,
    `OmegaCellC1P1B2BA0.substParamInForm
  ]
  let mut ancAutoExecCheckers : List Name := []
  for i in [:env.header.moduleNames.size] do
    let m := env.header.moduleNames[i]!
    if ancestorExecModules.contains m then
      for c in env.header.moduleData[i]!.constNames do
        if !(isCompilerOrElabAuxName c || env.isProjectionFn c || allowedPureSyntaxAstHelpersInSem.contains c) then
          match env.find? c with
          | some (.defnInfo ciVal) =>
              if !isPropReturningType ciVal.type &&
                 !(stripForalls ciVal.type).isSort then
                let cs := c.toString
                if hasSubstr cs "check" || hasSubstr cs "eval" || hasSubstr cs "verify" ||
                   hasSubstr cs "reify" || hasSubstr cs "qualify" || hasSubstr cs "derive" ||
                   hasSubstr cs "extract" || hasSubstr cs "multiRoot" || hasSubstr cs "intrinsicNz" then
                  ancAutoExecCheckers := c :: ancAutoExecCheckers
          | _ => pure ()

  let pureStructuralProjectionsB3 : List Name := [
    `OmegaCellC1P1B2BB3.G56TransitionBinding.toCoreKey,
    `OmegaCellC1P1B2BB3.projectG5CoreKey,
    `OmegaCellC1P1B2BB3.projectG6CoreKey,
    `OmegaCellC1P1B2BB3.projectG5Transition,
    `OmegaCellC1P1B2BB3.projectRelBoundG6,
    `OmegaCellC1P1B2BB3.pullbackProjG5,
    `OmegaCellC1P1B2BB3.pullbackProjG6,
    `OmegaCellC1P1B2BB3.liftToG56RelationalPullback,
    `OmegaCellC1P1B2BB3.extractVerifiedObject
  ]
  let pureB3CheckersOnly := bucketK_Exec.filter (fun n => !pureStructuralProjectionsB3.contains n)
  let fullClassifiedCheckers := pureB3CheckersOnly ++ ancAutoExecCheckers
  let fullSemCone := transitiveCone env bucketS_Sem
  let mut classifiedCircularHits : List String := []
  for k in fullClassifiedCheckers do
    if fullSemCone.contains k then
      classifiedCircularHits := k.toString :: classifiedCircularHits

  -- Barrier-stopped computational lookup confinement (`F-B3-T19-04`):
  -- Starting from top-level B3 entrypoints, traverse computational `.defnInfo` calls stopping ONLY
  -- at sanctioned frozen gate entrypoints, verifying ZERO paths reach raw `lookupDagNode?` / `lookupPrimPrem?`!
  let b3TopEntrypoints : List Name := [
    `OmegaCellC1P1B2BB3.checkG56Coupling,
    `OmegaCellC1P1B2BB3.checkG56PacketWithContext,
    `OmegaCellC1P1B2BB3.evalG56DetailedR1,
    `OmegaCellC1P1B2BB3.projectCoupledVerdictR1,
    `OmegaCellC1P1B2BB3.reifyVerifiedG56,
    `OmegaCellC1P1B2BB3.qualifyG56Coupled?,
    `OmegaCellC1P1B2BB3.checkActiveG56CouplingBool,
    `OmegaCellC1P1B2BB3.checkActiveG56RecordBool
  ]
  let sanctionedAncestorBarriers : List Name := [
    `OmegaCellC1P1B2A.checkPrimEnvIntegrityBool,
    `OmegaCellC1P1B2A.checkContainerIntegrityBool,
    `OmegaCellC1P1B2A.verifyReachableDerivation,
    `OmegaCellC1P1B2BA0.verifyMultiRootTraced,
    `OmegaCellC1P1B2BA0.extractTransitivePrimDeps,
    `OmegaCellC1P1B2BA0.multiRootTransitivePrimDeps,
    `OmegaCellC1P1B2BB1.deriveG5PrimDeps,
    `OmegaCellC1P1B2BB1.checkG5CoreProofsBool,
    `OmegaCellC1P1B2BB1.checkG5DischargeBool,
    `OmegaCellC1P1B2BB1.checkExactG7SequentBool,
    `OmegaCellC1P1B2BB1.checkGuardEntailmentListBool,
    `OmegaCellC1P1B2BB2.deriveG6PrimDeps,
    `OmegaCellC1P1B2BB2.checkG6Suite
  ]
  let b3TransitiveAboveBarriers := computationalBarrierStoppedCone env b3TopEntrypoints sanctionedAncestorBarriers
  let mut transitiveLookupBypassHits : List String := []
  if b3TransitiveAboveBarriers.contains `OmegaCellC1P1B2A.lookupDagNode? then
    transitiveLookupBypassHits := "lookupDagNode?_REACHED_ABOVE_BARRIERS" :: transitiveLookupBypassHits
  if b3TransitiveAboveBarriers.contains `OmegaCellC1P1B2A.lookupPrimPrem? then
    transitiveLookupBypassHits := "lookupPrimPrem?_REACHED_ABOVE_BARRIERS" :: transitiveLookupBypassHits

  let recordPrivateSealed := isStructCtorPrivate env `OmegaCellC1P1B2BB3.G56QualifiedRecord

  -- 3. Live 71-Case Evaluation & Comparison Against Pre-Committed `i1_precommitted_oracle_71.json`
  let oracleRaw ← IO.FS.readFile oraclePathStr
  let oracleJson ← IO.ofExcept (Json.parse oracleRaw)
  let casesArr ← IO.ofExcept ((oracleJson.getObjVal? "cases") >>= Json.getArr?)
  let live71 := evaluateAll71CasesLiveI1

  let live71Arr := live71.toArray
  let mut live71Mismatches : List String := []
  let mut live71Rows : Array Json := #[]
  if casesArr.size != live71Arr.size then
    live71Mismatches := s!"COUNT_MISMATCH:{casesArr.size}!={live71Arr.size}" :: live71Mismatches
  for idx in [:live71Arr.size] do
    if hAct : idx < live71Arr.size then
      let act : LiveI1CaseObservation := live71Arr[idx]
      if h : idx < casesArr.size then
        let expObj := casesArr[idx]
        let expId ← IO.ofExcept ((expObj.getObjVal? "caseId") >>= Json.getStr?)
        let expGrp ← IO.ofExcept ((expObj.getObjVal? "suiteGroup") >>= Json.getStr?)
        let expVer ← IO.ofExcept ((expObj.getObjVal? "expectedVerdict") >>= Json.getStr?)
        let expQual ← IO.ofExcept ((expObj.getObjVal? "expectedLiveQualifyOption") >>= Json.getStr?)
        let matchOk :=
          (expId == act.caseId) &&
          (expGrp == act.suiteGroup) &&
          (expVer == act.actualVerdict) &&
          (expQual == act.liveQualifyOptionStatus)
        if !matchOk then
          live71Mismatches := s!"CASE_MISMATCH:{act.caseId}(exp={expVer}/{expQual}, act={act.actualVerdict}/{act.liveQualifyOptionStatus})" :: live71Mismatches
        live71Rows := live71Rows.push (Json.mkObj [
          ("caseId", Json.str act.caseId),
          ("suiteGroup", Json.str act.suiteGroup),
          ("actualVerdict", Json.str act.actualVerdict),
          ("liveQualifyOptionStatus", Json.str act.liveQualifyOptionStatus),
          ("matchedOracle", Json.bool matchOk)
        ])

  -- 4. Separated Mutation Observations (`M_registered` 12 vs `M_end_to_end` 12)
  let reg12 := evaluateAll12Mutants
  let mut reg12Rows : Array Json := #[]
  for m in reg12 do
    let layerStr :=
      match registered12ProbeLayerMap.find? (fun p => p.1 == m.mutantId) with
      | some (_, cat) => reprStr cat
      | none          => "unclassified"
    reg12Rows := reg12Rows.push (Json.mkObj [
      ("mutantId", Json.str m.mutantId),
      ("probeLayerCategory", Json.str layerStr),
      ("targetCaseId", Json.str m.targetCaseId),
      ("mutantFalseAccept", Json.bool m.mutantFalseAccept),
      ("canonicalRejects", Json.bool m.canonicalRejects),
      ("killed", Json.bool m.killed)
    ])
  let reg12AllKilled := reg12.all (fun m => m.killed)

  let e2e12 := evaluateAll12EndToEndSingleFaultMutants
  let mut e2e12Rows : Array Json := #[]
  for r in e2e12 do
    e2e12Rows := e2e12Rows.push (Json.mkObj [
      ("e2eMutantId", Json.str r.e2eMutantId),
      ("layerCategory", Json.str "isolatedEndToEndSingleFault"),
      ("faultDescription", Json.str r.faultDescription),
      ("positiveCaseId", Json.str r.positiveCaseId),
      ("adversarialCaseId", Json.str r.adversarialCaseId),
      ("mutantAcceptsPositive", Json.bool r.mutantAcceptsPositive),
      ("canonicalAcceptsPositive", Json.bool r.canonicalAcceptsPositive),
      ("mutantFalseAcceptsAdv", Json.bool r.mutantFalseAcceptsAdv),
      ("canonicalRejectsAdv", Json.bool r.canonicalRejectsAdv),
      ("killedEndToEnd", Json.bool r.killedEndToEnd)
    ])
  let e2e12AllKilled := e2e12.all (fun r => r.killedEndToEnd)

  -- 5. Live Provenance-Bound Consumer Spoof-Blocking Observation (`I1-A9`, `F-B3-T19-01`)
  let unboundSpoofedVerdict :=
    reprStr (projectCoupledVerdictR1 ctx_ceG56_01 cert_ceG56_01 det_t19_01_spoofedFromValid)
  let boundConsumerVerdict :=
    reprStr (consumeProvenanceBoundVerdict (evalProvenanceBoundG56 ctx_ceG56_01 cert_ceG56_01))
  let boundQualifyNone :=
    (consumeProvenanceBoundQualifiedRecord? ctx_ceG56_01 cert_ceG56_01).isNone
  let boundPosQualifySome :=
    (consumeProvenanceBoundQualifiedRecord? ctx_posG56_01 cert_posG56_01).isSome
  let consumerCheckOk :=
    (projectCoupledVerdictR1 ctx_ceG56_01 cert_ceG56_01 det_t19_01_spoofedFromValid ==
      .g56Verified false false) &&
    (consumeProvenanceBoundVerdict (evalProvenanceBoundG56 ctx_ceG56_01 cert_ceG56_01) ==
      .invalidBinding .g6TransitionIdMismatch) &&
    boundQualifyNone &&
    boundPosQualifySome

  let leanVerExact := (Lean.versionString == "4.33.1")
  let allPassed :=
    leanVerExact &&
    pinFailures.isEmpty &&
    sorryRefs.isEmpty &&
    nativeDecideRefs.isEmpty &&
    badAxiomRefs.isEmpty &&
    b3UnsafeOrOpaqueOrBadPartial.isEmpty &&
    bucketU_Unclassified.isEmpty &&
    classifiedCircularHits.isEmpty &&
    transitiveLookupBypassHits.isEmpty &&
    recordPrivateSealed &&
    live71Mismatches.isEmpty &&
    reg12AllKilled &&
    e2e12AllKilled &&
    consumerCheckOk

  let outObj := Json.mkObj [
    ("observationSchema", Json.str "principia.omega.p1b2b.b3.i1.live_replay_observation.v1"),
    ("workId", Json.str "PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_I1_INDEPENDENT_EXTERNAL_REPLAY_ACT"),
    ("allChecksPassed", Json.bool allPassed),
    ("leanVersion", Json.str Lean.versionString),
    ("leanVersionExact_4_33_1", Json.bool leanVerExact),
    ("gate_I1_A5_TheoremSignatureAndAxiomAudit", Json.mkObj [
      ("headline41Count", Json.num theoremPinRows.size),
      ("pinFailures", toJsonStrArr pinFailures),
      ("sorryAxRefs", toJsonStrArr sorryRefs),
      ("nativeDecideOrTrustCompilerRefs", toJsonStrArr nativeDecideRefs),
      ("badAxiomRefs", toJsonStrArr badAxiomRefs),
      ("headline41PinsAndSignatures", Json.arr theoremPinRows),
      ("i1Kit6Theorems", Json.arr i1KitThmRows)
    ]),
    ("gate_I1_A6_Live71OracleAndQualificationObservation", Json.mkObj [
      ("totalCases", Json.num live71Rows.size),
      ("liveCoupledCertQualifyCases", Json.num 55),
      ("nonCertTargetEvaluatorCases", Json.num 16),
      ("mismatches", toJsonStrArr live71Mismatches),
      ("cases", Json.arr live71Rows)
    ]),
    ("gate_I1_A7_SeparatedMutationTesting", Json.mkObj [
      ("registered12ProbeCount", Json.num reg12Rows.size),
      ("registered12AllKilled", Json.bool reg12AllKilled),
      ("registered12Probes", Json.arr reg12Rows),
      ("endToEnd12SingleFaultCount", Json.num e2e12Rows.size),
      ("endToEnd12AllPreservePosAndKilled", Json.bool e2e12AllKilled),
      ("zeroFaultPipelineIdentityTheorem", Json.str "ExternalSpecPinB3I1.T_I1_A7_01_ZeroFaultPipelineExactIdentity"),
      ("equivalentMutantTheorem", Json.str "ExternalSpecPinB3I1.T_I1_A7_03_EQ01_CommutedUnionIsProvablyEquivalentMutant"),
      ("nonConstructibleTypeBlockedClass", Json.str "G56QualifiedRecord private mk :: blocks cross-slot mixing at typecheck time"),
      ("endToEnd12SingleFaultMutants", Json.arr e2e12Rows)
    ]),
    ("gate_I1_A8_ExhaustiveDeclarationAndTransitiveConfinementAudit", Json.mkObj [
      ("epistemicNote_Q_B3_I1_04", Json.str "Separates raw constant enumeration from rule-audited partition; unclassified relevant set U is explicitly computed and verified empty."),
      ("totalB3OwnedConstants", Json.num totalB3Owned),
      ("bucketS_DeclarativeSemanticsCount", Json.num bucketS_Sem.length),
      ("bucketS_DeclarativeSemanticsNames", toJsonStrArr ((bucketS_Sem.map Name.toString).mergeSort (· < ·))),
      ("bucketK_ExecutableEvaluatorsAndProjectionsCount", Json.num bucketK_Exec.length),
      ("bucketK_PureCheckersOnlyCount", Json.num pureB3CheckersOnly.length),
      ("bucketD_DatatypesAndCtorsCount", Json.num bucketD_Data.length),
      ("bucketT_TheoremsCount", Json.num bucketT_Thms.length),
      ("bucketF_SuiteFixturesAndMutantsCount", Json.num bucketF_Fixt.length),
      ("bucketA_CompilerAndPrivateAuxCount", Json.num bucketA_Aux.length),
      ("unclassifiedRelevantDeclarationSet_U", toJsonStrArr bucketU_Unclassified),
      ("unclassifiedRelevantDeclarationCount", Json.num bucketU_Unclassified.length),
      ("ancestorAutoCollectedCheckerCount", Json.num ancAutoExecCheckers.length),
      ("fullClassifiedSemanticConeSize", Json.num fullSemCone.size),
      ("classifiedSemanticCheckerCircularHits", toJsonStrArr classifiedCircularHits),
      ("b3TransitiveConeAboveSanctionedBarriersSize", Json.num b3TransitiveAboveBarriers.size),
      ("transitiveLookupBypassHits", toJsonStrArr transitiveLookupBypassHits),
      ("b3UnsafeOrOpaqueOrBadPartial", toJsonStrArr b3UnsafeOrOpaqueOrBadPartial),
      ("qualifiedRecordPrivateCtorSealed", Json.bool recordPrivateSealed)
    ]),
    ("gate_I1_A9_ProvenanceBoundConsumerVerification", Json.mkObj [
      ("consumerCheckPassed", Json.bool consumerCheckOk),
      ("unboundSpoofedDetProjectionResult", Json.str unboundSpoofedVerdict),
      ("provenanceBoundConsumerInvalidResult", Json.str boundConsumerVerdict),
      ("provenanceBoundQualifyInvalidIsNone", Json.bool boundQualifyNone),
      ("provenanceBoundQualifyValidIsSome", Json.bool boundPosQualifySome),
      ("spoofContrastTheorem", Json.str "ExternalSpecPinB3I1.T_I1_A9_01_UnboundDetProjectionCanSpoofInvalidCoupling"),
      ("consumerSoundnessTheorem", Json.str "ExternalSpecPinB3I1.T_I1_A9_02_ProvenanceBoundConsumerExactAndSound")
    ])
  ]

  IO.FS.writeFile outPathStr (outObj.pretty ++ "\n")
  if !allPassed then
    IO.eprintln s!"ExternalObsAndTcbAuditB3I1 FAILED: pins={pinFailures}, U={bucketU_Unclassified}, circ={classifiedCircularHits}, bypass={transitiveLookupBypassHits}, m71={live71Mismatches}"
    return 1
  return 0
