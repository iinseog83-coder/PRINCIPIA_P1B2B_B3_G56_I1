/-
  PRINCIPIA Ω-CELL-C1-P1B2B — Isolated Proof Core A0
  Module: OmegaCellC1P1B2BA0.A0_05_ProofDependencyClosure

  Authorized Scope (`A0_ISOLATED_LEAN_MECHANIZATION_APPROVED`, `A0-GUARD-01`):
    Explicitly separates and constructively proves ALL FOUR proof-dependency closure laws
    over multi-root `G7` proof collections `roots : List String`:
      1. `A0_05_1_OutputCongruence`:
         Two `(Γ₁, C₁)` and `(Γ₂, C₂)` agreeing on `(P*, R*)` produce identical multi-root verdicts.
      2. `A0_05_2_ActualLookupConfinement` + `A0_05_2b_OutputCongruence_NotImplies_LookupConfinement`:
         Threads an unconditional `QueryAuditLog` through every primitive/node lookup of the
         verifier (recording every query even when its return value is unused/discarded), proves
         100% behavioral identity with frozen `P1B2A` `verifyReachableDerivation`, proves EVERY
         queried node/premise ID belongs to `(R*, P*)`, AND constructs an explicit unused-lookup
         decoy proving `OutputCongruence ⇏ ActualLookupConfinement` (`A0-GUARD-01`).
      3. `A0_05_3_RestrictionInvariance`:
         Restricting `(Γ, C)` to `(restrictPrimEnv Γ P*, restrictContainer C R*)` preserves BOTH
         the multi-root verdicts AND the exact runtime query audit trace.
      4. `A0_05_4_SemanticDependencyClosure` + `A0_05_4b_PoisonOutsideClosureWitness`:
         `SemValidPrimId` on `P*` ALONE (even when `Γ` contains false premises outside `P*`)
         suffices to prove `SemValidSequent` for every accepted root in `roots`.
-/
import OmegaCellC1P1B2BA0.A0_04_06_ParamSubstAndSosWitness

namespace OmegaCellC1P1B2BA0

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A

/-! ### 1. Multi-Root Reachable Node Closure `R*` & Transitive Premise Closure `P*` -/

/-- Canonical multi-root reachable node closure `R*(C, roots)`. -/
def multiRootReachableNodes (C : G7DagContainer) (roots : List String) : List String :=
  canonSortStrs (roots.foldr (fun r acc => extractReachableNodeIds C r ++ acc) [])

/-- Canonical multi-root transitive primitive premise closure `P*(Γ, C, roots)`. -/
def multiRootTransitivePrimDeps (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (roots : List String) : List String :=
  canonSortStrs (roots.foldr (fun r acc => extractTransitivePrimDeps Γ C r ++ acc) [])

private theorem mem_foldr_union_of_mem {α : Type} (f : String → List α) :
    ∀ (roots : List String) {r : String} {x : α},
      r ∈ roots → x ∈ f r →
      x ∈ roots.foldr (fun u acc => f u ++ acc) []
  | [], _, _, hr, _ => nomatch hr
  | u :: us, r, x, hr, hx => by
      dsimp only [List.foldr]
      rcases List.mem_cons.mp hr with rfl | hTail
      · exact List.mem_append_left _ hx
      · exact List.mem_append_right _ (mem_foldr_union_of_mem f us hTail hx)

theorem mem_multiRootReachableNodes (C : G7DagContainer) {roots : List String}
    {r nid : String} (hr : r ∈ roots) (hn : nid ∈ extractReachableNodeIds C r) :
    nid ∈ multiRootReachableNodes C roots := by
  unfold multiRootReachableNodes
  rw [mem_canonSortStrs]
  exact mem_foldr_union_of_mem (extractReachableNodeIds C) roots hr hn

theorem mem_multiRootTransitivePrimDeps (Γ : PrimPremiseEnv) (C : G7DagContainer)
    {roots : List String} {r pid : String}
    (hr : r ∈ roots) (hp : pid ∈ extractTransitivePrimDeps Γ C r) :
    pid ∈ multiRootTransitivePrimDeps Γ C roots := by
  unfold multiRootTransitivePrimDeps
  rw [mem_canonSortStrs]
  exact mem_foldr_union_of_mem (extractTransitivePrimDeps Γ C) roots hr hp

/-! ### 2. Structural Reachability & Lookup-Restriction Lemmas over Frozen `P1B2AB` -/

private theorem subset_expandNodeStep_a0 (C : G7DagContainer) (cur : List String) :
    ∀ x ∈ cur, x ∈ expandNodeStep C cur := by
  induction cur with
  | nil => intro _ h; nomatch h
  | cons a as ih =>
      intro x hx
      unfold expandNodeStep
      simp only [List.foldr_cons, List.mem_cons, List.mem_append]
      rcases List.mem_cons.mp hx with rfl | hRest
      · exact Or.inl rfl
      · exact Or.inr (Or.inr (ih x hRest))

private theorem parent_mem_expandNodeStep_a0 (C : G7DagContainer) (cur : List String)
    {nid parId : String} {n : G7DagNode}
    (hMem : nid ∈ cur) (hLook : lookupDagNode? C nid = some n)
    (hPar : parId ∈ (extractStepFootprint n.step).parentNodeRefs) :
    parId ∈ expandNodeStep C cur := by
  induction cur with
  | nil => nomatch hMem
  | cons a as ih =>
      unfold expandNodeStep
      simp only [List.foldr_cons, List.mem_cons, List.mem_append]
      rcases List.mem_cons.mp hMem with rfl | hRest
      · rw [hLook]
        exact Or.inr (Or.inl hPar)
      · exact Or.inr (Or.inr (ih hRest))

private theorem mono_transNodeIter_a0 (C : G7DagContainer) (cur : List String) {k : Nat} :
    ∀ (d : Nat) {x : String}, x ∈ transNodeIter k C cur → x ∈ transNodeIter (k + d) C cur
  | 0,     _, hx => hx
  | d + 1, _, hx =>
      subset_expandNodeStep_a0 C (transNodeIter (k + d) C cur) _
        (mono_transNodeIter_a0 C cur d hx)

private theorem mem_transNodeIter_le_a0 (C : G7DagContainer) (cur : List String) {k m : Nat}
    (hLe : k ≤ m) {x : String} (hx : x ∈ transNodeIter k C cur) :
    x ∈ transNodeIter m C cur := by
  have hEq : k + (m - k) = m := Nat.add_sub_of_le hLe
  rw [← hEq]
  exact mono_transNodeIter_a0 C cur (m - k) hx

private theorem topoRank_le_maxTopoRank_a0 {C : G7DagContainer} {n : G7DagNode}
    (hMem : n ∈ C.nodes) : n.topoRank ≤ maxTopoRank C := by
  unfold maxTopoRank
  have hList : ∀ (L : List G7DagNode), n ∈ L →
      n.topoRank ≤ L.foldr (fun x acc => Nat.max x.topoRank acc) 0 := by
    intro L hIn
    induction L with
    | nil => nomatch hIn
    | cons a as ih =>
        dsimp only [List.foldr]
        rcases List.mem_cons.mp hIn with rfl | hTail
        · exact Nat.le_max_left n.topoRank _
        · exact Nat.le_trans (ih hTail) (Nat.le_max_right a.topoRank _)
  exact hList C.nodes hMem

private theorem validContainer_parent_rank_a0 {C : G7DagContainer} (hVal : ValidContainer C)
    {nid parId : String} {n : G7DagNode}
    (hLook : lookupDagNode? C nid = some n)
    (hPar : parId ∈ (extractStepFootprint n.step).parentNodeRefs) :
    ∃ par : G7DagNode, lookupDagNode? C parId = some par ∧ par.topoRank < n.topoRank := by
  unfold ValidContainer checkContainerIntegrityBool at hVal
  simp only [Bool.and_eq_true] at hVal
  have hMem : n ∈ C.nodes := List.mem_of_find?_eq_some hLook
  have hNodeOk := List.all_eq_true.mp hVal.2 n hMem
  simp only [Bool.and_eq_true] at hNodeOk
  have hParOk := List.all_eq_true.mp hNodeOk.2 parId hPar
  cases hp : lookupDagNode? C parId with
  | none     => rw [hp] at hParOk; nomatch hParOk
  | some par =>
      rw [hp] at hParOk
      exact ⟨par, rfl, of_decide_eq_true hParOk⟩

private theorem prim_mem_collectDirectPrimRefs_a0 (C : G7DagContainer) (nodeIds : List String)
    {nid pid : String} {n : G7DagNode}
    (hNodeMem : nid ∈ nodeIds) (hLook : lookupDagNode? C nid = some n)
    (hPrim : pid ∈ (extractStepFootprint n.step).primRefs) :
    pid ∈ collectDirectPrimRefsOfNodes C nodeIds := by
  unfold collectDirectPrimRefsOfNodes
  rw [mem_canonSortStrs]
  induction nodeIds with
  | nil => nomatch hNodeMem
  | cons a as ih =>
      simp only [List.foldr_cons]
      rcases List.mem_cons.mp hNodeMem with rfl | hRest
      · rw [hLook]
        exact List.mem_append_left _ hPrim
      · cases lookupDagNode? C a with
        | none    => exact ih hRest
        | some na => exact List.mem_append_right _ (ih hRest)

theorem lookup_restrictContainer_eq_a0 (C : G7DagContainer) (keepIds : List String)
    {nid : String} (hMem : nid ∈ keepIds) :
    lookupDagNode? (restrictContainer C keepIds) nid = lookupDagNode? C nid := by
  unfold lookupDagNode? restrictContainer
  apply filter_find?_eq_of_pred_imp_keep
  intro n _ hEq
  rw [eq_of_beq hEq]
  exact List.contains_iff_mem.mpr hMem

theorem lookup_restrictPrimEnv_eq_a0 (Γ : PrimPremiseEnv) (keepIds : List String)
    {pid : String} (hMem : pid ∈ keepIds) :
    lookupPrimPrem? (restrictPrimEnv Γ keepIds) pid = lookupPrimPrem? Γ pid := by
  unfold lookupPrimPrem? restrictPrimEnv
  apply filter_find?_eq_of_pred_imp_keep
  intro e _ hEq
  rw [eq_of_beq hEq]
  exact List.contains_iff_mem.mpr hMem

/-! ### 3. Unconditional Query-Logging Instrumented Verifier (`QueryAuditLog`) -/

/-- Monotonic audit log recording EVERY node ID and premise ID passed to a lookup primitive,
    even if the caller later discards or ignores the lookup result (`A0-GUARD-01`). -/
structure QueryAuditLog where
  queriedNodeIds : List String
  queriedPrimIds : List String
  deriving DecidableEq, Repr

def emptyQueryLog : QueryAuditLog := ⟨[], []⟩

def appendQueryLog (L1 L2 : QueryAuditLog) : QueryAuditLog where
  queriedNodeIds := L1.queriedNodeIds ++ L2.queriedNodeIds
  queriedPrimIds := L1.queriedPrimIds ++ L2.queriedPrimIds

/-- Instrumented node lookup unconditionally logging `nid`. -/
def tracedLookupNode (C : G7DagContainer) (nid : String) :
    Option G7DagNode × QueryAuditLog :=
  (lookupDagNode? C nid, ⟨[nid], []⟩)

/-- Instrumented primitive premise lookup unconditionally logging `pid`. -/
def tracedLookupPrim (Γ : PrimPremiseEnv) (pid : String) :
    Option PrimPremiseEntry × QueryAuditLog :=
  (lookupPrimPrem? Γ pid, ⟨[], [pid]⟩)

/-- Short-circuiting instrumented boolean conjunction matching Lean's `&&` evaluation order. -/
def tracedAnd (m1 : Bool × QueryAuditLog) (m2 : Unit → Bool × QueryAuditLog) :
    Bool × QueryAuditLog :=
  match m1.1 with
  | false => (false, m1.2)
  | true  =>
      let r2 := m2 ()
      (r2.1, appendQueryLog m1.2 r2.2)

/-- Short-circuiting instrumented `List.all` matching `List.all` evaluation order. -/
def tracedAll {α : Type} (f : α → Bool × QueryAuditLog) : List α → Bool × QueryAuditLog
  | []      => (true, emptyQueryLog)
  | x :: xs => tracedAnd (f x) (fun () => tracedAll f xs)

private theorem tracedAnd_fst (m1 : Bool × QueryAuditLog) (m2 : Unit → Bool × QueryAuditLog) :
    (tracedAnd m1 m2).1 = (m1.1 && (m2 ()).1) := by
  cases h1 : m1.1 <;> simp [tracedAnd, h1]

private theorem tracedAll_fst {α : Type} (f : α → Bool × QueryAuditLog) :
    ∀ L : List α, (tracedAll f L).1 = L.all (fun x => (f x).1)
  | []      => rfl
  | x :: xs => by
      dsimp only [tracedAll, List.all]
      rw [tracedAnd_fst, tracedAll_fst f xs]

/-- Predicate stating that every logged query in `log` lies within `(keepNodes, keepPrims)`. -/
def LogConfinedTo (keepNodes keepPrims : List String) (log : QueryAuditLog) : Prop :=
  (∀ nid ∈ log.queriedNodeIds, nid ∈ keepNodes) ∧
  (∀ pid ∈ log.queriedPrimIds, pid ∈ keepPrims)

private theorem logConfined_empty (keepNodes keepPrims : List String) :
    LogConfinedTo keepNodes keepPrims emptyQueryLog :=
  And.intro (fun _ h => nomatch h) (fun _ h => nomatch h)

private theorem logConfined_append {keepNodes keepPrims : List String} {L1 L2 : QueryAuditLog}
    (h1 : LogConfinedTo keepNodes keepPrims L1)
    (h2 : LogConfinedTo keepNodes keepPrims L2) :
    LogConfinedTo keepNodes keepPrims (appendQueryLog L1 L2) := by
  constructor
  · intro nid hMem
    rcases List.mem_append.mp hMem with hL | hR
    · exact h1.1 nid hL
    · exact h2.1 nid hR
  · intro pid hMem
    rcases List.mem_append.mp hMem with hL | hR
    · exact h1.2 pid hL
    · exact h2.2 pid hR

private theorem logConfined_tracedAnd {keepNodes keepPrims : List String}
    {m1 : Bool × QueryAuditLog} {m2 : Unit → Bool × QueryAuditLog}
    (h1 : LogConfinedTo keepNodes keepPrims m1.2)
    (h2 : m1.1 = true → LogConfinedTo keepNodes keepPrims (m2 ()).2) :
    LogConfinedTo keepNodes keepPrims (tracedAnd m1 m2).2 := by
  cases hm1 : m1.1 with
  | false => dsimp [tracedAnd]; rw [hm1]; exact h1
  | true  => dsimp [tracedAnd]; rw [hm1]; exact logConfined_append h1 (h2 hm1)

private theorem logConfined_tracedAll {α : Type} {keepNodes keepPrims : List String}
    (f : α → Bool × QueryAuditLog) :
    ∀ (L : List α),
      (∀ x ∈ L, LogConfinedTo keepNodes keepPrims (f x).2) →
      LogConfinedTo keepNodes keepPrims (tracedAll f L).2
  | [], _ => logConfined_empty keepNodes keepPrims
  | x :: xs, hAll =>
      logConfined_tracedAnd (hAll x (List.mem_cons_self ..))
        (fun _ => logConfined_tracedAll f xs (fun y hy => hAll y (List.mem_cons_of_mem x hy)))

/-- Instrumented counterpart of `checkSingleGuardWfBool`. -/
def tracedCheckSingleGuardWf (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (prefixGuards : List StrictForm)
    (γ : StrictForm) (wf : GuardWfWitness) : Bool × QueryAuditLog :=
  match wf with
  | .totalPolyWf =>
      (checkFormDefUnderNzBool [] γ, emptyQueryLog)
  | .prefixGuardDenomWf den =>
      ((prefixGuards.contains (.neqZero den) || prefixGuards.contains (.pos den)) &&
        checkFormDefUnderNzBool [den] γ, emptyQueryLog)
  | .domainIntrinsicNonzero =>
      ((domTag == .domQNonzero) && checkFormDefUnderNzBool [.varX] γ, emptyQueryLog)
  | .externalPremiseDenomWf pid den =>
      let (optPe, log) := tracedLookupPrim Γ pid
      let ok := match optPe with
        | some pe =>
            (pe.domTag == domTag) && (pe.specId == specId) &&
            (pe.formula == .neqZero den || pe.formula == .pos den) &&
            checkExprDefUnderNzBool [] den && checkFormDefUnderNzBool [den] γ
        | none => false
      (ok, log)
  | .parentNodeDenomWf nid den =>
      let (optPar, log) := tracedLookupNode C nid
      let ok := match optPar with
        | some par =>
            decide (par.topoRank < curRank) && (par.domTag == domTag) &&
            (par.specId == specId) && (par.guards == []) &&
            (par.conclusion == .neqZero den || par.conclusion == .pos den) &&
            checkExprDefUnderNzBool [] den && checkFormDefUnderNzBool [den] γ
        | none => false
      (ok, log)

/-- Instrumented counterpart of `checkGuardsPrefixDefinedAux`. -/
def tracedCheckGuardsPrefixAux (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (prefixGuards : List StrictForm) :
    List StrictForm → List GuardWfWitness → Bool × QueryAuditLog
  | [],      []        => (true, emptyQueryLog)
  | γ :: γs, wf :: wfs =>
      tracedAnd (tracedCheckSingleGuardWf domTag specId curRank Γ C prefixGuards γ wf)
        (fun () => tracedCheckGuardsPrefixAux domTag specId curRank Γ C (prefixGuards ++ [γ]) γs wfs)
  | _,       _         => (false, emptyQueryLog)

/-- Instrumented counterpart of `checkGuardCtxEvidenceBool`. -/
def tracedCheckGuardCtx (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) : GuardContextEvidence → Bool × QueryAuditLog
  | .selfContainedCtx => (true, emptyQueryLog)
  | .citedPremiseCtx pids =>
      tracedAnd (isStrictCanonStrList pids, emptyQueryLog) (fun () =>
        tracedAll (fun pid =>
          let (optPe, log) := tracedLookupPrim Γ pid
          let ok := match optPe with
            | some pe => (pe.domTag == domTag) && (pe.specId == specId) &&
                         checkFormDefUnderNzBool [] pe.formula
            | none    => false
          (ok, log)) pids)
  | .citedParentNodeCtx nids =>
      tracedAnd (isStrictCanonStrList nids, emptyQueryLog) (fun () =>
        tracedAll (fun nid =>
          let (optPar, log) := tracedLookupNode C nid
          let ok := match optPar with
            | some par => decide (par.topoRank < curRank) && (par.domTag == domTag) &&
                          (par.specId == specId) && (par.guards == [])
            | none     => false
          (ok, log)) nids)

/-- Instrumented counterpart of `checkLocalDerivBool`. -/
def tracedCheckLocalDeriv (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (guards : List StrictForm) :
    LocalDeriv → StrictForm → Bool × QueryAuditLog
  | .hypGuard idx φ, expectedGoal =>
      ((φ == expectedGoal) && (guards[idx]? == some φ), emptyQueryLog)
  | .primPrem pid φ, expectedGoal =>
      tracedAnd (φ == expectedGoal, emptyQueryLog) (fun () =>
        let (optPe, log) := tracedLookupPrim Γ pid
        let ok := match optPe with
          | some pe => (pe.domTag == domTag) && (pe.specId == specId) &&
                       (pe.formula == φ) && checkFormDefUnderNzBool [] φ
          | none    => false
        (ok, log))
  | .parentRef nid φ, expectedGoal =>
      tracedAnd (φ == expectedGoal, emptyQueryLog) (fun () =>
        let (optPar, log) := tracedLookupNode C nid
        let ok := match optPar with
          | some par => decide (par.topoRank < curRank) && (par.domTag == domTag) &&
                        (par.specId == specId) && (par.conclusion == φ) &&
                        par.guards.all (fun g => guards.contains g)
          | none     => false
        (ok, log))
  | .certStep φ cert, expectedGoal =>
      ((φ == expectedGoal) && checkAlgDomCertBool domTag guards φ cert, emptyQueryLog)
  | .strictMP φ ψ dAnt dImp, expectedGoal =>
      tracedAnd
        (tracedAnd (ψ == expectedGoal, emptyQueryLog)
          (fun () => tracedCheckLocalDeriv domTag specId curRank Γ C guards dAnt φ))
        (fun () => tracedCheckLocalDeriv domTag specId curRank Γ C guards dImp (.impStrict φ ψ))
  | .conjIntro φ ψ dL dR, expectedGoal =>
      tracedAnd
        (tracedAnd (expectedGoal == .conj φ ψ, emptyQueryLog)
          (fun () => tracedCheckLocalDeriv domTag specId curRank Γ C guards dL φ))
        (fun () => tracedCheckLocalDeriv domTag specId curRank Γ C guards dR ψ)

/-- Instrumented counterpart of `checkNodeStepLocal`. -/
def tracedCheckNodeStepLocal (Γ : PrimPremiseEnv) (C : G7DagContainer) (n : G7DagNode) :
    Except G7RejectErr Unit × QueryAuditLog :=
  match n.step with
  | .directDerivStep d =>
      if n.guards != [] then
        (.error .headerMismatch, emptyQueryLog)
      else
        let (ok, log) := tracedCheckLocalDeriv n.domTag n.specId n.topoRank Γ C [] d n.conclusion
        (if ok then .ok () else .error .localDerivFailed, log)
  | .guardedDomStep cert =>
      if !(cert.domTag == n.domTag && cert.guards == n.guards && cert.goalForm == n.conclusion) then
        (.error .headerMismatch, emptyQueryLog)
      else
        let (okWf, logWf) := tracedCheckGuardsPrefixAux cert.domTag n.specId n.topoRank
                               Γ C [] cert.guards cert.guardWfCerts
        if !okWf then
          (.error .guardWfFailed, logWf)
        else
          let (okCtx, logCtx) := tracedCheckGuardCtx cert.domTag n.specId n.topoRank
                                   Γ C cert.guardContextEvidence
          let log12 := appendQueryLog logWf logCtx
          if !okCtx then
            (.error .guardCtxFailed, log12)
          else
            let (okGoal, logGoal) := tracedCheckLocalDeriv cert.domTag n.specId n.topoRank
                                       Γ C cert.guards cert.goalDeriv cert.goalForm
            let logAll := appendQueryLog log12 logGoal
            (if okGoal then .ok () else .error .localDerivFailed, logAll)

/-- Instrumented counterpart of `verifyParentsAux`. -/
def tracedVerifyParentsAux (run : String → G7CheckResult × QueryAuditLog)
    (C : G7DagContainer) (childRank : Nat) :
    List String → Except G7RejectErr (Option Nat) × QueryAuditLog
  | [] => (.ok none, emptyQueryLog)
  | parId :: rest =>
      let (optPar, logLook) := tracedLookupNode C parId
      match optPar with
      | none => (.error (.nodeNotFound parId), logLook)
      | some par =>
          if !(decide (par.topoRank < childRank)) then
            (.error (.causalRankViolation parId), logLook)
          else
            let (resPar, logRun) := run parId
            let log1 := appendQueryLog logLook logRun
            match resPar with
            | .rejectInvalid e => (.error e, log1)
            | .resourceHeld k  => (.ok (some k), log1)
            | .accept _        =>
                let (resTail, logTail) := tracedVerifyParentsAux run C childRank rest
                (resTail, appendQueryLog log1 logTail)

/-- Instrumented counterpart of `verifyNodeFuel`. -/
def tracedVerifyNodeFuel : Nat → PrimPremiseEnv → G7DagContainer → String →
    G7CheckResult × QueryAuditLog
  | 0,     _, _, _   => (.resourceHeld 0, emptyQueryLog)
  | f + 1, Γ, C, nid =>
      let (optN, logRoot) := tracedLookupNode C nid
      match optN with
      | none => (.rejectInvalid (.nodeNotFound nid), logRoot)
      | some n =>
          if n.nodeId != nid then
            (.rejectInvalid .headerMismatch, logRoot)
          else
            let (stepRes, logStep) := tracedCheckNodeStepLocal Γ C n
            let log1 := appendQueryLog logRoot logStep
            match stepRes with
            | .error e => (.rejectInvalid e, log1)
            | .ok () =>
                let pars := (extractStepFootprint n.step).parentNodeRefs
                let (parRes, logPars) := tracedVerifyParentsAux (tracedVerifyNodeFuel f Γ C)
                                           C n.topoRank pars
                let logAll := appendQueryLog log1 logPars
                match parRes with
                | .error e       => (.rejectInvalid e, logAll)
                | .ok (some rem) => (.resourceHeld rem, logAll)
                | .ok none       => (.accept ⟨n.domTag, n.specId, n.guards, n.conclusion⟩, logAll)

/-- Multi-root instrumented evaluator returning `(results, combinedQueryAuditLog)`. -/
def verifyMultiRootTraced (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) :
    List String → List G7CheckResult × QueryAuditLog
  | []      => ([], emptyQueryLog)
  | r :: rs =>
      let (resR, logR) := tracedVerifyNodeFuel fuel Γ C r
      let (resTail, logTail) := verifyMultiRootTraced fuel Γ C rs
      (resR :: resTail, appendQueryLog logR logTail)

/-! ### 4. Exact Behavioral Equivalence with Unmodified Frozen `P1B2A` Verifier -/

private theorem tracedCheckSingleGuardWf_fst (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (prefixGuards : List StrictForm)
    (γ : StrictForm) (wf : GuardWfWitness) :
    (tracedCheckSingleGuardWf domTag specId curRank Γ C prefixGuards γ wf).1 =
    checkSingleGuardWfBool domTag specId curRank Γ C prefixGuards γ wf := by
  cases wf <;> rfl

private theorem tracedCheckGuardsPrefixAux_fst (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) :
    ∀ (prefixGuards gs : List StrictForm) (wfs : List GuardWfWitness),
      (tracedCheckGuardsPrefixAux domTag specId curRank Γ C prefixGuards gs wfs).1 =
      checkGuardsPrefixDefinedAux domTag specId curRank Γ C prefixGuards gs wfs
  | _, [],      []        => rfl
  | _, [],      _ :: _    => rfl
  | _, _ :: _,  []        => rfl
  | prefixGuards, γ :: γs, wf :: wfs => by
      dsimp only [tracedCheckGuardsPrefixAux, checkGuardsPrefixDefinedAux]
      rw [tracedAnd_fst, tracedCheckSingleGuardWf_fst,
          tracedCheckGuardsPrefixAux_fst domTag specId curRank Γ C (prefixGuards ++ [γ]) γs wfs]

private theorem tracedCheckGuardCtx_fst (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (ctx : GuardContextEvidence) :
    (tracedCheckGuardCtx domTag specId curRank Γ C ctx).1 =
    checkGuardCtxEvidenceBool domTag specId curRank Γ C ctx := by
  cases ctx with
  | selfContainedCtx => rfl
  | citedPremiseCtx pids =>
      dsimp only [tracedCheckGuardCtx, checkGuardCtxEvidenceBool]
      rw [tracedAnd_fst, tracedAll_fst]
      rfl
  | citedParentNodeCtx nids =>
      dsimp only [tracedCheckGuardCtx, checkGuardCtxEvidenceBool]
      rw [tracedAnd_fst, tracedAll_fst]
      rfl

private theorem tracedCheckLocalDeriv_fst (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (guards : List StrictForm) :
    ∀ (d : LocalDeriv) (expectedGoal : StrictForm),
      (tracedCheckLocalDeriv domTag specId curRank Γ C guards d expectedGoal).1 =
      checkLocalDerivBool domTag specId curRank Γ C guards d expectedGoal
  | .hypGuard _ _,       _ => rfl
  | .primPrem _ _,       _ => by dsimp only [tracedCheckLocalDeriv, checkLocalDerivBool]; rw [tracedAnd_fst]; rfl
  | .parentRef _ _,      _ => by dsimp only [tracedCheckLocalDeriv, checkLocalDerivBool]; rw [tracedAnd_fst]; rfl
  | .certStep _ _,       _ => rfl
  | .strictMP φ ψ d1 d2, expectedGoal => by
      dsimp only [tracedCheckLocalDeriv, checkLocalDerivBool]
      rw [tracedAnd_fst, tracedAnd_fst,
          tracedCheckLocalDeriv_fst domTag specId curRank Γ C guards d1 φ,
          tracedCheckLocalDeriv_fst domTag specId curRank Γ C guards d2 (.impStrict φ ψ)]
  | .conjIntro φ ψ d1 d2, expectedGoal => by
      dsimp only [tracedCheckLocalDeriv, checkLocalDerivBool]
      rw [tracedAnd_fst, tracedAnd_fst,
          tracedCheckLocalDeriv_fst domTag specId curRank Γ C guards d1 φ,
          tracedCheckLocalDeriv_fst domTag specId curRank Γ C guards d2 ψ]

private theorem tracedCheckNodeStepLocal_fst (Γ : PrimPremiseEnv) (C : G7DagContainer) (n : G7DagNode) :
    (tracedCheckNodeStepLocal Γ C n).1 = checkNodeStepLocal Γ C n := by
  cases hs : n.step with
  | directDerivStep d =>
      unfold tracedCheckNodeStepLocal checkNodeStepLocal
      rw [hs]; dsimp only
      if hG : (n.guards != []) = true then
        rw [if_pos hG, if_pos hG]
      else
        rw [if_neg hG, if_neg hG]
        have hEq := tracedCheckLocalDeriv_fst n.domTag n.specId n.topoRank Γ C [] d n.conclusion
        cases hL : checkLocalDerivBool n.domTag n.specId n.topoRank Γ C [] d n.conclusion <;>
          simp [hEq, hL]
  | guardedDomStep cert =>
      unfold tracedCheckNodeStepLocal checkNodeStepLocal
      rw [hs]; dsimp only
      if hHdr : (!(cert.domTag == n.domTag && cert.guards == n.guards && cert.goalForm == n.conclusion)) = true then
        rw [if_pos hHdr, if_pos hHdr]
      else
        rw [if_neg hHdr, if_neg hHdr]
        have hWfEq := tracedCheckGuardsPrefixAux_fst cert.domTag n.specId n.topoRank Γ C [] cert.guards cert.guardWfCerts
        unfold checkGuardsPrefixDefinedBool
        cases hWf : checkGuardsPrefixDefinedAux cert.domTag n.specId n.topoRank Γ C [] cert.guards cert.guardWfCerts with
        | false => simp [hWfEq, hWf]
        | true =>
            simp only [hWfEq, hWf, Bool.not_true]
            have hCtxEq := tracedCheckGuardCtx_fst cert.domTag n.specId n.topoRank Γ C cert.guardContextEvidence
            cases hCtx : checkGuardCtxEvidenceBool cert.domTag n.specId n.topoRank Γ C cert.guardContextEvidence with
            | false => simp [hCtxEq, hCtx]
            | true =>
                simp only [hCtxEq, hCtx, Bool.not_true]
                have hGoalEq := tracedCheckLocalDeriv_fst cert.domTag n.specId n.topoRank Γ C cert.guards cert.goalDeriv cert.goalForm
                cases hGoal : checkLocalDerivBool cert.domTag n.specId n.topoRank Γ C cert.guards cert.goalDeriv cert.goalForm <;>
                  simp [hGoalEq, hGoal]

private theorem tracedVerifyParentsAux_fst {run : String → G7CheckResult × QueryAuditLog}
    (C : G7DagContainer) (childRank : Nat) :
    ∀ pars : List String,
      (tracedVerifyParentsAux run C childRank pars).1 =
      verifyParentsAux (fun p => (run p).1) C childRank pars
  | [] => rfl
  | parId :: rest => by
      dsimp only [tracedVerifyParentsAux, verifyParentsAux, tracedLookupNode]
      cases lookupDagNode? C parId with
      | none => rfl
      | some par =>
          dsimp only
          if hRk : (!(decide (par.topoRank < childRank))) = true then
            rw [if_pos hRk, if_pos hRk]
          else
            rw [if_neg hRk, if_neg hRk]
            cases hR : (run parId).1 with
            | rejectInvalid _ => rfl
            | resourceHeld _  => rfl
            | accept _        => exact tracedVerifyParentsAux_fst C childRank rest

theorem tracedVerifyNodeFuel_eq_frozen :
    ∀ (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) (nid : String),
      (tracedVerifyNodeFuel fuel Γ C nid).1 = verifyReachableDerivation fuel Γ C nid
  | 0,     _, _, _   => rfl
  | f + 1, Γ, C, nid => by
      unfold verifyReachableDerivation
      dsimp only [tracedVerifyNodeFuel, verifyNodeFuel, tracedLookupNode]
      cases lookupDagNode? C nid with
      | none => rfl
      | some n =>
          dsimp only
          if hId : (n.nodeId != nid) = true then
            rw [if_pos hId, if_pos hId]
          else
            rw [if_neg hId, if_neg hId]
            have hStep := tracedCheckNodeStepLocal_fst Γ C n
            cases hS : checkNodeStepLocal Γ C n with
            | error e =>
                cases hTS : tracedCheckNodeStepLocal Γ C n with
                | mk sr sl =>
                    rw [hTS] at hStep; dsimp at hStep; subst hStep
                    rw [hS]
            | ok u =>
                cases hTS : tracedCheckNodeStepLocal Γ C n with
                | mk sr sl =>
                    rw [hTS] at hStep; dsimp at hStep; subst hStep
                    rw [hS]; dsimp only
                    have hPars := tracedVerifyParentsAux_fst (run := tracedVerifyNodeFuel f Γ C)
                      C n.topoRank (extractStepFootprint n.step).parentNodeRefs
                    have hFunEq : (fun p => (tracedVerifyNodeFuel f Γ C p).1) =
                        verifyNodeFuel f Γ C := by
                      funext p
                      exact tracedVerifyNodeFuel_eq_frozen f Γ C p
                    rw [hFunEq] at hPars
                    cases hTP : tracedVerifyParentsAux (tracedVerifyNodeFuel f Γ C) C n.topoRank
                        (extractStepFootprint n.step).parentNodeRefs with
                    | mk pr pl =>
                        rw [hTP] at hPars; dsimp at hPars; subst hPars; dsimp only
                        cases verifyParentsAux (verifyNodeFuel f Γ C) C n.topoRank
                            (extractStepFootprint n.step).parentNodeRefs with
                        | error _ => rfl
                        | ok opt =>
                            cases opt with
                            | some _ => rfl
                            | none   => rfl

/-- **Exact Behavioral Equivalence Theorem**:
    `verifyMultiRootTraced` computes the EXACT same verdict list as mapping frozen `P1B2A`'s
    `verifyReachableDerivation` over `roots` for ALL inputs `(fuel, Γ, C, roots)`! -/
theorem verifyMultiRootTraced_eq_frozen (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) :
    ∀ roots : List String,
      (verifyMultiRootTraced fuel Γ C roots).1 = roots.map (verifyReachableDerivation fuel Γ C)
  | []      => rfl
  | r :: rs => by
      dsimp only [verifyMultiRootTraced, List.map]
      rw [tracedVerifyNodeFuel_eq_frozen, verifyMultiRootTraced_eq_frozen fuel Γ C rs]

/-! ### 5. Proof of `ActualLookupConfinement` & `OutputCongruence` + Separation (`A0-GUARD-01`) -/

private theorem logConfined_singleGuardWf (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (prefixGuards : List StrictForm)
    (γ : StrictForm) (wf : GuardWfWitness) {keepN keepP : List String}
    (hP : ∀ pid ∈ (extractSingleGuardWfFootprint wf).primRefs, pid ∈ keepP)
    (hN : ∀ nid ∈ (extractSingleGuardWfFootprint wf).parentNodeRefs, nid ∈ keepN) :
    LogConfinedTo keepN keepP
      (tracedCheckSingleGuardWf domTag specId curRank Γ C prefixGuards γ wf).2 := by
  cases wf with
  | totalPolyWf            => exact logConfined_empty keepN keepP
  | prefixGuardDenomWf _   => exact logConfined_empty keepN keepP
  | domainIntrinsicNonzero => exact logConfined_empty keepN keepP
  | externalPremiseDenomWf pid _ =>
      constructor
      · intro _ h; nomatch h
      · intro p hp
        rcases List.mem_cons.mp hp with rfl | hNil
        · exact hP p (List.mem_cons_self ..)
        · nomatch hNil
  | parentNodeDenomWf nid _ =>
      constructor
      · intro u hu
        rcases List.mem_cons.mp hu with rfl | hNil
        · exact hN u (List.mem_cons_self ..)
        · nomatch hNil
      · intro _ h; nomatch h

private theorem logConfined_guardsPrefixAux (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) {keepN keepP : List String} :
    ∀ (prefixGuards gs : List StrictForm) (wfs : List GuardWfWitness),
      (∀ pid ∈ (extractGuardWfFootprint wfs).primRefs, pid ∈ keepP) →
      (∀ nid ∈ (extractGuardWfFootprint wfs).parentNodeRefs, nid ∈ keepN) →
      LogConfinedTo keepN keepP
        (tracedCheckGuardsPrefixAux domTag specId curRank Γ C prefixGuards gs wfs).2
  | _, [],      [],        _,  _  => logConfined_empty keepN keepP
  | _, [],      _ :: _,    _,  _  => logConfined_empty keepN keepP
  | _, _ :: _,  [],        _,  _  => logConfined_empty keepN keepP
  | prefixGuards, γ :: γs, wf :: wfs, hP, hN => by
      dsimp only [tracedCheckGuardsPrefixAux]
      apply logConfined_tracedAnd
      · exact logConfined_singleGuardWf domTag specId curRank Γ C prefixGuards γ wf
          (fun p hp => hP p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
          (fun u hu => hN u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))
      · intro _
        exact logConfined_guardsPrefixAux domTag specId curRank Γ C (prefixGuards ++ [γ]) γs wfs
          (fun p hp => hP p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
          (fun u hu => hN u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))

private theorem logConfined_guardCtx (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (ctx : GuardContextEvidence)
    {keepN keepP : List String}
    (hP : ∀ pid ∈ (extractGuardCtxFootprint ctx).primRefs, pid ∈ keepP)
    (hN : ∀ nid ∈ (extractGuardCtxFootprint ctx).parentNodeRefs, nid ∈ keepN) :
    LogConfinedTo keepN keepP (tracedCheckGuardCtx domTag specId curRank Γ C ctx).2 := by
  cases ctx with
  | selfContainedCtx => exact logConfined_empty keepN keepP
  | citedPremiseCtx pids =>
      dsimp only [tracedCheckGuardCtx]
      apply logConfined_tracedAnd (logConfined_empty keepN keepP)
      intro _
      apply logConfined_tracedAll
      intro pid hpMem
      constructor
      · intro _ h; nomatch h
      · intro q hq
        rcases List.mem_cons.mp hq with rfl | hNil
        · exact hP q ((mem_canonSortStrs pids q).mpr hpMem)
        · nomatch hNil
  | citedParentNodeCtx nids =>
      dsimp only [tracedCheckGuardCtx]
      apply logConfined_tracedAnd (logConfined_empty keepN keepP)
      intro _
      apply logConfined_tracedAll
      intro nid hnMem
      constructor
      · intro u hu
        rcases List.mem_cons.mp hu with rfl | hNil
        · exact hN u ((mem_canonSortStrs nids u).mpr hnMem)
        · nomatch hNil
      · intro _ h; nomatch h

private theorem logConfined_localDeriv (domTag : G7DomTag) (specId : String) (curRank : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (guards : List StrictForm)
    {keepN keepP : List String} :
    ∀ (d : LocalDeriv) (expectedGoal : StrictForm),
      (∀ pid ∈ (extractDerivFootprint d).primRefs, pid ∈ keepP) →
      (∀ nid ∈ (extractDerivFootprint d).parentNodeRefs, nid ∈ keepN) →
      LogConfinedTo keepN keepP
        (tracedCheckLocalDeriv domTag specId curRank Γ C guards d expectedGoal).2
  | .hypGuard _ _, _, _, _ => logConfined_empty keepN keepP
  | .primPrem pid _, _, hP, _ => by
      dsimp only [tracedCheckLocalDeriv]
      apply logConfined_tracedAnd (logConfined_empty keepN keepP)
      intro _
      constructor
      · intro _ h; nomatch h
      · intro q hq
        rcases List.mem_cons.mp hq with rfl | hNil
        · exact hP q (List.mem_cons_self ..)
        · nomatch hNil
  | .parentRef nid _, _, _, hN => by
      dsimp only [tracedCheckLocalDeriv]
      apply logConfined_tracedAnd (logConfined_empty keepN keepP)
      intro _
      constructor
      · intro u hu
        rcases List.mem_cons.mp hu with rfl | hNil
        · exact hN u (List.mem_cons_self ..)
        · nomatch hNil
      · intro _ h; nomatch h
  | .certStep _ _, _, _, _ => logConfined_empty keepN keepP
  | .strictMP φ ψ d1 d2, _, hP, hN => by
      dsimp only [tracedCheckLocalDeriv]
      apply logConfined_tracedAnd
      · apply logConfined_tracedAnd (logConfined_empty keepN keepP)
        intro _
        exact logConfined_localDeriv domTag specId curRank Γ C guards d1 φ
          (fun p hp => hP p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
          (fun u hu => hN u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))
      · intro _
        exact logConfined_localDeriv domTag specId curRank Γ C guards d2 (.impStrict φ ψ)
          (fun p hp => hP p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
          (fun u hu => hN u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))
  | .conjIntro φ ψ d1 d2, _, hP, hN => by
      dsimp only [tracedCheckLocalDeriv]
      apply logConfined_tracedAnd
      · apply logConfined_tracedAnd (logConfined_empty keepN keepP)
        intro _
        exact logConfined_localDeriv domTag specId curRank Γ C guards d1 φ
          (fun p hp => hP p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
          (fun u hu => hN u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))
      · intro _
        exact logConfined_localDeriv domTag specId curRank Γ C guards d2 ψ
          (fun p hp => hP p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
          (fun u hu => hN u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))

private theorem logConfined_nodeStepLocal (Γ : PrimPremiseEnv) (C : G7DagContainer) (n : G7DagNode)
    {keepN keepP : List String}
    (hP : ∀ pid ∈ (extractStepFootprint n.step).primRefs, pid ∈ keepP)
    (hN : ∀ nid ∈ (extractStepFootprint n.step).parentNodeRefs, nid ∈ keepN) :
    LogConfinedTo keepN keepP (tracedCheckNodeStepLocal Γ C n).2 := by
  cases hs : n.step with
  | directDerivStep d =>
      unfold tracedCheckNodeStepLocal
      rw [hs]; dsimp only
      rw [hs] at hP hN
      split
      · exact logConfined_empty keepN keepP
      · exact logConfined_localDeriv n.domTag n.specId n.topoRank Γ C [] d n.conclusion hP hN
  | guardedDomStep cert =>
      unfold tracedCheckNodeStepLocal
      rw [hs]; dsimp only
      rw [hs] at hP hN
      have hConfWf := logConfined_guardsPrefixAux cert.domTag n.specId n.topoRank Γ C
        [] cert.guards cert.guardWfCerts
        (fun p hp => hP p ((mem_unionFootprint_prim _ _ p).mpr
          (Or.inr ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))))
        (fun u hu => hN u ((mem_unionFootprint_parent _ _ u).mpr
          (Or.inr ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))))
      have hConfCtx := logConfined_guardCtx cert.domTag n.specId n.topoRank Γ C
        cert.guardContextEvidence
        (fun p hp => hP p ((mem_unionFootprint_prim _ _ p).mpr
          (Or.inr ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))))
        (fun u hu => hN u ((mem_unionFootprint_parent _ _ u).mpr
          (Or.inr ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))))
      have hConfGoal := logConfined_localDeriv cert.domTag n.specId n.topoRank Γ C
        cert.guards cert.goalDeriv cert.goalForm
        (fun p hp => hP p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
        (fun u hu => hN u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))
      split
      · exact logConfined_empty keepN keepP
      · split
        · exact hConfWf
        · split
          · exact logConfined_append hConfWf hConfCtx
          · exact logConfined_append (logConfined_append hConfWf hConfCtx) hConfGoal

private theorem logConfined_parentsAux {run : String → G7CheckResult × QueryAuditLog}
    {C : G7DagContainer} {childRank : Nat} {keepN keepP : List String} :
    ∀ (pars : List String),
      (∀ p ∈ pars, p ∈ keepN ∧ LogConfinedTo keepN keepP (run p).2) →
      LogConfinedTo keepN keepP (tracedVerifyParentsAux run C childRank pars).2
  | [], _ => logConfined_empty keepN keepP
  | parId :: rest, hPars => by
      have hHead := hPars parId (List.mem_cons_self ..)
      have hLookConf : LogConfinedTo keepN keepP (tracedLookupNode C parId).2 := by
        constructor
        · intro u hu
          rcases List.mem_cons.mp hu with rfl | hNil
          · exact hHead.1
          · nomatch hNil
        · intro _ h; nomatch h
      dsimp only [tracedVerifyParentsAux, tracedLookupNode] at hLookConf ⊢
      cases hL : lookupDagNode? C parId with
      | none => exact hLookConf
      | some par =>
          dsimp only
          split
          · exact hLookConf
          · cases hR : run parId with
            | mk rVal rLog =>
                have hHeadLog : LogConfinedTo keepN keepP rLog := by
                  have h := hHead.2; rw [hR] at h; exact h
                have h1 := logConfined_append hLookConf hHeadLog
                cases rVal with
                | rejectInvalid _ => exact h1
                | resourceHeld _  => exact h1
                | accept _        =>
                    exact logConfined_append h1
                      (logConfined_parentsAux rest (fun q hq => hPars q (List.mem_cons_of_mem parId hq)))

private theorem singleRoot_actualLookupConfinement (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (rootId : String) (hVal : ValidContainer C) (fuel : Nat) :
    LogConfinedTo (extractReachableNodeIds C rootId)
      (extractTransitivePrimDeps Γ C rootId)
      (tracedVerifyNodeFuel fuel Γ C rootId).2 := by
  let reachN := extractReachableNodeIds C rootId
  let depsP  := extractTransitivePrimDeps Γ C rootId
  have hAux : ∀ (f : Nat) (nid : String),
      (∃ k : Nat, k ≤ maxTopoRank C + 1 ∧ nid ∈ transNodeIter k C [rootId] ∧
        (∀ n : G7DagNode, lookupDagNode? C nid = some n → k + n.topoRank ≤ maxTopoRank C)) →
      LogConfinedTo reachN depsP (tracedVerifyNodeFuel f Γ C nid).2 := by
    intro f
    induction f with
    | zero => intro _ _; exact logConfined_empty reachN depsP
    | succ f' ih =>
        intro nid ⟨k, hkLe, hIter, hRankBound⟩
        have hInReach : nid ∈ reachN := by
          show nid ∈ extractReachableNodeIds C rootId
          unfold extractReachableNodeIds
          rw [mem_canonSortStrs]
          exact mem_transNodeIter_le_a0 C [rootId] hkLe hIter
        have hRootConf : LogConfinedTo reachN depsP (tracedLookupNode C nid).2 := by
          constructor
          · intro u hu
            rcases List.mem_cons.mp hu with rfl | hNil
            · exact hInReach
            · nomatch hNil
          · intro _ h; nomatch h
        dsimp only [tracedVerifyNodeFuel, tracedLookupNode] at hRootConf ⊢
        cases hLook : lookupDagNode? C nid with
        | none => exact hRootConf
        | some n =>
            dsimp only
            split
            · exact hRootConf
            · have hParInReach : ∀ parId ∈ (extractStepFootprint n.step).parentNodeRefs,
                  parId ∈ reachN ∧
                  ∃ k' : Nat, k' ≤ maxTopoRank C + 1 ∧ parId ∈ transNodeIter k' C [rootId] ∧
                    (∀ par' : G7DagNode, lookupDagNode? C parId = some par' →
                      k' + par'.topoRank ≤ maxTopoRank C) := by
                intro parId hPar
                rcases validContainer_parent_rank_a0 hVal hLook hPar with ⟨par, hLookPar, hLt⟩
                have hnb := hRankBound n hLook
                have hk1Le : k + 1 ≤ maxTopoRank C + 1 := by omega
                have hParIter : parId ∈ transNodeIter (k + 1) C [rootId] :=
                  parent_mem_expandNodeStep_a0 C (transNodeIter k C [rootId]) hIter hLook hPar
                have hpReach : parId ∈ reachN := by
                  show parId ∈ extractReachableNodeIds C rootId
                  unfold extractReachableNodeIds
                  rw [mem_canonSortStrs]
                  exact mem_transNodeIter_le_a0 C [rootId] hk1Le hParIter
                refine ⟨hpReach, k + 1, hk1Le, hParIter, ?_⟩
                intro par' hLookPar'
                rw [hLookPar] at hLookPar'
                injection hLookPar' with hpEq; subst hpEq
                omega
              have hStepConf : LogConfinedTo reachN depsP (tracedCheckNodeStepLocal Γ C n).2 := by
                apply logConfined_nodeStepLocal
                · intro pid hp
                  have hDir : pid ∈ collectDirectPrimRefsOfNodes C reachN :=
                    prim_mem_collectDirectPrimRefs_a0 C reachN hInReach hLook hp
                  exact direct_mem_depsStarCanon (toPremDag Γ) _ hDir
                · intro parId hPar
                  exact (hParInReach parId hPar).1
              cases hTS : tracedCheckNodeStepLocal Γ C n with
              | mk stepVal stepLog =>
                  have hStepLog : LogConfinedTo reachN depsP stepLog := by
                    rw [hTS] at hStepConf; exact hStepConf
                  have h1 := logConfined_append hRootConf hStepLog
                  cases stepVal with
                  | error _ => exact h1
                  | ok _ =>
                      have hParsConf : LogConfinedTo reachN depsP
                          (tracedVerifyParentsAux (tracedVerifyNodeFuel f' Γ C) C n.topoRank
                            (extractStepFootprint n.step).parentNodeRefs).2 := by
                        apply logConfined_parentsAux
                        intro parId hPar
                        rcases hParInReach parId hPar with ⟨hpR, hWitness⟩
                        exact ⟨hpR, ih parId hWitness⟩
                      cases hTP : tracedVerifyParentsAux (tracedVerifyNodeFuel f' Γ C) C n.topoRank
                          (extractStepFootprint n.step).parentNodeRefs with
                      | mk parVal parLog =>
                          have hParLog : LogConfinedTo reachN depsP parLog := by
                            rw [hTP] at hParsConf; exact hParsConf
                          have hAll := logConfined_append h1 hParLog
                          cases parVal with
                          | error _ => exact hAll
                          | ok opt  =>
                              cases opt with
                              | some _ => exact hAll
                              | none   => exact hAll
  exact hAux fuel rootId ⟨0, Nat.zero_le _, List.mem_cons_self ..,
    fun n hL => by rw [Nat.zero_add]; exact topoRank_le_maxTopoRank_a0 (List.mem_of_find?_eq_some hL)⟩

/-- **`A0-05.2` (`A0_05_2_ActualLookupConfinement` — `A0-GUARD-01`)**:
    Under `ValidContainer C`, EVERY node ID and EVERY primitive premise ID ever passed to a
    lookup primitive during `verifyMultiRootTraced fuel Γ C roots` (even if its return value is
    subsequently unused/discarded) lies strictly inside `(multiRootReachableNodes C roots,
    multiRootTransitivePrimDeps Γ C roots)`! -/
theorem A0_05_2_ActualLookupConfinement (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (roots : List String) (hVal : ValidContainer C) :
    LogConfinedTo (multiRootReachableNodes C roots)
      (multiRootTransitivePrimDeps Γ C roots)
      (verifyMultiRootTraced fuel Γ C roots).2 := by
  have hSub : ∀ rs : List String, (∀ r ∈ rs, r ∈ roots) →
      LogConfinedTo (multiRootReachableNodes C roots)
        (multiRootTransitivePrimDeps Γ C roots)
        (verifyMultiRootTraced fuel Γ C rs).2 := by
    intro rs
    induction rs with
    | nil => intro _; exact logConfined_empty _ _
    | cons r tail ih =>
        intro hSubR
        have hrMem : r ∈ roots := hSubR r (List.mem_cons_self ..)
        have hSingle := singleRoot_actualLookupConfinement Γ C r hVal fuel
        have hLiftSingle : LogConfinedTo (multiRootReachableNodes C roots)
            (multiRootTransitivePrimDeps Γ C roots)
            (tracedVerifyNodeFuel fuel Γ C r).2 :=
          ⟨fun nid hn => mem_multiRootReachableNodes C hrMem (hSingle.1 nid hn),
           fun pid hp => mem_multiRootTransitivePrimDeps Γ C hrMem (hSingle.2 pid hp)⟩
        dsimp only [verifyMultiRootTraced]
        exact logConfined_append hLiftSingle
          (ih (fun u hu => hSubR u (List.mem_cons_of_mem r hu)))
  exact hSub roots (fun r hr => hr)

/-! ### 6. Two-Container Congruence (`OutputCongruence`), `RestrictionInvariance`, & `SemanticDependencyClosure` -/

private theorem tracedSingleGuardWf_congr (domTag : G7DomTag) (specId : String) (curRank : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    (prefixGuards : List StrictForm) (γ : StrictForm) (wf : GuardWfWitness)
    (hPrim : ∀ pid ∈ (extractSingleGuardWfFootprint wf).primRefs,
      lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid)
    (hNode : ∀ nid ∈ (extractSingleGuardWfFootprint wf).parentNodeRefs,
      lookupDagNode? C1 nid = lookupDagNode? C2 nid) :
    tracedCheckSingleGuardWf domTag specId curRank Γ1 C1 prefixGuards γ wf =
    tracedCheckSingleGuardWf domTag specId curRank Γ2 C2 prefixGuards γ wf := by
  cases wf with
  | totalPolyWf            => rfl
  | prefixGuardDenomWf _   => rfl
  | domainIntrinsicNonzero => rfl
  | externalPremiseDenomWf pid _ =>
      dsimp only [tracedCheckSingleGuardWf, tracedLookupPrim]
      rw [hPrim pid (List.mem_cons_self ..)]
  | parentNodeDenomWf nid _ =>
      dsimp only [tracedCheckSingleGuardWf, tracedLookupNode]
      rw [hNode nid (List.mem_cons_self ..)]

private theorem tracedGuardsPrefixAux_congr (domTag : G7DomTag) (specId : String) (curRank : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} :
    ∀ (prefixGuards gs : List StrictForm) (wfs : List GuardWfWitness),
      (∀ pid ∈ (extractGuardWfFootprint wfs).primRefs,
        lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) →
      (∀ nid ∈ (extractGuardWfFootprint wfs).parentNodeRefs,
        lookupDagNode? C1 nid = lookupDagNode? C2 nid) →
      tracedCheckGuardsPrefixAux domTag specId curRank Γ1 C1 prefixGuards gs wfs =
      tracedCheckGuardsPrefixAux domTag specId curRank Γ2 C2 prefixGuards gs wfs
  | _, [],      [],        _,     _     => rfl
  | _, [],      _ :: _,    _,     _     => rfl
  | _, _ :: _,  [],        _,     _     => rfl
  | prefixGuards, γ :: γs, wf :: wfs, hPrim, hNode => by
      dsimp only [tracedCheckGuardsPrefixAux]
      rw [tracedSingleGuardWf_congr domTag specId curRank prefixGuards γ wf
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
            (fun u hu => hNode u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu))),
          tracedGuardsPrefixAux_congr domTag specId curRank (prefixGuards ++ [γ]) γs wfs
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
            (fun u hu => hNode u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))]

private theorem tracedAll_congr {α : Type} {f1 f2 : α → Bool × QueryAuditLog} :
    ∀ (L : List α), (∀ x ∈ L, f1 x = f2 x) → tracedAll f1 L = tracedAll f2 L
  | [], _ => rfl
  | x :: xs, hEq => by
      dsimp only [tracedAll]
      rw [hEq x (List.mem_cons_self ..),
          tracedAll_congr xs (fun y hy => hEq y (List.mem_cons_of_mem x hy))]

private theorem tracedGuardCtx_congr (domTag : G7DomTag) (specId : String) (curRank : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (ctx : GuardContextEvidence)
    (hPrim : ∀ pid ∈ (extractGuardCtxFootprint ctx).primRefs,
      lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid)
    (hNode : ∀ nid ∈ (extractGuardCtxFootprint ctx).parentNodeRefs,
      lookupDagNode? C1 nid = lookupDagNode? C2 nid) :
    tracedCheckGuardCtx domTag specId curRank Γ1 C1 ctx =
    tracedCheckGuardCtx domTag specId curRank Γ2 C2 ctx := by
  cases ctx with
  | selfContainedCtx => rfl
  | citedPremiseCtx pids =>
      dsimp only [tracedCheckGuardCtx]
      have hAllEq : tracedAll (fun pid =>
          let (optPe, log) := tracedLookupPrim Γ1 pid
          let ok := match optPe with
            | some pe => (pe.domTag == domTag) && (pe.specId == specId) &&
                         checkFormDefUnderNzBool [] pe.formula
            | none    => false
          (ok, log)) pids =
        tracedAll (fun pid =>
          let (optPe, log) := tracedLookupPrim Γ2 pid
          let ok := match optPe with
            | some pe => (pe.domTag == domTag) && (pe.specId == specId) &&
                         checkFormDefUnderNzBool [] pe.formula
            | none    => false
          (ok, log)) pids := by
        apply tracedAll_congr
        intro pid hpMem
        dsimp only [tracedLookupPrim]
        rw [hPrim pid ((mem_canonSortStrs pids pid).mpr hpMem)]
      rw [hAllEq]
  | citedParentNodeCtx nids =>
      dsimp only [tracedCheckGuardCtx]
      have hAllEq : tracedAll (fun nid =>
          let (optPar, log) := tracedLookupNode C1 nid
          let ok := match optPar with
            | some par => decide (par.topoRank < curRank) && (par.domTag == domTag) &&
                          (par.specId == specId) && (par.guards == [])
            | none     => false
          (ok, log)) nids =
        tracedAll (fun nid =>
          let (optPar, log) := tracedLookupNode C2 nid
          let ok := match optPar with
            | some par => decide (par.topoRank < curRank) && (par.domTag == domTag) &&
                          (par.specId == specId) && (par.guards == [])
            | none     => false
          (ok, log)) nids := by
        apply tracedAll_congr
        intro nid hnMem
        dsimp only [tracedLookupNode]
        rw [hNode nid ((mem_canonSortStrs nids nid).mpr hnMem)]
      rw [hAllEq]

private theorem tracedLocalDeriv_congr (domTag : G7DomTag) (specId : String) (curRank : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (guards : List StrictForm) :
    ∀ (d : LocalDeriv) (expectedGoal : StrictForm),
      (∀ pid ∈ (extractDerivFootprint d).primRefs,
        lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) →
      (∀ nid ∈ (extractDerivFootprint d).parentNodeRefs,
        lookupDagNode? C1 nid = lookupDagNode? C2 nid) →
      tracedCheckLocalDeriv domTag specId curRank Γ1 C1 guards d expectedGoal =
      tracedCheckLocalDeriv domTag specId curRank Γ2 C2 guards d expectedGoal
  | .hypGuard _ _, _, _, _ => rfl
  | .primPrem pid _, _, hPrim, _ => by
      dsimp only [tracedCheckLocalDeriv, tracedLookupPrim]
      rw [hPrim pid (List.mem_cons_self ..)]
  | .parentRef nid _, _, _, hNode => by
      dsimp only [tracedCheckLocalDeriv, tracedLookupNode]
      rw [hNode nid (List.mem_cons_self ..)]
  | .certStep _ _, _, _, _ => rfl
  | .strictMP φ ψ d1 d2, _, hPrim, hNode => by
      dsimp only [tracedCheckLocalDeriv]
      rw [tracedLocalDeriv_congr domTag specId curRank guards d1 φ
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
            (fun u hu => hNode u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu))),
          tracedLocalDeriv_congr domTag specId curRank guards d2 (.impStrict φ ψ)
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
            (fun u hu => hNode u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))]
  | .conjIntro φ ψ d1 d2, _, hPrim, hNode => by
      dsimp only [tracedCheckLocalDeriv]
      rw [tracedLocalDeriv_congr domTag specId curRank guards d1 φ
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
            (fun u hu => hNode u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu))),
          tracedLocalDeriv_congr domTag specId curRank guards d2 ψ
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))
            (fun u hu => hNode u ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu)))]

private theorem tracedNodeStepLocal_congr {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer}
    (n : G7DagNode)
    (hPrim : ∀ pid ∈ (extractStepFootprint n.step).primRefs,
      lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid)
    (hNode : ∀ nid ∈ (extractStepFootprint n.step).parentNodeRefs,
      lookupDagNode? C1 nid = lookupDagNode? C2 nid) :
    tracedCheckNodeStepLocal Γ1 C1 n = tracedCheckNodeStepLocal Γ2 C2 n := by
  cases hs : n.step with
  | directDerivStep d =>
      unfold tracedCheckNodeStepLocal
      rw [hs]; dsimp only
      rw [hs] at hPrim hNode
      rw [tracedLocalDeriv_congr n.domTag n.specId n.topoRank [] d n.conclusion hPrim hNode]
  | guardedDomStep cert =>
      unfold tracedCheckNodeStepLocal
      rw [hs]; dsimp only
      rw [hs] at hPrim hNode
      rw [tracedGuardsPrefixAux_congr cert.domTag n.specId n.topoRank [] cert.guards cert.guardWfCerts
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr
              (Or.inr ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))))
            (fun u hu => hNode u ((mem_unionFootprint_parent _ _ u).mpr
              (Or.inr ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu))))),
          tracedGuardCtx_congr cert.domTag n.specId n.topoRank cert.guardContextEvidence
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr
              (Or.inr ((mem_unionFootprint_prim _ _ p).mpr (Or.inr hp)))))
            (fun u hu => hNode u ((mem_unionFootprint_parent _ _ u).mpr
              (Or.inr ((mem_unionFootprint_parent _ _ u).mpr (Or.inr hu))))),
          tracedLocalDeriv_congr cert.domTag n.specId n.topoRank cert.guards cert.goalDeriv cert.goalForm
            (fun p hp => hPrim p ((mem_unionFootprint_prim _ _ p).mpr (Or.inl hp)))
            (fun u hu => hNode u ((mem_unionFootprint_parent _ _ u).mpr (Or.inl hu)))]

private theorem tracedVerifyParentsAux_congr {run1 run2 : String → G7CheckResult × QueryAuditLog}
    {C1 C2 : G7DagContainer} (childRank : Nat) :
    ∀ (pars : List String),
      (∀ p ∈ pars, lookupDagNode? C1 p = lookupDagNode? C2 p ∧ run1 p = run2 p) →
      tracedVerifyParentsAux run1 C1 childRank pars =
      tracedVerifyParentsAux run2 C2 childRank pars
  | [], _ => rfl
  | parId :: rest, hEq => by
      have hHead := hEq parId (List.mem_cons_self ..)
      have hTail := tracedVerifyParentsAux_congr childRank rest
        (fun p hp => hEq p (List.mem_cons_of_mem parId hp))
      dsimp only [tracedVerifyParentsAux, tracedLookupNode]
      rw [hHead.1]
      cases lookupDagNode? C2 parId with
      | none => rfl
      | some par =>
          dsimp only
          split
          · rfl
          · rw [hHead.2]
            cases (run2 parId).1 with
            | rejectInvalid _ => rfl
            | resourceHeld _  => rfl
            | accept _        => rw [hTail]

private theorem singleRoot_traced_congr (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (rootId : String)
    (hVal1 : ValidContainer C1)
    (hNodeEq : ∀ nid ∈ extractReachableNodeIds C1 rootId,
      lookupDagNode? C1 nid = lookupDagNode? C2 nid)
    (hPrimEq : ∀ pid ∈ extractTransitivePrimDeps Γ1 C1 rootId,
      lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) :
    tracedVerifyNodeFuel fuel Γ1 C1 rootId = tracedVerifyNodeFuel fuel Γ2 C2 rootId := by
  let reachN := extractReachableNodeIds C1 rootId
  let depsP  := extractTransitivePrimDeps Γ1 C1 rootId
  have hAux : ∀ (f : Nat) (nid : String),
      (∃ k : Nat, k ≤ maxTopoRank C1 + 1 ∧ nid ∈ transNodeIter k C1 [rootId] ∧
        (∀ n : G7DagNode, lookupDagNode? C1 nid = some n → k + n.topoRank ≤ maxTopoRank C1)) →
      tracedVerifyNodeFuel f Γ1 C1 nid = tracedVerifyNodeFuel f Γ2 C2 nid := by
    intro f
    induction f with
    | zero => intro _ _; rfl
    | succ f' ih =>
        intro nid ⟨k, hkLe, hIter, hRankBound⟩
        have hInReach : nid ∈ reachN := by
          show nid ∈ extractReachableNodeIds C1 rootId
          unfold extractReachableNodeIds
          rw [mem_canonSortStrs]
          exact mem_transNodeIter_le_a0 C1 [rootId] hkLe hIter
        have hLookEq : lookupDagNode? C1 nid = lookupDagNode? C2 nid := hNodeEq nid hInReach
        dsimp only [tracedVerifyNodeFuel, tracedLookupNode]
        rw [← hLookEq]
        cases hLook1 : lookupDagNode? C1 nid with
        | none => rfl
        | some n =>
            dsimp only
            split
            · rfl
            · have hParInfo : ∀ parId ∈ (extractStepFootprint n.step).parentNodeRefs,
                  parId ∈ reachN ∧
                  ∃ k' : Nat, k' ≤ maxTopoRank C1 + 1 ∧ parId ∈ transNodeIter k' C1 [rootId] ∧
                    (∀ par' : G7DagNode, lookupDagNode? C1 parId = some par' →
                      k' + par'.topoRank ≤ maxTopoRank C1) := by
                intro parId hPar
                rcases validContainer_parent_rank_a0 hVal1 hLook1 hPar with ⟨par, hLookPar, hLt⟩
                have hnb := hRankBound n hLook1
                have hk1Le : k + 1 ≤ maxTopoRank C1 + 1 := by omega
                have hParIter : parId ∈ transNodeIter (k + 1) C1 [rootId] :=
                  parent_mem_expandNodeStep_a0 C1 (transNodeIter k C1 [rootId]) hIter hLook1 hPar
                have hpReach : parId ∈ reachN := by
                  show parId ∈ extractReachableNodeIds C1 rootId
                  unfold extractReachableNodeIds
                  rw [mem_canonSortStrs]
                  exact mem_transNodeIter_le_a0 C1 [rootId] hk1Le hParIter
                refine ⟨hpReach, k + 1, hk1Le, hParIter, ?_⟩
                intro par' hLookPar'
                rw [hLookPar] at hLookPar'
                injection hLookPar' with hpEq; subst hpEq
                omega
              have hStepEq : tracedCheckNodeStepLocal Γ1 C1 n = tracedCheckNodeStepLocal Γ2 C2 n := by
                apply tracedNodeStepLocal_congr
                · intro pid hp
                  have hDir : pid ∈ collectDirectPrimRefsOfNodes C1 reachN :=
                    prim_mem_collectDirectPrimRefs_a0 C1 reachN hInReach hLook1 hp
                  exact hPrimEq pid (direct_mem_depsStarCanon (toPremDag Γ1) _ hDir)
                · intro parId hPar
                  exact hNodeEq parId (hParInfo parId hPar).1
              rw [hStepEq]
              cases (tracedCheckNodeStepLocal Γ2 C2 n).1 with
              | error _ => rfl
              | ok _ =>
                  have hParsEq :
                      tracedVerifyParentsAux (tracedVerifyNodeFuel f' Γ1 C1) C1 n.topoRank
                        (extractStepFootprint n.step).parentNodeRefs =
                      tracedVerifyParentsAux (tracedVerifyNodeFuel f' Γ2 C2) C2 n.topoRank
                        (extractStepFootprint n.step).parentNodeRefs := by
                    apply tracedVerifyParentsAux_congr n.topoRank
                    intro parId hPar
                    rcases hParInfo parId hPar with ⟨hpR, hWit⟩
                    exact ⟨hNodeEq parId hpR, ih parId hWit⟩
                  rw [hParsEq]
  exact hAux fuel rootId ⟨0, Nat.zero_le _, List.mem_cons_self ..,
    fun n hL => by rw [Nat.zero_add]; exact topoRank_le_maxTopoRank_a0 (List.mem_of_find?_eq_some hL)⟩

/-- Full traced two-container congruence across `roots`. -/
theorem verifyMultiRootTraced_congr (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (roots : List String)
    (hVal1 : ValidContainer C1)
    (hNodeEq : ∀ nid ∈ multiRootReachableNodes C1 roots,
      lookupDagNode? C1 nid = lookupDagNode? C2 nid)
    (hPrimEq : ∀ pid ∈ multiRootTransitivePrimDeps Γ1 C1 roots,
      lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) :
    verifyMultiRootTraced fuel Γ1 C1 roots = verifyMultiRootTraced fuel Γ2 C2 roots := by
  have hSub : ∀ rs : List String, (∀ r ∈ rs, r ∈ roots) →
      verifyMultiRootTraced fuel Γ1 C1 rs = verifyMultiRootTraced fuel Γ2 C2 rs := by
    intro rs
    induction rs with
    | nil => intro _; rfl
    | cons r tail ih =>
        intro hSubR
        have hrMem : r ∈ roots := hSubR r (List.mem_cons_self ..)
        dsimp only [verifyMultiRootTraced]
        rw [singleRoot_traced_congr fuel r hVal1
              (fun nid hn => hNodeEq nid (mem_multiRootReachableNodes C1 hrMem hn))
              (fun pid hp => hPrimEq pid (mem_multiRootTransitivePrimDeps Γ1 C1 hrMem hp)),
            ih (fun u hu => hSubR u (List.mem_cons_of_mem r hu))]
  exact hSub roots (fun r hr => hr)

/-- **`A0-05.1` (`A0_05_1_OutputCongruence` — `A0-GUARD-01`)**:
    Any two environments `(Γ₁, C₁)` and `(Γ₂, C₂)` agreeing on `(P*(Γ₁, C₁, roots), R*(C₁, roots))`
    produce IDENTICAL multi-root `verifyReachableDerivation` outputs! -/
theorem A0_05_1_OutputCongruence (fuel : Nat)
    {Γ1 Γ2 : PrimPremiseEnv} {C1 C2 : G7DagContainer} (roots : List String)
    (hVal1 : ValidContainer C1)
    (hNodeEq : ∀ nid ∈ multiRootReachableNodes C1 roots,
      lookupDagNode? C1 nid = lookupDagNode? C2 nid)
    (hPrimEq : ∀ pid ∈ multiRootTransitivePrimDeps Γ1 C1 roots,
      lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) :
    roots.map (verifyReachableDerivation fuel Γ1 C1) =
    roots.map (verifyReachableDerivation fuel Γ2 C2) := by
  rw [← verifyMultiRootTraced_eq_frozen, ← verifyMultiRootTraced_eq_frozen,
      verifyMultiRootTraced_congr fuel roots hVal1 hNodeEq hPrimEq]

/-- **`A0-05.3` (`A0_05_3_RestrictionInvariance` — `A0-GUARD-01`)**:
    Under `ValidContainer C`, restricting `(Γ, C)` to `(restrictPrimEnv Γ P*, restrictContainer C R*)`
    preserves BOTH the multi-root verdicts AND the exact runtime query audit trace! -/
theorem A0_05_3_RestrictionInvariance (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (roots : List String) (hVal : ValidContainer C) :
    let RStar := multiRootReachableNodes C roots
    let PStar := multiRootTransitivePrimDeps Γ C roots
    verifyMultiRootTraced fuel (restrictPrimEnv Γ PStar) (restrictContainer C RStar) roots =
    verifyMultiRootTraced fuel Γ C roots ∧
    roots.map (verifyReachableDerivation fuel (restrictPrimEnv Γ PStar) (restrictContainer C RStar)) =
    roots.map (verifyReachableDerivation fuel Γ C) := by
  dsimp only
  have hTrEq := (verifyMultiRootTraced_congr fuel (Γ1 := Γ)
    (Γ2 := restrictPrimEnv Γ (multiRootTransitivePrimDeps Γ C roots))
    (C1 := C) (C2 := restrictContainer C (multiRootReachableNodes C roots)) roots hVal
    (fun nid hn => (lookup_restrictContainer_eq_a0 C _ hn).symm)
    (fun pid hp => (lookup_restrictPrimEnv_eq_a0 Γ _ hp).symm)).symm
  refine ⟨hTrEq, ?_⟩
  rw [← verifyMultiRootTraced_eq_frozen, ← verifyMultiRootTraced_eq_frozen, hTrEq]

/-- **`A0-05.4` (`A0_05_4_SemanticDependencyClosure` — `A0-GUARD-01`)**:
    Assuming `SemValidPrimId Γ pid` ONLY for `pid ∈ multiRootTransitivePrimDeps Γ C roots`
    (with ZERO hypothesis on premises outside `P*`), every accepted root `r ∈ roots` satisfies
    `SemValidSequent out`! -/
theorem A0_05_4_SemanticDependencyClosure (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (roots : List String) (hVal : ValidContainer C)
    (hPremClosure : ∀ pid ∈ multiRootTransitivePrimDeps Γ C roots, SemValidPrimId Γ pid) :
    ∀ r ∈ roots, ∀ out : VerifiedSequentOut,
      verifyReachableDerivation fuel Γ C r = .accept out →
      SemValidSequent out := by
  intro r hr out hAcc
  exact verifyReachable_master_sound fuel Γ C r out hVal hAcc
    (fun pid hp => hPremClosure pid (mem_multiRootTransitivePrimDeps Γ C hr hp))

/-! ### 7. Explicit Counterfactual Separation Witnesses (`A0-GUARD-01` Non-Equivalence) -/

/-- Decoy evaluator performing an unused/ignored lookup of `"ghost_outside_closure"` before
    delegating to `verifyMultiRootTraced`. -/
def decoyUnusedLookupEvaluator (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (roots : List String) : List G7CheckResult × QueryAuditLog :=
  let (_ignoredResult, ghostLog) := tracedLookupNode C "ghost_outside_closure"
  let (res, mainLog) := verifyMultiRootTraced fuel Γ C roots
  (res, appendQueryLog ghostLog mainLog)

/-- **`A0-05.2b` (`A0_05_2b_OutputCongruence_DoesNotImply_ActualLookupConfinement`)**:
    Proves constructively that `decoyUnusedLookupEvaluator` satisfies full two-container
    `OutputCongruence` on `.1` (because the outside lookup result is discarded), YET VIOLATES
    `ActualLookupConfinement` on `.2` (`"ghost_outside_closure" ∉ R*`), whereas
    `verifyMultiRootTraced` satisfies BOTH! -/
theorem A0_05_2b_OutputCongruence_DoesNotImply_ActualLookupConfinement :
    -- (1) Decoy satisfies OutputCongruence on .1 identically:
    (∀ (fuel : Nat) (Γ1 Γ2 : PrimPremiseEnv) (C1 C2 : G7DagContainer) (roots : List String),
      ValidContainer C1 →
      (∀ nid ∈ multiRootReachableNodes C1 roots, lookupDagNode? C1 nid = lookupDagNode? C2 nid) →
      (∀ pid ∈ multiRootTransitivePrimDeps Γ1 C1 roots, lookupPrimPrem? Γ1 pid = lookupPrimPrem? Γ2 pid) →
      (decoyUnusedLookupEvaluator fuel Γ1 C1 roots).1 =
      (decoyUnusedLookupEvaluator fuel Γ2 C2 roots).1) ∧
    -- (2) Yet Decoy VIOLATES ActualLookupConfinement on concrete fixture f05_dagContainerGoalNew:
    ¬ LogConfinedTo (multiRootReachableNodes f05_dagContainerGoalNew ["n_f05_goal_new"])
        (multiRootTransitivePrimDeps [] f05_dagContainerGoalNew ["n_f05_goal_new"])
        (decoyUnusedLookupEvaluator 4 [] f05_dagContainerGoalNew ["n_f05_goal_new"]).2 ∧
    -- (3) Whereas genuine verifyMultiRootTraced SATISFIES ActualLookupConfinement on the same fixture:
    LogConfinedTo (multiRootReachableNodes f05_dagContainerGoalNew ["n_f05_goal_new"])
        (multiRootTransitivePrimDeps [] f05_dagContainerGoalNew ["n_f05_goal_new"])
        (verifyMultiRootTraced 4 [] f05_dagContainerGoalNew ["n_f05_goal_new"]).2 := by
  refine ⟨?_, ?_, A0_05_2_ActualLookupConfinement 4 [] f05_dagContainerGoalNew ["n_f05_goal_new"] (by decide)⟩
  · intro fuel Γ1 Γ2 C1 C2 roots hV hN hP
    dsimp only [decoyUnusedLookupEvaluator]
    rw [verifyMultiRootTraced_eq_frozen, verifyMultiRootTraced_eq_frozen]
    exact A0_05_1_OutputCongruence fuel roots hV hN hP
  · intro hBadConf
    have hGhostLogged : "ghost_outside_closure" ∈
        (decoyUnusedLookupEvaluator 4 [] f05_dagContainerGoalNew ["n_f05_goal_new"]).2.queriedNodeIds :=
      List.mem_cons_self ..
    have hInReach : "ghost_outside_closure" ∈
        multiRootReachableNodes f05_dagContainerGoalNew ["n_f05_goal_new"] :=
      hBadConf.1 "ghost_outside_closure" hGhostLogged
    exact absurd hInReach (by decide)

/-- Concrete poison-premise environment containing BOTH valid `"p_good" : 1 > 0` AND blatantly
    false `"p_poison_false" : 0 > 1` outside `P*`. -/
def a05_poisonPrimEnv : PrimPremiseEnv :=
  [ ⟨"p_good",         .domQ, "spec_a05", .pos (.const 1), []⟩
  , ⟨"p_poison_false", .domQ, "spec_a05", .pos (.const 0), []⟩ ]

def a05_goodRootContainer : G7DagContainer where
  nodes := [
    { nodeId     := "n_good_root"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_a05"
      guards     := []
      conclusion := .pos (.const 1)
      step       := .directDerivStep (.primPrem "p_good" (.pos (.const 1))) }
  ]

/-- **`A0-05.4b` (`A0_05_4b_PoisonOutsideClosureWitness`)**:
    Even though `"p_poison_false"` (`0 > 1`) is in `a05_poisonPrimEnv` and is semantically FALSE,
    it lies outside `P* = ["p_good"]`, so `A0_05_4_SemanticDependencyClosure` still applies and
    certifies `SemValidSequent` for `"n_good_root"`! -/
theorem A0_05_4b_PoisonOutsideClosureWitness :
    multiRootTransitivePrimDeps a05_poisonPrimEnv a05_goodRootContainer ["n_good_root"] = ["p_good"] ∧
    ¬ SemValidPrimId a05_poisonPrimEnv "p_poison_false" ∧
    SemValidSequent ⟨.domQ, "spec_a05", [], .pos (.const 1)⟩ := by
  have hFalsePoison : ¬ SemValidPrimId a05_poisonPrimEnv "p_poison_false" := by
    intro hSem
    have hLook : lookupPrimPrem? a05_poisonPrimEnv "p_poison_false" =
        some ⟨"p_poison_false", .domQ, "spec_a05", .pos (.const 0), []⟩ := rfl
    have hM : ModelsStrictForm (.pos (.const 0)) (0, 0) := hSem _ hLook (0, 0) rfl
    rcases hM.2 with ⟨v, hv, hpos⟩
    cases hv
    exact Rat.lt_irrefl hpos
  have hPremClosure : ∀ pid ∈ multiRootTransitivePrimDeps a05_poisonPrimEnv
      a05_goodRootContainer ["n_good_root"], SemValidPrimId a05_poisonPrimEnv pid := by
    intro pid hp
    have hEq : multiRootTransitivePrimDeps a05_poisonPrimEnv a05_goodRootContainer ["n_good_root"] =
        ["p_good"] := by decide
    rw [hEq] at hp
    rcases List.mem_cons.mp hp with rfl | hNil
    · intro e hLook ρ _
      have hL : lookupPrimPrem? a05_poisonPrimEnv "p_good" =
          some ⟨"p_good", .domQ, "spec_a05", .pos (.const 1), []⟩ := rfl
      rw [hL] at hLook
      injection hLook with he; subst he
      exact ⟨⟨((1 : Int) : Rat), .const 1 ρ⟩,
             ⟨((1 : Int) : Rat), .const 1 ρ, Rat.intCast_pos.mpr (by decide)⟩⟩
    · nomatch hNil
  have hSemOut := A0_05_4_SemanticDependencyClosure 3 a05_poisonPrimEnv a05_goodRootContainer
    ["n_good_root"] (by decide) hPremClosure "n_good_root" (List.mem_cons_self ..)
    ⟨.domQ, "spec_a05", [], .pos (.const 1)⟩ (by decide)
  exact ⟨by decide, hFalsePoison, hSemOut⟩

end OmegaCellC1P1B2BA0
