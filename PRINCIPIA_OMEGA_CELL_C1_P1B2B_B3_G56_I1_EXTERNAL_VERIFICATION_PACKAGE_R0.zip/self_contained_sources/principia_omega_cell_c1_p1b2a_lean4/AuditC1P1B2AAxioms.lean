import OmegaCellC1P1B2A

/-!
# Zero-Gap Kernel Axiom Audit for `PRINCIPIA Ω-CELL-C1-P1B2A-R1`

Audits **100%** of public declarations (`186 / 186`, `GAP = 0`) across:
- `OmegaCellC1P1B2A.P1B2AA_PartialExprPolyCert` (`66` definitions/types + `12` theorems)
- `OmegaCellC1P1B2A.P1B2AB_TelescopicGuardAndDAG` (`62` definitions/types + `15` theorems)
- `OmegaCellC1P1B2A.P1B2AC_ConservativeRefinementAndBundle` (`25` definitions/types + `6` theorems)

Verifies zero `sorryAx`, zero `Lean.ofReduceBool` / `Lean.trustCompiler`, and zero custom axioms.
-/

open OmegaCellC1P1B2A

/-! ## P1B2AA (`P1B2AA_PartialExprPolyCert.lean`): 66 Definitions/Types + 12 Theorems -/
#print axioms OmegaCellC1P1B2A.Env2
#print axioms OmegaCellC1P1B2A.G7DomTag
#print axioms OmegaCellC1P1B2A.isInfiniteDomTagBool
#print axioms OmegaCellC1P1B2A.g7DomTagToId?
#print axioms OmegaCellC1P1B2A.liftKernelDomTag
#print axioms OmegaCellC1P1B2A.liftCarrierToEnv2
#print axioms OmegaCellC1P1B2A.gridPtToEnv2
#print axioms OmegaCellC1P1B2A.inG7Dom
#print axioms OmegaCellC1P1B2A.PartExpr
#print axioms OmegaCellC1P1B2A.PartExprEvalRel
#print axioms OmegaCellC1P1B2A.PartExprDefined
#print axioms OmegaCellC1P1B2A.PartEvalRes
#print axioms OmegaCellC1P1B2A.evalPartExprFuel
#print axioms OmegaCellC1P1B2A.PolyExpr
#print axioms OmegaCellC1P1B2A.evalPolyExpr
#print axioms OmegaCellC1P1B2A.tropDegBound
#print axioms OmegaCellC1P1B2A.polyToPartExpr
#print axioms OmegaCellC1P1B2A.promoteToPolyExpr?
#print axioms OmegaCellC1P1B2A.Poly1
#print axioms OmegaCellC1P1B2A.evalPoly1
#print axioms OmegaCellC1P1B2A.poly1Add
#print axioms OmegaCellC1P1B2A.poly1Neg
#print axioms OmegaCellC1P1B2A.poly1Scale
#print axioms OmegaCellC1P1B2A.poly1Mul
#print axioms OmegaCellC1P1B2A.Poly2
#print axioms OmegaCellC1P1B2A.evalPoly2
#print axioms OmegaCellC1P1B2A.poly2Add
#print axioms OmegaCellC1P1B2A.poly2Neg
#print axioms OmegaCellC1P1B2A.poly2Sub
#print axioms OmegaCellC1P1B2A.poly2Scale1
#print axioms OmegaCellC1P1B2A.poly2Mul
#print axioms OmegaCellC1P1B2A.isZeroPoly2Bool
#print axioms OmegaCellC1P1B2A.toPoly2
#print axioms OmegaCellC1P1B2A.polyExprEqBool
#print axioms OmegaCellC1P1B2A.StrictForm
#print axioms OmegaCellC1P1B2A.FormDefined
#print axioms OmegaCellC1P1B2A.FormRawSat
#print axioms OmegaCellC1P1B2A.toStrictPred
#print axioms OmegaCellC1P1B2A.ModelsStrictForm
#print axioms OmegaCellC1P1B2A.FormEvalRes
#print axioms OmegaCellC1P1B2A.evalStrictFormFuel
#print axioms OmegaCellC1P1B2A.SynFrac
#print axioms OmegaCellC1P1B2A.SynEvalRes
#print axioms OmegaCellC1P1B2A.evalPartExprGrid
#print axioms OmegaCellC1P1B2A.evalStrictFormGrid
#print axioms OmegaCellC1P1B2A.SynFracRep
#print axioms OmegaCellC1P1B2A.PolyPositivstellensatzCert
#print axioms OmegaCellC1P1B2A.LinearFarkasOrderCert
#print axioms OmegaCellC1P1B2A.GuardedReciprocalCert
#print axioms OmegaCellC1P1B2A.FiniteGridExhaustiveCert
#print axioms OmegaCellC1P1B2A.AlgDomCert
#print axioms OmegaCellC1P1B2A.buildSosPoly
#print axioms OmegaCellC1P1B2A.lookupNonnegPolyGuard?
#print axioms OmegaCellC1P1B2A.lookupPosPolyGuard?
#print axioms OmegaCellC1P1B2A.lookupEqZeroPolyGuard?
#print axioms OmegaCellC1P1B2A.buildWeightedGuardPoly
#print axioms OmegaCellC1P1B2A.buildEqIdealPoly
#print axioms OmegaCellC1P1B2A.checkPolyPositivCertBool
#print axioms OmegaCellC1P1B2A.checkLinearFarkasCertBool
#print axioms OmegaCellC1P1B2A.hasActiveNonzeroDenBool
#print axioms OmegaCellC1P1B2A.checkGuardedRecipCertBool
#print axioms OmegaCellC1P1B2A.checkFiniteGridCertBool
#print axioms OmegaCellC1P1B2A.checkAlgDomCertBool
#print axioms OmegaCellC1P1B2A.exprDivSelfMinusOne
#print axioms OmegaCellC1P1B2A.exprZeroTimesRecip
#print axioms OmegaCellC1P1B2A.exprBinomialDiff

#print axioms OmegaCellC1P1B2A.liftCarrierToEnv2_inG7Dom
#print axioms OmegaCellC1P1B2A.partExprEvalRel_unique
#print axioms OmegaCellC1P1B2A.evalPartExprFuel_sound
#print axioms OmegaCellC1P1B2A.polyToPartExpr_evalRel
#print axioms OmegaCellC1P1B2A.promoteToPolyExpr?_sound
#print axioms OmegaCellC1P1B2A.toPoly2_eval_eq
#print axioms OmegaCellC1P1B2A.polyExprEqBool_sound
#print axioms OmegaCellC1P1B2A.strictMPStep_sound
#print axioms OmegaCellC1P1B2A.evalStrictFormFuel_sound
#print axioms OmegaCellC1P1B2A.checkAlgDomCert_sound
#print axioms OmegaCellC1P1B2A.T_B2A_01_partial_definedness_poly_firewall_and_resource_safety
#print axioms OmegaCellC1P1B2A.T_B2A_03_four_certificates_soundness_and_finite_infinite_separation

/-! ## P1B2AB (`P1B2AB_TelescopicGuardAndDAG.lean`): 62 Definitions/Types + 15 Theorems -/
#print axioms OmegaCellC1P1B2A.nodupStrsBool
#print axioms OmegaCellC1P1B2A.PrimPremiseEntry
#print axioms OmegaCellC1P1B2A.PrimPremiseEnv
#print axioms OmegaCellC1P1B2A.toPremDag
#print axioms OmegaCellC1P1B2A.lookupPrimPrem?
#print axioms OmegaCellC1P1B2A.restrictPrimEnv
#print axioms OmegaCellC1P1B2A.checkPrimEnvIntegrityBool
#print axioms OmegaCellC1P1B2A.SemValidPrimEntry
#print axioms OmegaCellC1P1B2A.SemValidPrimId
#print axioms OmegaCellC1P1B2A.checkExprDefUnderNzBool
#print axioms OmegaCellC1P1B2A.checkFormDefUnderNzBool
#print axioms OmegaCellC1P1B2A.GuardWfWitness
#print axioms OmegaCellC1P1B2A.GuardContextEvidence
#print axioms OmegaCellC1P1B2A.LocalDeriv
#print axioms OmegaCellC1P1B2A.GuardedDomainCert
#print axioms OmegaCellC1P1B2A.G7StepRule
#print axioms OmegaCellC1P1B2A.DepFootprint
#print axioms OmegaCellC1P1B2A.unionFootprint
#print axioms OmegaCellC1P1B2A.extractDerivFootprint
#print axioms OmegaCellC1P1B2A.extractSingleGuardWfFootprint
#print axioms OmegaCellC1P1B2A.extractGuardWfFootprint
#print axioms OmegaCellC1P1B2A.extractGuardCtxFootprint
#print axioms OmegaCellC1P1B2A.extractStepFootprint
#print axioms OmegaCellC1P1B2A.extractStepFootprintGoalOnlyMutant
#print axioms OmegaCellC1P1B2A.isSelfContainedGuardWfBool
#print axioms OmegaCellC1P1B2A.G7DagNode
#print axioms OmegaCellC1P1B2A.G7DagContainer
#print axioms OmegaCellC1P1B2A.lookupDagNode?
#print axioms OmegaCellC1P1B2A.maxTopoRank
#print axioms OmegaCellC1P1B2A.checkContainerIntegrityBool
#print axioms OmegaCellC1P1B2A.ValidContainer
#print axioms OmegaCellC1P1B2A.expandNodeStep
#print axioms OmegaCellC1P1B2A.transNodeIter
#print axioms OmegaCellC1P1B2A.extractReachableNodeIds
#print axioms OmegaCellC1P1B2A.restrictContainer
#print axioms OmegaCellC1P1B2A.collectDirectPrimRefsOfNodes
#print axioms OmegaCellC1P1B2A.extractTransitivePrimDeps
#print axioms OmegaCellC1P1B2A.CertifiedReachableClosure
#print axioms OmegaCellC1P1B2A.extractCertifiedReachableClosure
#print axioms OmegaCellC1P1B2A.checkSingleGuardWfBool
#print axioms OmegaCellC1P1B2A.checkGuardsPrefixDefinedAux
#print axioms OmegaCellC1P1B2A.checkGuardsPrefixDefinedBool
#print axioms OmegaCellC1P1B2A.checkGuardCtxEvidenceBool
#print axioms OmegaCellC1P1B2A.TelescopicGuardsDefined
#print axioms OmegaCellC1P1B2A.VerifiedSequentOut
#print axioms OmegaCellC1P1B2A.SemValidSequent
#print axioms OmegaCellC1P1B2A.G7RejectErr
#print axioms OmegaCellC1P1B2A.G7CheckResult
#print axioms OmegaCellC1P1B2A.isG7AcceptBool
#print axioms OmegaCellC1P1B2A.checkLocalDerivBool
#print axioms OmegaCellC1P1B2A.checkNodeStepLocal
#print axioms OmegaCellC1P1B2A.verifyParentsAux
#print axioms OmegaCellC1P1B2A.verifyNodeFuel
#print axioms OmegaCellC1P1B2A.verifyReachableDerivation
#print axioms OmegaCellC1P1B2A.verifyGlobalWithFuel
#print axioms OmegaCellC1P1B2A.certSeqRecipPos
#print axioms OmegaCellC1P1B2A.certBogusNegSqPos
#print axioms OmegaCellC1P1B2A.certUnorderedBadGuard
#print axioms OmegaCellC1P1B2A.certExtPremGuardWf
#print axioms OmegaCellC1P1B2A.stdG7PrimEnv
#print axioms OmegaCellC1P1B2A.dagMultiWithUnreachGood
#print axioms OmegaCellC1P1B2A.dagWithUnreachDupBad

#print axioms OmegaCellC1P1B2A.filter_find?_eq_of_pred_imp_keep
#print axioms OmegaCellC1P1B2A.checkExprDefUnderNz_sound
#print axioms OmegaCellC1P1B2A.checkFormDefUnderNz_sound
#print axioms OmegaCellC1P1B2A.mem_unionFootprint_prim
#print axioms OmegaCellC1P1B2A.mem_unionFootprint_parent
#print axioms OmegaCellC1P1B2A.selfContainedGuardWf_extraRefs_empty
#print axioms OmegaCellC1P1B2A.verifyReachable_restricted_eq
#print axioms OmegaCellC1P1B2A.validContainer_restricted_of_root
#print axioms OmegaCellC1P1B2A.checkGuardsPrefixDefinedAux_sound
#print axioms OmegaCellC1P1B2A.checkLocalDeriv_sound
#print axioms OmegaCellC1P1B2A.verifyReachable_master_sound
#print axioms OmegaCellC1P1B2A.verifyReachable_fuel_monotone_accept
#print axioms OmegaCellC1P1B2A.T_B2A_02_guarded_goalDeriv_soundness_and_full_wf_dependency_closure
#print axioms OmegaCellC1P1B2A.T_B2A_05_G7_T1_reachable_invariance_T2_master_soundness_T3_fuel_laws
#print axioms OmegaCellC1P1B2A.T_B2A_06_adversarial_dag_premise_guardwf_and_dup_id_suite

/-! ## P1B2AC (`P1B2AC_ConservativeRefinementAndBundle.lean`): 25 Definitions/Types + 6 Theorems -/
#print axioms OmegaCellC1P1B2A.P1B2AWitnessReceipt
#print axioms OmegaCellC1P1B2A.synthTrivPrimEnv
#print axioms OmegaCellC1P1B2A.liftPremDagToEnv
#print axioms OmegaCellC1P1B2A.verifyP1B2AWitnessStandaloneBool
#print axioms OmegaCellC1P1B2A.translateRatClaimId
#print axioms OmegaCellC1P1B2A.translateRatSubdomId
#print axioms OmegaCellC1P1B2A.translateRatProofCert
#print axioms OmegaCellC1P1B2A.iotaP1A0Witness
#print axioms OmegaCellC1P1B2A.rwNewSeqRecip
#print axioms OmegaCellC1P1B2A.ReflexSubjectKey
#print axioms OmegaCellC1P1B2A.CertifiedG7Bundle
#print axioms OmegaCellC1P1B2A.checkCertifiedG7BundleBool
#print axioms OmegaCellC1P1B2A.G7VerifiedSlot
#print axioms OmegaCellC1P1B2A.checkActiveG7BundleBool
#print axioms OmegaCellC1P1B2A.bundlePosRepairG2
#print axioms OmegaCellC1P1B2A.bundlePosRetreatG1
#print axioms OmegaCellC1P1B2A.bundlePosRefineStep2G2
#print axioms OmegaCellC1P1B2A.subjectKeyOfB1Summary
#print axioms OmegaCellC1P1B2A.B1AndG7Spine
#print axioms OmegaCellC1P1B2A.extractB1G7Summary
#print axioms OmegaCellC1P1B2A.extractB1G7Bundle
#print axioms OmegaCellC1P1B2A.CoupledB1G7Qualification
#print axioms OmegaCellC1P1B2A.CouplingRejectErr
#print axioms OmegaCellC1P1B2A.coupleStructuralAndG7
#print axioms OmegaCellC1P1B2A.checkAndCoupleB1G7

#print axioms OmegaCellC1P1B2A.canonSortStrs_eq_of_isStrictCanon
#print axioms OmegaCellC1P1B2A.toPremDag_liftPremDagToEnv
#print axioms OmegaCellC1P1B2A.T_B2A_04_conservative_refinement_of_P1A0_witness_transport
#print axioms OmegaCellC1P1B2A.certifiedG7Bundle_whitebox_sound
#print axioms OmegaCellC1P1B2A.T_B2A_07_certifiedG7Bundle_official_checker_and_ledger_binding
#print axioms OmegaCellC1P1B2A.T_B2A_08_coupled_structural_and_G7_qualification_with_G1_G56_unchecked
