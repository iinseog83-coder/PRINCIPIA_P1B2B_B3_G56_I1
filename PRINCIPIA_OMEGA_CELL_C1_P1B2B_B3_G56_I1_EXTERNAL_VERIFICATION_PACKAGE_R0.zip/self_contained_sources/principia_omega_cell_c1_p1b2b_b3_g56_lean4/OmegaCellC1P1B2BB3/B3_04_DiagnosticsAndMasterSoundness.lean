/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B3 — G56 Certified Coupling Kernel (`Formalization Act I0`)
  Module: OmegaCellC1P1B2BB3.B3_04_DiagnosticsAndMasterSoundness

  Authorization: Human L4 Final Freeze (`SCOPED_STATIC_BASELINE_FROZEN`) & `FORMALIZATION_ACT_I0`
  Gates & Binding Conditions Covered:
    - `I0-A5` (`F-B3-T17-04`, `Q-B3-R1-02`, `F-B3-T18-04`):
      * Independent declarative applicability predicates `IsCheckApplicable chk ctx c56` (`A_i`)
        defined strictly from `(ctx, c56)` and inspection policy (`0` diagnostic circularity!).
      * Non-masking product evaluator `evalG56DetailedR1`, applicability-enforcing 7-branch
        `projectCoupledVerdictR1`, `checkG56Coupling`, and `isG56CouplingVerifiedBool`.
      * Diagnostic reflection theorems `T_I0_A5_01 .. T_I0_A5_04`.
    - `I0-A4 / F-B3-T18-03` Path Seal (`T_I0_A4_05_TopLevelForcesConstrainedL1Path`).
    - `I0-A6` (`T_I0_A6_G56_MasterConditionalSoundness`).
-/
import OmegaCellC1P1B2BB3.B3_03_G7L1LossEquivalence

namespace OmegaCellC1P1B2BB3

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2

/-! ### 1. Declarative Check Identifiers & Input-Driven Applicability Predicates `A_i` (`I0-A5`) -/

/-- Closed enumeration of all 15 diagnostic sub-checks in `G56DetailedResultR1`. -/
inductive G56CheckId where
  | couplingHeader       : G56CheckId
  | g5Transition         : G56CheckId
  | g6CoreKey            : G56CheckId
  | g6Epoch              : G56CheckId
  | itemCarriers         : G56CheckId
  | evidenceRoots        : G56CheckId
  | g5Discharge          : G56CheckId
  | g6Suite              : G56CheckId
  | g5PrimDeps           : G56CheckId
  | g6PrimDeps           : G56CheckId
  | jointPrimDeps        : G56CheckId
  | l1LossDepsSubsetD56  : G56CheckId
  | reflexRetreatFlag    : G56CheckId
  | itemScopePolicy      : G56CheckId
  | retreatLossAgreement : G56CheckId
  deriving DecidableEq, Repr

/-- Exhaustive list of all 15 `G56CheckId`s for computable universal quantification. -/
def allG56CheckIds : List G56CheckId :=
  [ .couplingHeader, .g5Transition, .g6CoreKey, .g6Epoch, .itemCarriers, .evidenceRoots,
    .g5Discharge, .g6Suite, .g5PrimDeps, .g6PrimDeps, .jointPrimDeps, .l1LossDepsSubsetD56,
    .reflexRetreatFlag, .itemScopePolicy, .retreatLossAgreement ]

theorem mem_allG56CheckIds (chk : G56CheckId) : chk ∈ allG56CheckIds := by
  cases chk <;> decide

/-- **Declarative Applicability Predicate `A_i(ctx, c56)` (`F-B3-T18-04`, `I0-A5`)**:
    Derived strictly from the input transition mode (`0` references to any diagnostic result!). -/
def IsCheckApplicable (chk : G56CheckId) (_ctx : G56SharedContext) (c56 : G56CouplingCert) : Prop :=
  match chk with
  | .l1LossDepsSubsetD56  => c56.transitionBinding.reflexKind = .retreat
  | .retreatLossAgreement => c56.transitionBinding.reflexKind = .retreat
  | _                     => True

/-- Computable boolean counterpart of `IsCheckApplicable`. -/
def isCheckApplicableBool (chk : G56CheckId) (_ctx : G56SharedContext)
    (c56 : G56CouplingCert) : Bool :=
  match chk with
  | .l1LossDepsSubsetD56  => c56.transitionBinding.reflexKind == .retreat
  | .retreatLossAgreement => c56.transitionBinding.reflexKind == .retreat
  | _                     => true

theorem isCheckApplicableBool_iff (chk : G56CheckId) (ctx : G56SharedContext)
    (c56 : G56CouplingCert) :
    isCheckApplicableBool chk ctx c56 = true ↔ IsCheckApplicable chk ctx c56 := by
  cases chk <;> simp [isCheckApplicableBool, IsCheckApplicable]

/-- Functorial map over `DiagnosticObservation`. -/
def DiagnosticObservation.map {α β : Type} (f : α → β) :
    DiagnosticObservation α → DiagnosticObservation β
  | .evaluated v   => .evaluated (f v)
  | .blocked r     => .blocked r
  | .notApplicable => .notApplicable

/-- Project any `G56CheckId` in `det : G56DetailedResultR1` to a normalized `DiagnosticObservation Bool`. -/
def obsPassOfCheckId (det : G56DetailedResultR1) : G56CheckId → DiagnosticObservation Bool
  | .couplingHeader => det.bindingDiag.couplingHeaderCanonicalObs
  | .g5Transition   => det.bindingDiag.g5TransitionMatchesObs
  | .g6CoreKey      => det.bindingDiag.g6CoreKeyMatchesObs
  | .g6Epoch        => det.bindingDiag.g6EpochMatchesAssignedObs
  | .itemCarriers   => det.bindingDiag.itemCarrierMismatchIdsObs.map List.isEmpty
  | .evidenceRoots  => det.bindingDiag.evidenceRootsMatchObs
  | .g5Discharge    => det.g5DiagObs.map (fun s =>
      match s with | .g5Accepted _ _ => true | .g5NotDischarged _ _ => false)
  | .g6Suite        => det.g6DiagObs.map (fun v =>
      match v with | .verified _ => true | _ => false)
  | .g5PrimDeps     => det.depsDiag.g5ClaimedMatchesDerivedObs.map (fun t => t.1)
  | .g6PrimDeps     => det.depsDiag.g6ClaimedMatchesDerivedObs.map (fun t => t.1)
  | .jointPrimDeps  => det.depsDiag.jointClaimedMatchesUnionObs.map (fun t => t.1)
  | .l1LossDepsSubsetD56  => det.depsDiag.l1LossEquivDepsSubsetD56Obs.map Prod.fst
  | .reflexRetreatFlag    => det.scopeDiag.reflexRetreatFlagConsistentObs
  | .itemScopePolicy      => det.scopeDiag.itemPolicyIncompatibleIdsObs.map List.isEmpty
  | .retreatLossAgreement => det.scopeDiag.lossAgreementCheckObs.map Prod.fst

/-- Check that `notApplicable` appears in `det` ONLY when `¬ A_i(ctx, c56)` (`F-B3-T18-04`, `CE-I0-08`). -/
def checkApplicableObservationsConsistentBool (ctx : G56SharedContext) (c56 : G56CouplingCert)
    (det : G56DetailedResultR1) : Bool :=
  allG56CheckIds.all (fun chk =>
    let app := isCheckApplicableBool chk ctx c56
    match obsPassOfCheckId det chk with
    | .notApplicable => !app
    | _              => app)

/-! ### 2. Sub-Evaluators & `evalG56DetailedR1` (`F-B3-T17-04`, `Q-B3-R1-02`) -/

/-- Check canonical non-empty coupling & transition header strings. -/
def checkG56CouplingHeaderBasicBool (c56 : G56CouplingCert) : Bool :=
  (c56.certVersion == "g56_b3_v1") &&
  (c56.couplingCid != "") &&
  (c56.transitionBinding.baseId == "base_Q") &&
  (c56.transitionBinding.rflxCid != "") &&
  (c56.transitionBinding.cellOldCid != "") &&
  (c56.transitionBinding.cellNewCid != "") &&
  (c56.transitionBinding.specOldId != "") &&
  (c56.transitionBinding.specNewId != "")

/-- Check whether a single `G6ProtectedInvariantSpec` shares `b`'s transition specs and carriers. -/
def checkG6ItemCarrierAlignedBool (b : G56TransitionBinding)
    (item : G6ProtectedInvariantSpec) : Bool :=
  (item.specId == b.specNewId) &&
  (item.oldNewState.specOldId == b.specOldId) &&
  (item.oldNewState.specNewId == b.specNewId) &&
  (item.oldNewState.domOld == b.domOld) &&
  (item.oldNewState.guardsOld == b.guardsOld) &&
  (item.oldNewState.domNew == b.domNew) &&
  (item.oldNewState.guardsNew == b.guardsNew) &&
  (item.protectedDomain == b.domNew) &&
  (item.protectedGuards == b.guardsNew)

/-- Check `G56EvidenceBinding` against actual derived proof roots (`F-B3-T18-03`). -/
def checkG56EvidenceManifestBool (c56 : G56CouplingCert) : Bool :=
  (c56.evidenceBinding.g5ObstCid == c56.g5Cert.obstCid) &&
  (c56.evidenceBinding.g6SuiteCid == c56.g6Suite.suiteCid) &&
  (c56.evidenceBinding.g5ProofRootIds == collectG5ProofRootIds c56.g5Cert) &&
  (c56.evidenceBinding.g6ProofRootIds == collectG6ProofRootIds c56.g6Suite) &&
  (c56.evidenceBinding.jointProofRoots ==
    collectG56JointProofRootIds c56.g5Cert c56.g6Suite c56.scopeCompatibility)

/-- Evaluate `G56BindingDiagnosticProduct` (`0` short-circuit masking across its 6 observations!). -/
def evalG56BindingDiag (c56 : G56CouplingCert) : G56BindingDiagnosticProduct :=
  let hdrOk := checkG56CouplingHeaderBasicBool c56
  let g5KeyOk := (projectG5CoreKey c56.g5Cert == c56.transitionBinding.toCoreKey)
  let g5CarrOk :=
    (c56.g5Cert.domOld == c56.transitionBinding.domOld) &&
    (c56.g5Cert.guardsOld == c56.transitionBinding.guardsOld) &&
    (c56.g5Cert.domNew == c56.transitionBinding.domNew) &&
    (c56.g5Cert.guardsNew == c56.transitionBinding.guardsNew)
  let g5FullOk :=
    (projectG5Transition ⟨c56.g5Cert, c56.transitionBinding.assignedEvalEpoch⟩ ==
      c56.transitionBinding)
  let g6KeyOk := (projectG6CoreKey c56.g6Suite == c56.transitionBinding.toCoreKey)
  let g6EpochOk := (c56.g6Suite.evaluationEpoch == c56.transitionBinding.assignedEvalEpoch)
  let badCarrIds :=
    (c56.g6Suite.items.filter
      (fun it => !checkG6ItemCarrierAlignedBool c56.transitionBinding it)).map (·.invariantId)
  let evOk := checkG56EvidenceManifestBool c56
  let firstErr? : Option G56BindingError :=
    if !hdrOk then some .nonCanonicalCouplingHeader
    else if !g5KeyOk then some .g5TransitionIdMismatch
    else if !g6KeyOk then some .g6TransitionIdMismatch
    else if !g6EpochOk then some .evaluationEpochMismatch
    else if !g5CarrOk then some (.prePostCarrierMismatch "g5_carrier")
    else match badCarrIds with
      | badId :: _ => some (.prePostCarrierMismatch badId)
      | [] =>
          if !g5FullOk then some .reflexRetreatFlagMismatch
          else if !evOk then some .evidenceManifestMismatch
          else none
  { couplingHeaderCanonicalObs := .evaluated hdrOk
    g5TransitionMatchesObs     := .evaluated g5FullOk
    g6CoreKeyMatchesObs        := .evaluated g6KeyOk
    g6EpochMatchesAssignedObs  := .evaluated g6EpochOk
    itemCarrierMismatchIdsObs  := .evaluated badCarrIds
    evidenceRootsMatchObs      := .evaluated evOk
    firstBindingError?         := firstErr? }

/-- Computable non-shrinking same-scope item policy check for `.repairSameScope` and `.refinementSameScope`. -/
def checkItemSameScopePolBool (item : G6ProtectedInvariantSpec) : Bool :=
  item.scopeLossRecord?.isNone &&
  match item.oldNewState.scopePolicy with
  | .globalPostSameDom _                  => true
  | .oldScopeInclusion _ _ _ _ false none => true
  | _                                     => false

/-- Computable expanded-scope item policy check for `.refinementExpandedScope`. -/
def checkItemExpandedScopePolBool (item : G6ProtectedInvariantSpec) : Bool :=
  item.scopeLossRecord?.isNone &&
  match item.oldNewState.scopePolicy with
  | .oldScopeInclusion _ _ _ _ true (some _) => true
  | _                                        => false

/-- Check consistent `(reflexKind, requiresRetreatHistory)` alignment between `c5` and `b`. -/
def checkReflexRetreatFlagConsistentBool (c56 : G56CouplingCert) : Bool :=
  (c56.g5Cert.reflexKind == c56.transitionBinding.reflexKind) &&
  (c56.g5Cert.requiresRetreatHistory == c56.transitionBinding.requiresRetreatHistory) &&
  match c56.transitionBinding.reflexKind with
  | .repair     => !c56.transitionBinding.requiresRetreatHistory
  | .refinement => !c56.transitionBinding.requiresRetreatHistory
  | .retreat    => c56.transitionBinding.requiresRetreatHistory

/-- Evaluate `G56ScopeDiagnosticProduct` (`D_scope`, written without top-level `let` binders so
    `rw [hRk]` reduces immediately on `c56.transitionBinding.reflexKind`). -/
def evalG56ScopeDiag (ctx : G56SharedContext) (ctxBlock? : Option DiagnosticBlockingReason)
    (c56 : G56CouplingCert) : G56ScopeDiagnosticProduct :=
  match c56.transitionBinding.reflexKind with
  | .repair =>
      let flagOk := checkReflexRetreatFlagConsistentBool c56
      let modeOk := (c56.scopeCompatibility == .repairSameScope)
      let badPolIds :=
        (c56.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId)
      let err? : Option G56BindingError :=
        if !flagOk then some .reflexRetreatFlagMismatch
        else if !modeOk then some (.scopePolicyModeMismatch "g56_scope_mode")
        else match badPolIds with
          | id0 :: _ => some (.scopePolicyModeMismatch id0)
          | []       => none
      { reflexRetreatFlagConsistentObs := .evaluated flagOk
        itemPolicyIncompatibleIdsObs   := .evaluated (if modeOk then badPolIds else "g56_scope_mode" :: badPolIds)
        lossAgreementCheckObs          := .notApplicable
        firstScopeBindingError?        := err? }
  | .refinement =>
      let flagOk := checkReflexRetreatFlagConsistentBool c56
      match c56.scopeCompatibility with
      | .refinementSameScope =>
          let refModeOk : Bool :=
            match c56.g5Cert.refinementCert? with
            | some rf => !rf.scopeExpanded
            | none    => true
          let badPolIds :=
            (c56.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId)
          let allBadIds := if refModeOk then badPolIds else "g5_refinement_mode" :: badPolIds
          let err? : Option G56BindingError :=
            if !flagOk then some .reflexRetreatFlagMismatch
            else match allBadIds with
              | id0 :: _ => some (.scopePolicyModeMismatch id0)
              | []       => none
          { reflexRetreatFlagConsistentObs := .evaluated flagOk
            itemPolicyIncompatibleIdsObs   := .evaluated allBadIds
            lossAgreementCheckObs          := .notApplicable
            firstScopeBindingError?        := err? }
      | .refinementExpandedScope =>
          let refModeOk : Bool :=
            match c56.g5Cert.refinementCert? with
            | some rf => rf.scopeExpanded
            | none    => true
          let badPolIds :=
            (c56.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId)
          let allBadIds := if refModeOk then badPolIds else "g5_refinement_mode" :: badPolIds
          let err? : Option G56BindingError :=
            if !flagOk then some .reflexRetreatFlagMismatch
            else match allBadIds with
              | id0 :: _ => some (.scopePolicyModeMismatch id0)
              | []       => none
          { reflexRetreatFlagConsistentObs := .evaluated flagOk
            itemPolicyIncompatibleIdsObs   := .evaluated allBadIds
            lossAgreementCheckObs          := .notApplicable
            firstScopeBindingError?        := err? }
      | _ =>
          { reflexRetreatFlagConsistentObs := .evaluated flagOk
            itemPolicyIncompatibleIdsObs   := .evaluated ["g56_scope_mode"]
            lossAgreementCheckObs          := .notApplicable
            firstScopeBindingError?        :=
              if !flagOk then some .reflexRetreatFlagMismatch
              else some (.scopePolicyModeMismatch "g56_scope_mode") }
  | .retreat =>
      let flagOk := checkReflexRetreatFlagConsistentBool c56
      let forbidIds := (c56.g6Suite.items.filter (fun it =>
        it.oldNewState.scopePolicy != .retreatWithLossAccounting)).map (·.invariantId)
      let missingLrIds := (c56.g6Suite.items.filter (fun it =>
        (it.oldNewState.scopePolicy == .retreatWithLossAccounting) &&
        it.scopeLossRecord?.isNone)).map (·.invariantId)
      let polBadIds := forbidIds ++ missingLrIds
      match c56.scopeCompatibility with
      | .retreatExactSharedLoss Φ_shared itemBinds =>
          match ctxBlock? with
          | some blk =>
              let preErr? : Option G56BindingError :=
                if !flagOk then some .reflexRetreatFlagMismatch
                else match forbidIds with
                  | id0 :: _ => some (.g5RetreatForbiddenByG6Pol id0)
                  | [] =>
                      match missingLrIds with
                      | id0 :: _ => some (.scopePolicyModeMismatch id0)
                      | []       => none
              { reflexRetreatFlagConsistentObs := .evaluated flagOk
                itemPolicyIncompatibleIdsObs   := .evaluated polBadIds
                lossAgreementCheckObs          := .blocked blk
                firstScopeBindingError?        := preErr? }
          | none =>
              match c56.g5Cert.retreatCert? with
              | none =>
                  let preErr? : Option G56BindingError :=
                    if !flagOk then some .reflexRetreatFlagMismatch
                    else match forbidIds with
                      | id0 :: _ => some (.g5RetreatForbiddenByG6Pol id0)
                      | [] =>
                          match missingLrIds with
                          | id0 :: _ => some (.scopePolicyModeMismatch id0)
                          | []       => none
                  { reflexRetreatFlagConsistentObs := .evaluated flagOk
                    itemPolicyIncompatibleIdsObs   := .evaluated polBadIds
                    lossAgreementCheckObs          := .blocked .missingRetreatSubCertificate
                    firstScopeBindingError?        := preErr? }
              | some rt5 =>
                  let mapOk := (itemBinds.map (·.invariantId) == c56.g6Suite.items.map (·.invariantId))
                  let g5LocOk := (rt5.excisedBranches == Φ_shared)
                  let pairRes :=
                    checkRetreatItemPairsLoop ctx.fuelG6 ctx.primEnv ctx.dagCont
                      c56.transitionBinding.domOld c56.transitionBinding.guardsOld
                      c56.transitionBinding.specNewId Φ_shared c56.g6Suite.items itemBinds
                  let lossOk := g5LocOk && mapOk && pairRes.2.isNone
                  let lossFailedIds :=
                    (if g5LocOk then [] else ["g5_shared_locus"]) ++
                    (if mapOk then [] else ["item_binds_coverage"]) ++
                    pairRes.1
                  let err? : Option G56BindingError :=
                    if !flagOk then some .reflexRetreatFlagMismatch
                    else match forbidIds with
                      | id0 :: _ => some (.g5RetreatForbiddenByG6Pol id0)
                      | [] =>
                          match missingLrIds with
                          | id0 :: _ => some (.scopePolicyModeMismatch id0)
                          | [] =>
                              if !g5LocOk then
                                some (.scopeLossLocusMismatch
                                  (match c56.g6Suite.items with | it :: _ => it.invariantId | [] => "g5_shared_locus"))
                              else if !mapOk then
                                some (.scopeLossLocusMismatch
                                  (match c56.g6Suite.items with | it :: _ => it.invariantId | [] => "item_binds_coverage"))
                              else
                                pairRes.2
                  { reflexRetreatFlagConsistentObs := .evaluated flagOk
                    itemPolicyIncompatibleIdsObs   := .evaluated polBadIds
                    lossAgreementCheckObs          := .evaluated (lossOk, lossFailedIds)
                    firstScopeBindingError?        := err? }
      | _ =>
          let lossObs : DiagnosticObservation (Bool × List String) :=
            match ctxBlock? with
            | some blk => .blocked blk
            | none     => .evaluated (false, ["g56_scope_mode"])
          let err? : Option G56BindingError :=
            if !flagOk then some .reflexRetreatFlagMismatch
            else match forbidIds with
              | id0 :: _ => some (.g5RetreatForbiddenByG6Pol id0)
              | []       => some (.scopePolicyModeMismatch "g56_scope_mode")
          { reflexRetreatFlagConsistentObs := .evaluated flagOk
            itemPolicyIncompatibleIdsObs   := .evaluated ("g56_scope_mode" :: polBadIds)
            lossAgreementCheckObs          := lossObs
            firstScopeBindingError?        := err? }

/-- Evaluate `G56DependencyDiagnosticProduct` when `contextStatus = .contextValid`. -/
def evalG56DepsDiagValid (ctx : G56SharedContext) (c56 : G56CouplingCert) :
    G56DependencyDiagnosticProduct :=
  let d5  := deriveG5PrimDeps ctx.primEnv ctx.dagCont c56.g5Cert
  let d6  := deriveG6PrimDeps ctx.primEnv ctx.dagCont c56.g6Suite
  let d56 := deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite
  let g5DepsOk : Bool :=
    (c56.g5Cert.claimedPrimDeps.primDepIds == d5) &&
    (c56.claimedJointPrimDeps.g5PrimDepIds == d5)
  let g6DepsOk : Bool :=
    isStrictCanonStrList c56.g6Suite.claimedPrimDeps.primDepIds &&
    (c56.g6Suite.claimedPrimDeps.primDepIds == d6) &&
    (c56.claimedJointPrimDeps.g6PrimDepIds == d6)
  let jointDepsOk : Bool :=
    isStrictCanonStrList c56.claimedJointPrimDeps.jointPrimDepIds &&
    (c56.claimedJointPrimDeps.jointPrimDepIds == d56)
  let l1Obs : DiagnosticObservation (Bool × List String) :=
    if c56.transitionBinding.reflexKind == .retreat then
      let extra := computeExtraL1PremisesOutsideD56 ctx.primEnv ctx.dagCont c56.scopeCompatibility d56
      .evaluated (extra.isEmpty, extra)
    else
      .notApplicable
  { g5ClaimedMatchesDerivedObs  := .evaluated (g5DepsOk, c56.g5Cert.claimedPrimDeps.primDepIds, d5)
    g6ClaimedMatchesDerivedObs  := .evaluated (g6DepsOk, c56.g6Suite.claimedPrimDeps.primDepIds, d6)
    jointClaimedMatchesUnionObs := .evaluated (jointDepsOk, c56.claimedJointPrimDeps.jointPrimDepIds, d56)
    l1LossEquivDepsSubsetD56Obs := l1Obs }

/-- Evaluate `G56DependencyDiagnosticProduct` when upstream context fails with `blk`. -/
def evalG56DepsDiagBlocked (blk : DiagnosticBlockingReason) (c56 : G56CouplingCert) :
    G56DependencyDiagnosticProduct :=
  { g5ClaimedMatchesDerivedObs  := .blocked blk
    g6ClaimedMatchesDerivedObs  := .blocked blk
    jointClaimedMatchesUnionObs := .blocked blk
    l1LossEquivDepsSubsetD56Obs :=
      if c56.transitionBinding.reflexKind == .retreat then .blocked blk else .notApplicable }

/-- Evaluate `G56G5Status` when `contextStatus = .contextValid`. -/
def evalG5StatusValid (ctx : G56SharedContext) (c56 : G56CouplingCert) : G56G5Status :=
  let d5 := deriveG5PrimDeps ctx.primEnv ctx.dagCont c56.g5Cert
  if checkG5DischargeBool ctx.fuelG5 ctx.primEnv ctx.dagCont c56.g5Cert then
    .g5Accepted c56.g5Cert.reflexKind c56.g5Cert.requiresRetreatHistory
  else
    .g5NotDischarged
      (checkG5CoreProofsBool ctx.fuelG5 ctx.primEnv ctx.dagCont c56.g5Cert)
      (c56.g5Cert.claimedPrimDeps.primDepIds == d5)

/-- **Full Product Diagnostic Evaluator `evalG56DetailedR1` (`F-B3-T17-04`, `Q-B3-R1-02`, `I0-A5`)**. -/
def evalG56DetailedR1 (ctx : G56SharedContext) (c56 : G56CouplingCert) : G56DetailedResultR1 :=
  match checkPrimEnvIntegrityBool ctx.primEnv, checkContainerIntegrityBool ctx.dagCont with
  | true, true =>
      { contextStatus := .contextValid
        bindingDiag   := evalG56BindingDiag c56
        g5DiagObs     := .evaluated (evalG5StatusValid ctx c56)
        g6DiagObs     := .evaluated (checkG6Suite ctx.fuelG6 ctx.primEnv ctx.dagCont c56.g6Suite)
        depsDiag      := evalG56DepsDiagValid ctx c56
        scopeDiag     := evalG56ScopeDiag ctx none c56 }
  | false, true =>
      { contextStatus := .malformedPrimEnv
        bindingDiag   := evalG56BindingDiag c56
        g5DiagObs     := .blocked .malformedSharedPrimEnv
        g6DiagObs     := .blocked .malformedSharedPrimEnv
        depsDiag      := evalG56DepsDiagBlocked .malformedSharedPrimEnv c56
        scopeDiag     := evalG56ScopeDiag ctx (some .malformedSharedPrimEnv) c56 }
  | true, false =>
      { contextStatus := .malformedContainer
        bindingDiag   := evalG56BindingDiag c56
        g5DiagObs     := .blocked .malformedSharedContainer
        g6DiagObs     := .blocked .malformedSharedContainer
        depsDiag      := evalG56DepsDiagBlocked .malformedSharedContainer c56
        scopeDiag     := evalG56ScopeDiag ctx (some .malformedSharedContainer) c56 }
  | false, false =>
      { contextStatus := .malformedEnvAndContainer
        bindingDiag   := evalG56BindingDiag c56
        g5DiagObs     := .blocked .malformedEnvAndContainer
        g6DiagObs     := .blocked .malformedEnvAndContainer
        depsDiag      := evalG56DepsDiagBlocked .malformedEnvAndContainer c56
        scopeDiag     := evalG56ScopeDiag ctx (some .malformedEnvAndContainer) c56 }

/-! ### 3. Applicability-Guarded 7-Branch `projectCoupledVerdictR1` & `checkG56Coupling` -/

/-- Check the 8 core structural boolean observations on `det`. -/
def checkCore8BindingScopeObsBool (det : G56DetailedResultR1) : Bool :=
  (obsPassOfCheckId det .couplingHeader == .evaluated true) &&
  (obsPassOfCheckId det .g5Transition == .evaluated true) &&
  (obsPassOfCheckId det .g6CoreKey == .evaluated true) &&
  (obsPassOfCheckId det .g6Epoch == .evaluated true) &&
  (obsPassOfCheckId det .itemCarriers == .evaluated true) &&
  (obsPassOfCheckId det .evidenceRoots == .evaluated true) &&
  (obsPassOfCheckId det .reflexRetreatFlag == .evaluated true) &&
  (obsPassOfCheckId det .itemScopePolicy == .evaluated true)

/-- Project `det : G56DetailedResultR1` to the canonical 7-branch `G56CoupledVerdict`. -/
def projectCoupledVerdictR1 (ctx : G56SharedContext) (c56 : G56CouplingCert)
    (det : G56DetailedResultR1) : G56CoupledVerdict :=
  match det.contextStatus with
  | .malformedPrimEnv         => .invalidEvidence .malformedSharedPrimEnv
  | .malformedEnvAndContainer => .invalidEvidence .malformedSharedPrimEnv
  | .malformedContainer       => .invalidEvidence .malformedSharedContainer
  | .contextValid =>
      if !checkApplicableObservationsConsistentBool ctx c56 det then
        .invalidEvidence .invalidDiagnosticObservation
      else
        match det.bindingDiag.firstBindingError? with
        | some bErr => .invalidBinding bErr
        | none =>
            match det.scopeDiag.firstScopeBindingError? with
            | some sErr => .invalidBinding sErr
            | none =>
                if !checkCore8BindingScopeObsBool det then
                  .invalidBinding .nonCanonicalCouplingHeader
                else
                  match det.depsDiag.jointClaimedMatchesUnionObs,
                        det.depsDiag.g5ClaimedMatchesDerivedObs,
                        det.depsDiag.g6ClaimedMatchesDerivedObs with
                  | .evaluated (jOk, _, _), .evaluated (d5Ok, _, _), .evaluated (d6Ok, _, _) =>
                      if !jOk then
                        .invalidEvidence .jointPrimDepsMismatch
                      else if !d5Ok then
                        .invalidEvidence .g5ClaimedPrimDepsMismatch
                      else if !d6Ok then
                        .invalidEvidence .g6ClaimedPrimDepsMismatch
                      else
                        let l1DepsGate : Option G56EvidenceError :=
                          if c56.transitionBinding.reflexKind == .retreat then
                            match det.depsDiag.l1LossEquivDepsSubsetD56Obs with
                            | .evaluated (true, _)  => none
                            | .evaluated (false, _) => some .lossEquivExtraPremiseNotInD56
                            | _                     => some .invalidDiagnosticObservation
                          else
                            none
                        match l1DepsGate with
                        | some eErr => .invalidEvidence eErr
                        | none =>
                            match det.g6DiagObs, det.g5DiagObs with
                            | .evaluated (.invalid r), _ =>
                                .invalidEvidence (.g6SuiteInvalid r)
                            | .evaluated (.violated vIds uIds), .evaluated g5s =>
                                let g5AccBool :=
                                  match g5s with
                                  | .g5Accepted _ _      => true
                                  | .g5NotDischarged _ _ => false
                                .g6Violated vIds uIds g5AccBool
                            | .evaluated (.verified hasLoss), .evaluated (.g5NotDischarged _ _) =>
                                .g5NotDischarged (.g6AlsoVerified hasLoss)
                            | .evaluated (.unresolved uIds), .evaluated (.g5NotDischarged _ _) =>
                                .g5NotDischarged (.g6AlsoUnresolved uIds)
                            | .evaluated (.emptySuiteAccepted polCid), .evaluated (.g5NotDischarged _ _) =>
                                .g5NotDischarged (.g6AlsoEmpty polCid)
                            | .evaluated (.unresolved uIds), .evaluated (.g5Accepted _ _) =>
                                .g6Unresolved uIds
                            | .evaluated (.emptySuiteAccepted polCid), .evaluated (.g5Accepted _ _) =>
                                .g6Empty polCid
                            | .evaluated (.verified hasLoss), .evaluated (.g5Accepted _ reqRet) =>
                                if c56.transitionBinding.reflexKind == .retreat then
                                  match det.scopeDiag.lossAgreementCheckObs with
                                  | .evaluated (true, _) => .g56Verified hasLoss reqRet
                                  | .evaluated (false, _) =>
                                      .invalidBinding (.scopeLossLocusMismatch "retreat_loss")
                                  | _ => .invalidEvidence .invalidDiagnosticObservation
                                else
                                  .g56Verified hasLoss reqRet
                            | _, _ => .invalidEvidence .invalidDiagnosticObservation
                  | _, _, _ => .invalidEvidence .invalidDiagnosticObservation

/-- **Official Deterministic `B3` Coupled Kernel Checker (`checkG56Coupling`)**. -/
def checkG56Coupling (ctx : G56SharedContext) (c56 : G56CouplingCert) : G56CoupledVerdict :=
  projectCoupledVerdictR1 ctx c56 (evalG56DetailedR1 ctx c56)

/-- Packet-guarded entry point rejecting split `(Γ5, C5) ≠ (Γ6, C6)` before `checkG56Coupling`. -/
def checkG56PacketWithContext (ctx : G56SharedContext) (pkt : G56UntrustedCandidatePacket)
    (c56 : G56CouplingCert) : G56CoupledVerdict :=
  match checkG56PacketContextError? ctx pkt with
  | some bErr => .invalidBinding bErr
  | none      => checkG56Coupling ctx c56

/-- Boolean predicate true iff `checkG56Coupling ctx c56` returns `.g56Verified _ _`. -/
def isG56CouplingVerifiedBool (ctx : G56SharedContext) (c56 : G56CouplingCert) : Bool :=
  match checkG56Coupling ctx c56 with
  | .g56Verified _ _ => true
  | _                => false

/-- Helper testing whether `verdict` is `.g56Verified _ _`. -/
def isCoupledVerdictVerifiedBool : G56CoupledVerdict → Bool
  | .g56Verified _ _ => true
  | _                => false

/-! ### 4. Abstract `projectCoupledVerdictR1` Unpacking Lemmas (Fast & Modular!) -/

/-- Unpack `.g56Verified` on an arbitrary `det : G56DetailedResultR1`. -/
private theorem unpack_projected_g56Verified
    {ctx : G56SharedContext} {c56 : G56CouplingCert} {det : G56DetailedResultR1}
    {hasLoss reqRet : Bool}
    (hProj : projectCoupledVerdictR1 ctx c56 det = .g56Verified hasLoss reqRet) :
    det.contextStatus = .contextValid ∧
    det.bindingDiag.firstBindingError? = none ∧
    det.scopeDiag.firstScopeBindingError? = none ∧
    checkCore8BindingScopeObsBool det = true ∧
    (∃ jC jA, det.depsDiag.jointClaimedMatchesUnionObs = .evaluated (true, jC, jA)) ∧
    (∃ c5C c5A, det.depsDiag.g5ClaimedMatchesDerivedObs = .evaluated (true, c5C, c5A)) ∧
    (∃ c6C c6A, det.depsDiag.g6ClaimedMatchesDerivedObs = .evaluated (true, c6C, c6A)) ∧
    det.g6DiagObs = .evaluated (.verified hasLoss) ∧
    (∃ rk, det.g5DiagObs = .evaluated (.g5Accepted rk reqRet)) ∧
    (c56.transitionBinding.reflexKind = .retreat →
      (∃ ex, det.depsDiag.l1LossEquivDepsSubsetD56Obs = .evaluated (true, ex)) ∧
      (∃ lIds, det.scopeDiag.lossAgreementCheckObs = .evaluated (true, lIds))) := by
  unfold projectCoupledVerdictR1 at hProj
  cases hCtx : det.contextStatus <;> rw [hCtx] at hProj
  case malformedPrimEnv => nomatch hProj
  case malformedEnvAndContainer => nomatch hProj
  case malformedContainer => nomatch hProj
  case contextValid =>
    dsimp only at hProj
    by_cases hApp : (!checkApplicableObservationsConsistentBool ctx c56 det) = true
    · rw [if_pos hApp] at hProj; nomatch hProj
    · rw [if_neg hApp] at hProj
      cases hB1 : det.bindingDiag.firstBindingError? <;> rw [hB1] at hProj
      case some => nomatch hProj
      case none =>
        cases hS1 : det.scopeDiag.firstScopeBindingError? <;> rw [hS1] at hProj
        case some => nomatch hProj
        case none =>
          dsimp only at hProj
          by_cases hC8 : (!checkCore8BindingScopeObsBool det) = true
          · rw [if_pos hC8] at hProj; nomatch hProj
          · rw [if_neg hC8] at hProj
            have hC8True : checkCore8BindingScopeObsBool det = true := by
              cases hb : checkCore8BindingScopeObsBool det <;> simp_all
            cases hJ : det.depsDiag.jointClaimedMatchesUnionObs <;> rw [hJ] at hProj
            case blocked => nomatch hProj
            case notApplicable => nomatch hProj
            case evaluated jTup =>
              cases hD5 : det.depsDiag.g5ClaimedMatchesDerivedObs <;> rw [hD5] at hProj
              case blocked => nomatch hProj
              case notApplicable => nomatch hProj
              case evaluated d5Tup =>
                cases hD6 : det.depsDiag.g6ClaimedMatchesDerivedObs <;> rw [hD6] at hProj
                case blocked => nomatch hProj
                case notApplicable => nomatch hProj
                case evaluated d6Tup =>
                  rcases jTup with ⟨jOk, jC, jA⟩
                  rcases d5Tup with ⟨d5Ok, d5C, d5A⟩
                  rcases d6Tup with ⟨d6Ok, d6C, d6A⟩
                  dsimp only at hProj
                  cases hj : jOk <;> rw [hj] at hProj
                  case false => nomatch hProj
                  case true =>
                    cases hd5 : d5Ok <;> rw [hd5] at hProj
                    case false => nomatch hProj
                    case true =>
                      cases hd6 : d6Ok <;> rw [hd6] at hProj
                      case false => nomatch hProj
                      case true =>
                        simp only [Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hProj
                        by_cases hrk : (c56.transitionBinding.reflexKind == .retreat) = true
                        · rw [if_pos hrk] at hProj
                          cases hL1 : det.depsDiag.l1LossEquivDepsSubsetD56Obs <;> rw [hL1] at hProj
                          case blocked => nomatch hProj
                          case notApplicable => nomatch hProj
                          case evaluated l1Tup =>
                            rcases l1Tup with ⟨l1Ok, l1Ex⟩
                            cases hl1 : l1Ok <;> rw [hl1] at hProj
                            case false => nomatch hProj
                            case true =>
                              dsimp only at hProj
                              cases hG6 : det.g6DiagObs <;> rw [hG6] at hProj
                              case blocked => nomatch hProj
                              case notApplicable => nomatch hProj
                              case evaluated g6v =>
                                cases g6v
                                case invalid => nomatch hProj
                                case violated =>
                                  cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj <;> nomatch hProj
                                case unresolved =>
                                  cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                                  case blocked => nomatch hProj
                                  case notApplicable => nomatch hProj
                                  case evaluated g5s => cases g5s <;> nomatch hProj
                                case emptySuiteAccepted =>
                                  cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                                  case blocked => nomatch hProj
                                  case notApplicable => nomatch hProj
                                  case evaluated g5s => cases g5s <;> nomatch hProj
                                case verified hl' =>
                                  cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                                  case blocked => nomatch hProj
                                  case notApplicable => nomatch hProj
                                  case evaluated g5s =>
                                    cases g5s with
                                    | g5NotDischarged _ _ => nomatch hProj
                                    | g5Accepted rk5 rr5 =>
                                        dsimp only at hProj
                                        rw [if_pos hrk] at hProj
                                        cases hLoss : det.scopeDiag.lossAgreementCheckObs <;>
                                          rw [hLoss] at hProj
                                        case blocked => nomatch hProj
                                        case notApplicable => nomatch hProj
                                        case evaluated ltup =>
                                          rcases ltup with ⟨lok, lids⟩
                                          cases hlok : lok <;> rw [hlok] at hProj
                                          case false => nomatch hProj
                                          case true =>
                                            injection hProj with hhl hrr
                                            subst hhl; subst hrr
                                            exact ⟨rfl, rfl, rfl, hC8True,
                                                   ⟨jC, jA, rfl⟩, ⟨d5C, d5A, rfl⟩, ⟨d6C, d6A, rfl⟩,
                                                   rfl, ⟨rk5, rfl⟩,
                                                   fun _ => ⟨⟨l1Ex, rfl⟩, ⟨lids, rfl⟩⟩⟩
                        · rw [if_neg hrk] at hProj
                          dsimp only at hProj
                          cases hG6 : det.g6DiagObs <;> rw [hG6] at hProj
                          case blocked => nomatch hProj
                          case notApplicable => nomatch hProj
                          case evaluated g6v =>
                            cases g6v
                            case invalid => nomatch hProj
                            case violated =>
                              cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj <;> nomatch hProj
                            case unresolved =>
                              cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                              case blocked => nomatch hProj
                              case notApplicable => nomatch hProj
                              case evaluated g5s => cases g5s <;> nomatch hProj
                            case emptySuiteAccepted =>
                              cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                              case blocked => nomatch hProj
                              case notApplicable => nomatch hProj
                              case evaluated g5s => cases g5s <;> nomatch hProj
                            case verified hl' =>
                              cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                              case blocked => nomatch hProj
                              case notApplicable => nomatch hProj
                              case evaluated g5s =>
                                cases g5s with
                                | g5NotDischarged _ _ => nomatch hProj
                                | g5Accepted rk5 rr5 =>
                                    dsimp only at hProj
                                    rw [if_neg hrk] at hProj
                                    injection hProj with hhl hrr
                                    subst hhl; subst hrr
                                    refine ⟨rfl, rfl, rfl, hC8True,
                                            ⟨jC, jA, rfl⟩, ⟨d5C, d5A, rfl⟩, ⟨d6C, d6A, rfl⟩,
                                            rfl, ⟨rk5, rfl⟩, ?_⟩
                                    intro hRetEq
                                    exact False.elim (hrk (beq_iff_eq.mpr hRetEq))

/-- Unpack `.g6Violated` on an arbitrary `det : G56DetailedResultR1`. -/
private theorem unpack_projected_g6Violated
    {ctx : G56SharedContext} {c56 : G56CouplingCert} {det : G56DetailedResultR1}
    {vIds uIds : List String} {g5Ok : Bool}
    (hProj : projectCoupledVerdictR1 ctx c56 det = .g6Violated vIds uIds g5Ok) :
    det.contextStatus = .contextValid ∧
    det.g6DiagObs = .evaluated (.violated vIds uIds) := by
  unfold projectCoupledVerdictR1 at hProj
  cases hCtx : det.contextStatus <;> rw [hCtx] at hProj
  case malformedPrimEnv => nomatch hProj
  case malformedEnvAndContainer => nomatch hProj
  case malformedContainer => nomatch hProj
  case contextValid =>
    dsimp only at hProj
    by_cases hApp : (!checkApplicableObservationsConsistentBool ctx c56 det) = true
    · rw [if_pos hApp] at hProj; nomatch hProj
    · rw [if_neg hApp] at hProj
      cases hB1 : det.bindingDiag.firstBindingError? <;> rw [hB1] at hProj
      case some => nomatch hProj
      case none =>
        cases hS1 : det.scopeDiag.firstScopeBindingError? <;> rw [hS1] at hProj
        case some => nomatch hProj
        case none =>
          dsimp only at hProj
          by_cases hC8 : (!checkCore8BindingScopeObsBool det) = true
          · rw [if_pos hC8] at hProj; nomatch hProj
          · rw [if_neg hC8] at hProj
            cases hJ : det.depsDiag.jointClaimedMatchesUnionObs <;> rw [hJ] at hProj
            case blocked => nomatch hProj
            case notApplicable => nomatch hProj
            case evaluated jTup =>
              cases hD5 : det.depsDiag.g5ClaimedMatchesDerivedObs <;> rw [hD5] at hProj
              case blocked => nomatch hProj
              case notApplicable => nomatch hProj
              case evaluated d5Tup =>
                cases hD6 : det.depsDiag.g6ClaimedMatchesDerivedObs <;> rw [hD6] at hProj
                case blocked => nomatch hProj
                case notApplicable => nomatch hProj
                case evaluated d6Tup =>
                  rcases jTup with ⟨jOk, _, _⟩
                  rcases d5Tup with ⟨d5Ok, _, _⟩
                  rcases d6Tup with ⟨d6Ok, _, _⟩
                  dsimp only at hProj
                  cases hj : jOk <;> rw [hj] at hProj
                  case false => nomatch hProj
                  case true =>
                    cases hd5 : d5Ok <;> rw [hd5] at hProj
                    case false => nomatch hProj
                    case true =>
                      cases hd6 : d6Ok <;> rw [hd6] at hProj
                      case false => nomatch hProj
                      case true =>
                        simp only [Bool.not_true, Bool.false_eq_true, ↓reduceIte] at hProj
                        by_cases hrk : (c56.transitionBinding.reflexKind == .retreat) = true
                        · rw [if_pos hrk] at hProj
                          cases hL1 : det.depsDiag.l1LossEquivDepsSubsetD56Obs <;> rw [hL1] at hProj
                          case blocked => nomatch hProj
                          case notApplicable => nomatch hProj
                          case evaluated l1Tup =>
                            rcases l1Tup with ⟨l1Ok, _⟩
                            cases hl1 : l1Ok <;> rw [hl1] at hProj
                            case false => nomatch hProj
                            case true =>
                              dsimp only at hProj
                              cases hG6 : det.g6DiagObs <;> rw [hG6] at hProj
                              case blocked => nomatch hProj
                              case notApplicable => nomatch hProj
                              case evaluated g6v =>
                                cases g6v
                                case invalid => nomatch hProj
                                case violated v' u' =>
                                  cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                                  case blocked => nomatch hProj
                                  case notApplicable => nomatch hProj
                                  case evaluated =>
                                    injection hProj with hv hu _
                                    subst hv; subst hu
                                    exact ⟨rfl, rfl⟩
                                case verified =>
                                  cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                                  case blocked => nomatch hProj
                                  case notApplicable => nomatch hProj
                                  case evaluated g5s =>
                                    cases g5s with
                                    | g5NotDischarged _ _ => nomatch hProj
                                    | g5Accepted _ _ =>
                                        dsimp only at hProj
                                        rw [if_pos hrk] at hProj
                                        cases hLoss : det.scopeDiag.lossAgreementCheckObs <;>
                                          rw [hLoss] at hProj
                                        case blocked => nomatch hProj
                                        case notApplicable => nomatch hProj
                                        case evaluated ltup =>
                                          rcases ltup with ⟨lok, _⟩
                                          cases hlok : lok <;> rw [hlok] at hProj <;> nomatch hProj
                                case unresolved =>
                                  cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                                  case blocked => nomatch hProj
                                  case notApplicable => nomatch hProj
                                  case evaluated g5s => cases g5s <;> nomatch hProj
                                case emptySuiteAccepted =>
                                  cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                                  case blocked => nomatch hProj
                                  case notApplicable => nomatch hProj
                                  case evaluated g5s => cases g5s <;> nomatch hProj
                        · rw [if_neg hrk] at hProj
                          dsimp only at hProj
                          cases hG6 : det.g6DiagObs <;> rw [hG6] at hProj
                          case blocked => nomatch hProj
                          case notApplicable => nomatch hProj
                          case evaluated g6v =>
                            cases g6v
                            case invalid => nomatch hProj
                            case violated v' u' =>
                              cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                              case blocked => nomatch hProj
                              case notApplicable => nomatch hProj
                              case evaluated =>
                                injection hProj with hv hu _
                                subst hv; subst hu
                                exact ⟨rfl, rfl⟩
                            case verified =>
                              cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                              case blocked => nomatch hProj
                              case notApplicable => nomatch hProj
                              case evaluated g5s =>
                                cases g5s <;> dsimp only at hProj
                                · rw [if_neg hrk] at hProj; nomatch hProj
                                · nomatch hProj
                            case unresolved =>
                              cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                              case blocked => nomatch hProj
                              case notApplicable => nomatch hProj
                              case evaluated g5s => cases g5s <;> nomatch hProj
                            case emptySuiteAccepted =>
                              cases hG5 : det.g5DiagObs <;> rw [hG5] at hProj
                              case blocked => nomatch hProj
                              case notApplicable => nomatch hProj
                              case evaluated g5s => cases g5s <;> nomatch hProj

/-! ### 5. `I0-A5` Diagnostic Reflection & `I0-A4` Constrained-Path Theorems -/

private theorem iff_not_true_of_evaluated {α : Type} {v : α} :
    (@DiagnosticObservation.evaluated α v = @DiagnosticObservation.notApplicable α) ↔ ¬ True :=
  Iff.intro (fun h => nomatch h) (fun h => False.elim (h trivial))

private theorem iff_not_true_of_blocked {α : Type} {r : DiagnosticBlockingReason} :
    (@DiagnosticObservation.blocked α r = @DiagnosticObservation.notApplicable α) ↔ ¬ True :=
  Iff.intro (fun h => nomatch h) (fun h => False.elim (h trivial))

private theorem scopeLossObs_notApplicable_iff
    (ctx : G56SharedContext) (blk? : Option DiagnosticBlockingReason) (c56 : G56CouplingCert) :
    (evalG56ScopeDiag ctx blk? c56).lossAgreementCheckObs.map Prod.fst = .notApplicable ↔
      c56.transitionBinding.reflexKind ≠ .retreat := by
  unfold evalG56ScopeDiag
  cases hrk : c56.transitionBinding.reflexKind with
  | repair =>
      exact Iff.intro (fun _ h => nomatch h) (fun _ => rfl)
  | refinement =>
      cases c56.scopeCompatibility <;>
        exact Iff.intro (fun _ h => nomatch h) (fun _ => rfl)
  | retreat =>
      dsimp only
      refine Iff.intro ?_ (fun hNe => False.elim (hNe rfl))
      cases c56.scopeCompatibility with
      | retreatExactSharedLoss Φ binds =>
          cases blk? with
          | some _ => intro hNA; nomatch hNA
          | none =>
              cases c56.g5Cert.retreatCert? with
              | none   => intro hNA; nomatch hNA
              | some _ => intro hNA; nomatch hNA
      | repairSameScope =>
          cases blk? <;> (intro hNA; nomatch hNA)
      | refinementSameScope =>
          cases blk? <;> (intro hNA; nomatch hNA)
      | refinementExpandedScope =>
          cases blk? <;> (intro hNA; nomatch hNA)

private theorem scopeFlagObs_notApplicable_iff
    (ctx : G56SharedContext) (blk? : Option DiagnosticBlockingReason) (c56 : G56CouplingCert) :
    ((evalG56ScopeDiag ctx blk? c56).reflexRetreatFlagConsistentObs = .notApplicable ↔ ¬ True) ∧
    ((evalG56ScopeDiag ctx blk? c56).itemPolicyIncompatibleIdsObs.map List.isEmpty = .notApplicable ↔ ¬ True) := by
  unfold evalG56ScopeDiag
  cases c56.transitionBinding.reflexKind with
  | repair => exact ⟨iff_not_true_of_evaluated, iff_not_true_of_evaluated⟩
  | refinement =>
      cases c56.scopeCompatibility <;> exact ⟨iff_not_true_of_evaluated, iff_not_true_of_evaluated⟩
  | retreat =>
      cases c56.scopeCompatibility with
      | retreatExactSharedLoss Φ binds =>
          cases blk? with
          | some _ => exact ⟨iff_not_true_of_evaluated, iff_not_true_of_evaluated⟩
          | none =>
              cases c56.g5Cert.retreatCert? <;>
                exact ⟨iff_not_true_of_evaluated, iff_not_true_of_evaluated⟩
      | repairSameScope => exact ⟨iff_not_true_of_evaluated, iff_not_true_of_evaluated⟩
      | refinementSameScope => exact ⟨iff_not_true_of_evaluated, iff_not_true_of_evaluated⟩
      | refinementExpandedScope => exact ⟨iff_not_true_of_evaluated, iff_not_true_of_evaluated⟩

private theorem l1DepsObs_notApplicable_iff_valid
    (ctx : G56SharedContext) (c56 : G56CouplingCert) :
    (evalG56DepsDiagValid ctx c56).l1LossEquivDepsSubsetD56Obs.map Prod.fst = .notApplicable ↔
      c56.transitionBinding.reflexKind ≠ .retreat := by
  unfold evalG56DepsDiagValid
  dsimp only
  cases hrk : c56.transitionBinding.reflexKind <;>
    simp [DiagnosticObservation.map]

private theorem l1DepsObs_notApplicable_iff_blocked
    (blk : DiagnosticBlockingReason) (c56 : G56CouplingCert) :
    (evalG56DepsDiagBlocked blk c56).l1LossEquivDepsSubsetD56Obs.map Prod.fst = .notApplicable ↔
      c56.transitionBinding.reflexKind ≠ .retreat := by
  unfold evalG56DepsDiagBlocked
  dsimp only
  cases hrk : c56.transitionBinding.reflexKind <;>
    simp [DiagnosticObservation.map]

/-- **`T_I0_A5_01` — Exact Applicability Reflection (`Obs_i = .notApplicable ⟺ ¬ A_i(ctx, c56)`)**:
    In `evalG56DetailedR1 ctx c56`, for every `chk : G56CheckId`, `obsPassOfCheckId` equals
    `.notApplicable` IF AND ONLY IF `¬ IsCheckApplicable chk ctx c56`! -/
theorem T_I0_A5_01_EvalDetailedNotApplicableIffNotApplicable
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (chk : G56CheckId) :
    obsPassOfCheckId (evalG56DetailedR1 ctx c56) chk = .notApplicable ↔
      ¬ IsCheckApplicable chk ctx c56 := by
  unfold evalG56DetailedR1
  cases checkPrimEnvIntegrityBool ctx.primEnv <;>
    cases checkContainerIntegrityBool ctx.dagCont <;>
    dsimp only
  all_goals
    cases chk
    case couplingHeader       => exact iff_not_true_of_evaluated
    case g5Transition         => exact iff_not_true_of_evaluated
    case g6CoreKey            => exact iff_not_true_of_evaluated
    case g6Epoch              => exact iff_not_true_of_evaluated
    case itemCarriers         => exact iff_not_true_of_evaluated
    case evidenceRoots        => exact iff_not_true_of_evaluated
    case g5Discharge          => first | exact iff_not_true_of_evaluated | exact iff_not_true_of_blocked
    case g6Suite              => first | exact iff_not_true_of_evaluated | exact iff_not_true_of_blocked
    case g5PrimDeps           => first | exact iff_not_true_of_evaluated | exact iff_not_true_of_blocked
    case g6PrimDeps           => first | exact iff_not_true_of_evaluated | exact iff_not_true_of_blocked
    case jointPrimDeps        => first | exact iff_not_true_of_evaluated | exact iff_not_true_of_blocked
    case reflexRetreatFlag    => exact (scopeFlagObs_notApplicable_iff ctx _ c56).1
    case itemScopePolicy      => exact (scopeFlagObs_notApplicable_iff ctx _ c56).2
    case retreatLossAgreement => exact scopeLossObs_notApplicable_iff ctx _ c56
    case l1LossDepsSubsetD56  =>
      first
      | exact l1DepsObs_notApplicable_iff_valid ctx c56
      | exact l1DepsObs_notApplicable_iff_blocked _ c56

/-- **`T_I0_A5_02` — Projection Soundness: Verified Verdict Forces Every Applicable Check to `.evaluated true`
    and Rejects Forged `.notApplicable` (`CE-I0-08`) & `.blocked` (`CE-I0-09`)**. -/
theorem T_I0_A5_02_ProjectedVerdictEnforcesApplicableEvaluatedPass
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (det : G56DetailedResultR1)
    (chk : G56CheckId) :
    (isCoupledVerdictVerifiedBool (projectCoupledVerdictR1 ctx c56 det) = true →
      IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .evaluated true) ∧
    (IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .notApplicable →
      isCoupledVerdictVerifiedBool (projectCoupledVerdictR1 ctx c56 det) = false) ∧
    (∀ r : DiagnosticBlockingReason,
      IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .blocked r →
      isCoupledVerdictVerifiedBool (projectCoupledVerdictR1 ctx c56 det) = false) := by
  have hMain :
      isCoupledVerdictVerifiedBool (projectCoupledVerdictR1 ctx c56 det) = true →
      IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .evaluated true := by
    intro hVer hApp
    unfold isCoupledVerdictVerifiedBool at hVer
    cases hP : projectCoupledVerdictR1 ctx c56 det <;> rw [hP] at hVer
    case invalidBinding => nomatch hVer
    case invalidEvidence => nomatch hVer
    case g6Violated => nomatch hVer
    case g5NotDischarged => nomatch hVer
    case g6Unresolved => nomatch hVer
    case g6Empty => nomatch hVer
    case g56Verified hasLoss reqRet =>
      rcases unpack_projected_g56Verified hP with
        ⟨_, _, _, hC8, ⟨jC, jA, hJ⟩, ⟨c5C, c5A, hD5⟩, ⟨c6C, c6A, hD6⟩,
         hG6, ⟨rk, hG5⟩, hRetPack⟩
      unfold checkCore8BindingScopeObsBool at hC8
      simp only [Bool.and_eq_true, beq_iff_eq] at hC8
      cases chk with
      | couplingHeader    => exact hC8.1.1.1.1.1.1.1
      | g5Transition      => exact hC8.1.1.1.1.1.1.2
      | g6CoreKey         => exact hC8.1.1.1.1.1.2
      | g6Epoch           => exact hC8.1.1.1.1.2
      | itemCarriers      => exact hC8.1.1.1.2
      | evidenceRoots     => exact hC8.1.1.2
      | reflexRetreatFlag => exact hC8.1.2
      | itemScopePolicy   => exact hC8.2
      | jointPrimDeps     => simp [obsPassOfCheckId, hJ, DiagnosticObservation.map]
      | g5PrimDeps        => simp [obsPassOfCheckId, hD5, DiagnosticObservation.map]
      | g6PrimDeps        => simp [obsPassOfCheckId, hD6, DiagnosticObservation.map]
      | g5Discharge       => simp [obsPassOfCheckId, hG5, DiagnosticObservation.map]
      | g6Suite           => simp [obsPassOfCheckId, hG6, DiagnosticObservation.map]
      | l1LossDepsSubsetD56 =>
          rcases (hRetPack hApp).1 with ⟨ex, hL1⟩
          simp [obsPassOfCheckId, hL1, DiagnosticObservation.map]
      | retreatLossAgreement =>
          rcases (hRetPack hApp).2 with ⟨lIds, hLoss⟩
          simp [obsPassOfCheckId, hLoss, DiagnosticObservation.map]
  refine ⟨hMain, ?_, ?_⟩
  · intro hApp hNA
    apply Bool.eq_false_iff.mpr
    intro hVer
    have hEv := hMain hVer hApp
    rw [hNA] at hEv; nomatch hEv
  · intro r hApp hBlk
    apply Bool.eq_false_iff.mpr
    intro hVer
    have hEv := hMain hVer hApp
    rw [hBlk] at hEv; nomatch hEv

/-- **`T_I0_A5_03` — End-to-End `checkG56Coupling` Diagnostic Reflection**. -/
theorem T_I0_A5_03_CheckG56DiagnosticReflection
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (chk : G56CheckId) :
    let det := evalG56DetailedR1 ctx c56
    (isG56CouplingVerifiedBool ctx c56 = true →
      IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .evaluated true) ∧
    (obsPassOfCheckId det chk = .notApplicable ↔ ¬ IsCheckApplicable chk ctx c56) ∧
    (∀ r : DiagnosticBlockingReason,
      IsCheckApplicable chk ctx c56 →
      obsPassOfCheckId det chk = .blocked r →
      isG56CouplingVerifiedBool ctx c56 = false) := by
  dsimp only
  have hVerEq :
      isG56CouplingVerifiedBool ctx c56 =
      isCoupledVerdictVerifiedBool
        (projectCoupledVerdictR1 ctx c56 (evalG56DetailedR1 ctx c56)) := by
    unfold isG56CouplingVerifiedBool checkG56Coupling isCoupledVerdictVerifiedBool
    rfl
  have hProj := T_I0_A5_02_ProjectedVerdictEnforcesApplicableEvaluatedPass
    ctx c56 (evalG56DetailedR1 ctx c56) chk
  rw [hVerEq]
  exact ⟨hProj.1, T_I0_A5_01_EvalDetailedNotApplicableIffNotApplicable ctx c56 chk, hProj.2.2⟩

/-- **`T_I0_A5_04` — Violation Soundness Preservation on `.g6Violated` (`R0` §4, `CE-G56-06`)**. -/
theorem T_I0_A5_04_CoupledViolationSoundnessPreserved
    (ctx : G56SharedContext) (c56 : G56CouplingCert)
    (vIds uIds : List String) (g5Ok : Bool)
    (hViol : checkG56Coupling ctx c56 = .g6Violated vIds uIds g5Ok) :
    (allViolationsPointBasedBool c56.g6Suite = true →
      SemPointCounterexampleOnNewDom c56.g6Suite vIds) ∧
    ((∀ p ∈ deriveG6PrimDeps ctx.primEnv ctx.dagCont c56.g6Suite, SemValidPrimId ctx.primEnv p) →
      SemViolatedG6ProtectedSuite c56.g6Suite vIds) := by
  unfold checkG56Coupling at hViol
  rcases unpack_projected_g6Violated hViol with ⟨hCtxV, hG6Obs⟩
  have hG6Viol : checkG6Suite ctx.fuelG6 ctx.primEnv ctx.dagCont c56.g6Suite =
      .violated vIds uIds := by
    unfold evalG56DetailedR1 at hCtxV hG6Obs
    cases hEnv : checkPrimEnvIntegrityBool ctx.primEnv <;>
      cases hCont : checkContainerIntegrityBool ctx.dagCont <;>
      rw [hEnv, hCont] at hCtxV hG6Obs
    case false.true => nomatch hCtxV
    case true.false => nomatch hCtxV
    case false.false => nomatch hCtxV
    case true.true =>
      dsimp only at hG6Obs
      injection hG6Obs
  refine ⟨?_, ?_⟩
  · intro hPt
    exact (T_B2_A4a_CounterexampleSound_Unconditional
      ctx.fuelG6 ctx.primEnv ctx.dagCont c56.g6Suite vIds uIds hG6Viol hPt).2.2
  · intro hPrem6
    exact T_B2_A4b_FullViolationRecordSound_Conditional
      ctx.fuelG6 ctx.primEnv ctx.dagCont c56.g6Suite vIds uIds hG6Viol hPrem6

/-! ### 6. Unpacking Verified Coupling & Constrained `L1` Path Seal (`I0-A4` / `I0-A6`) -/

/-- Core structural extraction lemma unpacking all deterministic invariants from
    `checkG56Coupling ctx c56 = .g56Verified hasLoss reqRet`. -/
theorem unpack_g56Verified
    {ctx : G56SharedContext} {c56 : G56CouplingCert} {hasLoss reqRet : Bool}
    (hVer : checkG56Coupling ctx c56 = .g56Verified hasLoss reqRet) :
    SyntacticValidPrimEnv ctx.primEnv ∧
    ValidContainer ctx.dagCont ∧
    (evalG56BindingDiag c56).firstBindingError? = none ∧
    (evalG56ScopeDiag ctx none c56).firstScopeBindingError? = none ∧
    checkG5DischargeBool ctx.fuelG5 ctx.primEnv ctx.dagCont c56.g5Cert = true ∧
    reqRet = c56.g5Cert.requiresRetreatHistory ∧
    checkG6Suite ctx.fuelG6 ctx.primEnv ctx.dagCont c56.g6Suite = .verified hasLoss ∧
    c56.claimedJointPrimDeps.g5PrimDepIds =
      deriveG5PrimDeps ctx.primEnv ctx.dagCont c56.g5Cert ∧
    c56.claimedJointPrimDeps.g6PrimDepIds =
      deriveG6PrimDeps ctx.primEnv ctx.dagCont c56.g6Suite ∧
    c56.claimedJointPrimDeps.jointPrimDepIds =
      deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite ∧
    (c56.transitionBinding.reflexKind = .retreat →
      (computeExtraL1PremisesOutsideD56 ctx.primEnv ctx.dagCont c56.scopeCompatibility
        (deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite)).isEmpty = true ∧
      ∃ lIds, (evalG56ScopeDiag ctx none c56).lossAgreementCheckObs = .evaluated (true, lIds)) := by
  unfold checkG56Coupling at hVer
  rcases unpack_projected_g56Verified hVer with
    ⟨hCtxV, hB1, hS1, _, ⟨jC, jA, hJ⟩, ⟨c5C, c5A, hD5⟩, ⟨c6C, c6A, hD6⟩,
     hG6Obs, ⟨rk5, hG5Obs⟩, hRetPack⟩
  unfold evalG56DetailedR1 at hCtxV hB1 hS1 hJ hD5 hD6 hG6Obs hG5Obs hRetPack
  cases hEnv : checkPrimEnvIntegrityBool ctx.primEnv <;>
    cases hCont : checkContainerIntegrityBool ctx.dagCont <;>
    rw [hEnv, hCont] at hCtxV hB1 hS1 hJ hD5 hD6 hG6Obs hG5Obs hRetPack
  case false.true => nomatch hCtxV
  case true.false => nomatch hCtxV
  case false.false => nomatch hCtxV
  case true.true =>
    dsimp only at hB1 hS1 hJ hD5 hD6 hG6Obs hG5Obs hRetPack
    unfold evalG56DepsDiagValid at hJ hD5 hD6 hRetPack
    dsimp only at hJ hD5 hD6 hRetPack
    injection hJ with hjTup
    injection hjTup with hjTrue _
    injection hD5 with hd5Tup
    injection hd5Tup with hd5True _
    injection hD6 with hd6Tup
    injection hd6Tup with hd6True _
    simp only [Bool.and_eq_true, beq_iff_eq] at hjTrue hd5True hd6True
    injection hG6Obs with hG6Eq
    unfold evalG5StatusValid at hG5Obs
    dsimp only at hG5Obs
    cases hg5 : checkG5DischargeBool ctx.fuelG5 ctx.primEnv ctx.dagCont c56.g5Cert <;>
      rw [hg5] at hG5Obs
    case false =>
      injection hG5Obs with hBad
      nomatch hBad
    case true =>
      injection hG5Obs with hAccEq
      injection hAccEq with _ hReqEq
      refine ⟨hEnv, hCont, hB1, hS1, rfl, hReqEq.symm, hG6Eq,
              hd5True.2, hd6True.2, hjTrue.2, ?_⟩
      intro hRet
      rcases hRetPack hRet with ⟨⟨ex, hL1Obs⟩, hLossObs⟩
      have hrkB : (c56.transitionBinding.reflexKind == .retreat) = true := beq_iff_eq.mpr hRet
      rw [if_pos hrkB] at hL1Obs
      injection hL1Obs with hl1Pair
      injection hl1Pair with hExEmpty _
      exact ⟨hExEmpty, hLossObs⟩

/-- **`T_I0_A4_05` — Top-Level Coupling Enforces Constrained `L1` Loss-Equivalence Path (`F-B3-T18-03`, `CE-I0-07`)**. -/
theorem T_I0_A4_05_TopLevelForcesConstrainedL1Path
    (ctx : G56SharedContext) (c56 : G56CouplingCert)
    (hVer : isG56CouplingVerifiedBool ctx c56 = true)
    (hRet : c56.transitionBinding.reflexKind = .retreat) :
    ∃ (Φ_shared : ExcisedLocus) (itemBinds : List G56ItemLossBinding)
      (rt5 : G5RetreatPartitionCert),
      c56.scopeCompatibility = .retreatExactSharedLoss Φ_shared itemBinds ∧
      c56.g5Cert.retreatCert? = some rt5 ∧
      rt5.excisedBranches = Φ_shared ∧
      checkAllItemsRetreatLossConstrainedBool ctx.fuelG6 ctx.primEnv ctx.dagCont
        c56.transitionBinding.domOld c56.transitionBinding.guardsOld
        c56.transitionBinding.specNewId Φ_shared c56.g6Suite.items itemBinds
        (deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite) = true := by
  unfold isG56CouplingVerifiedBool at hVer
  cases hC : checkG56Coupling ctx c56 <;> rw [hC] at hVer
  case invalidBinding => nomatch hVer
  case invalidEvidence => nomatch hVer
  case g6Violated => nomatch hVer
  case g5NotDischarged => nomatch hVer
  case g6Unresolved => nomatch hVer
  case g6Empty => nomatch hVer
  case g56Verified hasLoss reqRet =>
    rcases unpack_g56Verified hC with
      ⟨_, _, _, hSNone, _, _, _, _, _, _, hRetExtra⟩
    rcases hRetExtra hRet with ⟨hExEmpty, ⟨lIds, hLossObs⟩⟩
    unfold evalG56ScopeDiag at hSNone hLossObs
    rw [hRet] at hSNone hLossObs
    dsimp only at hSNone hLossObs
    cases hSc : c56.scopeCompatibility <;> rw [hSc] at hSNone hLossObs
    case repairSameScope => nomatch hLossObs
    case refinementSameScope => nomatch hLossObs
    case refinementExpandedScope => nomatch hLossObs
    case retreatExactSharedLoss Φ_shared itemBinds =>
      rw [hSc] at hExEmpty
      dsimp only at hSNone hLossObs
      cases hRt : c56.g5Cert.retreatCert? <;> rw [hRt] at hSNone hLossObs
      case none => nomatch hLossObs
      case some rt5 =>
        dsimp only at hLossObs
        injection hLossObs with hPairEq
        injection hPairEq with hLossOkTrue _
        simp only [Bool.and_eq_true] at hLossOkTrue
        refine ⟨Φ_shared, itemBinds, rt5, rfl, rfl, eq_of_beq hLossOkTrue.1.1, ?_⟩
        unfold checkAllItemsRetreatLossConstrainedBool
        rw [hLossOkTrue.1.2, hLossOkTrue.2, hExEmpty]
        rfl

/-! ### 7. `I0-A6` — Unified Master Conditional Soundness (`T_I0_A6_G56_MasterConditionalSoundness`) -/

theorem bindingDiag_none_implies_components {c56 : G56CouplingCert}
    (hNone : (evalG56BindingDiag c56).firstBindingError? = none) :
    checkG56CouplingHeaderBasicBool c56 = true ∧
    projectG5Transition ⟨c56.g5Cert, c56.transitionBinding.assignedEvalEpoch⟩ =
      c56.transitionBinding ∧
    projectG6CoreKey c56.g6Suite = c56.transitionBinding.toCoreKey ∧
    c56.g6Suite.evaluationEpoch = c56.transitionBinding.assignedEvalEpoch ∧
    (∀ item ∈ c56.g6Suite.items, checkG6ItemCarrierAlignedBool c56.transitionBinding item = true) ∧
    checkG56EvidenceManifestBool c56 = true := by
  unfold evalG56BindingDiag at hNone
  dsimp only at hNone
  by_cases h1 : (!checkG56CouplingHeaderBasicBool c56) = true
  · rw [if_pos h1] at hNone; nomatch hNone
  · rw [if_neg h1] at hNone
    have hHdr : checkG56CouplingHeaderBasicBool c56 = true := by
      cases hb : checkG56CouplingHeaderBasicBool c56 <;> simp_all
    by_cases h2 : (!(projectG5CoreKey c56.g5Cert == c56.transitionBinding.toCoreKey)) = true
    · rw [if_pos h2] at hNone; nomatch hNone
    · rw [if_neg h2] at hNone
      by_cases h3 : (!(projectG6CoreKey c56.g6Suite == c56.transitionBinding.toCoreKey)) = true
      · rw [if_pos h3] at hNone; nomatch hNone
      · rw [if_neg h3] at hNone
        have hG6Key : projectG6CoreKey c56.g6Suite = c56.transitionBinding.toCoreKey := by
          cases hb : (projectG6CoreKey c56.g6Suite == c56.transitionBinding.toCoreKey) with
          | true => exact eq_of_beq hb
          | false => simp [hb] at h3
        by_cases h4 : (!(c56.g6Suite.evaluationEpoch == c56.transitionBinding.assignedEvalEpoch)) = true
        · rw [if_pos h4] at hNone; nomatch hNone
        · rw [if_neg h4] at hNone
          have hEp : c56.g6Suite.evaluationEpoch = c56.transitionBinding.assignedEvalEpoch := by
            cases hb : (c56.g6Suite.evaluationEpoch == c56.transitionBinding.assignedEvalEpoch) with
            | true => exact eq_of_beq hb
            | false => simp [hb] at h4
          by_cases h5 :
              (!((c56.g5Cert.domOld == c56.transitionBinding.domOld) &&
                 (c56.g5Cert.guardsOld == c56.transitionBinding.guardsOld) &&
                 (c56.g5Cert.domNew == c56.transitionBinding.domNew) &&
                 (c56.g5Cert.guardsNew == c56.transitionBinding.guardsNew))) = true
          · rw [if_pos h5] at hNone; nomatch hNone
          · rw [if_neg h5] at hNone
            cases hBad :
                (c56.g6Suite.items.filter
                  (fun it => !checkG6ItemCarrierAlignedBool c56.transitionBinding it)).map
                  (·.invariantId) with
            | cons _ _ => rw [hBad] at hNone; nomatch hNone
            | nil =>
                rw [hBad] at hNone
                dsimp only at hNone
                by_cases h6 :
                    (!(projectG5Transition ⟨c56.g5Cert, c56.transitionBinding.assignedEvalEpoch⟩ ==
                      c56.transitionBinding)) = true
                · rw [if_pos h6] at hNone; nomatch hNone
                · rw [if_neg h6] at hNone
                  have hG5Tr :
                      projectG5Transition ⟨c56.g5Cert, c56.transitionBinding.assignedEvalEpoch⟩ =
                      c56.transitionBinding := by
                    cases hb : (projectG5Transition ⟨c56.g5Cert, c56.transitionBinding.assignedEvalEpoch⟩ ==
                        c56.transitionBinding) with
                    | true => exact eq_of_beq hb
                    | false => simp [hb] at h6
                  by_cases h7 : (!checkG56EvidenceManifestBool c56) = true
                  · rw [if_pos h7] at hNone; nomatch hNone
                  · have hEv : checkG56EvidenceManifestBool c56 = true := by
                      cases hb : checkG56EvidenceManifestBool c56 <;> simp_all
                    have hItemsOk :
                        ∀ item ∈ c56.g6Suite.items,
                          checkG6ItemCarrierAlignedBool c56.transitionBinding item = true := by
                      intro item hMem
                      cases hc : checkG6ItemCarrierAlignedBool c56.transitionBinding item with
                      | true => rfl
                      | false =>
                          have hInFilt : item ∈ c56.g6Suite.items.filter
                              (fun it => !checkG6ItemCarrierAlignedBool c56.transitionBinding it) :=
                            List.mem_filter.mpr ⟨hMem, by rw [hc]; rfl⟩
                          have hInMap : item.invariantId ∈
                              (c56.g6Suite.items.filter
                                (fun it => !checkG6ItemCarrierAlignedBool c56.transitionBinding it)).map
                                (·.invariantId) :=
                            List.mem_map_of_mem hInFilt
                          rw [hBad] at hInMap
                          nomatch hInMap
                    exact ⟨hHdr, hG5Tr, hG6Key, hEp, hItemsOk, hEv⟩

/-- **`T_I0_A6_G56_MasterConditionalSoundness` (`I0-A6` — Unified Master Theorem of `B3`)**. -/
theorem T_I0_A6_G56_MasterConditionalSoundness
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (hasLoss reqRet : Bool)
    (hVer  : checkG56Coupling ctx c56 = .g56Verified hasLoss reqRet)
    (hPrem : ∀ p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite,
               SemValidPrimId ctx.primEnv p) :
    let D5  := deriveG5PrimDeps ctx.primEnv ctx.dagCont c56.g5Cert
    let D6  := deriveG6PrimDeps ctx.primEnv ctx.dagCont c56.g6Suite
    let D56 := deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite
    let D7  := deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont c56.scopeCompatibility
    SyntacticValidPrimEnv ctx.primEnv ∧
    ValidContainer ctx.dagCont ∧
    c56.g6Suite.items ≠ [] ∧
    c56.claimedJointPrimDeps.g5PrimDepIds = D5 ∧
    c56.claimedJointPrimDeps.g6PrimDepIds = D6 ∧
    c56.claimedJointPrimDeps.jointPrimDepIds = D56 ∧
    (∀ p ∈ D7, p ∈ D56) ∧
    reqRet = c56.g5Cert.requiresRetreatHistory ∧
    hasLoss = c56.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) ∧
    reqRet = hasLoss ∧
    SemValidG56Coupling c56 := by
  dsimp only
  rcases unpack_g56Verified hVer with
    ⟨hEnv, hCont, hBindNone, hScopeNone, hG5Ok, hReqRetEq, hG6Ver,
     hd5Eq, hd6Eq, hd56Eq, _⟩
  rcases bindingDiag_none_implies_components hBindNone with
    ⟨hHdrB, hG5Proj, hG6Key, hG6Epoch, hItemCarriers, _⟩
  have hDist := (T_I0_A3_02_SemanticPremiseDistributionAndConfinement
    ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite
    (deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont c56.scopeCompatibility)).1.mp hPrem
  have hSemG5 : SemValidG5Discharge c56.g5Cert :=
    T_B1_07_CheckG5Discharge_MasterSoundness hEnv hCont hG5Ok hDist.1
  rcases T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness
      ctx.fuelG6 ctx.primEnv ctx.dagCont c56.g6Suite hasLoss hG6Ver hDist.2 with
    ⟨_, _, hItemsNonEmpty, _, _, hSemG6, hHasLossIff⟩
  have hHasLossEq : hasLoss = c56.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) := by
    cases hL : hasLoss with
    | true =>
        rcases hHasLossIff.mp hL with ⟨it, hitMem, hitSome⟩
        exact (List.any_eq_true.mpr ⟨it, hitMem, hitSome⟩).symm
    | false =>
        apply Eq.symm
        apply Bool.eq_false_iff.mpr
        intro hAny
        rcases List.any_eq_true.mp hAny with ⟨it, hitMem, hitSome⟩
        have hTrue := hHasLossIff.mpr ⟨it, hitMem, hitSome⟩
        rw [hL] at hTrue
        nomatch hTrue
  unfold checkG56CouplingHeaderBasicBool at hHdrB
  simp only [Bool.and_eq_true, beq_iff_eq, bne_iff_ne] at hHdrB
  rcases hHdrB with ⟨⟨⟨⟨⟨⟨⟨hVerStr, hCouplCid⟩, hBaseQ⟩, hRflxNe⟩, hCOldNe⟩, hCNewNe⟩, hSOldNe⟩, hSNewNe⟩
  have hCarrProps : ∀ item ∈ c56.g6Suite.items,
      item.specId = c56.transitionBinding.specNewId ∧
      item.oldNewState.specOldId = c56.transitionBinding.specOldId ∧
      item.oldNewState.specNewId = c56.transitionBinding.specNewId ∧
      item.oldNewState.domOld = c56.transitionBinding.domOld ∧
      item.oldNewState.guardsOld = c56.transitionBinding.guardsOld ∧
      item.oldNewState.domNew = c56.transitionBinding.domNew ∧
      item.oldNewState.guardsNew = c56.transitionBinding.guardsNew ∧
      item.protectedDomain = c56.transitionBinding.domNew ∧
      item.protectedGuards = c56.transitionBinding.guardsNew := by
    intro item hMem
    have hC := hItemCarriers item hMem
    unfold checkG6ItemCarrierAlignedBool at hC
    simp only [Bool.and_eq_true, beq_iff_eq] at hC
    exact ⟨hC.1.1.1.1.1.1.1.1, hC.1.1.1.1.1.1.1.2, hC.1.1.1.1.1.1.2,
           hC.1.1.1.1.1.2, hC.1.1.1.1.2, hC.1.1.1.2, hC.1.1.2, hC.1.2, hC.2⟩
  have hDomOldEq : c56.g5Cert.domOld = c56.transitionBinding.domOld :=
    congrArg G56TransitionBinding.domOld hG5Proj
  have hGuardsOldEq : c56.g5Cert.guardsOld = c56.transitionBinding.guardsOld :=
    congrArg G56TransitionBinding.guardsOld hG5Proj
  have hDomNewEq : c56.g5Cert.domNew = c56.transitionBinding.domNew :=
    congrArg G56TransitionBinding.domNew hG5Proj
  have hGuardsNewEq : c56.g5Cert.guardsNew = c56.transitionBinding.guardsNew :=
    congrArg G56TransitionBinding.guardsNew hG5Proj
  have hRkEq : c56.g5Cert.reflexKind = c56.transitionBinding.reflexKind :=
    congrArg G56TransitionBinding.reflexKind hG5Proj
  have hReqEqB : c56.g5Cert.requiresRetreatHistory = c56.transitionBinding.requiresRetreatHistory :=
    congrArg G56TransitionBinding.requiresRetreatHistory hG5Proj
  have hIsVer : isG56CouplingVerifiedBool ctx c56 = true := by
    unfold isG56CouplingVerifiedBool; rw [hVer]
  cases hRk : c56.transitionBinding.reflexKind with
  | repair =>
      unfold evalG56ScopeDiag at hScopeNone
      rw [hRk] at hScopeNone
      dsimp only at hScopeNone
      by_cases hFl : (!checkReflexRetreatFlagConsistentBool c56) = true
      · rw [if_pos hFl] at hScopeNone; nomatch hScopeNone
      · rw [if_neg hFl] at hScopeNone
        by_cases hMode : (!(c56.scopeCompatibility == .repairSameScope)) = true
        · rw [if_pos hMode] at hScopeNone; nomatch hScopeNone
        · rw [if_neg hMode] at hScopeNone
          have hScEq : c56.scopeCompatibility = .repairSameScope := by
            cases hb : (c56.scopeCompatibility == .repairSameScope) with
            | true => exact eq_of_beq hb
            | false => simp [hb] at hMode
          cases hBadPol :
              (c56.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) with
          | cons _ _ => rw [hBadPol] at hScopeNone; nomatch hScopeNone
          | nil =>
              have hItemPol : ∀ item ∈ c56.g6Suite.items, checkItemSameScopePolBool item = true := by
                intro item hMem
                cases hc : checkItemSameScopePolBool item with
                | true => rfl
                | false =>
                    have hInM : item.invariantId ∈
                        (c56.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) :=
                      List.mem_map_of_mem (List.mem_filter.mpr ⟨hMem, by rw [hc]; rfl⟩)
                    rw [hBadPol] at hInM; nomatch hInM
              have hBr := hSemG5.branchExactDischarge
              rw [hRkEq, hRk] at hBr
              rcases hBr with ⟨_, _, _, hReqF5, hSameDom5, _⟩
              rw [hDomOldEq, hGuardsOldEq, hDomNewEq, hGuardsNewEq] at hSameDom5
              have hReqF : c56.transitionBinding.requiresRetreatHistory = false :=
                hReqEqB.symm.trans hReqF5
              have hAllNoLoss : ∀ item ∈ c56.g6Suite.items,
                  IsNonShrinkingG6Policy item.oldNewState.scopePolicy ∧
                  item.scopeLossRecord? = none := by
                intro item hMem
                have hp := hItemPol item hMem
                unfold checkItemSameScopePolBool at hp
                simp only [Bool.and_eq_true] at hp
                refine ⟨?_, Option.isNone_iff_eq_none.mp hp.1⟩
                cases hPol : item.oldNewState.scopePolicy <;> rw [hPol] at hp <;>
                  simp_all [IsNonShrinkingG6Policy]
              have hAnyFalse : c56.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) = false := by
                apply Bool.eq_false_iff.mpr
                intro hAny
                rcases List.any_eq_true.mp hAny with ⟨it, hitM, hitS⟩
                rw [(hAllNoLoss it hitM).2] at hitS
                nomatch hitS
              have hD7Sub : ∀ p ∈ deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont c56.scopeCompatibility,
                  p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite := by
                rw [hScEq]
                intro p hp
                unfold deriveScopeCompatL1PrimDeps collectScopeCompatLossRootIds
                  multiRootTransitivePrimDeps canonSortStrs at hp
                nomatch hp
              refine ⟨hEnv, hCont, hItemsNonEmpty, hd5Eq, hd6Eq, hd56Eq, hD7Sub,
                      hReqRetEq, hHasLossEq, ?_, ?_⟩
              · rw [hReqRetEq, hReqF5, hHasLossEq, hAnyFalse]
              · refine {
                  canonicalCouplingHeader := ⟨hVerStr, hCouplCid⟩
                  validTransitionBinding  := {
                    canonicalNonEmptyIds     := ⟨hBaseQ, hRflxNe, hCOldNe, hCNewNe, hSOldNe, hSNewNe⟩
                    g5ProjectsToBinding      := hG5Proj
                    g6RelationallyCompatible := by
                      unfold G6TransitionCompatibleRel
                      rw [hRk]
                      exact ⟨hG6Key, hG6Epoch, hItemsNonEmpty, hCarrProps, hReqF,
                             fun it hm => (hAllNoLoss it hm).2⟩
                  }
                  validG5Discharge        := hSemG5
                  validG6ProtectedSuite   := hSemG6
                  compatibleScopeAndLoss  := by
                    unfold SemCompatibleG56Scope
                    rw [hRk, hScEq]
                    exact ⟨hReqF, hSameDom5, hAllNoLoss⟩
                }
  | refinement =>
      unfold evalG56ScopeDiag at hScopeNone
      rw [hRk] at hScopeNone
      dsimp only at hScopeNone
      have hBr := hSemG5.branchExactDischarge
      rw [hRkEq, hRk] at hBr
      rcases hBr with ⟨_, _, hReqF5, hRefMatch⟩
      have hReqF : c56.transitionBinding.requiresRetreatHistory = false :=
        hReqEqB.symm.trans hReqF5
      cases hRf : c56.g5Cert.refinementCert? with
      | none => rw [hRf] at hRefMatch; exact False.elim hRefMatch
      | some rf =>
          rw [hRf] at hRefMatch
          dsimp only at hRefMatch
          rcases hRefMatch with ⟨hInclDom, _, hExpIf, _⟩
          rw [hDomOldEq, hGuardsOldEq, hDomNewEq, hGuardsNewEq] at hInclDom hExpIf
          cases hSc : c56.scopeCompatibility <;> rw [hSc] at hScopeNone
          case repairSameScope =>
            dsimp only at hScopeNone
            split at hScopeNone <;> nomatch hScopeNone
          case retreatExactSharedLoss =>
            dsimp only at hScopeNone
            split at hScopeNone <;> nomatch hScopeNone
          case refinementSameScope =>
            dsimp only at hScopeNone
            rw [hRf] at hScopeNone
            dsimp only at hScopeNone
            by_cases hFl : (!checkReflexRetreatFlagConsistentBool c56) = true
            · rw [if_pos hFl] at hScopeNone; nomatch hScopeNone
            · rw [if_neg hFl] at hScopeNone
              cases hExpB : rf.scopeExpanded <;> simp only [hExpB, Bool.not_true, Bool.not_false, Bool.false_eq_true, ↓reduceIte] at hScopeNone hExpIf
              case true =>
                nomatch hScopeNone
              case false =>
                cases hBadPol :
                    (c56.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) with
                | cons _ _ => rw [hBadPol] at hScopeNone; nomatch hScopeNone
                | nil =>
                    have hAllNoLoss : ∀ item ∈ c56.g6Suite.items,
                        IsNonShrinkingG6Policy item.oldNewState.scopePolicy ∧
                        item.scopeLossRecord? = none := by
                      intro item hMem
                      cases hc : checkItemSameScopePolBool item with
                      | false =>
                          have hInM : item.invariantId ∈
                              (c56.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) :=
                            List.mem_map_of_mem (List.mem_filter.mpr ⟨hMem, by rw [hc]; rfl⟩)
                          rw [hBadPol] at hInM; nomatch hInM
                      | true =>
                          unfold checkItemSameScopePolBool at hc
                          simp only [Bool.and_eq_true] at hc
                          refine ⟨?_, Option.isNone_iff_eq_none.mp hc.1⟩
                          cases hPol : item.oldNewState.scopePolicy <;> rw [hPol] at hc <;>
                            simp_all [IsNonShrinkingG6Policy]
                    have hAnyFalse : c56.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) = false := by
                      apply Bool.eq_false_iff.mpr
                      intro hAny
                      rcases List.any_eq_true.mp hAny with ⟨it, hitM, hitS⟩
                      rw [(hAllNoLoss it hitM).2] at hitS; nomatch hitS
                    have hD7Sub : ∀ p ∈ deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont .refinementSameScope,
                        p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite := by
                      intro p hp
                      unfold deriveScopeCompatL1PrimDeps collectScopeCompatLossRootIds
                        multiRootTransitivePrimDeps canonSortStrs at hp
                      nomatch hp
                    refine ⟨hEnv, hCont, hItemsNonEmpty, hd5Eq, hd6Eq, hd56Eq, hD7Sub,
                            hReqRetEq, hHasLossEq, ?_, ?_⟩
                    · rw [hReqRetEq, hReqF5, hHasLossEq, hAnyFalse]
                    · refine {
                        canonicalCouplingHeader := ⟨hVerStr, hCouplCid⟩
                        validTransitionBinding  := {
                          canonicalNonEmptyIds     := ⟨hBaseQ, hRflxNe, hCOldNe, hCNewNe, hSOldNe, hSNewNe⟩
                          g5ProjectsToBinding      := hG5Proj
                          g6RelationallyCompatible := by
                            unfold G6TransitionCompatibleRel; rw [hRk]
                            exact ⟨hG6Key, hG6Epoch, hItemsNonEmpty, hCarrProps, hReqF,
                                   fun it hm => (hAllNoLoss it hm).2⟩
                        }
                        validG5Discharge        := hSemG5
                        validG6ProtectedSuite   := hSemG6
                        compatibleScopeAndLoss  := by
                          unfold SemCompatibleG56Scope; rw [hRk, hSc, hRf]
                          exact ⟨hReqF, ⟨rf, List.mem_cons_self .., hExpB⟩, hExpIf.2, hAllNoLoss⟩
                      }
          case refinementExpandedScope =>
            dsimp only at hScopeNone
            rw [hRf] at hScopeNone
            dsimp only at hScopeNone
            by_cases hFl : (!checkReflexRetreatFlagConsistentBool c56) = true
            · rw [if_pos hFl] at hScopeNone; nomatch hScopeNone
            · rw [if_neg hFl] at hScopeNone
              cases hExpB : rf.scopeExpanded <;> simp only [hExpB, Bool.false_eq_true, ↓reduceIte] at hScopeNone hExpIf
              case false =>
                nomatch hScopeNone
              case true =>
                rcases hExpIf with ⟨pt_exp, _, _, _, hPtInNew, hPtNotOld⟩
                cases hBadPol :
                    (c56.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId) with
                | cons _ _ => rw [hBadPol] at hScopeNone; nomatch hScopeNone
                | nil =>
                    have hAllExp : ∀ item ∈ c56.g6Suite.items,
                        item.scopeLossRecord? = none ∧
                        ∃ step oldDef o2n n2o pt_w,
                          item.oldNewState.scopePolicy =
                            .oldScopeInclusion step oldDef o2n n2o true (some pt_w) := by
                      intro item hMem
                      cases hc : checkItemExpandedScopePolBool item with
                      | false =>
                          have hInM : item.invariantId ∈
                              (c56.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId) :=
                            List.mem_map_of_mem (List.mem_filter.mpr ⟨hMem, by rw [hc]; rfl⟩)
                          rw [hBadPol] at hInM; nomatch hInM
                      | true =>
                          unfold checkItemExpandedScopePolBool at hc
                          simp only [Bool.and_eq_true] at hc
                          refine ⟨Option.isNone_iff_eq_none.mp hc.1, ?_⟩
                          cases hPol : item.oldNewState.scopePolicy with
                          | globalPostSameDom _ => rw [hPol] at hc; nomatch hc.2
                          | retreatWithLossAccounting => rw [hPol] at hc; nomatch hc.2
                          | oldScopeInclusion stp od o2n n2o se ew =>
                              rw [hPol] at hc
                              cases se with
                              | false => nomatch hc.2
                              | true =>
                                  cases ew with
                                  | none => nomatch hc.2
                                  | some ptw => exact ⟨stp, od, o2n, n2o, ptw, rfl⟩
                    have hAnyFalse : c56.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) = false := by
                      apply Bool.eq_false_iff.mpr
                      intro hAny
                      rcases List.any_eq_true.mp hAny with ⟨it, hitM, hitS⟩
                      rw [(hAllExp it hitM).1] at hitS; nomatch hitS
                    have hD7Sub : ∀ p ∈ deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont .refinementExpandedScope,
                        p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite := by
                      intro p hp
                      unfold deriveScopeCompatL1PrimDeps collectScopeCompatLossRootIds
                        multiRootTransitivePrimDeps canonSortStrs at hp
                      nomatch hp
                    refine ⟨hEnv, hCont, hItemsNonEmpty, hd5Eq, hd6Eq, hd56Eq, hD7Sub,
                            hReqRetEq, hHasLossEq, ?_, ?_⟩
                    · rw [hReqRetEq, hReqF5, hHasLossEq, hAnyFalse]
                    · refine {
                        canonicalCouplingHeader := ⟨hVerStr, hCouplCid⟩
                        validTransitionBinding  := {
                          canonicalNonEmptyIds     := ⟨hBaseQ, hRflxNe, hCOldNe, hCNewNe, hSOldNe, hSNewNe⟩
                          g5ProjectsToBinding      := hG5Proj
                          g6RelationallyCompatible := by
                            unfold G6TransitionCompatibleRel; rw [hRk]
                            exact ⟨hG6Key, hG6Epoch, hItemsNonEmpty, hCarrProps, hReqF,
                                   fun it hm => (hAllExp it hm).1⟩
                        }
                        validG5Discharge        := hSemG5
                        validG6ProtectedSuite   := hSemG6
                        compatibleScopeAndLoss  := by
                          unfold SemCompatibleG56Scope; rw [hRk, hSc, hRf]
                          exact ⟨hReqF, ⟨rf, List.mem_cons_self .., hExpB⟩, hInclDom,
                                 ⟨ratCoordToEnv2 pt_exp, hPtInNew, hPtNotOld⟩, hAllExp⟩
                      }
  | retreat =>
      rcases T_I0_A4_05_TopLevelForcesConstrainedL1Path ctx c56 hIsVer hRk with
        ⟨Φ_shared, itemBinds, rt5, hScEq, hRt5Eq, hRtLocEq, hConstrTrue⟩
      rcases T_I0_A4_03_MultiItemConstrainedLossEquiv_CompleteSuiteSound
          ctx.fuelG6 ctx.primEnv ctx.dagCont
          c56.transitionBinding.domOld c56.transitionBinding.guardsOld
          c56.transitionBinding.specNewId Φ_shared c56.g6Suite.items itemBinds
          (deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite)
          hCont hConstrTrue hPrem with
        ⟨hBindsMapEq, hD7Sub', hItemsAllSound⟩
      have hD7Sub : ∀ p ∈ deriveScopeCompatL1PrimDeps ctx.primEnv ctx.dagCont c56.scopeCompatibility,
          p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite := by
        rw [hScEq]; exact hD7Sub'
      have hBr := hSemG5.branchExactDischarge
      rw [hRkEq, hRk] at hBr
      rcases hBr with ⟨_, _, hReqT5, hRetBody⟩
      rw [hRt5Eq] at hRetBody
      dsimp only at hRetBody
      rcases hRetBody with ⟨_, _, hPart5, _⟩
      rw [hDomOldEq, hGuardsOldEq, hDomNewEq, hGuardsNewEq, hRtLocEq] at hPart5
      have hReqT : c56.transitionBinding.requiresRetreatHistory = true :=
        hReqEqB.symm.trans hReqT5
      have hAnyTrue : c56.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) = true := by
        cases hIts : c56.g6Suite.items with
        | nil => exact False.elim (hItemsNonEmpty hIts)
        | cons it0 rest =>
            apply List.any_eq_true.mpr
            rcases hItemsAllSound it0 (by rw [hIts]; exact List.mem_cons_self ..) with
              ⟨_, lr0, hlr0, _⟩
            exact ⟨it0, List.mem_cons_self .., by rw [hlr0]; rfl⟩
      refine ⟨hEnv, hCont, hItemsNonEmpty, hd5Eq, hd6Eq, hd56Eq, hD7Sub,
              hReqRetEq, hHasLossEq, ?_, ?_⟩
      · rw [hReqRetEq, hReqT5, hHasLossEq, hAnyTrue]
      · refine {
          canonicalCouplingHeader := ⟨hVerStr, hCouplCid⟩
          validTransitionBinding  := {
            canonicalNonEmptyIds     := ⟨hBaseQ, hRflxNe, hCOldNe, hCNewNe, hSOldNe, hSNewNe⟩
            g5ProjectsToBinding      := hG5Proj
            g6RelationallyCompatible := by
              unfold G6TransitionCompatibleRel; rw [hRk]
              refine ⟨hG6Key, hG6Epoch, hItemsNonEmpty, hCarrProps, hReqT, ?_⟩
              intro item hMem
              rcases hItemsAllSound item hMem with ⟨hPol, lr6, hLr6, _⟩
              exact ⟨hPol, by rw [hLr6]; intro h; nomatch h⟩
          }
          validG5Discharge        := hSemG5
          validG6ProtectedSuite   := hSemG6
          compatibleScopeAndLoss  := by
            unfold SemCompatibleG56Scope; rw [hRk, hScEq]
            exact ⟨hReqT, hBindsMapEq, hPart5, ⟨rt5, hRt5Eq, hRtLocEq⟩, hItemsAllSound⟩
        }

end OmegaCellC1P1B2BB3
