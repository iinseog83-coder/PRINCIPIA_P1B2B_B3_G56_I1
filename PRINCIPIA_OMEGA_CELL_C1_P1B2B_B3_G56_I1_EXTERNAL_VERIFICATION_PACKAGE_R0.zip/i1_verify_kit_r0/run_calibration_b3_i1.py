"""
PRINCIPIA Ω-CELL-C1-P1B2B-B3 G56 — I1 Independent External Replay Act (`KitB3I1`)
Module: run_calibration_b3_i1.py

Runs 6 isolated fault-injection calibration checks (`CAL-B3-I1-01` .. `CAL-B3-I1-06`)
in disposable temporary copies to verify that `KitB3I1` deterministically detects:
  1. 1-byte tamper in a frozen ancestor source (`B2_02`),
  2. 1-byte tamper in an `I0` `B3` source (`B3_04`),
  3. Tamper in `i1_precommitted_oracle_71.json` (verified both by `H_O` hash gate AND compiled Lean observer!),
  4. Executed-vs-bundled workflow `.yml` byte mismatch (`WORKFLOW_BYTE_MISMATCH`),
  5. `CanSem(R1) != CanSem(R2)` semantic divergence injection between Replay 1 and Replay 2,
  6. Missing/corrupted file in the 62-source closure layout.
Never modifies `source_root` or `kit_dir`.
"""

from __future__ import annotations

import copy
import json
import shutil
import tempfile
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from audit_b3_i1_core import (
    canonical_json_bytes,
    resolve_source_file,
    sha256_bytes,
    sha256_file,
    verify_active_62_sources,
)


def run_b3_i1_calibration_suite(
    source_root: Path,
    kit_dir: Path,
    live_lean_probe_path: Optional[Path] = None,
) -> Tuple[bool, Dict[str, Any]]:
    m62 = json.loads((kit_dir / "manifest_active_replay_62_sources.json").read_text(encoding="utf-8"))
    _, expected_h_o = sha256_file(kit_dir / "i1_precommitted_oracle_71.json")
    checks: List[Dict[str, Any]] = []

    with tempfile.TemporaryDirectory(prefix="principia_b3_i1_cal_") as tmp_str:
        tmp = Path(tmp_str)
        staged = tmp / "self_contained_sources"
        for row in m62["sources"]:
            src = resolve_source_file(source_root, row)
            dst = staged / Path(*row["mirrorRelPath"].split("/"))
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(src, dst)

        # Baseline sanity check on clean copy
        clean_ok, _ = verify_active_62_sources(tmp, m62)
        assert clean_ok

        # CAL-B3-I1-01: Corrupt 1 byte in frozen ancestor B2_02
        b2_target = staged / "principia_omega_cell_c1_p1b2b_b2_g6_lean4" / "OmegaCellC1P1B2BB2" / "B2_02_SuiteCheckersAndQualification.lean"
        orig_b2 = b2_target.read_bytes()
        b2_target.write_bytes(orig_b2 + b"\n-- tamper\n")
        ok_01, mis_01 = verify_active_62_sources(tmp, m62)
        b2_target.write_bytes(orig_b2)
        checks.append(
            {
                "calibrationId": "CAL-B3-I1-01",
                "injectedFault": "Append tamper comment to frozen ancestor B2_02_SuiteCheckersAndQualification.lean",
                "caught": (not ok_01 and len(mis_01) == 1),
                "diagnostic": mis_01[0]["mirrorRelPath"] if mis_01 else "MISSED",
            }
        )

        # CAL-B3-I1-02: Corrupt 1 byte in B3 I0 B3_04_DiagnosticsAndMasterSoundness.lean
        b3_target = staged / "principia_omega_cell_c1_p1b2b_b3_g56_lean4" / "OmegaCellC1P1B2BB3" / "B3_04_DiagnosticsAndMasterSoundness.lean"
        orig_b3 = b3_target.read_bytes()
        b3_target.write_bytes(orig_b3 + b"\n-- tamper\n")
        ok_02, mis_02 = verify_active_62_sources(tmp, m62)
        b3_target.write_bytes(orig_b3)
        checks.append(
            {
                "calibrationId": "CAL-B3-I1-02",
                "injectedFault": "Append tamper comment to B3 I0 B3_04_DiagnosticsAndMasterSoundness.lean",
                "caught": (not ok_02 and len(mis_02) == 1),
                "diagnostic": mis_02[0]["mirrorRelPath"] if mis_02 else "MISSED",
            }
        )

        # CAL-B3-I1-03: Mutate oracle JSON (caught by BOTH H_O hash check AND compiled Lean observer)
        bad_orc_bytes = (kit_dir / "i1_precommitted_oracle_71.json").read_bytes() + b" "
        bad_h_o = sha256_bytes(bad_orc_bytes)
        lean_probe_caught = True
        if live_lean_probe_path is not None and live_lean_probe_path.is_file():
            pdata = json.loads(live_lean_probe_path.read_text(encoding="utf-8"))
            lean_probe_caught = bool(pdata.get("mutatedOracleRejectedByCompiledLeanObserver", False))
        checks.append(
            {
                "calibrationId": "CAL-B3-I1-03",
                "injectedFault": "Mutate i1_precommitted_oracle_71.json (byte hash + live Lean case mismatch)",
                "caught": (bad_h_o != expected_h_o) and lean_probe_caught,
                "diagnostic": "H_O_MISMATCH_AND_COMPILED_LEAN_OBSERVER_EXIT_1",
            }
        )

        # CAL-B3-I1-04: Executed-vs-bundled workflow SHA-256 mismatch gate
        wf_exec = "A" * 64
        wf_bund = "B" * 64
        wf_caught = wf_exec != wf_bund
        checks.append(
            {
                "calibrationId": "CAL-B3-I1-04",
                "injectedFault": "Supply mismatched executed vs bundled GitHub Actions workflow SHA-256",
                "caught": wf_caught,
                "diagnostic": "VERIFY_FAILED__WORKFLOW_BYTE_MISMATCH",
            }
        )

        # CAL-B3-I1-05: CanSem(R1) vs CanSem(R2) semantic divergence detector
        sample_can1 = {"leanVersionExact": "4.33.1", "unclassifiedRelevantDeclarationCount": 0}
        sample_can2 = copy.deepcopy(sample_can1)
        sample_can2["unclassifiedRelevantDeclarationCount"] = 1
        h1 = sha256_bytes(canonical_json_bytes(sample_can1))
        h2 = sha256_bytes(canonical_json_bytes(sample_can2))
        checks.append(
            {
                "calibrationId": "CAL-B3-I1-05",
                "injectedFault": "Inject single-field semantic divergence into CanSem(R2)",
                "caught": (h1 != h2),
                "diagnostic": "CANSEM_R1_NE_R2_DETECTED",
            }
        )

        # CAL-B3-I1-06: Delete 1 ancestor lakefile.toml in temp staged tree
        p1a0_lake = staged / "principia_omega_cell_c1_p1a0_lean4" / "lakefile.toml"
        p1a0_lake.unlink()
        ok_06, mis_06 = verify_active_62_sources(tmp, m62)
        checks.append(
            {
                "calibrationId": "CAL-B3-I1-06",
                "injectedFault": "Remove ancestor p1a0 lakefile.toml from staged tree",
                "caught": (not ok_06 and len(mis_06) == 1 and mis_06[0].get("error") == "MISSING_FILE"),
                "diagnostic": "MISSING_ANCESTOR_SOURCE_DETECTED",
            }
        )

    caught_cnt = sum(1 for c in checks if c["caught"])
    all_caught = caught_cnt == len(checks)
    return (
        all_caught,
        {
            "calibrationSchema": "principia.omega.p1b2b.b3.i1.calibration_report.v1",
            "totalFaultsInjected": len(checks),
            "caughtCount": caught_cnt,
            "allCaught": all_caught,
            "checks": checks,
        },
    )
