/-
  PRINCIPIA Ω-CELL-C1-P1A0 — Isolated Minimal Whitebox Type Kernel
  Module: OmegaCellC1P1A0.P1A0B_TransportScopeLoss (Stage P1A0-B)

  Authorization Scope (`PRINCIPIA_OMEGA_CELL_C1_P1A0_R1` Conditionally Authorized — Stage P1A0-B):
    1. Base-Commuting `SemanticTransport` over `CertifiedChartAnchor`s (`F-C1-R1-01`, `F-A0-01`):
       Partial bijection `f : {x : D1 // retDom x} ≃ {y : D2 // imgDom y}` commuting with semantic
       base projections (`anch2.j (f x).1 = anch1.j x.1`), plus `ValidRepairTransport`,
       `ValidRetreatTransport`, and `ValidRefinementSection`.
    2. Identity Transport, Partial Composition `composeSemanticTransport`, & Base-Anchored
       `ScopeLoss_B` (`T-A0-01`, `T-A0-02`, `T-A0-03` transport-level No-Go):
       Proves base commutativity and observable preservation across composition (`T-A0-01`),
       proves monotone non-decreasing `ScopeLoss_B` and `Retreat` irreversibility (`T-A0-02` /
       `CE-C1-02`), proves non-existence of `ValidRepairTransport` from `ℚ` to `ℚ \ {0}` (`T-A0-03`),
       and constructs the exact 2-step `Retreat → Refinement` re-expansion path `g0(ℚ) → g1(ℚ\{0}) → g2(ℚ)`
       with indelible `HistoricalScopeLoss_B = {0}` (`F-A0-03` setup for `T-A0-08`).

  Explicitly Excluded (`NOT AUTHORIZED` / `FROZEN` / `HELD`):
    - Zero imports from `GPED-MINCORE-0`; sheafs, general functoriality, holonomy, and homotopy
      invariance are not claimed.
-/
import OmegaCellC1P1A0.P1A0A_BaseChartGuard

namespace OmegaCellC1P1A0

/-! ### 1. Base-Commuting `SemanticTransport` & `ReflexKind` Laws -/

/-- Partial domain bijection between two certified chart anchors over a shared `(reg, baseId)`
    that commutes strictly with the semantic base projections (`j_2(f(x)) = j_1(x)`). -/
structure SemanticTransport {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId1 domId2 : String}
    {D1 D2 : Type}
    (anch1 : CertifiedChartAnchor reg baseId domId1 D1)
    (anch2 : CertifiedChartAnchor reg baseId domId2 D2) where
  retDom    : D1 → Prop
  imgDom    : D2 → Prop
  toFun     : { x : D1 // retDom x } → { y : D2 // imgDom y }
  invFun    : { y : D2 // imgDom y } → { x : D1 // retDom x }
  left_inv  : ∀ x, invFun (toFun x) = x
  right_inv : ∀ y, toFun (invFun y) = y
  base_comm : ∀ x : { x : D1 // retDom x }, anch2.j (toFun x).1 = anch1.j x.1

/-- Two certified anchors over the same `(reg, baseId)` necessarily share the exact `SemanticBase`. -/
theorem certifiedAnchor_same_base {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId1 domId2 : String}
    {D1 D2 : Type}
    (anch1 : CertifiedChartAnchor reg baseId domId1 D1)
    (anch2 : CertifiedChartAnchor reg baseId domId2 D2) :
    anch1.base = anch2.base := by
  have h1 := anch1.base_pinned
  have h2 := anch2.base_pinned
  rw [h1] at h2
  injection h2

/-- Every `SemanticTransport` preserves all pinned domain observables across `toFun`. -/
theorem semanticTransport_preserves_obs {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId1 domId2 : String}
    {D1 D2 : Type}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ : SemanticTransport anch1 anch2)
    (i : ObsIdx) (x : { x : D1 // τ.retDom x }) :
    anch2.domSpec.obsD i (τ.toFun x).1 ↔ anch1.domSpec.obsD i x.1 := by
  have hbase : anch1.base = anch2.base := certifiedAnchor_same_base anch1 anch2
  rw [anch2.preserves i (τ.toFun x).1, τ.base_comm x, ← hbase, ← anch1.preserves i x.1]

/-- `Repair` law: full source retention (`retDom = D1`) and full target coverage (`imgDom = D2`). -/
def ValidRepairTransport {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId1 domId2 : String}
    {D1 D2 : Type}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ : SemanticTransport anch1 anch2) : Prop :=
  (∀ x : D1, τ.retDom x) ∧ (∀ y : D2, τ.imgDom y)

/-- `Retreat` law: strict source excision (`∃ xLost, ¬retDom xLost`) with exact image target (`imgDom = D2`). -/
def ValidRetreatTransport {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId1 domId2 : String}
    {D1 D2 : Type}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ : SemanticTransport anch1 anch2) : Prop :=
  (∃ xLost : D1, ¬ τ.retDom xLost) ∧ (∀ y : D2, τ.imgDom y)

/-- `Refinement` section law: full source embedding (`∀ x, retDom x`) into a potentially larger `D2`. -/
def ValidRefinementSection {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId1 domId2 : String}
    {D1 D2 : Type}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ : SemanticTransport anch1 anch2) : Prop :=
  ∀ x : D1, τ.retDom x

/-- Injectivity predicate for coordinate charts `j : D → B`. -/
def ChartInjective {B D : Type} (j : D → B) : Prop :=
  ∀ x1 x2 : D, j x1 = j x2 → x1 = x2

/-- Base-anchored scope loss `j(D) \ j(retDom) ⊆ B` (`F-C1-R1-01`). -/
def ScopeLoss_B {B D : Type} (j : D → B) (retDom : D → Prop) (b : B) : Prop :=
  (∃ x : D, j x = b) ∧ ¬ (∃ x : D, retDom x ∧ j x = b)

/-- Under `ChartInjective j`, `ScopeLoss_B j retDom (j x)` holds iff `¬ retDom x`. -/
theorem scopeLoss_B_chart_iff {B D : Type} {j : D → B} (hinj : ChartInjective j)
    (retDom : D → Prop) (x : D) :
    ScopeLoss_B j retDom (j x) ↔ ¬ retDom x := by
  constructor
  · intro hloss hret
    exact hloss.2 ⟨x, hret, rfl⟩
  · intro hnot
    refine ⟨⟨x, rfl⟩, ?_⟩
    rintro ⟨x', hret', hj⟩
    have heq : x' = x := hinj x' x hj
    subst heq
    exact hnot hret'

/-- **`T-A0-03` (Transport-Level Statement)** — No `ValidRepairTransport` Exists from `ℚ` to `ℚ \ {0}`:
    Even though `ℚ ≃ ℚ \ {0}` via `hilbertRatToNonzero`, NO `SemanticTransport` between
    `ratFullCertifiedAnchor` and `ratNonzeroCertifiedAnchor` can satisfy `ValidRepairTransport`. -/
theorem T_A0_03_no_ValidRepairTransport_Q_to_QNonzero :
    ¬ ∃ τ : SemanticTransport ratFullCertifiedAnchor ratNonzeroCertifiedAnchor,
        ValidRepairTransport τ := by
  rintro ⟨τ, hrep⟩
  let f : Rat → RatNonzero := fun x => (τ.toFun ⟨x, hrep.1 x⟩).1
  have hcomm : ∀ x : Rat, ratSubspaceChart (f x) = ratIdChart x :=
    fun x => τ.base_comm ⟨x, hrep.1 x⟩
  exact T_A0_03_hilbert_bijection_exists_yet_no_base_commuting_map.2 ⟨f, hcomm⟩

/-! ### 2. Identity Transport, Partial Composition `composeSemanticTransport`, & `T-A0-01` / `T-A0-02` -/

/-- Identity `SemanticTransport` on a certified anchor. -/
def idSemanticTransport {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId : String} {D : Type}
    (anch : CertifiedChartAnchor reg baseId domId D) :
    SemanticTransport anch anch where
  retDom    := fun _ => True
  imgDom    := fun _ => True
  toFun     := fun x => ⟨x.1, trivial⟩
  invFun    := fun y => ⟨y.1, trivial⟩
  left_inv  := fun _ => Subtype.ext rfl
  right_inv := fun _ => Subtype.ext rfl
  base_comm := fun _ => rfl

/-- Inherited pullback domain `D_inh(τ2 ∘ τ1) = f1⁻¹(D_img1 ∩ D_ret2) ⊆ D0`. -/
def CompRetDom {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId0 domId1 domId2 : String}
    {D0 D1 D2 : Type}
    {anch0 : CertifiedChartAnchor reg baseId domId0 D0}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ1 : SemanticTransport anch0 anch1)
    (τ2 : SemanticTransport anch1 anch2) (x : D0) : Prop :=
  ∃ hx1 : τ1.retDom x, τ2.retDom (τ1.toFun ⟨x, hx1⟩).1

/-- Pushforward image domain `D_img(τ2 ∘ τ1) = f2(D_img1 ∩ D_ret2) ⊆ D2`. -/
def CompImgDom {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId0 domId1 domId2 : String}
    {D0 D1 D2 : Type}
    {anch0 : CertifiedChartAnchor reg baseId domId0 D0}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ1 : SemanticTransport anch0 anch1)
    (τ2 : SemanticTransport anch1 anch2) (z : D2) : Prop :=
  ∃ hz2 : τ2.imgDom z, τ1.imgDom (τ2.invFun ⟨z, hz2⟩).1

/-- Partial composition of two base-anchored `SemanticTransport`s over a common `(reg, baseId)`. -/
def composeSemanticTransport {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId0 domId1 domId2 : String}
    {D0 D1 D2 : Type}
    {anch0 : CertifiedChartAnchor reg baseId domId0 D0}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ1 : SemanticTransport anch0 anch1)
    (τ2 : SemanticTransport anch1 anch2) :
    SemanticTransport anch0 anch2 where
  retDom := CompRetDom τ1 τ2
  imgDom := CompImgDom τ1 τ2
  toFun u :=
    let hx1 : τ1.retDom u.1 := u.2.1
    let hx2 : τ2.retDom (τ1.toFun ⟨u.1, hx1⟩).1 := u.2.2
    let y1 := τ1.toFun ⟨u.1, hx1⟩
    let z2 := τ2.toFun ⟨y1.1, hx2⟩
    ⟨z2.1, ⟨z2.2, by
      have hleft := τ2.left_inv ⟨y1.1, hx2⟩
      have hval : (τ2.invFun ⟨z2.1, z2.2⟩).1 = y1.1 := congrArg Subtype.val hleft
      rw [hval]
      exact y1.2⟩⟩
  invFun v :=
    let hz2 : τ2.imgDom v.1 := v.2.1
    let hy1 : τ1.imgDom (τ2.invFun ⟨v.1, hz2⟩).1 := v.2.2
    let y1 := τ2.invFun ⟨v.1, hz2⟩
    let x0 := τ1.invFun ⟨y1.1, hy1⟩
    ⟨x0.1, ⟨x0.2, by
      have hright := τ1.right_inv ⟨y1.1, hy1⟩
      have hval : (τ1.toFun ⟨x0.1, x0.2⟩).1 = y1.1 := congrArg Subtype.val hright
      rw [hval]
      exact y1.2⟩⟩
  left_inv u := by
    apply Subtype.ext
    dsimp only
    have h2 := congrArg Subtype.val (τ2.left_inv ⟨(τ1.toFun ⟨u.1, u.2.1⟩).1, u.2.2⟩)
    have hsub :
        (⟨(τ2.invFun ⟨(τ2.toFun ⟨(τ1.toFun ⟨u.1, u.2.1⟩).1, u.2.2⟩).1,
          (τ2.toFun ⟨(τ1.toFun ⟨u.1, u.2.1⟩).1, u.2.2⟩).2⟩).1,
          by
            have hleft := τ2.left_inv ⟨(τ1.toFun ⟨u.1, u.2.1⟩).1, u.2.2⟩
            have hval : (τ2.invFun ⟨(τ2.toFun ⟨(τ1.toFun ⟨u.1, u.2.1⟩).1, u.2.2⟩).1,
              (τ2.toFun ⟨(τ1.toFun ⟨u.1, u.2.1⟩).1, u.2.2⟩).2⟩).1 =
                (τ1.toFun ⟨u.1, u.2.1⟩).1 := congrArg Subtype.val hleft
            rw [hval]
            exact (τ1.toFun ⟨u.1, u.2.1⟩).2⟩ : { y : D1 // τ1.imgDom y }) =
        τ1.toFun ⟨u.1, u.2.1⟩ := Subtype.ext h2
    rw [hsub]
    exact congrArg Subtype.val (τ1.left_inv ⟨u.1, u.2.1⟩)
  right_inv v := by
    apply Subtype.ext
    dsimp only
    have h1 := congrArg Subtype.val (τ1.right_inv ⟨(τ2.invFun ⟨v.1, v.2.1⟩).1, v.2.2⟩)
    have hsub :
        (⟨(τ1.toFun ⟨(τ1.invFun ⟨(τ2.invFun ⟨v.1, v.2.1⟩).1, v.2.2⟩).1,
          (τ1.invFun ⟨(τ2.invFun ⟨v.1, v.2.1⟩).1, v.2.2⟩).2⟩).1,
          by
            have hright := τ1.right_inv ⟨(τ2.invFun ⟨v.1, v.2.1⟩).1, v.2.2⟩
            have hval : (τ1.toFun ⟨(τ1.invFun ⟨(τ2.invFun ⟨v.1, v.2.1⟩).1, v.2.2⟩).1,
              (τ1.invFun ⟨(τ2.invFun ⟨v.1, v.2.1⟩).1, v.2.2⟩).2⟩).1 =
                (τ2.invFun ⟨v.1, v.2.1⟩).1 := congrArg Subtype.val hright
            rw [hval]
            exact (τ2.invFun ⟨v.1, v.2.1⟩).2⟩ : { y : D1 // τ2.retDom y }) =
        τ2.invFun ⟨v.1, v.2.1⟩ := Subtype.ext h1
    rw [hsub]
    exact congrArg Subtype.val (τ2.right_inv ⟨v.1, v.2.1⟩)
  base_comm u := by
    dsimp only
    rw [τ2.base_comm ⟨(τ1.toFun ⟨u.1, u.2.1⟩).1, u.2.2⟩]
    exact τ1.base_comm ⟨u.1, u.2.1⟩

/-- Base-anchored historical scope loss of a transport `τ` relative to its origin anchor. -/
def HistoricalScopeLoss_B {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId1 domId2 : String}
    {D1 D2 : Type}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ : SemanticTransport anch1 anch2) (b : B) : Prop :=
  ScopeLoss_B anch1.j τ.retDom b

/-- Permanent lineage flag recording whether any historical point was lost (`∃ x, ¬retDom x`). -/
def HistoricalRetreatFlag {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId1 domId2 : String}
    {D1 D2 : Type}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ : SemanticTransport anch1 anch2) : Prop :=
  ∃ xLost : D1, ¬ τ.retDom xLost

/-- **`T-A0-01` — Partial Composition Preserves Base Commutativity, Observable Equivalence, & Unit Domains**:
    For any composable `τ1 : anch0 ⇝ anch1` and `τ2 : anch1 ⇝ anch2` over common `(reg, baseId)`:
    (1) `anch2.j ((composeSemanticTransport τ1 τ2).toFun u).1 = anch0.j u.1`;
    (2) `anch2.domSpec.obsD i ((composeSemanticTransport τ1 τ2).toFun u).1 ↔ anch0.domSpec.obsD i u.1`;
    (3) Left and right composition with `idSemanticTransport` preserve exact retained domains. -/
theorem T_A0_01_composeSemanticTransport_comm_and_obs {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId0 domId1 domId2 : String}
    {D0 D1 D2 : Type}
    {anch0 : CertifiedChartAnchor reg baseId domId0 D0}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ1 : SemanticTransport anch0 anch1)
    (τ2 : SemanticTransport anch1 anch2) :
    (∀ u : { x : D0 // (composeSemanticTransport τ1 τ2).retDom x },
      anch2.j ((composeSemanticTransport τ1 τ2).toFun u).1 = anch0.j u.1) ∧
    (∀ (i : ObsIdx) (u : { x : D0 // (composeSemanticTransport τ1 τ2).retDom x }),
      anch2.domSpec.obsD i ((composeSemanticTransport τ1 τ2).toFun u).1 ↔
        anch0.domSpec.obsD i u.1) ∧
    (∀ x : D0, (composeSemanticTransport (idSemanticTransport anch0) τ1).retDom x ↔ τ1.retDom x) ∧
    (∀ x : D0, (composeSemanticTransport τ1 (idSemanticTransport anch1)).retDom x ↔ τ1.retDom x) := by
  refine ⟨(composeSemanticTransport τ1 τ2).base_comm,
          semanticTransport_preserves_obs (composeSemanticTransport τ1 τ2), ?_, ?_⟩
  · intro x
    exact ⟨fun ⟨_, hx⟩ => hx, fun hx => ⟨trivial, hx⟩⟩
  · intro x
    exact ⟨fun ⟨hx, _⟩ => hx, fun hx => ⟨hx, trivial⟩⟩

/-- **`T-A0-02` (`CE-C1-02`) — Monotone `HistoricalScopeLoss_B` & Irreversibility of `Retreat`**:
    (1) `HistoricalScopeLoss_B τ1 ⊆ HistoricalScopeLoss_B (composeSemanticTransport τ1 τ2)`;
    (2) If `ValidRetreatTransport τ1` holds, then for EVERY subsequent `τ2`, `HistoricalRetreatFlag`
        persists and `composeSemanticTransport τ1 τ2` can NEVER satisfy `ValidRepairTransport`;
    (3) Under `ChartInjective anch0.j`, `ValidRetreatTransport τ1` guarantees a permanent base witness
        `bLost ∈ HistoricalScopeLoss_B (composeSemanticTransport τ1 τ2)`. -/
theorem T_A0_02_historicalScopeLoss_monotone_and_retreat_irreversible {B ObsIdx : Type}
    {reg : ChartRegistry B ObsIdx} {baseId domId0 domId1 domId2 : String}
    {D0 D1 D2 : Type}
    {anch0 : CertifiedChartAnchor reg baseId domId0 D0}
    {anch1 : CertifiedChartAnchor reg baseId domId1 D1}
    {anch2 : CertifiedChartAnchor reg baseId domId2 D2}
    (τ1 : SemanticTransport anch0 anch1)
    (τ2 : SemanticTransport anch1 anch2) :
    (∀ b : B, HistoricalScopeLoss_B τ1 b →
      HistoricalScopeLoss_B (composeSemanticTransport τ1 τ2) b) ∧
    (ValidRetreatTransport τ1 →
      HistoricalRetreatFlag (composeSemanticTransport τ1 τ2) ∧
      ¬ ValidRepairTransport (composeSemanticTransport τ1 τ2)) ∧
    (ChartInjective anch0.j → ValidRetreatTransport τ1 →
      ∃ bLost : B, HistoricalScopeLoss_B (composeSemanticTransport τ1 τ2) bLost) := by
  have hmono : ∀ b : B, HistoricalScopeLoss_B τ1 b →
      HistoricalScopeLoss_B (composeSemanticTransport τ1 τ2) b := by
    intro b hloss
    refine ⟨hloss.1, ?_⟩
    rintro ⟨x, ⟨hx1, _⟩, hbx⟩
    exact hloss.2 ⟨x, hx1, hbx⟩
  refine ⟨hmono, ?_, ?_⟩
  · intro hret
    rcases hret.1 with ⟨xLost, hnot1⟩
    have hflag : HistoricalRetreatFlag (composeSemanticTransport τ1 τ2) :=
      ⟨xLost, fun ⟨hx1, _⟩ => hnot1 hx1⟩
    refine ⟨hflag, ?_⟩
    intro hrep
    exact hnot1 (hrep.1 xLost).1
  · intro hinj hret
    rcases hret.1 with ⟨xLost, hnot1⟩
    have hb1 : HistoricalScopeLoss_B τ1 (anch0.j xLost) :=
      (scopeLoss_B_chart_iff hinj τ1.retDom xLost).mpr hnot1
    exact ⟨anch0.j xLost, hmono (anch0.j xLost) hb1⟩

/-! ### 3. Concrete 2-Step `Retreat → Refinement` Re-Expansion Path `g0(ℚ) → g1(ℚ\{0}) → g2(ℚ)` -/

/-- Step 1 (`g0 → g1`): Honest `Retreat` from `ℚ` to `ℚ \ {0}` excising `0`. -/
def ratRetreatToNonzero :
    SemanticTransport ratFullCertifiedAnchor ratNonzeroCertifiedAnchor where
  retDom    := fun x => x ≠ 0
  imgDom    := fun _ => True
  toFun     := fun x => ⟨⟨x.1, x.2⟩, trivial⟩
  invFun    := fun y => ⟨y.1.1, y.1.2⟩
  left_inv  := fun _ => Subtype.ext rfl
  right_inv := fun _ => Subtype.ext (Subtype.ext rfl)
  base_comm := fun _ => rfl

/-- Step 2 (`g1 → g2`): Honest `Refinement` section re-embedding `ℚ \ {0}` into restored `D2 = ℚ`. -/
def ratReexpandToFull :
    SemanticTransport ratNonzeroCertifiedAnchor ratFullCertifiedAnchor where
  retDom    := fun _ => True
  imgDom    := fun z => z ≠ 0
  toFun     := fun y => ⟨y.1.1, y.1.2⟩
  invFun    := fun z => ⟨⟨z.1, z.2⟩, trivial⟩
  left_inv  := fun _ => Subtype.ext (Subtype.ext rfl)
  right_inv := fun _ => Subtype.ext rfl
  base_comm := fun _ => rfl

/-- Composed 2-step lineage `p = τ_reexpand ∘ τ_retreat : g0(ℚ) ⇝ g2(ℚ)`. -/
def ratRetreatThenReexpand :
    SemanticTransport ratFullCertifiedAnchor ratFullCertifiedAnchor :=
  composeSemanticTransport ratRetreatToNonzero ratReexpandToFull

/-- Exact characterization of the 2-step path `g0(ℚ) → g1(ℚ\{0}) → g2(ℚ)`:
    `ratRetreatToNonzero` is a `ValidRetreatTransport`, `ratReexpandToFull` is a `ValidRefinementSection`,
    and the composed path `ratRetreatThenReexpand` permanently retains `HistoricalScopeLoss_B = {0}`. -/
theorem ratRetreatThenReexpand_historicalLoss_eq_singleton_zero :
    ValidRetreatTransport ratRetreatToNonzero ∧
    ValidRefinementSection ratReexpandToFull ∧
    (∀ b : Rat, HistoricalScopeLoss_B ratRetreatThenReexpand b ↔ b = 0) ∧
    ¬ ValidRepairTransport ratRetreatThenReexpand := by
  have hinj : ChartInjective ratFullCertifiedAnchor.j := fun _ _ h => h
  have hret : ValidRetreatTransport ratRetreatToNonzero :=
    ⟨⟨0, fun hne => hne rfl⟩, fun _ => trivial⟩
  have href : ValidRefinementSection ratReexpandToFull := fun _ => trivial
  refine ⟨hret, href, ?_, ?_⟩
  · intro b
    have hiff : HistoricalScopeLoss_B ratRetreatThenReexpand b ↔
        ¬ ratRetreatThenReexpand.retDom b := by
      simpa [HistoricalScopeLoss_B, ratFullCertifiedAnchor, ratIdChart] using
        (scopeLoss_B_chart_iff hinj ratRetreatThenReexpand.retDom b)
    rw [hiff]
    constructor
    · intro hnot
      by_cases hb : b = 0
      · exact hb
      · exfalso
        exact hnot ⟨hb, trivial⟩
    · intro hb
      subst hb
      rintro ⟨hne, _⟩
      exact hne rfl
  · exact (T_A0_02_historicalScopeLoss_monotone_and_retreat_irreversible
      ratRetreatToNonzero ratReexpandToFull).2.1 hret |>.2

end OmegaCellC1P1A0
