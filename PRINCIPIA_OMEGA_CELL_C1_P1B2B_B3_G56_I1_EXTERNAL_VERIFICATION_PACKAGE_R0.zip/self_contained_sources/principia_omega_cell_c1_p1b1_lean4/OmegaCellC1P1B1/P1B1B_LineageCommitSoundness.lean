/-
  PRINCIPIA Ω-CELL-C1-P1B1 — Isolated Minimal Structural Checker Kernel
  Module: OmegaCellC1P1B1.P1B1B_LineageCommitSoundness

  Authorization Scope (`PRINCIPIA_OMEGA_CELL_C1_P1B1` Authorized — 7-Theorem Minimal Structural Kernel):
    1. Orthogonal `EpistemicStructState × GrantLedgerState`, `ExactHistorySnapshot`, &
       `StructuralPathKey` (`Masterstrokes 4 & 5`, `T-B1-04`, `T-B1-06`):
       - Separates pure read-only `checkStructuralReflex` (`Check`), snapshot- and pathKey-guarded
         `tryCommitStructural` (`Commit`), and `HELD` institutional grant events (`Grant`).
       - Proves `GrantLedger` exact invariance across all epistemic events (`Zero-Mint`), separates
         fresh-cell empty grants from reused-`CellCID` preserved grants, rejects divergent same-length
         snapshots (`|L_a| = |L_b|` yet `L_a ≠ L_b`), and proves `GrantLedger_{t+1} = GrantLedger_t`
         does NOT imply `Eligible_{t+1} = Eligible_t` (`Tribunal §3`).
    2. Non-Circular `SemStructuralValid`, Structural Master Soundness (`T-B1-05`), & 4-Gate
       `GateDropCounterexample` Suite (`Masterstroke 3`, `Tribunal §2.C`):
       - `SemStructuralValid` makes ZERO calls in its transitive closure to `checkStructuralReflex`,
         `reifyTransportCode`, `reifyRawTransport`, or `checkG3Matrix`.
       - Proves joint consistency of `H_reg ∧ H_store`, proves `T-B1-05`, and proves constructive
         `GateDropCounterexample`s for all four structural gates (`G2`, `G3`, `G4`, `G8`).
    3. Positive Structural Acceptance (`3` kinds) & Adversarial Rejection/Hold Suite (`T-B1-08`).

  Explicitly Excluded (`NOT AUTHORIZED` / `FROZEN` / `HELD`):
    - `G1` wire/hash framing, `G5/G6` discharge/protected proof engine, `G7` full derivation engine
      (`T-B1-07`), `P1B2/P1C`, `GPED` integration, `MT-22b`, `L3-P2C`, and `checkTraceDec`.
-/
import OmegaCellC1P1B1.P1B1A_VerdictSlotReifier

namespace OmegaCellC1P1B1

open OmegaCellC1P1A0

/-! ### 1. Syntactic Store, Orthogonal `Epistemic × Grant` Ledger, & Snapshot/PathKey Commit -/

/-- Stored cell header in the detached structural store. -/
structure StoredCellHeader where
  cellCid : String
  baseId  : String
  domId   : String
  specId  : String
  prov    : ChartProvenance
  deriving DecidableEq, Repr

/-- Stored obstruction header in the detached structural store (`G5` semantic truth unassumed). -/
structure StoredObstHeader where
  obstCid : String
  cellCid : String
  specId  : String
  inpKind : ExplorerObstInput
  deriving DecidableEq, Repr

/-- Detached structural payload store (`none` routes to `UnavailableHeld`). -/
structure StructuralStore where
  lookupCell? : String → Option StoredCellHeader
  lookupObst? : String → Option StoredObstHeader

/-- Minimal input context assumption `H_reg`: canonical pinned rational registry identifier. -/
def RegistryContextValid (regId : String) : Prop :=
  regId = "reg_Q_v1"

/-- Minimal input context assumption `H_store`: stored record keys match their lookup CIDs. -/
def StoreLookupConsistent (store : StructuralStore) : Prop :=
  (∀ cid c, store.lookupCell? cid = some c → c.cellCid = cid) ∧
  (∀ oid o, store.lookupObst? oid = some o → o.obstCid = oid)

/-- Untrusted syntactic reflex proposal AST submitted by an AI explorer (`TCB = 0`). -/
structure StructuralReflexAST where
  rflxCid            : String
  parentPathKey?     : Option StructuralPathKey
  cellOldCid         : String
  obstCid            : String
  cellNewCid         : String
  baseId             : String
  domOldId           : String
  domNewId           : String
  specOldId          : String
  specNewId          : String
  reflexKind         : ReflexKind
  transportCode      : TransportCode
  claimedHistRetreat : Bool
  deriving DecidableEq, Repr

/-- Deterministic structural `PathKey` derivation from `(parentPathKey?, cellOld, obst, cellNew, rflx)`. -/
def derivePathKey (ast : StructuralReflexAST) : StructuralPathKey :=
  match ast.parentPathKey? with
  | none     => .root ast.cellOldCid ast.obstCid ast.cellNewCid ast.rflxCid
  | some par => .step par ast.cellOldCid ast.obstCid ast.cellNewCid ast.rflxCid

/-- Committed structural lineage record stored in `EpistemicStructState`. -/
structure CommittedLineageEntry where
  pathKey           : StructuralPathKey
  rflxCid           : String
  cellOldCid        : String
  obstCid           : String
  cellNewCid        : String
  baseId            : String
  domOldId          : String
  domNewId          : String
  specOldId         : String
  specNewId         : String
  stepKind          : ReflexKind
  historicalRetreat : Bool
  deriving DecidableEq, Repr

/-- Institutional grant record (`TCB_Institutional` = `HELD`; never minted by `Check` or `Commit`). -/
structure InstitutionalGrantRec where
  grantCid         : String
  targetCellCid    : String
  claimId          : RatClaimId
  specId           : String
  subdomId         : RatSubdomId
  requiredPremises : List String
  expiresEpoch     : Nat
  deriving DecidableEq, Repr

/-- First coordinate of orthogonal ledger state: epistemic lineage, retractions, & epoch. -/
structure EpistemicStructState where
  committedLineages : List CommittedLineageEntry
  retractedPremises : List String
  currentEpoch      : Nat
  deriving DecidableEq, Repr

/-- Second coordinate of orthogonal ledger state: raw institutional grant ledger. -/
abbrev GrantLedgerState : Type := List InstitutionalGrantRec

/-- Orthogonal product ledger state `EpistemicStructState × GrantLedgerState` (`Masterstroke 5`). -/
structure StructuralLedgerState where
  epistemic   : EpistemicStructState
  grantLedger : GrantLedgerState
  deriving DecidableEq, Repr

/-- Events operating on `StructuralLedgerState`: epistemic events touch ONLY `.epistemic`;
    `HELD` institutional events touch ONLY `.grantLedger`. -/
inductive StructuralLedgerEvent where
  | recordStructuralReflex : CommittedLineageEntry → StructuralLedgerEvent
  | retractPremise         : String → StructuralLedgerEvent
  | advanceEpoch           : Nat → StructuralLedgerEvent
  | issueGrantHeld         : InstitutionalGrantRec → StructuralLedgerEvent
  | revokeGrantHeld        : String → StructuralLedgerEvent
  deriving DecidableEq, Repr

/-- Short canonical event tag used in `CheckedG2348Summary.checkedHistoryIds`. -/
def ledgerEventSummaryTag : StructuralLedgerEvent → String
  | .recordStructuralReflex e => "rflx:" ++ e.rflxCid
  | .retractPremise p         => "retract:" ++ p
  | .advanceEpoch n           => "epoch:" ++ toString n
  | .issueGrantHeld g         => "grant:" ++ g.grantCid
  | .revokeGrantHeld cid      => "revgrant:" ++ cid

/-- Pure epistemic coordinate step function. -/
def stepEpistemicState (ep : EpistemicStructState) : StructuralLedgerEvent → EpistemicStructState
  | .recordStructuralReflex e => { ep with committedLineages := ep.committedLineages ++ [e] }
  | .retractPremise p         => { ep with retractedPremises := ep.retractedPremises ++ [p] }
  | .advanceEpoch n           => { ep with currentEpoch := n }
  | .issueGrantHeld _         => ep
  | .revokeGrantHeld _        => ep

/-- Pure institutional grant coordinate step function (`recordStructuralReflex` is identity `rfl`!). -/
def stepGrantLedgerState (gr : GrantLedgerState) : StructuralLedgerEvent → GrantLedgerState
  | .recordStructuralReflex _ => gr
  | .retractPremise _         => gr
  | .advanceEpoch _           => gr
  | .issueGrantHeld g         => gr ++ [g]
  | .revokeGrantHeld cid      => gr.filter (fun x => x.grantCid != cid)

/-- Orthogonal product step function (`Masterstroke 5`). -/
def stepStructuralLedger (st : StructuralLedgerState) (ev : StructuralLedgerEvent) :
    StructuralLedgerState where
  epistemic   := stepEpistemicState st.epistemic ev
  grantLedger := stepGrantLedgerState st.grantLedger ev

/-- Empty initial `StructuralLedgerState`. -/
def initStructuralLedger : StructuralLedgerState where
  epistemic   := { committedLineages := [], retractedPremises := [], currentEpoch := 0 }
  grantLedger := []

/-- Folded ledger state from ordered append-only `List StructuralLedgerEvent`. -/
def foldStructuralLedger (L : List StructuralLedgerEvent) : StructuralLedgerState :=
  L.foldl stepStructuralLedger initStructuralLedger

/-- Grants recorded for `cellCid` in `GrantLedgerState` (raw grant presence, distinct from `Eligible`). -/
def lookupCellGrantsInLedger (L : List StructuralLedgerEvent) (cellCid : String) :
    List InstitutionalGrantRec :=
  (foldStructuralLedger L).grantLedger.filter (fun g => g.targetCellCid == cellCid)

/-- Current operational eligibility (`Tribunal §3` Separation): requires raw grant presence PLUS
    survival of all transitive required premises `depsStarCanon` and unexpired epoch. -/
def isGrantCurrentlyEligibleBool (dag : PremDag) (L : List StructuralLedgerEvent)
    (g : InstitutionalGrantRec) : Bool :=
  let st := foldStructuralLedger L
  st.grantLedger.contains g &&
  (depsStarCanon dag g.requiredPremises).all (fun p => !st.epistemic.retractedPremises.contains p) &&
  decide (st.epistemic.currentEpoch < g.expiresEpoch)

/-! ### 2. Pure Read-Only `checkStructuralReflex` (`G2 · G3 · G4 · G8`) & Snapshot Commit -/

/-- Pure stateless structural checker (`Phase 1: Check` — mutates nothing). -/
def checkStructuralReflex (fuel : Nat) (regId : String) (store : StructuralStore)
    (L : List StructuralLedgerEvent) (ast : StructuralReflexAST) : StructuralVerdict6 :=
  match fuel with
  | 0 => .resourceHeld 0
  | _ + 1 =>
      if hCid : ast.rflxCid == "" then
        .rejectInvalid .G2 .obstCellOrSpecMismatch
      else
        match store.lookupCell? ast.cellOldCid with
        | none => .unavailableHeld ast.cellOldCid
        | some cOld =>
            match store.lookupCell? ast.cellNewCid with
            | none => .unavailableHeld ast.cellNewCid
            | some cNew =>
                match store.lookupObst? ast.obstCid with
                | none => .unavailableHeld ast.obstCid
                | some obst =>
                    -- G2: Cell, Obstruction, Base, Domain, and Spec header binding
                    if !(cOld.baseId == ast.baseId &&
                         cNew.baseId == ast.baseId &&
                         cOld.domId == ast.domOldId &&
                         cNew.domId == ast.domNewId &&
                         cOld.specId == ast.specOldId &&
                         cNew.specId == ast.specNewId &&
                         obst.cellCid == ast.cellOldCid &&
                         obst.specId == ast.specOldId) then
                      .rejectInvalid .G2 .obstCellOrSpecMismatch
                    else
                      -- G3: Obstruction × ReflexKind matrix dispatch
                      match checkG3Matrix obst.inpKind ast.reflexKind with
                      | .error out => nonAcceptToVerdict6 out
                      | .ok _ =>
                          -- G4: Proof-carrying Tag-Reflection TransportCode reifier
                          match reifyTransportCode fuel regId ast.baseId ast.domOldId ast.domNewId
                              ast.specOldId ast.specNewId cOld.prov cNew.prov
                              ast.reflexKind ast.transportCode with
                          | .error out => nonAcceptToVerdict6 out
                          | .ok _ =>
                              -- G8: StructuralPathKey uniqueness & parent lineage loss inheritance
                              let ep := (foldStructuralLedger L).epistemic
                              let pkey := derivePathKey ast
                              if (ep.committedLineages.map (·.pathKey)).contains pkey then
                                .rejectInvalid .G8 .duplicatePathKey
                              else
                                match ast.parentPathKey? with
                                | none =>
                                    let expectedRet := ast.reflexKind == .retreat
                                    if ast.claimedHistRetreat != expectedRet then
                                      .rejectInvalid .G8 .retreatFlagLaundering
                                    else
                                      let summary : CheckedG2348Summary := {
                                        rflxCid              := ast.rflxCid
                                        pathKey              := pkey
                                        cellOldCid           := ast.cellOldCid
                                        obstCid              := ast.obstCid
                                        cellNewCid           := ast.cellNewCid
                                        baseId               := ast.baseId
                                        domOldId             := ast.domOldId
                                        domNewId             := ast.domNewId
                                        specOldId            := ast.specOldId
                                        specNewId            := ast.specNewId
                                        historicalRetreat    := ast.claimedHistRetreat
                                        checkedHistoryIds    := L.map ledgerEventSummaryTag
                                        nonEmptyRflxCidCheck := true
                                      }
                                      have hsum : checkG2348SummaryBool summary = true := by
                                        unfold checkG2348SummaryBool
                                        cases hne : (ast.rflxCid != "") with
                                        | true => rfl
                                        | false =>
                                            have heq : (ast.rflxCid == "") = true := by
                                              cases h : (ast.rflxCid == "") <;> simp_all [bne]
                                            exact False.elim (hCid heq)
                                      .structuralAccept {
                                        slotG1    := .mkUnchecked
                                        slot2348  := .mkVerified ⟨summary, hsum⟩
                                        slotG56   := .mkUnchecked
                                        slotG7    := .mkUnchecked
                                        grantFlag := .noGrantFromMathCheck
                                      }
                                | some parKey =>
                                    match ep.committedLineages.find? (fun e => e.pathKey == parKey) with
                                    | none => .rejectInvalid .G8 .parentLineageNotFound
                                    | some parEntry =>
                                        if !(parEntry.baseId == ast.baseId &&
                                             parEntry.cellNewCid == ast.cellOldCid &&
                                             parEntry.domNewId == ast.domOldId &&
                                             parEntry.specNewId == ast.specOldId) then
                                          .rejectInvalid .G8 .parentCellOrSpecDiscont
                                        else
                                          let expectedRet :=
                                            parEntry.historicalRetreat || (ast.reflexKind == .retreat)
                                          if ast.claimedHistRetreat != expectedRet then
                                            .rejectInvalid .G8 .retreatFlagLaundering
                                          else
                                            let summary : CheckedG2348Summary := {
                                              rflxCid              := ast.rflxCid
                                              pathKey              := pkey
                                              cellOldCid           := ast.cellOldCid
                                              obstCid              := ast.obstCid
                                              cellNewCid           := ast.cellNewCid
                                              baseId               := ast.baseId
                                              domOldId             := ast.domOldId
                                              domNewId             := ast.domNewId
                                              specOldId            := ast.specOldId
                                              specNewId            := ast.specNewId
                                              historicalRetreat    := ast.claimedHistRetreat
                                              checkedHistoryIds    := L.map ledgerEventSummaryTag
                                              nonEmptyRflxCidCheck := true
                                            }
                                            have hsum : checkG2348SummaryBool summary = true := by
                                              unfold checkG2348SummaryBool
                                              cases hne : (ast.rflxCid != "") with
                                              | true => rfl
                                              | false =>
                                                  have heq : (ast.rflxCid == "") = true := by
                                                    cases h : (ast.rflxCid == "") <;> simp_all [bne]
                                                  exact False.elim (hCid heq)
                                            .structuralAccept {
                                              slotG1    := .mkUnchecked
                                              slot2348  := .mkVerified ⟨summary, hsum⟩
                                              slotG56   := .mkUnchecked
                                              slotG7    := .mkUnchecked
                                              grantFlag := .noGrantFromMathCheck
                                            }

/-- Snapshot-bound structural commit packet (`Masterstroke 4` — binds `ExactHistorySnapshot`). -/
structure ExactHistoryCommitPacket where
  qual            : StructuralQualification
  stepKind        : ReflexKind
  checkedSnapshot : List StructuralLedgerEvent

/-- Explicit commit failure reasons (`Phase 2: Commit`). -/
inductive StructuralCommitErr where
  | staleOrDivergentSnapshot : StructuralCommitErr
  | duplicatePathKey         : StructuralCommitErr
  deriving DecidableEq, Repr

/-- `Phase 2: Commit` — checks exact history equality (`L_commit == pkt.checkedSnapshot`) and
    `StructuralPathKey` freshness before appending `.recordStructuralReflex` (`0` grants minted). -/
def tryCommitStructural (L_commit : List StructuralLedgerEvent) (pkt : ExactHistoryCommitPacket) :
    Except StructuralCommitErr (List StructuralLedgerEvent) :=
  let s := extractSummary pkt.qual
  if L_commit != pkt.checkedSnapshot then
    .error .staleOrDivergentSnapshot
  else if ((foldStructuralLedger L_commit).epistemic.committedLineages.map (·.pathKey)).contains s.pathKey then
    .error .duplicatePathKey
  else
    let entry : CommittedLineageEntry := {
      pathKey           := s.pathKey
      rflxCid           := s.rflxCid
      cellOldCid        := s.cellOldCid
      obstCid           := s.obstCid
      cellNewCid        := s.cellNewCid
      baseId            := s.baseId
      domOldId          := s.domOldId
      domNewId          := s.domNewId
      specOldId         := s.specOldId
      specNewId         := s.specNewId
      stepKind          := pkt.stepKind
      historicalRetreat := s.historicalRetreat
    }
    .ok (L_commit ++ [.recordStructuralReflex entry])

/-! ### 3. Independent Non-Circular `SemStructuralValid` (`SEM_STRUCT_CALLS_CHECKER = 0`) -/

/-- **Independent Declarative Structural Validity (`Prop`)**:
    Defined strictly over `P1A0` semantic anchors/transports, `ObstReflexMatrixAllowed`, and ledger
    lineage invariants with **ZERO** references in its transitive closure to `checkStructuralReflex`,
    `reifyTransportCode`, `reifyRawTransport`, `checkG3Matrix`, or `extractKindDomainLaw`! -/
def SemStructuralValid (regId : String) (store : StructuralStore)
    (L : List StructuralLedgerEvent) (ast : StructuralReflexAST) : Prop :=
  regId = "reg_Q_v1" ∧
  ast.baseId = "base_Q" ∧
  ast.rflxCid ≠ "" ∧
  (∃ (cOld cNew : StoredCellHeader) (obst : StoredObstHeader) (okind : KernelObstKindV1),
    store.lookupCell? ast.cellOldCid = some cOld ∧
    store.lookupCell? ast.cellNewCid = some cNew ∧
    store.lookupObst? ast.obstCid = some obst ∧
    cOld.cellCid = ast.cellOldCid ∧
    cNew.cellCid = ast.cellNewCid ∧
    obst.obstCid = ast.obstCid ∧
    cOld.baseId = ast.baseId ∧
    cNew.baseId = ast.baseId ∧
    cOld.domId = ast.domOldId ∧
    cNew.domId = ast.domNewId ∧
    cOld.specId = ast.specOldId ∧
    cNew.specId = ast.specNewId ∧
    obst.cellCid = ast.cellOldCid ∧
    obst.specId = ast.specOldId ∧
    cOld.prov ≠ .externalCalibrationHeld ∧
    cNew.prov ≠ .externalCalibrationHeld ∧
    obst.inpKind = .knownV1 okind ∧
    okind ≠ .environmentalFailure ∧
    ObstReflexMatrixAllowed okind ast.reflexKind) ∧
  (∃ (tOld tNew : KernelDomTagV1)
     (τ : SemanticTransport (domTagCanonicalAnchor tOld) (domTagCanonicalAnchor tNew)),
    domTagToId tOld = ast.domOldId ∧
    domTagToId tNew = ast.domNewId ∧
    KindDomainLaw ast.reflexKind τ) ∧
  derivePathKey ast ∉ ((foldStructuralLedger L).epistemic.committedLineages.map (·.pathKey)) ∧
  (ast.reflexKind = .retreat → ast.claimedHistRetreat = true) ∧
  (∀ parKey : StructuralPathKey, ast.parentPathKey? = some parKey →
    ∃ parEntry ∈ (foldStructuralLedger L).epistemic.committedLineages,
      parEntry.pathKey = parKey ∧
      parEntry.baseId = ast.baseId ∧
      parEntry.cellNewCid = ast.cellOldCid ∧
      parEntry.domNewId = ast.domOldId ∧
      parEntry.specNewId = ast.specOldId ∧
      (parEntry.historicalRetreat = true → ast.claimedHistRetreat = true))

/-! ### 4. Theorems `T-B1-04`, `T-B1-05` (+ 4-Gate Drop Suite), `T-B1-06`, & `T-B1-08` -/

/-- Coordinate-chart injectivity holds for every `KernelDomTagV1` canonical anchor (`ℚ` and `ℚ \ {0}`). -/
theorem domTagCanonicalAnchor_injective (t : KernelDomTagV1) :
    ChartInjective (domTagCanonicalAnchor t).j := by
  cases t with
  | domQ        => intro _ _ h; exact h
  | domQNonzero => intro _ _ h; exact Subtype.ext h

/-- **`T-B1-04` — Structural `PathKey` Injectivity & Lineage `HistoricalScopeLoss_B` Monotonicity**:
    (1) `derivePathKey` is injective on `(parentPathKey?, cellOldCid, obstCid, cellNewCid, rflxCid)`
        with zero hash-collision assumptions;
    (2) Whenever a `Retreat` step `pkg1` (`t0 → t1`) is followed by any composable step `pkg2` (`t1 → t2`),
        the composed `SemanticTransport` satisfies `HistoricalScopeLoss_B pkg1.transport ⊆ HistoricalScopeLoss_B comp`,
        `HistoricalRetreatFlag comp`, `¬ ValidRepairTransport comp`, and guarantees an indelible lost
        base witness `bLost : Rat`. -/
theorem T_B1_04_pathKey_injective_and_lineage_scopeLoss_monotone :
    (∀ a1 a2 : StructuralReflexAST,
      derivePathKey a1 = derivePathKey a2 →
        a1.parentPathKey? = a2.parentPathKey? ∧
        a1.cellOldCid = a2.cellOldCid ∧
        a1.obstCid = a2.obstCid ∧
        a1.cellNewCid = a2.cellNewCid ∧
        a1.rflxCid = a2.rflxCid) ∧
    (∀ {t0 t1 t2 : KernelDomTagV1}
       (τ1 : SemanticTransport (domTagCanonicalAnchor t0) (domTagCanonicalAnchor t1))
       (τ2 : SemanticTransport (domTagCanonicalAnchor t1) (domTagCanonicalAnchor t2)),
      ValidRetreatTransport τ1 →
        (∀ b : Rat, HistoricalScopeLoss_B τ1 b →
          HistoricalScopeLoss_B (composeSemanticTransport τ1 τ2) b) ∧
        HistoricalRetreatFlag (composeSemanticTransport τ1 τ2) ∧
        ¬ ValidRepairTransport (composeSemanticTransport τ1 τ2) ∧
        (∃ bLost : Rat, HistoricalScopeLoss_B (composeSemanticTransport τ1 τ2) bLost)) := by
  refine ⟨?_, ?_⟩
  · intro a1 a2 heq
    unfold derivePathKey at heq
    cases hp1 : a1.parentPathKey? <;> cases hp2 : a2.parentPathKey? <;>
      rw [hp1, hp2] at heq
    · injection heq with h1 h2 h3 h4
      exact ⟨rfl, h1, h2, h3, h4⟩
    · nomatch heq
    · nomatch heq
    · injection heq with hpar h1 h2 h3 h4
      rw [hpar]
      exact ⟨rfl, h1, h2, h3, h4⟩
  · intro t0 t1 t2 τ1 τ2 hret
    have h02 := T_A0_02_historicalScopeLoss_monotone_and_retreat_irreversible τ1 τ2
    have hflag_norep := h02.2.1 hret
    have hex := h02.2.2 (domTagCanonicalAnchor_injective t0) hret
    exact ⟨h02.1, hflag_norep.1, hflag_norep.2, hex⟩

/-- Concrete reference store for consistency, positive acceptance, and adversarial tests. -/
def stdStructStore : StructuralStore where
  lookupCell? cid :=
    if cid == "g0" then
      some ⟨"g0", "base_Q", "dom_Q", "spec_v1", .canonicalIdentity⟩
    else if cid == "g1" then
      some ⟨"g1", "base_Q", "dom_Q_nonzero", "spec_v2", .canonicalSubspace⟩
    else if cid == "g2" then
      some ⟨"g2", "base_Q", "dom_Q", "spec_v2", .canonicalIdentity⟩
    else if cid == "g1_rep" then
      some ⟨"g1_rep", "base_Q", "dom_Q_nonzero", "spec_v2", .canonicalSubspace⟩
    else if cid == "g_ext_cal" then
      some ⟨"g_ext_cal", "base_Q", "dom_Q", "spec_v2", .externalCalibrationHeld⟩
    else if cid == "g_unauth_dom" then
      some ⟨"g_unauth_dom", "base_Q", "dom_C_complex", "spec_v2", .canonicalIdentity⟩
    else none
  lookupObst? oid :=
    if oid == "obst_ce0" then
      some ⟨"obst_ce0", "g0", "spec_v1", .knownV1 .counterexamplePoint⟩
    else if oid == "obst_g1_ce" then
      some ⟨"obst_g1_ce", "g1", "spec_v2", .knownV1 .counterexamplePoint⟩
    else if oid == "obst_nogo_xor" then
      some ⟨"obst_nogo_xor", "g0", "spec_v1", .knownV1 .scopedNoGo⟩
    else if oid == "obst_env_timeout" then
      some ⟨"obst_env_timeout", "g0", "spec_v1", .knownV1 .environmentalFailure⟩
    else if oid == "obst_wrong_cell" then
      some ⟨"obst_wrong_cell", "g1", "spec_v1", .knownV1 .counterexamplePoint⟩
    else if oid == "obst_blocked" then
      some ⟨"obst_blocked", "g0", "spec_v1", .derivationBlocked 50⟩
    else if oid == "obst_ext_prob" then
      some ⟨"obst_ext_prob", "g0", "spec_v1", .extObstruction "prob_drift_v2"⟩
    else none

/-- Proof that `("reg_Q_v1", stdStructStore)` jointly satisfies `H_reg ∧ H_store` (non-vacuity). -/
theorem stdStructCtx_consistent :
    RegistryContextValid "reg_Q_v1" ∧ StoreLookupConsistent stdStructStore := by
  refine ⟨rfl, ⟨?_, ?_⟩⟩
  · intro cid c h
    unfold stdStructStore at h
    dsimp only at h
    by_cases h1 : (cid == "g0") = true
    · rw [if_pos h1] at h; injection h with hc; subst hc; exact (eq_of_beq h1).symm
    · rw [if_neg h1] at h
      by_cases h2 : (cid == "g1") = true
      · rw [if_pos h2] at h; injection h with hc; subst hc; exact (eq_of_beq h2).symm
      · rw [if_neg h2] at h
        by_cases h3 : (cid == "g2") = true
        · rw [if_pos h3] at h; injection h with hc; subst hc; exact (eq_of_beq h3).symm
        · rw [if_neg h3] at h
          by_cases h4 : (cid == "g1_rep") = true
          · rw [if_pos h4] at h; injection h with hc; subst hc; exact (eq_of_beq h4).symm
          · rw [if_neg h4] at h
            by_cases h5 : (cid == "g_ext_cal") = true
            · rw [if_pos h5] at h; injection h with hc; subst hc; exact (eq_of_beq h5).symm
            · rw [if_neg h5] at h
              by_cases h6 : (cid == "g_unauth_dom") = true
              · rw [if_pos h6] at h; injection h with hc; subst hc; exact (eq_of_beq h6).symm
              · rw [if_neg h6] at h; nomatch h
  · intro oid o h
    unfold stdStructStore at h
    dsimp only at h
    by_cases h1 : (oid == "obst_ce0") = true
    · rw [if_pos h1] at h; injection h with ho; subst ho; exact (eq_of_beq h1).symm
    · rw [if_neg h1] at h
      by_cases h2 : (oid == "obst_g1_ce") = true
      · rw [if_pos h2] at h; injection h with ho; subst ho; exact (eq_of_beq h2).symm
      · rw [if_neg h2] at h
        by_cases h3 : (oid == "obst_nogo_xor") = true
        · rw [if_pos h3] at h; injection h with ho; subst ho; exact (eq_of_beq h3).symm
        · rw [if_neg h3] at h
          by_cases h4 : (oid == "obst_env_timeout") = true
          · rw [if_pos h4] at h; injection h with ho; subst ho; exact (eq_of_beq h4).symm
          · rw [if_neg h4] at h
            by_cases h5 : (oid == "obst_wrong_cell") = true
            · rw [if_pos h5] at h; injection h with ho; subst ho; exact (eq_of_beq h5).symm
            · rw [if_neg h5] at h
              by_cases h6 : (oid == "obst_blocked") = true
              · rw [if_pos h6] at h; injection h with ho; subst ho; exact (eq_of_beq h6).symm
              · rw [if_neg h6] at h
                by_cases h7 : (oid == "obst_ext_prob") = true
                · rw [if_pos h7] at h; injection h with ho; subst ho; exact (eq_of_beq h7).symm
                · rw [if_neg h7] at h; nomatch h

/-- **`T-B1-05` — Non-Circular Structural Master Soundness (`SEM_STRUCT_CALLS_CHECKER = 0`)**:
    (1) Joint consistency witness: `∃ regId store, RegistryContextValid regId ∧ StoreLookupConsistent store`;
    (2) Under `RegistryContextValid regId ∧ StoreLookupConsistent store`, whenever
        `checkStructuralReflex fuel regId store L ast = .structuralAccept sq`, the non-circular
        semantic target `SemStructuralValid regId store L ast` holds, while `sq` carries `.unchecked`
        for `G1/G56/G7` and `grantFlag = .noGrantFromMathCheck`. -/
theorem T_B1_05_structural_master_soundness_and_consistency :
    (∃ (regId : String) (store : StructuralStore),
      RegistryContextValid regId ∧ StoreLookupConsistent store) ∧
    (∀ (fuel : Nat) (regId : String) (store : StructuralStore)
       (L : List StructuralLedgerEvent) (ast : StructuralReflexAST)
       (sq : StructuralQualification),
      RegistryContextValid regId →
      StoreLookupConsistent store →
      checkStructuralReflex fuel regId store L ast = .structuralAccept sq →
        SemStructuralValid regId store L ast ∧
        sq.grantFlag = .noGrantFromMathCheck) := by
  refine ⟨⟨"reg_Q_v1", stdStructStore, stdStructCtx_consistent⟩, ?_⟩
  intro fuel regId store L ast sq hreg hstore hchk
  cases fuel with
  | zero => unfold checkStructuralReflex at hchk; nomatch hchk
  | succ f' =>
      unfold checkStructuralReflex at hchk
      by_cases hCid : (ast.rflxCid == "") = true
      · rw [dif_pos hCid] at hchk; nomatch hchk
      · rw [dif_neg hCid] at hchk
        have hCid_ne : ast.rflxCid ≠ "" := fun heq => hCid (beq_iff_eq.mpr heq)
        cases hcOld : store.lookupCell? ast.cellOldCid with
        | none => rw [hcOld] at hchk; nomatch hchk
        | some cOld =>
            rw [hcOld] at hchk
            cases hcNew : store.lookupCell? ast.cellNewCid with
            | none => rw [hcNew] at hchk; nomatch hchk
            | some cNew =>
                rw [hcNew] at hchk
                cases hObst : store.lookupObst? ast.obstCid with
                | none => rw [hObst] at hchk; nomatch hchk
                | some obst =>
                    rw [hObst] at hchk
                    dsimp only at hchk
                    by_cases hG2 :
                        (!(cOld.baseId == ast.baseId &&
                           cNew.baseId == ast.baseId &&
                           cOld.domId == ast.domOldId &&
                           cNew.domId == ast.domNewId &&
                           cOld.specId == ast.specOldId &&
                           cNew.specId == ast.specNewId &&
                           obst.cellCid == ast.cellOldCid &&
                           obst.specId == ast.specOldId)) = true
                    · rw [if_pos hG2] at hchk; nomatch hchk
                    · rw [if_neg hG2] at hchk
                      have hG2_ok :
                          (cOld.baseId == ast.baseId &&
                           cNew.baseId == ast.baseId &&
                           cOld.domId == ast.domOldId &&
                           cNew.domId == ast.domNewId &&
                           cOld.specId == ast.specOldId &&
                           cNew.specId == ast.specNewId &&
                           obst.cellCid == ast.cellOldCid &&
                           obst.specId == ast.specOldId) = true := by
                        cases hb : (cOld.baseId == ast.baseId &&
                           cNew.baseId == ast.baseId &&
                           cOld.domId == ast.domOldId &&
                           cNew.domId == ast.domNewId &&
                           cOld.specId == ast.specOldId &&
                           cNew.specId == ast.specNewId &&
                           obst.cellCid == ast.cellOldCid &&
                           obst.specId == ast.specOldId) with
                        | true => rfl
                        | false => simp [hb] at hG2
                      simp only [Bool.and_eq_true] at hG2_ok
                      rcases hG2_ok with ⟨⟨⟨⟨⟨⟨⟨hb1, hb2⟩, hd1⟩, hd2⟩, hs1⟩, hs2⟩, hoc⟩, hos⟩
                      cases hG3 : checkG3Matrix obst.inpKind ast.reflexKind with
                      | error e =>
                          rw [hG3] at hchk
                          cases e <;> nomatch hchk
                      | ok okind =>
                          rw [hG3] at hchk
                          have hG3_sem :=
                            T_B1_03_obstruction_matrix_and_env_misuse_separation.1
                              obst.inpKind ast.reflexKind okind hG3
                          cases hG4 : reifyTransportCode (f' + 1) regId ast.baseId
                              ast.domOldId ast.domNewId ast.specOldId ast.specNewId
                              cOld.prov cNew.prov ast.reflexKind ast.transportCode with
                          | error e =>
                              rw [hG4] at hchk
                              cases e <;> nomatch hchk
                          | ok pkg =>
                              rw [hG4] at hchk
                              have hG4_sem :=
                                T_B1_02_reifyTransportCode_sound_and_seq_checked.1
                                  (f' + 1) regId ast.baseId ast.domOldId ast.domNewId
                                  ast.specOldId ast.specNewId cOld.prov cNew.prov
                                  ast.reflexKind ast.transportCode pkg hG4
                              dsimp only at hchk
                              by_cases hDup :
                                  (((foldStructuralLedger L).epistemic.committedLineages.map (·.pathKey)).contains
                                    (derivePathKey ast)) = true
                              · rw [if_pos hDup] at hchk; nomatch hchk
                              · rw [if_neg hDup] at hchk
                                have hFresh : derivePathKey ast ∉
                                    ((foldStructuralLedger L).epistemic.committedLineages.map (·.pathKey)) :=
                                  fun hm => hDup (List.contains_iff_mem.mpr hm)
                                cases hPar : ast.parentPathKey? with
                                | none =>
                                    rw [hPar] at hchk
                                    dsimp only at hchk
                                    by_cases hRet : (ast.claimedHistRetreat != (ast.reflexKind == .retreat)) = true
                                    · rw [if_pos hRet] at hchk; nomatch hchk
                                    · rw [if_neg hRet] at hchk
                                      injection hchk with hsq
                                      have hgf : sq.grantFlag = .noGrantFromMathCheck := by
                                        rw [← hsq]
                                      have hRetEq : ast.claimedHistRetreat = (ast.reflexKind == .retreat) := by
                                        cases hc1 : ast.claimedHistRetreat <;>
                                          cases hc2 : (ast.reflexKind == .retreat) <;>
                                          simp_all [bne]
                                      refine ⟨⟨hreg, hG4_sem.2.1, hCid_ne, ?_, ?_, hFresh, ?_, ?_⟩, hgf⟩
                                      · exact ⟨cOld, cNew, obst, okind, hcOld, hcNew, hObst,
                                          hstore.1 _ _ hcOld, hstore.1 _ _ hcNew, hstore.2 _ _ hObst,
                                          eq_of_beq hb1, eq_of_beq hb2, eq_of_beq hd1, eq_of_beq hd2,
                                          eq_of_beq hs1, eq_of_beq hs2, eq_of_beq hoc, eq_of_beq hos,
                                          hG4_sem.2.2.1, hG4_sem.2.2.2.1,
                                          hG3_sem.1, hG3_sem.2.1, hG3_sem.2.2⟩
                                      · exact ⟨pkg.srcTag, pkg.dstTag, pkg.transport,
                                          pkg.srcDom_eq, pkg.dstDom_eq, pkg.domainLaw⟩
                                      · intro hrk
                                        rw [hRetEq, hrk]; rfl
                                      · intro _ hp
                                        rw [hPar] at hp
                                        nomatch hp
                                | some parKey =>
                                    rw [hPar] at hchk
                                    dsimp only at hchk
                                    cases hFind : (foldStructuralLedger L).epistemic.committedLineages.find?
                                        (fun e => e.pathKey == parKey) with
                                    | none => rw [hFind] at hchk; nomatch hchk
                                    | some parEntry =>
                                        rw [hFind] at hchk
                                        dsimp only at hchk
                                        by_cases hCont :
                                            (!(parEntry.baseId == ast.baseId &&
                                               parEntry.cellNewCid == ast.cellOldCid &&
                                               parEntry.domNewId == ast.domOldId &&
                                               parEntry.specNewId == ast.specOldId)) = true
                                        · rw [if_pos hCont] at hchk; nomatch hchk
                                        · rw [if_neg hCont] at hchk
                                          have hCont_ok :
                                              (parEntry.baseId == ast.baseId &&
                                               parEntry.cellNewCid == ast.cellOldCid &&
                                               parEntry.domNewId == ast.domOldId &&
                                               parEntry.specNewId == ast.specOldId) = true := by
                                            cases hb : (parEntry.baseId == ast.baseId &&
                                               parEntry.cellNewCid == ast.cellOldCid &&
                                               parEntry.domNewId == ast.domOldId &&
                                               parEntry.specNewId == ast.specOldId) with
                                            | true => rfl
                                            | false => simp [hb] at hCont
                                          simp only [Bool.and_eq_true] at hCont_ok
                                          rcases hCont_ok with ⟨⟨⟨hpb, hpc⟩, hpd⟩, hps⟩
                                          by_cases hRet :
                                              (ast.claimedHistRetreat !=
                                                (parEntry.historicalRetreat || (ast.reflexKind == .retreat))) = true
                                          · rw [if_pos hRet] at hchk; nomatch hchk
                                          · rw [if_neg hRet] at hchk
                                            injection hchk with hsq
                                            have hgf : sq.grantFlag = .noGrantFromMathCheck := by
                                              rw [← hsq]
                                            have hRetEq : ast.claimedHistRetreat =
                                                (parEntry.historicalRetreat || (ast.reflexKind == .retreat)) := by
                                              cases hc1 : ast.claimedHistRetreat <;>
                                                cases hc2 : (parEntry.historicalRetreat || (ast.reflexKind == .retreat)) <;>
                                                simp_all [bne]
                                            have hmem : parEntry ∈
                                                (foldStructuralLedger L).epistemic.committedLineages :=
                                              List.mem_of_find?_eq_some hFind
                                            have hpk : (parEntry.pathKey == parKey) = true :=
                                              @List.find?_some CommittedLineageEntry (fun e => e.pathKey == parKey) _ _ hFind
                                            refine ⟨⟨hreg, hG4_sem.2.1, hCid_ne, ?_, ?_, hFresh, ?_, ?_⟩, hgf⟩
                                            · exact ⟨cOld, cNew, obst, okind, hcOld, hcNew, hObst,
                                                hstore.1 _ _ hcOld, hstore.1 _ _ hcNew, hstore.2 _ _ hObst,
                                                eq_of_beq hb1, eq_of_beq hb2, eq_of_beq hd1, eq_of_beq hd2,
                                                eq_of_beq hs1, eq_of_beq hs2, eq_of_beq hoc, eq_of_beq hos,
                                                hG4_sem.2.2.1, hG4_sem.2.2.2.1,
                                                hG3_sem.1, hG3_sem.2.1, hG3_sem.2.2⟩
                                            · exact ⟨pkg.srcTag, pkg.dstTag, pkg.transport,
                                                pkg.srcDom_eq, pkg.dstDom_eq, pkg.domainLaw⟩
                                            · intro hrk
                                              rw [hRetEq, hrk]
                                              cases parEntry.historicalRetreat <;> rfl
                                            · intro pk hp
                                              rw [hPar] at hp
                                              injection hp with hp_eq
                                              subst hp_eq
                                              refine ⟨parEntry, hmem, eq_of_beq hpk,
                                                eq_of_beq hpb, eq_of_beq hpc, eq_of_beq hpd, eq_of_beq hps, ?_⟩
                                              intro hparRet
                                              rw [hRetEq, hparRet]
                                              rfl

/-! ### 5. Four-Gate Drop Necessity Suite (`Masterstroke 3`, `Tribunal §2.C`) -/

/-- Explicit gate-necessity disposition (`Tribunal §2.C`: either constructive counterexample or
    redundancy proof). In `P1B1`, all four gates `G2`, `G3`, `G4`, `G8` achieve `GateDropCounterexample`. -/
inductive GateNecessityCert (mutAccept : StructuralReflexAST → Bool)
    (L : List StructuralLedgerEvent) : Prop where
  | gateDropCounterexample :
      ∀ ast : StructuralReflexAST,
        mutAccept ast = true → ¬ SemStructuralValid "reg_Q_v1" stdStructStore L ast →
          GateNecessityCert mutAccept L

/-- Mutant 1 (`skipG2`): skips `obst.cellCid == ast.cellOldCid` check while keeping `G3`, `G4`, `G8`. -/
def checkMutantSkipG2 (ast : StructuralReflexAST) : Bool :=
  match stdStructStore.lookupCell? ast.cellOldCid,
        stdStructStore.lookupCell? ast.cellNewCid,
        stdStructStore.lookupObst? ast.obstCid with
  | some cOld, some cNew, some obst =>
      (ast.rflxCid != "") &&
      (checkG3Matrix obst.inpKind ast.reflexKind).isOk &&
      (reifyTransportCode 4 "reg_Q_v1" ast.baseId ast.domOldId ast.domNewId
        ast.specOldId ast.specNewId cOld.prov cNew.prov ast.reflexKind ast.transportCode).isOk &&
      (ast.parentPathKey?.isNone) &&
      (ast.claimedHistRetreat == (ast.reflexKind == .retreat))
  | _, _, _ => false

/-- Mutant 2 (`skipG3`): skips `checkG3Matrix` while keeping `G2`, `G4`, `G8`. -/
def checkMutantSkipG3 (ast : StructuralReflexAST) : Bool :=
  match stdStructStore.lookupCell? ast.cellOldCid,
        stdStructStore.lookupCell? ast.cellNewCid,
        stdStructStore.lookupObst? ast.obstCid with
  | some cOld, some cNew, some obst =>
      (ast.rflxCid != "") &&
      (cOld.baseId == ast.baseId && cNew.baseId == ast.baseId &&
       cOld.domId == ast.domOldId && cNew.domId == ast.domNewId &&
       cOld.specId == ast.specOldId && cNew.specId == ast.specNewId &&
       obst.cellCid == ast.cellOldCid && obst.specId == ast.specOldId) &&
      (reifyTransportCode 4 "reg_Q_v1" ast.baseId ast.domOldId ast.domNewId
        ast.specOldId ast.specNewId cOld.prov cNew.prov ast.reflexKind ast.transportCode).isOk &&
      (ast.parentPathKey?.isNone) &&
      (ast.claimedHistRetreat == (ast.reflexKind == .retreat))
  | _, _, _ => false

/-- Mutant 3 (`skipG4`): skips `KindDomainLaw` (`reifyRawTransport` only, ignoring `rk` mismatch)
    while keeping `G2`, `G3`, `G8`. -/
def checkMutantSkipG4 (ast : StructuralReflexAST) : Bool :=
  match stdStructStore.lookupCell? ast.cellOldCid,
        stdStructStore.lookupCell? ast.cellNewCid,
        stdStructStore.lookupObst? ast.obstCid with
  | some cOld, some cNew, some obst =>
      (ast.rflxCid != "") &&
      (cOld.baseId == ast.baseId && cNew.baseId == ast.baseId &&
       cOld.domId == ast.domOldId && cNew.domId == ast.domNewId &&
       cOld.specId == ast.specOldId && cNew.specId == ast.specNewId &&
       obst.cellCid == ast.cellOldCid && obst.specId == ast.specOldId &&
       isKernelCertifiedProvenance cOld.prov && isKernelCertifiedProvenance cNew.prov) &&
      (checkG3Matrix obst.inpKind ast.reflexKind).isOk &&
      (reifyRawTransport 4 "reg_Q_v1" ast.transportCode).isOk &&
      (ast.parentPathKey?.isNone) &&
      (ast.claimedHistRetreat == (ast.reflexKind == .retreat))
  | _, _, _ => false

/-- Mutant 4 (`skipG8`): skips parent `historicalRetreat` propagation while keeping `G2`, `G3`, `G4`. -/
def checkMutantSkipG8 (L : List StructuralLedgerEvent) (ast : StructuralReflexAST) : Bool :=
  match stdStructStore.lookupCell? ast.cellOldCid,
        stdStructStore.lookupCell? ast.cellNewCid,
        stdStructStore.lookupObst? ast.obstCid with
  | some cOld, some cNew, some obst =>
      (ast.rflxCid != "") &&
      (cOld.baseId == ast.baseId && cNew.baseId == ast.baseId &&
       cOld.domId == ast.domOldId && cNew.domId == ast.domNewId &&
       cOld.specId == ast.specOldId && cNew.specId == ast.specNewId &&
       obst.cellCid == ast.cellOldCid && obst.specId == ast.specOldId) &&
      (checkG3Matrix obst.inpKind ast.reflexKind).isOk &&
      (reifyTransportCode 4 "reg_Q_v1" ast.baseId ast.domOldId ast.domNewId
        ast.specOldId ast.specNewId cOld.prov cNew.prov ast.reflexKind ast.transportCode).isOk &&
      !((foldStructuralLedger L).epistemic.committedLineages.map (·.pathKey)).contains (derivePathKey ast)
  | _, _, _ => false

/-- Concrete positive AST 1 (`Repair` `g0 → g2` over `ℚ`). -/
def astPosRepair : StructuralReflexAST where
  rflxCid            := "r_pos_repair"
  parentPathKey?     := none
  cellOldCid         := "g0"
  obstCid            := "obst_ce0"
  cellNewCid         := "g2"
  baseId             := "base_Q"
  domOldId           := "dom_Q"
  domNewId           := "dom_Q"
  specOldId          := "spec_v1"
  specNewId          := "spec_v2"
  reflexKind         := .repair
  transportCode      := .idCode "base_Q" "dom_Q" "spec_v1" "spec_v2"
  claimedHistRetreat := false

/-- Concrete positive AST 2 (`Retreat` `g0(ℚ) → g1(ℚ\{0})`). -/
def astPosRetreat : StructuralReflexAST where
  rflxCid            := "r_pos_retreat"
  parentPathKey?     := none
  cellOldCid         := "g0"
  obstCid            := "obst_ce0"
  cellNewCid         := "g1"
  baseId             := "base_Q"
  domOldId           := "dom_Q"
  domNewId           := "dom_Q_nonzero"
  specOldId          := "spec_v1"
  specNewId          := "spec_v2"
  reflexKind         := .retreat
  transportCode      := .restrictNonzeroCode "base_Q" "spec_v1" "spec_v2"
  claimedHistRetreat := true

/-- Concrete positive AST 3 (`Refinement` `g1(ℚ\{0}) → g2(ℚ)` chained after `astPosRetreat`). -/
def astPosRefinementStep2 : StructuralReflexAST where
  rflxCid            := "r_pos_refine2"
  parentPathKey?     := some (derivePathKey astPosRetreat)
  cellOldCid         := "g1"
  obstCid            := "obst_g1_ce"
  cellNewCid         := "g2"
  baseId             := "base_Q"
  domOldId           := "dom_Q_nonzero"
  domNewId           := "dom_Q"
  specOldId          := "spec_v2"
  specNewId          := "spec_v2"
  reflexKind         := .refinement
  transportCode      := .reexpandFullCode "base_Q" "spec_v2" "spec_v2"
  claimedHistRetreat := true

/-- Adversarial AST `CE-C1-01` (`ℚ → ℚ\{0}` excision disguised as `Repair`). -/
def astAttackCEC101 : StructuralReflexAST :=
  { astPosRetreat with rflxCid := "r_atk_ce01", reflexKind := .repair, claimedHistRetreat := false }

/-- Committed step-1 retreat lineage entry for `CE-C1-02` & `astPosRefinementStep2` tests. -/
def entryCommittedRetreatStep1 : CommittedLineageEntry where
  pathKey           := derivePathKey astPosRetreat
  rflxCid           := astPosRetreat.rflxCid
  cellOldCid        := "g0"
  obstCid           := "obst_ce0"
  cellNewCid        := "g1"
  baseId            := "base_Q"
  domOldId          := "dom_Q"
  domNewId          := "dom_Q_nonzero"
  specOldId         := "spec_v1"
  specNewId         := "spec_v2"
  stepKind          := .retreat
  historicalRetreat := true

/-- Adversarial AST `CE-C1-02` (`Retreat → Repair` laundering `claimedHistRetreat := false`). -/
def astAttackCEC102 : StructuralReflexAST where
  rflxCid            := "r_atk_ce02"
  parentPathKey?     := some (derivePathKey astPosRetreat)
  cellOldCid         := "g1"
  obstCid            := "obst_g1_ce"
  cellNewCid         := "g1_rep"
  baseId             := "base_Q"
  domOldId           := "dom_Q_nonzero"
  domNewId           := "dom_Q_nonzero"
  specOldId          := "spec_v2"
  specNewId          := "spec_v2"
  reflexKind         := .repair
  transportCode      := .idCode "base_Q" "dom_Q_nonzero" "spec_v2" "spec_v2"
  claimedHistRetreat := false

/-- Adversarial AST `CE-C1-04` (`ScopedNoGo` answered by in-frame `Repair`). -/
def astAttackCEC104 : StructuralReflexAST :=
  { astPosRepair with rflxCid := "r_atk_ce04", obstCid := "obst_nogo_xor" }

/-- Adversarial AST `CE-C1-06` (`EnvironmentalFailure` misused as mathematical reflex trigger). -/
def astAttackCEC106 : StructuralReflexAST :=
  { astPosRepair with rflxCid := "r_atk_ce06", obstCid := "obst_env_timeout" }

/-- Adversarial AST for `G2` drop (`obst_wrong_cell` belongs to `"g1"` instead of `"g0"`). -/
def astAttackWrongObstCell : StructuralReflexAST :=
  { astPosRepair with rflxCid := "r_atk_wrong_cell", obstCid := "obst_wrong_cell" }

/-- **`T-B1-05b` (`Masterstroke 3` — Constructive 4-Gate Drop Necessity Theorem)**:
    Every single structural gate in `{G2, G3, G4, G8}` has an independent constructive
    `GateDropCounterexample` that is accepted by the single-gate-dropped mutant, rejected by the
    real `checkStructuralReflex`, and provably falsifies `SemStructuralValid`. -/
theorem T_B1_05b_four_gate_drop_necessity_suite :
    let L1 : List StructuralLedgerEvent := [.recordStructuralReflex entryCommittedRetreatStep1]
    (checkMutantSkipG2 astAttackWrongObstCell = true ∧
      isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astAttackWrongObstCell) = false ∧
      ¬ SemStructuralValid "reg_Q_v1" stdStructStore [] astAttackWrongObstCell ∧
      GateNecessityCert checkMutantSkipG2 []) ∧
    (checkMutantSkipG3 astAttackCEC104 = true ∧
      isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astAttackCEC104) = false ∧
      ¬ SemStructuralValid "reg_Q_v1" stdStructStore [] astAttackCEC104 ∧
      GateNecessityCert checkMutantSkipG3 []) ∧
    (checkMutantSkipG4 astAttackCEC101 = true ∧
      isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astAttackCEC101) = false ∧
      ¬ SemStructuralValid "reg_Q_v1" stdStructStore [] astAttackCEC101 ∧
      GateNecessityCert checkMutantSkipG4 []) ∧
    (checkMutantSkipG8 L1 astAttackCEC102 = true ∧
      isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore L1 astAttackCEC102) = false ∧
      ¬ SemStructuralValid "reg_Q_v1" stdStructStore L1 astAttackCEC102 ∧
      GateNecessityCert (checkMutantSkipG8 L1) L1) := by
  dsimp only
  let L1 : List StructuralLedgerEvent := [.recordStructuralReflex entryCommittedRetreatStep1]
  have hnotG2 : ¬ SemStructuralValid "reg_Q_v1" stdStructStore [] astAttackWrongObstCell := by
    intro hsem
    rcases hsem.2.2.2.1 with ⟨_, _, obst, _, _, _, hlo, _, _, _, _, _, _, _, _, _, hoc, _⟩
    have ho : obst = ⟨"obst_wrong_cell", "g1", "spec_v1", .knownV1 .counterexamplePoint⟩ := by
      simpa [stdStructStore, astAttackWrongObstCell, astPosRepair] using hlo.symm
    rw [ho] at hoc
    exact (by decide : "g1" ≠ "g0") hoc
  have hnotG3 : ¬ SemStructuralValid "reg_Q_v1" stdStructStore [] astAttackCEC104 := by
    intro hsem
    rcases hsem.2.2.2.1 with ⟨_, _, obst, okind, _, _, hlo, _, _, _, _, _, _, _, _, _, _, _, _, _, hki, _, hmat⟩
    have ho : obst = ⟨"obst_nogo_xor", "g0", "spec_v1", .knownV1 .scopedNoGo⟩ := by
      simpa [stdStructStore, astAttackCEC104, astPosRepair] using hlo.symm
    rw [ho] at hki
    injection hki with hkeq
    subst hkeq
    exact hmat
  have hnotG4 : ¬ SemStructuralValid "reg_Q_v1" stdStructStore [] astAttackCEC101 := by
    intro hsem
    rcases hsem.2.2.2.2.1 with ⟨tOld, tNew, τ, ht1, ht2, hlaw⟩
    cases tOld with
    | domQNonzero => exact (by decide : "dom_Q_nonzero" ≠ "dom_Q") ht1
    | domQ =>
        cases tNew with
        | domQ => exact (by decide : "dom_Q" ≠ "dom_Q_nonzero") ht2
        | domQNonzero =>
            exact T_A0_03_no_ValidRepairTransport_Q_to_QNonzero ⟨τ, hlaw⟩
  have hnotG8 : ¬ SemStructuralValid "reg_Q_v1" stdStructStore L1 astAttackCEC102 := by
    intro hsem
    have hpar := hsem.2.2.2.2.2.2.2 (derivePathKey astPosRetreat) rfl
    rcases hpar with ⟨parEntry, hmem, _, _, _, _, _, hprop⟩
    simp [L1, foldStructuralLedger, initStructuralLedger, stepStructuralLedger, stepEpistemicState] at hmem
    subst hmem
    have hfalse : (false : Bool) = true := hprop rfl
    contradiction
  have hm1 : checkMutantSkipG2 astAttackWrongObstCell = true := by
    simp [checkMutantSkipG2, stdStructStore, astAttackWrongObstCell, astPosRepair,
          checkG3Matrix, reifyTransportCode, reifyRawTransport, parseDomTagV1?,
          isKernelCertifiedProvenance, domTagToId, extractKindDomainLaw, Except.isOk, Except.toBool]
  have hm2 : checkMutantSkipG3 astAttackCEC104 = true := by
    simp [checkMutantSkipG3, stdStructStore, astAttackCEC104, astPosRepair,
          reifyTransportCode, reifyRawTransport, parseDomTagV1?,
          isKernelCertifiedProvenance, domTagToId, extractKindDomainLaw, Except.isOk, Except.toBool]
  have hm3 : checkMutantSkipG4 astAttackCEC101 = true := by
    simp [checkMutantSkipG4, stdStructStore, astAttackCEC101, astPosRetreat,
          checkG3Matrix, reifyRawTransport, isKernelCertifiedProvenance, Except.isOk, Except.toBool]
  have hm4 : checkMutantSkipG8 L1 astAttackCEC102 = true := by
    simp [checkMutantSkipG8, L1, entryCommittedRetreatStep1, foldStructuralLedger,
          initStructuralLedger, stepStructuralLedger, stepEpistemicState, stdStructStore,
          astAttackCEC102, astPosRetreat, derivePathKey, checkG3Matrix, reifyTransportCode,
          reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance, domTagToId,
          extractKindDomainLaw, Except.isOk, Except.toBool]
  have hc1 : isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astAttackWrongObstCell) = false := by
    simp [checkStructuralReflex, stdStructStore, astAttackWrongObstCell, astPosRepair, isStructuralAcceptBool]
  have hc2 : isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astAttackCEC104) = false := by
    simp [checkStructuralReflex, stdStructStore, astAttackCEC104, astPosRepair, checkG3Matrix,
          nonAcceptToVerdict6, isStructuralAcceptBool]
  have hc3 : isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astAttackCEC101) = false := by
    simp [checkStructuralReflex, stdStructStore, astAttackCEC101, astPosRetreat, checkG3Matrix,
          reifyTransportCode, reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance,
          domTagToId, extractKindDomainLaw, nonAcceptToVerdict6, isStructuralAcceptBool]
  have hc4 : isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore L1 astAttackCEC102) = false := by
    simp [checkStructuralReflex, L1, entryCommittedRetreatStep1, foldStructuralLedger,
          initStructuralLedger, stepStructuralLedger, stepEpistemicState, stdStructStore,
          astAttackCEC102, astPosRetreat, derivePathKey, checkG3Matrix, reifyTransportCode,
          reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance, domTagToId,
          extractKindDomainLaw, isStructuralAcceptBool]
  exact ⟨⟨hm1, hc1, hnotG2, GateNecessityCert.gateDropCounterexample _ hm1 hnotG2⟩,
         ⟨hm2, hc2, hnotG3, GateNecessityCert.gateDropCounterexample _ hm2 hnotG3⟩,
         ⟨hm3, hc3, hnotG4, GateNecessityCert.gateDropCounterexample _ hm3 hnotG4⟩,
         ⟨hm4, hc4, hnotG8, GateNecessityCert.gateDropCounterexample _ hm4 hnotG8⟩⟩

/-! ### 6. `T-B1-06` (`Check / Commit / Grant` Separation) & `T-B1-08` (Positive + Adversarial Suite) -/

/-- Sample pre-existing institutional grant on `"g2"` (`Reused CellCID` test & `Eligible` separation). -/
def sampleGrantG2 : InstitutionalGrantRec where
  grantCid         := "grant_g2_01"
  targetCellCid    := "g2"
  claimId          := .sqNonneg
  specId           := "spec_v2"
  subdomId         := .allRat
  requiredPremises := ["p1"]
  expiresEpoch     := 50

/-- **`T-B1-06` — Tri-Phase `Check / Commit / Grant` Separation, Exact Snapshot & `PathKey` Guards,
    and `GrantLedger_{t+1} = GrantLedger_t` vs `Eligible_{t+1} ≠ Eligible_t` Separation**:
    (1) Universal Zero-Mint & Zero-Transfer: appending `.recordStructuralReflex e` leaves `grantLedger`
        and `lookupCellGrantsInLedger L c` identically unchanged for ALL cells `c`;
    (2) Fresh vs Reused `CellCID`: if `lookupCellGrantsInLedger L c = []`, it stays `[]` after commit;
        if `"g2"` already held `[sampleGrantG2]`, it retains exact `[sampleGrantG2]` without minting new grants;
    (3) Same-length divergent history substitution (`|L_a| = |L_b| = 1`, `L_a ≠ L_b`) is rejected with
        `.staleOrDivergentSnapshot`, and duplicate `PathKey` commit is rejected with `.duplicatePathKey`;
    (4) `GrantLedger` vs `Eligible` separation (`Tribunal §3`): appending `.retractPremise "p1"` preserves
        `grantLedger` identically (`rfl`), YET flips `isGrantCurrentlyEligibleBool` on `sampleGrantG2`
        from `true` to `false`. -/
theorem T_B1_06_tri_phase_zero_mint_snapshot_pathKey_and_eligibility_sep :
    (∀ (L : List StructuralLedgerEvent) (e : CommittedLineageEntry) (c : String),
      (foldStructuralLedger (L ++ [.recordStructuralReflex e])).grantLedger =
        (foldStructuralLedger L).grantLedger ∧
      lookupCellGrantsInLedger (L ++ [.recordStructuralReflex e]) c =
        lookupCellGrantsInLedger L c) ∧
    (∀ (L : List StructuralLedgerEvent) (e : CommittedLineageEntry) (c : String),
      lookupCellGrantsInLedger L c = [] →
        lookupCellGrantsInLedger (L ++ [.recordStructuralReflex e]) c = []) ∧
    (let L_reused : List StructuralLedgerEvent := [.issueGrantHeld sampleGrantG2]
     lookupCellGrantsInLedger (L_reused ++ [.recordStructuralReflex entryCommittedRetreatStep1]) "g2" =
       [sampleGrantG2] ∧
     lookupCellGrantsInLedger (L_reused ++ [.recordStructuralReflex entryCommittedRetreatStep1]) "g1" =
       []) ∧
    (∀ (sq : StructuralQualification),
      let La : List StructuralLedgerEvent := [.advanceEpoch 1]
      let Lb : List StructuralLedgerEvent := [.retractPremise "p1"]
      La.length = Lb.length ∧
      La ≠ Lb ∧
      tryCommitStructural Lb ⟨sq, .repair, La⟩ = .error .staleOrDivergentSnapshot) ∧
    (∀ (sq : StructuralQualification),
      (extractSummary sq).pathKey = entryCommittedRetreatStep1.pathKey →
        let L_dup : List StructuralLedgerEvent := [.recordStructuralReflex entryCommittedRetreatStep1]
        tryCommitStructural L_dup ⟨sq, .retreat, L_dup⟩ = .error .duplicatePathKey) ∧
    (let dag : PremDag := [("p1", [])]
     let L0 : List StructuralLedgerEvent := [.issueGrantHeld sampleGrantG2]
     let L1 : List StructuralLedgerEvent := [.issueGrantHeld sampleGrantG2, .retractPremise "p1"]
     (foldStructuralLedger L1).grantLedger = (foldStructuralLedger L0).grantLedger ∧
     isGrantCurrentlyEligibleBool dag L0 sampleGrantG2 = true ∧
     isGrantCurrentlyEligibleBool dag L1 sampleGrantG2 = false) := by
  have hzero : ∀ (L : List StructuralLedgerEvent) (e : CommittedLineageEntry) (c : String),
      (foldStructuralLedger (L ++ [.recordStructuralReflex e])).grantLedger =
        (foldStructuralLedger L).grantLedger ∧
      lookupCellGrantsInLedger (L ++ [.recordStructuralReflex e]) c =
        lookupCellGrantsInLedger L c := by
    intro L e c
    have hg : (foldStructuralLedger (L ++ [.recordStructuralReflex e])).grantLedger =
        (foldStructuralLedger L).grantLedger := by
      unfold foldStructuralLedger
      rw [List.foldl_append]
      rfl
    refine ⟨hg, ?_⟩
    unfold lookupCellGrantsInLedger
    rw [hg]
  refine ⟨hzero, ?_, ?_, ?_, ?_, ?_⟩
  · intro L e c hemp
    rw [(hzero L e c).2, hemp]
  · exact ⟨by decide, by decide⟩
  · intro sq
    dsimp only
    refine ⟨rfl, by decide, ?_⟩
    have hne : ([StructuralLedgerEvent.retractPremise "p1"] !=
        [StructuralLedgerEvent.advanceEpoch 1]) = true := by decide
    unfold tryCommitStructural
    dsimp only
    rw [if_pos hne]
  · intro sq hpk
    dsimp only
    unfold tryCommitStructural
    dsimp only
    have hsnap : ([StructuralLedgerEvent.recordStructuralReflex entryCommittedRetreatStep1] !=
        [StructuralLedgerEvent.recordStructuralReflex entryCommittedRetreatStep1]) = false := by decide
    rw [hsnap]
    have hcont : (((foldStructuralLedger [.recordStructuralReflex entryCommittedRetreatStep1]).epistemic.committedLineages.map
        (·.pathKey)).contains (extractSummary sq).pathKey) = true := by
      rw [hpk]
      decide
    exact if_pos hcont
  · exact ⟨rfl, by decide, by decide⟩

/-- **`T-B1-08` — Non-Vacuity (`3` Positive `StructuralAccept`s) & Full Adversarial Rejection/Hold Suite**:
    (1) Positive `StructuralAccept`: `astPosRepair` (`Repair`), `astPosRetreat` (`Retreat`), and
        chained `astPosRefinementStep2` (`Refinement`) all evaluate to `isStructuralAcceptBool = true`;
    (2) Adversarial `.rejectInvalid`: `CE-C1-01` (domain excision as `Repair`), `CE-C1-02` (`Retreat → Repair`
        hiding historical retreat), `CE-C1-04` (`ScopedNoGo` + `Repair`), and `CE-C1-06` (`EnvironmentalFailure`
        misuse) all evaluate to exact `.rejectInvalid` verdicts;
    (3) Non-refuting `Held` branches: missing store cell yields `.unavailableHeld`, `derivationBlocked`
        and `extObstruction` and unknown domain/transport tags yield `.unsupportedHeld`, and `fuel = 0`
        yields `.resourceHeld 0`. -/
theorem T_B1_08_positive_structural_accepts_and_adversarial_suite :
    let L1 : List StructuralLedgerEvent := [.recordStructuralReflex entryCommittedRetreatStep1]
    -- (1) Three positive `StructuralAccept` witnesses (`Repair`, `Retreat`, `Refinement`)
    (isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astPosRepair) = true ∧
     isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astPosRetreat) = true ∧
     isStructuralAcceptBool (checkStructuralReflex 4 "reg_Q_v1" stdStructStore L1 astPosRefinementStep2) = true) ∧
    -- (2) Adversarial `.rejectInvalid` witnesses (`CE-C1-01`, `CE-C1-02`, `CE-C1-04`, `CE-C1-06`)
    (checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astAttackCEC101 =
       .rejectInvalid .G4 .kindDomainLawViolation ∧
     checkStructuralReflex 4 "reg_Q_v1" stdStructStore L1 astAttackCEC102 =
       .rejectInvalid .G8 .retreatFlagLaundering ∧
     checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astAttackCEC104 =
       .rejectInvalid .G3 .forbiddenObstReflexPair ∧
     checkStructuralReflex 4 "reg_Q_v1" stdStructStore [] astAttackCEC106 =
       .rejectInvalid .G3 .nonEpistemicObstMisuse) ∧
    -- (3) Non-refuting `UnavailableHeld`, `UnsupportedHeld`, and `ResourceHeld` witnesses
    (checkStructuralReflex 4 "reg_Q_v1" stdStructStore []
       { astPosRepair with cellNewCid := "g_missing_payload" } =
       .unavailableHeld "g_missing_payload" ∧
     checkStructuralReflex 4 "reg_Q_v1" stdStructStore []
       { astPosRepair with obstCid := "obst_blocked" } =
       .unsupportedHeld "derivation_blocked_non_refuting" ∧
     checkStructuralReflex 4 "reg_Q_v1" stdStructStore []
       { astPosRepair with obstCid := "obst_ext_prob" } =
       .unsupportedHeld "ext_obst:prob_drift_v2" ∧
     checkStructuralReflex 4 "reg_Q_v1" stdStructStore []
       { astPosRepair with cellNewCid := "g_unauth_dom", domNewId := "dom_C_complex" } =
       .unsupportedHeld "dom_new:dom_C_complex" ∧
     checkStructuralReflex 0 "reg_Q_v1" stdStructStore [] astPosRepair =
       .resourceHeld 0) := by
  dsimp only
  refine ⟨⟨?_, ?_, ?_⟩, ⟨?_, ?_, ?_, ?_⟩, ⟨?_, ?_, ?_, ?_, rfl⟩⟩
  · simp [checkStructuralReflex, stdStructStore, astPosRepair, checkG3Matrix,
          reifyTransportCode, reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance,
          domTagToId, extractKindDomainLaw, foldStructuralLedger, initStructuralLedger,
          derivePathKey, isStructuralAcceptBool]
  · simp [checkStructuralReflex, stdStructStore, astPosRetreat, checkG3Matrix,
          reifyTransportCode, reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance,
          domTagToId, extractKindDomainLaw, foldStructuralLedger, initStructuralLedger,
          derivePathKey, isStructuralAcceptBool]
  · simp [checkStructuralReflex, stdStructStore, astPosRefinementStep2, astPosRetreat,
          entryCommittedRetreatStep1, checkG3Matrix, reifyTransportCode, reifyRawTransport,
          parseDomTagV1?, isKernelCertifiedProvenance, domTagToId, extractKindDomainLaw,
          foldStructuralLedger, initStructuralLedger, stepStructuralLedger, stepEpistemicState,
          derivePathKey, isStructuralAcceptBool]
  · simp [checkStructuralReflex, stdStructStore, astAttackCEC101, astPosRetreat, checkG3Matrix,
          reifyTransportCode, reifyRawTransport, parseDomTagV1?, isKernelCertifiedProvenance,
          domTagToId, extractKindDomainLaw, nonAcceptToVerdict6]
  · simp [checkStructuralReflex, stdStructStore, astAttackCEC102, astPosRetreat,
          entryCommittedRetreatStep1, checkG3Matrix, reifyTransportCode, reifyRawTransport,
          parseDomTagV1?, isKernelCertifiedProvenance, domTagToId, extractKindDomainLaw,
          foldStructuralLedger, initStructuralLedger, stepStructuralLedger, stepEpistemicState,
          derivePathKey]
  · simp [checkStructuralReflex, stdStructStore, astAttackCEC104, astPosRepair, checkG3Matrix,
          nonAcceptToVerdict6]
  · simp [checkStructuralReflex, stdStructStore, astAttackCEC106, astPosRepair, checkG3Matrix,
          nonAcceptToVerdict6]
  · simp [checkStructuralReflex, stdStructStore, astPosRepair]
  · simp [checkStructuralReflex, stdStructStore, astPosRepair, checkG3Matrix, nonAcceptToVerdict6]
  · simp [checkStructuralReflex, stdStructStore, astPosRepair, checkG3Matrix, nonAcceptToVerdict6]
  · simp [checkStructuralReflex, stdStructStore, astPosRepair, checkG3Matrix, reifyTransportCode,
          parseDomTagV1?, isKernelCertifiedProvenance, nonAcceptToVerdict6]

end OmegaCellC1P1B1
