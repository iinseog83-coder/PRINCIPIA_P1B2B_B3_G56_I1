/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B3 — G56 Certified Coupling Kernel (`Formalization Act I0`)
  Module: OmegaCellC1P1B2BB3.B3_02_SharedContextAndJointClosure

  Authorization: Human L4 Final Freeze (`SCOPED_STATIC_BASELINE_FROZEN`) & `FORMALIZATION_ACT_I0`
  Gates Covered:
    - `I0-A2`: Shared Context Enforcement (`Γ5 = Γ6 = ctx.primEnv`, `C5 = C6 = ctx.dagCont` without
      merging) & Constructive Separation of `SyntacticValidPrimEnv Γ` vs `SemValidPrimId Γ p`.
    - `I0-A3`: Exact Joint Premise Closure (`D56 = D5 ∪ D6 = canonSortStrs (D5 ++ D6) =
      multiRootTransitivePrimDeps Γ C (R5 ++ R6)`), strict sorting, `Nodup`, premise distribution,
      and full `L1` proof-root collection (`collectLossEquivRootIds`, `collectG56JointProofRootIds`).
-/
import OmegaCellC1P1B2BB3.B3_01_TransitionTypesAndPullback

namespace OmegaCellC1P1B2BB3

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2

/-! ### 1. `I0-A2` — Shared Context Packet Gate & `SyntacticValidPrimEnv` vs `SemValidPrimId` -/

/-- Deterministic packet-boundary check rejecting split `PrimPremiseEnv` or split `G7DagContainer`
    without attempting environment merging (`C-B3-02`, `CE-G56-04`, `CE-G56-05`). -/
def checkG56PacketContextError? (ctx : G56SharedContext)
    (pkt : G56UntrustedCandidatePacket) : Option G56BindingError :=
  if (pkt.g5ClaimedEnv != ctx.primEnv) || (pkt.g6ClaimedEnv != ctx.primEnv) then
    some .mismatchedPrimEnv
  else if (pkt.g5ClaimedCont != ctx.dagCont) || (pkt.g6ClaimedCont != ctx.dagCont) then
    some .mismatchedDagContainer
  else
    none

/-- **`T_I0_A2_01` — Split-Context Packet Gate Exactness**:
    `checkG56PacketContextError? ctx pkt = none` iff `pkt.g5ClaimedEnv = ctx.primEnv`,
    `pkt.g6ClaimedEnv = ctx.primEnv`, `pkt.g5ClaimedCont = ctx.dagCont`, and
    `pkt.g6ClaimedCont = ctx.dagCont` (hence `Γ5 = Γ6` and `C5 = C6`). -/
theorem T_I0_A2_01_PacketContextExactSharedIdentity
    (ctx : G56SharedContext) (pkt : G56UntrustedCandidatePacket) :
    checkG56PacketContextError? ctx pkt = none ↔
      (pkt.g5ClaimedEnv = ctx.primEnv ∧
       pkt.g6ClaimedEnv = ctx.primEnv ∧
       pkt.g5ClaimedCont = ctx.dagCont ∧
       pkt.g6ClaimedCont = ctx.dagCont) := by
  unfold checkG56PacketContextError?
  constructor
  · intro hNone
    by_cases hEnv : ((pkt.g5ClaimedEnv != ctx.primEnv) || (pkt.g6ClaimedEnv != ctx.primEnv)) = true
    · rw [if_pos hEnv] at hNone; nomatch hNone
    · rw [if_neg hEnv] at hNone
      by_cases hCont : ((pkt.g5ClaimedCont != ctx.dagCont) || (pkt.g6ClaimedCont != ctx.dagCont)) = true
      · rw [if_pos hCont] at hNone; nomatch hNone
      · have he1 : pkt.g5ClaimedEnv = ctx.primEnv := by
          cases hb : (pkt.g5ClaimedEnv == ctx.primEnv) with
          | true  => exact eq_of_beq hb
          | false => simp [bne, hb] at hEnv
        have he2 : pkt.g6ClaimedEnv = ctx.primEnv := by
          cases hb : (pkt.g6ClaimedEnv == ctx.primEnv) with
          | true  => exact eq_of_beq hb
          | false => simp [bne, hb] at hEnv
        have hc1 : pkt.g5ClaimedCont = ctx.dagCont := by
          cases hb : (pkt.g5ClaimedCont == ctx.dagCont) with
          | true  => exact eq_of_beq hb
          | false => simp [bne, hb] at hCont
        have hc2 : pkt.g6ClaimedCont = ctx.dagCont := by
          cases hb : (pkt.g6ClaimedCont == ctx.dagCont) with
          | true  => exact eq_of_beq hb
          | false => simp [bne, hb] at hCont
        exact ⟨he1, he2, hc1, hc2⟩
  · rintro ⟨he1, he2, hc1, hc2⟩
    rw [he1, he2, hc1, hc2]
    simp

/-- Structurally valid environment containing a semantically FALSE premise `0 > 0` (`I0-A2`). -/
def a2FalsePremiseEnv : PrimPremiseEnv :=
  [{ premId        := "p_false_zero_pos"
     domTag        := .domQ
     specId        := "spec_a2"
     formula       := .pos (.const 0)
     parentPremIds := [] }]

/-- **`T_I0_A2_02` — Constructive Separation of `SyntacticValidPrimEnv` and `SemValidPrimId`**:
    `a2FalsePremiseEnv` satisfies structural integrity `SyntacticValidPrimEnv a2FalsePremiseEnv`,
    yet violates `SemValidPrimId a2FalsePremiseEnv "p_false_zero_pos"`, proving that syntactic
    environment validity NEVER implies semantic truth of primitive premises! -/
theorem T_I0_A2_02_SyntacticEnvDoesNotImplySemValidPrim :
    SyntacticValidPrimEnv a2FalsePremiseEnv ∧
    ¬ SemValidPrimId a2FalsePremiseEnv "p_false_zero_pos" := by
  refine ⟨by decide, ?_⟩
  intro hSem
  have hEntry : lookupPrimPrem? a2FalsePremiseEnv "p_false_zero_pos" =
      some { premId := "p_false_zero_pos", domTag := .domQ, specId := "spec_a2",
             formula := .pos (.const 0), parentPremIds := [] } := rfl
  have hMod : ModelsStrictForm (.pos (.const 0)) ((0 : Rat), (0 : Rat)) :=
    hSem _ hEntry ((0 : Rat), (0 : Rat)) rfl
  rcases hMod.2 with ⟨v, hv, hPos⟩
  cases hv
  exact Rat.lt_irrefl hPos

/-! ### 2. Canonical Strict-Order Extensionality on `List String` (`I0-A3` Core Lemmas) -/

/-- Any pairwise `strStrictLt`-sorted list is duplicate-free (`List.Nodup`). -/
theorem nodup_of_pairwise_strStrictLt :
    ∀ {L : List String},
      List.Pairwise (fun a b => strStrictLt a b = true) L → L.Nodup
  | [], _ => List.Pairwise.nil
  | _ :: _, hpw => by
      rcases List.pairwise_cons.mp hpw with ⟨hHead, hTail⟩
      refine List.Pairwise.cons ?_ (nodup_of_pairwise_strStrictLt hTail)
      intro b hb heq
      subst heq
      have hlt := hHead _ hb
      rw [strStrictLt_irrefl] at hlt
      nomatch hlt

/-- Extensional uniqueness of `strStrictLt`-sorted lists: two strictly sorted `String` lists
    containing the exact same set of elements are syntactically identical (`L1 = L2`). -/
theorem pairwise_strStrictLt_ext :
    ∀ {L1 L2 : List String},
      List.Pairwise (fun a b => strStrictLt a b = true) L1 →
      List.Pairwise (fun a b => strStrictLt a b = true) L2 →
      (∀ x : String, x ∈ L1 ↔ x ∈ L2) →
      L1 = L2
  | [], [], _, _, _ => rfl
  | [], y :: _, _, _, hMem =>
      False.elim (List.not_mem_nil ((hMem y).mpr (List.mem_cons_self ..)))
  | x :: _, [], _, _, hMem =>
      False.elim (List.not_mem_nil ((hMem x).mp (List.mem_cons_self ..)))
  | x :: xs, y :: ys, hpw1, hpw2, hMem => by
      rcases List.pairwise_cons.mp hpw1 with ⟨hx_all, hxs⟩
      rcases List.pairwise_cons.mp hpw2 with ⟨hy_all, hys⟩
      have hxy : x = y := by
        rcases strStrictLt_trichotomy x y with hlt | heq | hgt
        · have hxIn2 : x ∈ y :: ys := (hMem x).mp (List.mem_cons_self ..)
          rcases List.mem_cons.mp hxIn2 with hEq | hxYs
          · exact hEq
          · have hyx := hy_all x hxYs
            have hxx := strStrictLt_trans hlt hyx
            rw [strStrictLt_irrefl] at hxx; nomatch hxx
        · exact heq
        · have hyIn1 : y ∈ x :: xs := (hMem y).mpr (List.mem_cons_self ..)
          rcases List.mem_cons.mp hyIn1 with hEq | hyXs
          · exact hEq.symm
          · have hxy' := hx_all y hyXs
            have hyy := strStrictLt_trans hgt hxy'
            rw [strStrictLt_irrefl] at hyy; nomatch hyy
      subst hxy
      have hTailMem : ∀ z : String, z ∈ xs ↔ z ∈ ys := by
        intro z
        constructor
        · intro hzXs
          have hzIn2 : z ∈ x :: ys := (hMem z).mp (List.mem_cons_of_mem x hzXs)
          rcases List.mem_cons.mp hzIn2 with rfl | hzYs
          · have hxx := hx_all z hzXs
            rw [strStrictLt_irrefl] at hxx; contradiction
          · exact hzYs
        · intro hzYs
          have hzIn1 : z ∈ x :: xs := (hMem z).mpr (List.mem_cons_of_mem x hzYs)
          rcases List.mem_cons.mp hzIn1 with rfl | hzXs
          · have hxx := hy_all z hzYs
            rw [strStrictLt_irrefl] at hxx; contradiction
          · exact hzXs
      rw [pairwise_strStrictLt_ext hxs hys hTailMem]

/-- Two `canonSortStrs` projections are equal iff the underlying lists have the same members. -/
theorem canonSortStrs_eq_iff_mem (L1 L2 : List String) :
    canonSortStrs L1 = canonSortStrs L2 ↔ (∀ x : String, x ∈ L1 ↔ x ∈ L2) := by
  constructor
  · intro hEq x
    rw [← mem_canonSortStrs L1 x, ← mem_canonSortStrs L2 x, hEq]
  · intro hIff
    apply pairwise_strStrictLt_ext
      (canonSortStrs_canonical_laws L1).1
      (canonSortStrs_canonical_laws L2).1
    intro x
    rw [mem_canonSortStrs, mem_canonSortStrs]
    exact hIff x

private theorem mem_foldr_union_iff_b3 {α : Type} (f : String → List α) :
    ∀ (roots : List String) (x : α),
      x ∈ roots.foldr (fun r acc => f r ++ acc) [] ↔
      ∃ r ∈ roots, x ∈ f r
  | [], _ =>
      Iff.intro (fun h => nomatch h) (fun h => by rcases h with ⟨_, hr, _⟩; nomatch hr)
  | r :: rs, x => by
      dsimp only [List.foldr]
      rw [List.mem_append, mem_foldr_union_iff_b3 f rs x]
      constructor
      · rintro (hx | ⟨u, hu, hxu⟩)
        · exact ⟨r, List.mem_cons_self .., hx⟩
        · exact ⟨u, List.mem_cons_of_mem r hu, hxu⟩
      · rintro ⟨u, hu, hxu⟩
        rcases List.mem_cons.mp hu with rfl | huTail
        · exact Or.inl hxu
        · exact Or.inr ⟨u, huTail, hxu⟩

/-- Exact membership characterization of `multiRootTransitivePrimDeps`. -/
theorem mem_multiRootTransitivePrimDeps_iff (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (roots : List String) (p : String) :
    p ∈ multiRootTransitivePrimDeps Γ C roots ↔
      ∃ r ∈ roots, p ∈ extractTransitivePrimDeps Γ C r := by
  unfold multiRootTransitivePrimDeps
  rw [mem_canonSortStrs]
  exact mem_foldr_union_iff_b3 (extractTransitivePrimDeps Γ C) roots p

/-- Distributivity of `multiRootTransitivePrimDeps` over root-list append (`I0-A3` Core Identity):
    `multiRootTransitivePrimDeps Γ C (R1 ++ R2) =
       canonSortStrs (multiRootTransitivePrimDeps Γ C R1 ++ multiRootTransitivePrimDeps Γ C R2)`. -/
theorem multiRootTransitivePrimDeps_append_eq (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (R1 R2 : List String) :
    multiRootTransitivePrimDeps Γ C (R1 ++ R2) =
      canonSortStrs (multiRootTransitivePrimDeps Γ C R1 ++ multiRootTransitivePrimDeps Γ C R2) := by
  unfold multiRootTransitivePrimDeps
  apply (canonSortStrs_eq_iff_mem _ _).mpr
  intro p
  rw [List.mem_append,
      mem_canonSortStrs, mem_canonSortStrs,
      mem_foldr_union_iff_b3 (extractTransitivePrimDeps Γ C) (R1 ++ R2) p,
      mem_foldr_union_iff_b3 (extractTransitivePrimDeps Γ C) R1 p,
      mem_foldr_union_iff_b3 (extractTransitivePrimDeps Γ C) R2 p]
  constructor
  · rintro ⟨r, hr, hp⟩
    rcases List.mem_append.mp hr with hr1 | hr2
    · exact Or.inl ⟨r, hr1, hp⟩
    · exact Or.inr ⟨r, hr2, hp⟩
  · rintro (⟨r, hr1, hp⟩ | ⟨r, hr2, hp⟩)
    · exact ⟨r, List.mem_append_left _ hr1, hp⟩
    · exact ⟨r, List.mem_append_right _ hr2, hp⟩

/-! ### 3. Joint Premise Closure `D56` & Auxiliary `L1` Proof-Root Collection (`I0-A3` & `I0-A4`) -/

/-- **`deriveG56JointPrimDeps` (`C-B3-05`, `I0-A3`)**:
    Canonical deduplicated strictly-sorted union `D56 := canonSortStrs (D5 ++ D6)`. -/
def deriveG56JointPrimDeps (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite) : List String :=
  canonSortStrs (deriveG5PrimDeps Γ C c5 ++ deriveG6PrimDeps Γ C s6)

/-- Raw `G7` node IDs referenced inside a single `G56DirectionalLocusCover`. -/
def rawDirectionalCoverRootIds (cov : G56DirectionalLocusCover) : List String :=
  cov.targetDefNodes.map Prod.snd ++
  cov.branchCovers.foldr (fun (_, _, ps) acc => ps.map Prod.snd ++ acc) []

/-- Canonical sorted list of ALL `G7` proof root IDs referenced in `w : G56LossEquivWitness`. -/
def collectLossEquivRootIds (w : G56LossEquivWitness) : List String :=
  canonSortStrs (rawDirectionalCoverRootIds w.l5ImpliesL6 ++ rawDirectionalCoverRootIds w.l6ImpliesL5)

/-- Canonical sorted list of all `L1` `G7` loss-equivalence proof roots across `sc : G56ScopeCompatibility`. -/
def collectScopeCompatLossRootIds : G56ScopeCompatibility → List String
  | .retreatExactSharedLoss _ itemBinds =>
      canonSortStrs (itemBinds.foldr (fun b acc =>
        match b.mode with
        | .l0SyntacticEq   => acc
        | .l1CertifiedEq w => collectLossEquivRootIds w ++ acc) [])
  | _ => []

/-- Canonical sorted list of all joint proof roots (`R5 ∪ R6 ∪ R_L1`) for `c56 : G56CouplingCert`. -/
def collectG56JointProofRootIds (c5 : G5DischargeCert) (s6 : G6ProtectedSuite)
    (sc : G56ScopeCompatibility) : List String :=
  canonSortStrs (
    collectG5ProofRootIds c5 ++
    collectG6ProofRootIds s6 ++
    collectScopeCompatLossRootIds sc)

/-- Transitive primitive premise closure `D7` of all `L1` loss-equivalence roots in `sc`. -/
def deriveScopeCompatL1PrimDeps (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (sc : G56ScopeCompatibility) : List String :=
  multiRootTransitivePrimDeps Γ C (collectScopeCompatLossRootIds sc)

/-! ### 4. Mandatory `I0-A3` Joint Dependency Closure Theorems (`T_I0_A3_01 .. T_I0_A3_04`) -/

/-- **`T_I0_A3_01` — Exact Set-Union, Canonical List, & Multi-Root Closure Identity**:
    Proves BOTH required equations of `I0-A3`:
    (1) `∀ p, p ∈ D56 ↔ p ∈ D5 ∨ p ∈ D6` (`D56 = D5 ∪ D6`),
    (2) `D56 = canonSortStrs (D5 ++ D6) = multiRootTransitivePrimDeps Γ C (R5 ++ R6)`,
    (3) `isStrictCanonStrList D56 = true` and `D56.Nodup`! -/
theorem T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure
    (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite) :
    let D5  := deriveG5PrimDeps Γ C c5
    let D6  := deriveG6PrimDeps Γ C s6
    let D56 := deriveG56JointPrimDeps Γ C c5 s6
    let R5  := collectG5ProofRootIds c5
    let R6  := collectG6ProofRootIds s6
    (∀ p : String, p ∈ D56 ↔ (p ∈ D5 ∨ p ∈ D6)) ∧
    D56 = canonSortStrs (D5 ++ D6) ∧
    D56 = multiRootTransitivePrimDeps Γ C (R5 ++ R6) ∧
    isStrictCanonStrList D56 = true ∧
    D56.Nodup := by
  dsimp only
  refine ⟨?_, rfl, ?_, ?_, ?_⟩
  · intro p
    unfold deriveG56JointPrimDeps
    rw [mem_canonSortStrs, List.mem_append]
  · unfold deriveG56JointPrimDeps deriveG5PrimDeps deriveG6PrimDeps
    exact (multiRootTransitivePrimDeps_append_eq Γ C
      (collectG5ProofRootIds c5) (collectG6ProofRootIds s6)).symm
  · unfold deriveG56JointPrimDeps
    exact (canonSortStrs_canonical_laws _).2.1
  · unfold deriveG56JointPrimDeps
    exact nodup_of_pairwise_strStrictLt (canonSortStrs_canonical_laws _).1

/-- **`T_I0_A3_02` — Semantic Premise Distribution Across `D56 = D5 ∪ D6` & Constrained `D7 ⊆ D56`**:
    (1) `(∀ p ∈ D56, SemValidPrimId Γ p) ↔ (∀ p ∈ D5, SemValidPrimId Γ p) ∧ (∀ p ∈ D6, SemValidPrimId Γ p)`;
    (2) Under conservative confinement `∀ p ∈ D7, p ∈ D56` (`Q-B3-R1-03`), `∀ p ∈ D56, SemValidPrimId Γ p`
        immediately entails `∀ p ∈ D7, SemValidPrimId Γ p` with ZERO expansion of `D56`! -/
theorem T_I0_A3_02_SemanticPremiseDistributionAndConfinement
    (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite) (D7 : List String) :
    let D5  := deriveG5PrimDeps Γ C c5
    let D6  := deriveG6PrimDeps Γ C s6
    let D56 := deriveG56JointPrimDeps Γ C c5 s6
    ((∀ p ∈ D56, SemValidPrimId Γ p) ↔
      ((∀ p ∈ D5, SemValidPrimId Γ p) ∧ (∀ p ∈ D6, SemValidPrimId Γ p))) ∧
    ((∀ p ∈ D7, p ∈ D56) →
      (∀ p ∈ D56, SemValidPrimId Γ p) →
      (∀ p ∈ D7, SemValidPrimId Γ p)) := by
  dsimp only
  have hMem := (T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure Γ C c5 s6).1
  refine ⟨?_, fun hSub hAll p hp7 => hAll p (hSub p hp7)⟩
  constructor
  · intro hAll
    exact ⟨fun p hp5 => hAll p ((hMem p).mpr (Or.inl hp5)),
           fun p hp6 => hAll p ((hMem p).mpr (Or.inr hp6))⟩
  · rintro ⟨h5, h6⟩ p hp56
    rcases (hMem p).mp hp56 with hp5 | hp6
    · exact h5 p hp5
    · exact h6 p hp6

/-- **`T_I0_A3_03` — Monotonicity of Root Inclusion Into Joint Proof Roots**:
    Every `G5` proof root, every `G6` proof root, and every `L1` loss-equivalence proof root
    in `sc` belongs to `collectG56JointProofRootIds c5 s6 sc`. -/
theorem T_I0_A3_03_JointProofRootsContainAllSubRoots
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite) (sc : G56ScopeCompatibility) :
    let R_joint := collectG56JointProofRootIds c5 s6 sc
    (∀ r ∈ collectG5ProofRootIds c5, r ∈ R_joint) ∧
    (∀ r ∈ collectG6ProofRootIds s6, r ∈ R_joint) ∧
    (∀ r ∈ collectScopeCompatLossRootIds sc, r ∈ R_joint) := by
  dsimp only
  refine ⟨?_, ?_, ?_⟩
  · intro r hr
    unfold collectG56JointProofRootIds
    rw [mem_canonSortStrs]
    exact List.mem_append_left _ (List.mem_append_left _ hr)
  · intro r hr
    unfold collectG56JointProofRootIds
    rw [mem_canonSortStrs]
    exact List.mem_append_left _ (List.mem_append_right _ hr)
  · intro r hr
    unfold collectG56JointProofRootIds
    rw [mem_canonSortStrs]
    exact List.mem_append_right _ hr

private theorem lookupPrimPrem?_replace_ne (Γ : PrimPremiseEnv)
    (p_out pid : String) (newFormula : StrictForm) (hNe : pid ≠ p_out) :
    lookupPrimPrem? (replacePrimFormulaInEnv Γ p_out newFormula) pid =
      lookupPrimPrem? Γ pid := by
  unfold lookupPrimPrem? replacePrimFormulaInEnv
  induction Γ with
  | nil => rfl
  | cons e es ih =>
      dsimp only [List.map, List.find?]
      by_cases h1 : (e.premId == p_out) = true
      · rw [if_pos h1]
        have heqOut : e.premId = p_out := eq_of_beq h1
        have hFalse : (e.premId == pid) = false := by
          apply Bool.eq_false_iff.mpr
          intro hb
          exact hNe (heqOut.symm.trans (eq_of_beq hb)).symm
        dsimp only
        rw [hFalse]
        exact ih
      · rw [if_neg h1]
        cases (e.premId == pid) with
        | true  => rfl
        | false => exact ih

/-- **`T_I0_A3_04` — Outside-`D56` Formula Non-Interference on `G5` & `G6` Core Evaluators**:
    If `p_out ∉ deriveG56JointPrimDeps Γ C c5 s6` and `SyntacticValidPrimEnv Γ` & `ValidContainer C`,
    replacing `p_out`'s formula via `replacePrimFormulaInEnv` preserves `SyntacticValidPrimEnv`,
    preserves `deriveG5PrimDeps`, `deriveG6PrimDeps`, and `deriveG56JointPrimDeps`, and preserves
    both `checkG5DischargeBool` and `checkG6Suite` (`CE-G56-17A`)! -/
theorem T_I0_A3_04_OutsideJointPremiseFormulaNonInterference
    (fuel5 fuel6 : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (c5 : G5DischargeCert) (s6 : G6ProtectedSuite)
    (p_out : String) (newFormula : StrictForm)
    (hEnv  : SyntacticValidPrimEnv Γ)
    (hCont : ValidContainer C)
    (hOut  : p_out ∉ deriveG56JointPrimDeps Γ C c5 s6) :
    let Γ' := replacePrimFormulaInEnv Γ p_out newFormula
    SyntacticValidPrimEnv Γ' ∧
    deriveG5PrimDeps Γ' C c5 = deriveG5PrimDeps Γ C c5 ∧
    deriveG6PrimDeps Γ' C s6 = deriveG6PrimDeps Γ C s6 ∧
    deriveG56JointPrimDeps Γ' C c5 s6 = deriveG56JointPrimDeps Γ C c5 s6 ∧
    checkG5DischargeBool fuel5 Γ' C c5 = checkG5DischargeBool fuel5 Γ C c5 ∧
    checkG6Suite fuel6 Γ' C s6 = checkG6Suite fuel6 Γ C s6 := by
  dsimp only
  have hMem := (T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure Γ C c5 s6).1 p_out
  have hOut5 : p_out ∉ deriveG5PrimDeps Γ C c5 :=
    fun h5 => hOut (hMem.mpr (Or.inl h5))
  have hOut6 : p_out ∉ deriveG6PrimDeps Γ C s6 :=
    fun h6 => hOut (hMem.mpr (Or.inr h6))
  have hG6NonInt := T_B2_A7_4_OutsidePremise_FullNonInterference
    fuel6 Γ C s6 hCont p_out hOut6 newFormula
  have hEnv' : SyntacticValidPrimEnv (replacePrimFormulaInEnv Γ p_out newFormula) := by
    unfold SyntacticValidPrimEnv at hEnv ⊢
    rw [hG6NonInt.1]
    exact hEnv
  have hD6Eq : deriveG6PrimDeps (replacePrimFormulaInEnv Γ p_out newFormula) C s6 =
      deriveG6PrimDeps Γ C s6 := hG6NonInt.2.1
  have hG6Eq : checkG6Suite fuel6 (replacePrimFormulaInEnv Γ p_out newFormula) C s6 =
      checkG6Suite fuel6 Γ C s6 := hG6NonInt.2.2.1
  have hDagEq : toPremDag (replacePrimFormulaInEnv Γ p_out newFormula) = toPremDag Γ := by
    unfold toPremDag replacePrimFormulaInEnv
    rw [List.map_map]
    apply List.map_congr_left
    intro e _
    dsimp only [Function.comp]
    by_cases h : (e.premId == p_out) = true
    · rw [if_pos h]
    · rw [if_neg h]
  have hD5Eq : deriveG5PrimDeps (replacePrimFormulaInEnv Γ p_out newFormula) C c5 =
      deriveG5PrimDeps Γ C c5 := by
    unfold deriveG5PrimDeps multiRootTransitivePrimDeps extractTransitivePrimDeps
    simp only [hDagEq]
  have hD56Eq : deriveG56JointPrimDeps (replacePrimFormulaInEnv Γ p_out newFormula) C c5 s6 =
      deriveG56JointPrimDeps Γ C c5 s6 := by
    unfold deriveG56JointPrimDeps
    rw [hD5Eq, hD6Eq]
  have hLook5' : ∀ pid ∈ deriveG5PrimDeps (replacePrimFormulaInEnv Γ p_out newFormula) C c5,
      lookupPrimPrem? (replacePrimFormulaInEnv Γ p_out newFormula) pid =
      lookupPrimPrem? Γ pid := by
    intro pid hPid
    rw [hD5Eq] at hPid
    exact lookupPrimPrem?_replace_ne Γ p_out pid newFormula (fun heq => hOut5 (heq ▸ hPid))
  have hG5Cong := (T_B1_06_ProofRoots_And_PrimDeps_Completeness fuel5 c5).2.1
    (replacePrimFormulaInEnv Γ p_out newFormula) Γ C C
    hCont (fun _ _ => rfl) hLook5'
  have hG5Eq : checkG5DischargeBool fuel5 (replacePrimFormulaInEnv Γ p_out newFormula) C c5 =
      checkG5DischargeBool fuel5 Γ C c5 := by
    unfold checkG5DischargeBool
    rw [hD5Eq, hG5Cong]
  exact ⟨hEnv', hD5Eq, hD6Eq, hD56Eq, hG5Eq, hG6Eq⟩

end OmegaCellC1P1B2BB3
