/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B2 — Isolated G6 Protected Invariant Kernel
  Module: OmegaCellC1P1B2BB2.B2_02_SuiteCheckersAndQualification

  Authorization: Scoped Human Execution Approval for `P1B2B-B2 G6 Isolated Lean Proof Core R0`
  Normative Specification: `B2 G6 Static Contract R0` + `Static Corrigendum 01` + `F-B2-T12-01..04`

  Scope:
    1. Complete G6 proof-root collector (`collectItemG6ProofRootIds`, `collectG6ProofRootIds`)
       and independent transitive primitive premise closure `deriveG6PrimDeps` (`B2-05`).
    2. Deterministic G6 sub-checkers and 5-branch suite evaluator (`evalG6SuiteCore`, `checkG6Suite`)
       enforcing `Invalid > Violated > Unresolved > Verified` on non-empty suites while isolating
       empty suites strictly to `.emptySuiteAccepted` / `.invalid` (`F-B2-T11-01`).
    3. Constructor-encapsulated (`private mk ::`) AND proof-field-sealed `G6QualifiedRecord`
       enforcing `verifiedInvariantCount = suite.items.length`, `0 < verifiedInvariantCount`,
       `submittedSuiteComplete = true`, `officialProtectionRegistryAuthenticated = false`,
       `officialRegistryBindingSlot = .mkUnchecked`, `g5DischargeSlot = .mkUnchecked`,
       `g1IntegritySlot = .mkUnchecked`, and `grantFlag = .noGrantFromMathCheck` (`F-B2-T12-01`).
    4. Zero-authority `G6EmptySuiteNotice`, `checkOfficialSuiteIdsMatchBool` (`F-B2-T11-02`),
       `checkActiveG6SuiteBool`, and `replacePrimFormulaInEnv` (`F-B2-T12-04`).
-/
import OmegaCellC1P1B2BB2.B2_01_CertTypesAndSemantics

namespace OmegaCellC1P1B2BB2

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1

/-! ### 1. Independent G6 Proof-Root Collection & `deriveG6PrimDeps` (`B2-05`) -/

/-- Raw (unsorted) list of `G7` node IDs referenced by `scopePolicy`. -/
def rawScopePolicyRootIds (pol : G6ScopePolicy) : List String :=
  match pol with
  | .globalPostSameDom r =>
      let baseN : List String :=
        match r.baseEquivStep with
        | .sameBaseDom _           => []
        | .qGuardNzToNonzero nzNid => [nzNid]
        | .nonzeroToQGuardNz nzNid => [nzNid]
      baseN ++
      r.oldGuardsDefNodeId?.toList ++
      r.oldEntailsNewGuardNodes.map Prod.snd ++
      r.newEntailsOldGuardNodes.map Prod.snd ++
      r.redundantGuardNodeId?.toList
  | .oldScopeInclusion _ oldDef? o2n n2o _ _ =>
      oldDef?.toList ++
      o2n.map Prod.snd ++
      n2o.map Prod.snd
  | .retreatWithLossAccounting => []

/-- Raw (unsorted) list of `G7` node IDs referenced by `scopeLossRecord?`. -/
def rawScopeLossRootIds : Option G6ScopeLossRecord → List String
  | none => []
  | some lr =>
      let connN : List String :=
        match lr.guardConn with
        | .syntacticConcat => []
        | .mutualImplication d2n n2d => d2n.map Prod.snd ++ n2d.map Prod.snd
      let rxN : List String :=
        match lr.reexprCert? with
        | none => []
        | some rx =>
            rx.branchDefAndDisjNodes.foldr (fun (_, dId, jId) acc => dId :: jId :: acc) [] ++
            rx.canonCoverWitnesses.foldr (fun (_, _, ps) acc => ps.map Prod.snd ++ acc) []
      [lr.prefixDefNodeId] ++ connN ++ rxN

/-- Raw (unsorted) list of `G7` node IDs referenced by `itemEvidence`. -/
def rawItemEvidenceRootIds : G6ItemEvidence → List String
  | .claimVerified rootNid                          => [rootNid]
  | .claimViolated (.derivedRefutationNode rNid _)  => [rNid]
  | .claimViolated (.counterexamplePoint _)         => []
  | .claimUnresolved _                              => []

/-- Canonical sorted list of all `G7` proof root IDs referenced anywhere in `item`. -/
def collectItemG6ProofRootIds (item : G6ProtectedInvariantSpec) : List String :=
  canonSortStrs (
    item.oldNewState.oldBaselineProofNodeId?.toList ++
    item.oldNewState.newGuardsDefNodeId?.toList ++
    rawScopePolicyRootIds item.oldNewState.scopePolicy ++
    rawScopeLossRootIds item.scopeLossRecord? ++
    rawItemEvidenceRootIds item.evidenceRoots.itemEvidence)

/-- Canonical sorted list of all `G7` proof root IDs across the entire `suite`. -/
def collectG6ProofRootIds (suite : G6ProtectedSuite) : List String :=
  canonSortStrs (suite.items.foldr (fun item acc => collectItemG6ProofRootIds item ++ acc) [])

/-- **`deriveG6PrimDeps` (`B2-05` — Independent Transitive Premise Closure `Deps_G6`)**:
    Computed strictly from `collectG6ProofRootIds suite`, with zero reference to `G5`. -/
def deriveG6PrimDeps (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) : List String :=
  multiRootTransitivePrimDeps Γ C (collectG6ProofRootIds suite)

/-! ### 2. Deterministic G6 Item & Scope Checkers -/

/-- Check well-formedness and instantiation alignment of `protectedFormula` & `parameterBinding` (`B2-04`). -/
def checkG6ParamBindingWfBool (item : G6ProtectedInvariantSpec) : Bool :=
  let st := item.oldNewState
  match item.protectedFormula, item.parameterBinding with
  | .fixedStateForm φ, .noParam =>
      (st.formOldInst == φ) && (st.formNewInst == φ)
  | .cellParamForm tpl, .boundCellParam θOldNum θOldDenPos θNewNum θNewDenPos =>
      decide (0 < θOldDenPos) &&
      decide (0 < θNewDenPos) &&
      checkWellFormedParamSpecBool st.domOld st.guardsOld (.cellParamForm tpl) &&
      checkWellFormedParamSpecBool st.domNew st.guardsNew (.cellParamForm tpl) &&
      (st.formOldInst == instantiateInvariantAtParam θOldNum θOldDenPos (.cellParamForm tpl)) &&
      (st.formNewInst == instantiateInvariantAtParam θNewNum θNewDenPos (.cellParamForm tpl))
  | _, _ => false

/-- Check `G6ScopeLossRecord` exact 2-stage telescopic partition (`B2-03`, `Gate A8`). -/
def checkG6ScopeLossRecordBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (st : G6OldNewStateBinding) (lr : G6ScopeLossRecord) : Bool :=
  let B_canon := buildCanonicalRetreatExcised lr.baseStep st.guardsOld lr.deltaGuards
  let guardConnOk : Bool :=
    match lr.guardConn with
    | .syntacticConcat =>
        st.guardsNew == st.guardsOld ++ lr.deltaGuards
    | .mutualImplication d2n n2d =>
        checkGuardEntailmentListBool fuel Γ C st.domNew st.specNewId
          (st.guardsOld ++ lr.deltaGuards) st.guardsNew d2n &&
        checkGuardEntailmentListBool fuel Γ C st.domNew st.specNewId
          st.guardsNew (st.guardsOld ++ lr.deltaGuards) n2d
  let excisedOk : Bool :=
    match lr.reexprCert? with
    | none => lr.excisedBranches == B_canon
    | some rx =>
        checkExcisedReexprBool fuel Γ C st.domOld st.guardsOld st.domNew st.guardsNew
          st.specNewId B_canon lr.excisedBranches rx
  checkBaseDomRetreatStepBool lr.baseStep st.domOld st.domNew &&
  lr.deltaGuards.all isAtomicStrictFormBool &&
  checkExactG7SequentBool fuel Γ C lr.prefixDefNodeId st.domNew st.specNewId
    (st.guardsOld ++ lr.deltaGuards) (.eqZero (.const 0)) &&
  guardConnOk &&
  excisedOk &&
  checkInEffDomRatCoordBool fuel st.domOld st.guardsOld lr.strictLossWitness &&
  checkModelsExcisedRatCoordBool fuel lr.excisedBranches lr.strictLossWitness &&
  lr.claimedRetentionAnchors.all (checkInEffDomRatCoordBool fuel st.domNew st.guardsNew)

/-- Check post-guards telescopic definedness and `scopePolicy` + `scopeLossRecord?` (`Gate A8`). -/
def checkG6ItemScopeBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (item : G6ProtectedInvariantSpec) : Bool :=
  let st := item.oldNewState
  let newGuardsDefOk : Bool :=
    if st.guardsNew.isEmpty then
      st.newGuardsDefNodeId?.isNone
    else
      match st.newGuardsDefNodeId? with
      | none      => false
      | some ndid => checkExactG7SequentBool fuel Γ C ndid st.domNew st.specNewId
                       st.guardsNew (.eqZero (.const 0))
  let polOk : Bool :=
    match st.scopePolicy, item.scopeLossRecord? with
    | .globalPostSameDom r, none =>
        r.redundantGuardNodeId?.isNone &&
        checkSameEffDomCoreBool fuel Γ C st.domOld st.guardsOld st.domNew st.guardsNew
          st.specNewId r.baseEquivStep r.oldGuardsDefNodeId?
          r.oldEntailsNewGuardNodes r.newEntailsOldGuardNodes
    | .oldScopeInclusion step oldDef? o2n n2o scopeExp expWit?, none =>
        let inclGuardsOk : Bool :=
          if st.guardsNew == st.guardsOld then o2n.isEmpty
          else checkGuardEntailmentListBool fuel Γ C st.domOld st.specNewId
                 st.guardsOld st.guardsNew o2n
        let scopeAccOk : Bool :=
          if scopeExp then
            oldDef?.isNone &&
            n2o.isEmpty &&
            match expWit? with
            | none        => false
            | some pt_exp =>
                checkInEffDomRatCoordBool fuel st.domNew st.guardsNew pt_exp &&
                checkNotInEffDomRatCoordBool fuel st.domOld st.guardsOld pt_exp
          else
            expWit?.isNone &&
            match step with
            | .sameBaseDom D =>
                checkSameEffDomCoreBool fuel Γ C st.domOld st.guardsOld st.domNew st.guardsNew
                  st.specNewId (.sameBaseDom D) oldDef?
                  (if st.guardsNew == st.guardsOld then [] else o2n)
                  n2o
            | _ => false
        checkBaseDomExpandStepBool step st.domOld st.domNew &&
        inclGuardsOk &&
        scopeAccOk
    | .retreatWithLossAccounting, some lr =>
        checkG6ScopeLossRecordBool fuel Γ C st lr
    | _, _ => false
  newGuardsDefOk && polOk

/-- Per-item non-invalid epistemic classification. -/
inductive G6ItemClass where
  | itemVerified   : G6ItemClass
  | itemViolated   : G6ItemClass
  | itemUnresolved : G6ItemClass
  deriving DecidableEq, Repr

/-- Evaluate a single `G6ProtectedInvariantSpec` item (`Stage 2`). -/
def evalSingleG6Item (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (evalEpoch : Nat) (item : G6ProtectedInvariantSpec) : Except G6InvalidReason G6ItemClass :=
  let st := item.oldNewState
  if item.versionEpoch.revokedBool ||
     !decide (item.versionEpoch.effectiveFromEpoch ≤ evalEpoch) ||
     !decide (evalEpoch < item.versionEpoch.expiresAtEpoch) then
    .error (.staleOrRevokedSpecVersion item.invariantId)
  else if !checkG6ParamBindingWfBool item then
    .error (.illFormedParameterBinding item.invariantId)
  else if item.evidenceRoots.declaredItemProofNids != collectItemG6ProofRootIds item then
    .error (.itemProofRootManifestMismatch item.invariantId)
  else
    let oldBaseOk : Bool :=
      match st.oldBaselineProofNodeId? with
      | none => true
      | some oldNid =>
          checkExactG7SequentBool fuel Γ C oldNid st.domOld st.specOldId
            st.guardsOld st.formOldInst
    if !oldBaseOk then
      .error (.forgedVerificationProof item.invariantId)
    else if !checkG6ItemScopeBool fuel Γ C item then
      .error (.uncertifiedScopeShrinkOrPolicy item.invariantId)
    else
      match item.evidenceRoots.itemEvidence with
      | .claimVerified rootNid =>
          if !checkInEffDomRatCoordBool fuel st.domNew st.guardsNew st.postDomNonEmptyWitness then
            .error (.forgedVerificationProof item.invariantId)
          else if evalStrictFormRatCoord fuel st.formNewInst st.postDomNonEmptyWitness ==
                    .undefinedTerm then
            .error (.undefinedPointTreatedAsTrue item.invariantId)
          else if checkExactG7SequentBool fuel Γ C rootNid st.domNew st.specNewId
                    st.guardsNew st.formNewInst then
            .ok .itemVerified
          else
            .error (.forgedVerificationProof item.invariantId)
      | .claimViolated (.counterexamplePoint violPt) =>
          if !checkInEffDomRatCoordBool fuel st.domNew st.guardsNew violPt then
            .error (.outOfDomainCounterexample item.invariantId)
          else if evalStrictFormRatCoord fuel st.formNewInst violPt == .satDefinedFalse then
            .ok .itemViolated
          else
            .error (.invalidRefutationEvidence item.invariantId)
      | .claimViolated (.derivedRefutationNode refutNid witPt) =>
          if !checkInEffDomRatCoordBool fuel st.domNew st.guardsNew witPt then
            .error (.outOfDomainCounterexample item.invariantId)
          else if isAtomicStrictFormBool st.formNewInst &&
                  checkExactG7SequentBool fuel Γ C refutNid st.domNew st.specNewId
                    st.guardsNew (atomicComplement st.formNewInst) then
            .ok .itemViolated
          else
            .error (.invalidRefutationEvidence item.invariantId)
      | .claimUnresolved _ =>
          .ok .itemUnresolved

/-- Exhaustive element-by-element item list evaluator (never skips an item; any `.error` aborts). -/
def evalG6ItemsList (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (evalEpoch : Nat) :
    List G6ProtectedInvariantSpec → Except G6InvalidReason (List (String × G6ItemClass))
  | [] => .ok []
  | item :: rest =>
      match evalSingleG6Item fuel Γ C evalEpoch item with
      | .error r => .error r
      | .ok cls  =>
          match evalG6ItemsList fuel Γ C evalEpoch rest with
          | .error r   => .error r
          | .ok tailCs => .ok ((item.invariantId, cls) :: tailCs)

/-! ### 3. Core Suite Evaluator `evalG6SuiteCore` & Official `checkG6Suite` (`Corrigendum 01` §1.1) -/

/-- Canonical suite header & internal item-alignment check (`Stage 1` syntax checks). -/
def checkG6SuiteHeaderBasicBool (suite : G6ProtectedSuite) : Bool :=
  (suite.suiteVersion == "g6_b2_v1") &&
  (suite.suiteCid != "") &&
  (suite.rflxCid != "") &&
  (suite.cellOldCid != "") &&
  (suite.cellNewCid != "") &&
  (suite.baseId == "base_Q") &&
  (suite.specOldId != "") &&
  (suite.specNewId != "") &&
  suite.items.all (fun item =>
    (item.invariantId != "") &&
    (item.specId != "") &&
    (item.specId == item.oldNewState.specNewId) &&
    (item.protectedDomain == item.oldNewState.domNew) &&
    (item.protectedGuards == item.oldNewState.guardsNew))

/-- Core G6 suite evaluator (factored from global `checkPrimEnvIntegrityBool`/`checkContainerIntegrityBool`
    and `claimedPrimDeps == deriveG6PrimDeps` so `RestrictionInvariance` and `OutputCongruence`
    compose 1:1 with `A0_05_1` & `A0_05_3`!). -/
def evalG6SuiteCore (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) : G6CheckVerdict :=
  if !checkG6SuiteHeaderBasicBool suite then
    .invalid .nonCanonicalSuiteHeader
  else if !nodupStrsBool suite.declaredInvariantIds ||
          suite.declaredInvariantIds.any (fun id => id == "") then
    .invalid .duplicateOrEmptyInvariantId
  else if (suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
          suite.items.any (fun item =>
            (item.oldNewState.specOldId != suite.specOldId) ||
            (item.oldNewState.specNewId != suite.specNewId)) then
    .invalid .suiteCoverageMismatch
  else
    match suite.items with
    | [] =>
        match suite.emptySuitePolicy with
        | .forbidEmptySuite => .invalid .unauthorizedEmptySuite
        | .allowExplicitEmpty polCid =>
            if polCid == "" then .invalid .unauthorizedEmptySuite
            else .emptySuiteAccepted polCid
    | item0 :: restItems =>
        match evalG6ItemsList fuel Γ C suite.evaluationEpoch (item0 :: restItems) with
        | .error r => .invalid r
        | .ok pairs =>
            let vIds := (pairs.filter (fun p => p.2 == .itemViolated)).map Prod.fst
            let uIds := (pairs.filter (fun p => p.2 == .itemUnresolved)).map Prod.fst
            if !vIds.isEmpty then
              .violated vIds uIds
            else if !uIds.isEmpty then
              .unresolved uIds
            else
              .verified ((item0 :: restItems).any (fun it => it.scopeLossRecord?.isSome))

/-- **`checkG6Suite` (`B2-02` & `Corrigendum 01` §1.1 — Official Deterministic 5-Branch G6 Kernel Checker)**:
    Enforces global `PrimPremiseEnv` & `G7DagContainer` structural integrity, exact `Deps_G6`
    transitive premise closure equality (`claimedPrimDeps == deriveG6PrimDeps`), and `evalG6SuiteCore`. -/
def checkG6Suite (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) : G6CheckVerdict :=
  if !checkPrimEnvIntegrityBool Γ || !checkContainerIntegrityBool C then
    .invalid .malformedEnvOrContainer
  else if !isStrictCanonStrList suite.claimedPrimDeps.primDepIds ||
          (suite.claimedPrimDeps.primDepIds != deriveG6PrimDeps Γ C suite) then
    .invalid .primDepsClosureMismatch
  else
    evalG6SuiteCore fuel Γ C suite

/--Computable boolean predicate testing whether `suite` has any structural or item certificate defect
   (`true` iff `checkG6Suite` returns `.invalid _`). -/
def hasAnyG6StructuralOrCertDefectBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) : Bool :=
  match checkG6Suite fuel Γ C suite with
  | .invalid _ => true
  | _          => false

/-- Computable helper testing whether every `.claimViolated` item in `suite` uses `.counterexamplePoint`. -/
def allViolationsPointBasedBool (suite : G6ProtectedSuite) : Bool :=
  suite.items.all (fun item =>
    match item.evidenceRoots.itemEvidence with
    | .claimViolated (.derivedRefutationNode _ _) => false
    | _                                           => true)

/-- Boolean projection testing whether `checkG6Suite` returned `.verified _` (`false` on `.emptySuiteAccepted`!). -/
def isG6SuiteVerifiedBool (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) : Bool :=
  match checkG6Suite fuel Γ C suite with
  | .verified _ => true
  | _           => false

/-! ### 4. Constructor-Sealed & Proof-Bearing `G6QualifiedRecord` (`F-B2-T12-01` & `F-B2-T12-02`) -/

/-- Extract the underlying `G6ProtectedSuite` from a `.verified` `SlotWitness`. -/
def extractVerifiedG6Suite {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    (w : SlotWitness G6ProtectedSuite (isG6SuiteVerifiedBool fuel Γ C) .verified) :
    G6ProtectedSuite :=
  match w with
  | .mkVerified c => c.1

/-- Key lemma: `isG6SuiteVerifiedBool = true` forces `suite.items ≠ []` (`0 < suite.items.length`). -/
theorem isG6SuiteVerifiedBool_implies_nonEmpty {fuel : Nat} {Γ : PrimPremiseEnv}
    {C : G7DagContainer} {suite : G6ProtectedSuite}
    (hVer : isG6SuiteVerifiedBool fuel Γ C suite = true) :
    suite.items ≠ [] ∧ 0 < suite.items.length := by
  unfold isG6SuiteVerifiedBool checkG6Suite at hVer
  by_cases hMal : (!checkPrimEnvIntegrityBool Γ || !checkContainerIntegrityBool C) = true
  · rw [if_pos hMal] at hVer; nomatch hVer
  · rw [if_neg hMal] at hVer
    by_cases hDeps : (!isStrictCanonStrList suite.claimedPrimDeps.primDepIds ||
        (suite.claimedPrimDeps.primDepIds != deriveG6PrimDeps Γ C suite)) = true
    · rw [if_pos hDeps] at hVer; nomatch hVer
    · rw [if_neg hDeps] at hVer
      unfold evalG6SuiteCore at hVer
      by_cases hHdr : (!checkG6SuiteHeaderBasicBool suite) = true
      · rw [if_pos hHdr] at hVer; nomatch hVer
      · rw [if_neg hHdr] at hVer
        by_cases hDup : (!nodupStrsBool suite.declaredInvariantIds ||
            suite.declaredInvariantIds.any (fun id => id == "")) = true
        · rw [if_pos hDup] at hVer; nomatch hVer
        · rw [if_neg hDup] at hVer
          by_cases hCov : ((suite.items.map (·.invariantId) != suite.declaredInvariantIds) ||
              suite.items.any (fun item =>
                (item.oldNewState.specOldId != suite.specOldId) ||
                (item.oldNewState.specNewId != suite.specNewId))) = true
          · rw [if_pos hCov] at hVer; nomatch hVer
          · rw [if_neg hCov] at hVer
            cases hItems : suite.items with
            | nil =>
                rw [hItems] at hVer
                dsimp only at hVer
                cases hPol : suite.emptySuitePolicy with
                | forbidEmptySuite =>
                    rw [hPol] at hVer; nomatch hVer
                | allowExplicitEmpty polCid =>
                    rw [hPol] at hVer
                    dsimp only at hVer
                    by_cases hp : (polCid == "") = true
                    · rw [if_pos hp] at hVer; nomatch hVer
                    · rw [if_neg hp] at hVer; nomatch hVer
            | cons it0 rest =>
                exact And.intro (fun hNil => nomatch hNil) (Nat.succ_pos _)

/-- **`G6QualifiedRecord` (`IV.9`, `Corrigendum 01` §1.2, & `F-B2-T12-01` Constructor + Proof Sealing)**:
    - Constructor is encapsulated via `private mk ::` so external code cannot forge arbitrary field values.
    - Carries type-level proof fields sealing:
      * `verifiedInvariantCount = (extractVerifiedG6Suite verifiedG6Slot).items.length`
      * `0 < verifiedInvariantCount` (hence empty suites have ZERO inhabitants in `G6QualifiedRecord`!)
      * `submittedSuiteComplete = true`
      * `officialProtectionRegistryAuthenticated = false`
      * `officialRegistryBindingSlot = .mkUnchecked`, `g5DischargeSlot = .mkUnchecked`,
        `g1IntegritySlot = .mkUnchecked`, and `grantFlag = .noGrantFromMathCheck`. -/
structure G6QualifiedRecord (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer) where
  private mk ::
  verifiedG6Slot                          : SlotWitness G6ProtectedSuite (isG6SuiteVerifiedBool fuel Γ C) .verified
  verifiedInvariantCount                  : Nat
  verifiedCount_eq_itemsLength            : verifiedInvariantCount =
                                              (extractVerifiedG6Suite verifiedG6Slot).items.length
  verifiedCountPos                        : 0 < verifiedInvariantCount
  hasCertifiedScopeLoss                   : Bool
  hasLoss_eq                              : hasCertifiedScopeLoss =
                                              (extractVerifiedG6Suite verifiedG6Slot).items.any
                                                (fun it => it.scopeLossRecord?.isSome)
  submittedSuiteComplete                  : Bool
  submittedSuiteComplete_eq_true          : submittedSuiteComplete = true
  officialProtectionRegistryAuthenticated : Bool
  officialRegistryAuth_eq_false           : officialProtectionRegistryAuthenticated = false
  officialRegistryBindingSlot             : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  derivedPrimDeps                         : G6DerivedPrimDeps
  derivedPrimDeps_eq                      : derivedPrimDeps.primDepIds =
                                              deriveG6PrimDeps Γ C (extractVerifiedG6Suite verifiedG6Slot)
  unauthenticatedOrigins                  : List (String × G6RegistryOrigin)
  g5DischargeSlot                         : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  g1IntegritySlot                         : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  grantFlag                               : CheckDerivesNoGrant
  grantFlag_eq                            : grantFlag = .noGrantFromMathCheck

/-- Official deterministic constructor producing `Option (G6QualifiedRecord fuel Γ C)`.
    Returns `some` ONLY when `isG6SuiteVerifiedBool fuel Γ C suite = true` (`suite.items ≠ []`). -/
def qualifyG6Isolated? (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) : Option (G6QualifiedRecord fuel Γ C) :=
  if hVer : isG6SuiteVerifiedBool fuel Γ C suite = true then
    have hPos : 0 < suite.items.length :=
      (isG6SuiteVerifiedBool_implies_nonEmpty hVer).2
    some {
      verifiedG6Slot                          := .mkVerified ⟨suite, hVer⟩
      verifiedInvariantCount                  := suite.items.length
      verifiedCount_eq_itemsLength            := rfl
      verifiedCountPos                        := hPos
      hasCertifiedScopeLoss                   := suite.items.any (fun it => it.scopeLossRecord?.isSome)
      hasLoss_eq                              := rfl
      submittedSuiteComplete                  := true
      submittedSuiteComplete_eq_true          := rfl
      officialProtectionRegistryAuthenticated := false
      officialRegistryAuth_eq_false           := rfl
      officialRegistryBindingSlot             := .mkUnchecked
      derivedPrimDeps                         := ⟨deriveG6PrimDeps Γ C suite⟩
      derivedPrimDeps_eq                      := rfl
      unauthenticatedOrigins                  := suite.items.map (fun it => (it.invariantId, it.registryOrigin))
      g5DischargeSlot                         := .mkUnchecked
      g1IntegritySlot                         := .mkUnchecked
      grantFlag                               := .noGrantFromMathCheck
      grantFlag_eq                            := rfl
    }
  else
    none

/-- Zero-authority administrative notice for `.emptySuiteAccepted` (`F-B2-T11-01`). -/
structure G6EmptySuiteNotice where
  private mk ::
  suiteCid               : String
  rflxCid                : String
  unauthPolicyCid        : String
  verifiedInvariantCount : Nat
  countIsZero            : verifiedInvariantCount = 0
  emptyPolicyAuthSlot    : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  grantFlag              : CheckDerivesNoGrant
  grantFlag_eq           : grantFlag = .noGrantFromMathCheck

/-- Extract `G6EmptySuiteNotice` ONLY when `checkG6Suite` returns `.emptySuiteAccepted polCid`. -/
def inspectG6EmptySuiteNotice? (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (suite : G6ProtectedSuite) : Option G6EmptySuiteNotice :=
  match checkG6Suite fuel Γ C suite with
  | .emptySuiteAccepted polCid =>
      some {
        suiteCid               := suite.suiteCid
        rflxCid                := suite.rflxCid
        unauthPolicyCid        := polCid
        verifiedInvariantCount := 0
        countIsZero            := rfl
        emptyPolicyAuthSlot    := .mkUnchecked
        grantFlag              := .noGrantFromMathCheck
        grantFlag_eq           := rfl
      }
  | _ => none

/-! ### 5. Reference Official Registry Comparator, Ledger Activity Check, & Premise Mutation Helper -/

/-- Read-only reference comparator checking whether `suite` covers a supplied official protection
    manifest `officialIds` (`Corrigendum 01` §2.1 `F-B2-T11-02`; full `B4` binding remains `HELD`). -/
def checkOfficialSuiteIdsMatchBool (officialIds : List String)
    (suite : G6ProtectedSuite) : Bool :=
  (!officialIds.isEmpty) &&
  nodupStrsBool officialIds &&
  (suite.declaredInvariantIds == officialIds) &&
  (suite.items.map (·.invariantId) == officialIds)

/-- Read-only dynamic ledger standing check (`Gate A7` & `CE-G6-09C` — mutates zero ledger state!). -/
def checkActiveG6SuiteBool (L : List StructuralLedgerEvent) (fuel : Nat)
    (Γ : PrimPremiseEnv) (C : G7DagContainer) (suite : G6ProtectedSuite) : Bool :=
  let ep := (foldStructuralLedger L).epistemic
  isG6SuiteVerifiedBool fuel Γ C suite &&
  suite.claimedPrimDeps.primDepIds.all (fun p => !ep.retractedPremises.contains p) &&
  suite.items.all (fun it =>
    !it.versionEpoch.revokedBool &&
    decide (it.versionEpoch.effectiveFromEpoch ≤ ep.currentEpoch) &&
    decide (ep.currentEpoch < it.versionEpoch.expiresAtEpoch))

/-- Pure helper replacing the formula of `targetPid` in `Γ` while keeping `premId`, `domTag`,
    `specId`, and `parentPremIds` unchanged (`F-B2-T12-04` outside-premise non-interference). -/
def replacePrimFormulaInEnv (Γ : PrimPremiseEnv) (targetPid : String)
    (newFormula : StrictForm) : PrimPremiseEnv :=
  Γ.map (fun e => if e.premId == targetPid then { e with formula := newFormula } else e)

end OmegaCellC1P1B2BB2
