/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B3 — G56 Certified Coupling Kernel (`Formalization Act I0`)
  Module: OmegaCellC1P1B2BB3.B3_05_ReificationAndTemporalInvalidation

  Authorization: Human L4 Final Freeze (`SCOPED_STATIC_BASELINE_FROZEN`) & `FORMALIZATION_ACT_I0`
  Gates & Binding Conditions Covered:
    - `I0-A7` (`F-B3-T17-02`, `F-B3-T18-01`):
      * Single-verified-object subtype `VerifiedG56Object ctx` and all 4 component projection
        theorems (`verifiedG56_projects_g5Bool`, `verifiedG56_projects_g6Bool`,
        `verifiedG56_projects_posCount`, `verifiedG56_projects_jointDeps`).
      * Constructor-sealed (`private mk ::`) `G56QualifiedRecord ctx` + deterministic total
        reifier `reifyVerifiedG56` (`Q : V → R`), object extractor `extractVerifiedObject` (`E : R → V`),
        and `qualifyG56Coupled?`.
      * Explicit 4-way separation demanded by `F-B3-T18-01`:
        1. `T_I0_A7_EXISTENCE`  (`∀ r : R, ∃ v : V, v.1 = extractVerifiedG56 r.verifiedG56Slot`)
        2. `T_I0_A7_TOTALITY`   (`∀ c56, isG56CouplingVerifiedBool ctx c56 = true → (qualifyG56Coupled? ctx c56).isSome = true`)
        3. `T_I0_A7_ROUNDTRIP`  (`∀ v : V, E (Q v) = v` AND `∀ r : R, Q (E r) = r`)
        4. `T_I0_A7_UNIQUENESS` (`∀ r1 r2 : R, extractVerifiedG56 r1.verifiedG56Slot = extractVerifiedG56 r2.verifiedG56Slot → r1 = r2`)
      * Constructive `CE-I0-01` contrast (`UncanonicalTaggedRecord`) proving `EXISTENCE ⇏ UNIQUENESS`
        whenever an unsealed auxiliary data field is present.
      * Zero-Authority & `FullReflexAdmitted` uninhabitability (`T_I0_A7_ZeroAuthorityAndNoFullReflex`).
    - `I0-A8` (`F-B3-T17-06`, `Q-B3-R1-04`):
      * Order-theoretic retraction monotonicity chain over frozen `P1B1` `StructuralLedgerEvent`:
        1. `T_I0_A8_01_StepRetractionMonotone`: `R(s) ⊆ R(stepStructuralLedger s ev)` across all 5 constructors.
        2. `T_I0_A8_02_FoldAppendRetractionSubset`: `R(L) ⊆ R(L ++ ΔL)` on append-only extensions.
        3. `T_I0_A8_03_CoupledActiveMonotoneInvalidation`: `p ∈ D56 ∩ R(L) ⟹ checkActiveG56CouplingBool (L ++ ΔL) ctx c56 = false`.
        4. `T_I0_A8_04_RecordActiveMonotoneInvalidation`: coherent `checkActiveG56RecordBool` invalidation
           under `G5`-only, `G6`-only, or shared premise retraction (`CE-G56-14B`, `CE-R1-09`), plus
           split-ledger packet rejection (`CE-G56-14A`) and official-registry comparator (`CE-G56-15`).
-/
import OmegaCellC1P1B2BB3.B3_04_DiagnosticsAndMasterSoundness

namespace OmegaCellC1P1B2BB3

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1
open OmegaCellC1P1B2BB2

/-! ### 1. `VerifiedG56Object` & Independent Projection Obligations (`F-B3-T17-02`) -/

/-- Single verified coupled object subtype (`V := VerifiedG56Object ctx`). -/
abbrev VerifiedG56Object (ctx : G56SharedContext) : Type :=
  { c56 : G56CouplingCert // isG56CouplingVerifiedBool ctx c56 = true }

/-- Unpack existential `hasLoss, reqRet` from `v : VerifiedG56Object ctx`. -/
theorem verifiedG56_exists_verdictParams (ctx : G56SharedContext) (v : VerifiedG56Object ctx) :
    ∃ hasLoss reqRet : Bool, checkG56Coupling ctx v.1 = .g56Verified hasLoss reqRet := by
  have hv := v.2
  unfold isG56CouplingVerifiedBool at hv
  cases hc : checkG56Coupling ctx v.1 <;> rw [hc] at hv
  case invalidBinding => nomatch hv
  case invalidEvidence => nomatch hv
  case g6Violated => nomatch hv
  case g5NotDischarged => nomatch hv
  case g6Unresolved => nomatch hv
  case g6Empty => nomatch hv
  case g56Verified hl rr => exact ⟨hl, rr, rfl⟩

/-- Projection Obligation 1: `v : VerifiedG56Object ctx` entails `checkG5DischargeBool = true` on `v.1.g5Cert`. -/
theorem verifiedG56_projects_g5Bool (ctx : G56SharedContext) (v : VerifiedG56Object ctx) :
    checkG5DischargeBool ctx.fuelG5 ctx.primEnv ctx.dagCont v.1.g5Cert = true := by
  rcases verifiedG56_exists_verdictParams ctx v with ⟨_, _, hc⟩
  exact (unpack_g56Verified hc).2.2.2.2.1

/-- Projection Obligation 2: `v : VerifiedG56Object ctx` entails `isG6SuiteVerifiedBool = true` on `v.1.g6Suite`. -/
theorem verifiedG56_projects_g6Bool (ctx : G56SharedContext) (v : VerifiedG56Object ctx) :
    isG6SuiteVerifiedBool ctx.fuelG6 ctx.primEnv ctx.dagCont v.1.g6Suite = true := by
  rcases verifiedG56_exists_verdictParams ctx v with ⟨hl, _, hc⟩
  have hg6 := (unpack_g56Verified hc).2.2.2.2.2.2.1
  unfold isG6SuiteVerifiedBool
  rw [hg6]

/-- Projection Obligation 3: `v : VerifiedG56Object ctx` entails `0 < v.1.g6Suite.items.length` (`F-B2-T12-02`). -/
theorem verifiedG56_projects_posCount (ctx : G56SharedContext) (v : VerifiedG56Object ctx) :
    0 < v.1.g6Suite.items.length :=
  (isG6SuiteVerifiedBool_implies_nonEmpty (verifiedG56_projects_g6Bool ctx v)).2

/-- Projection Obligation 4: `v : VerifiedG56Object ctx` entails exact 3-field `G56JointPrimDeps` equalities. -/
theorem verifiedG56_projects_jointDeps (ctx : G56SharedContext) (v : VerifiedG56Object ctx) :
    v.1.claimedJointPrimDeps.g5PrimDepIds =
      deriveG5PrimDeps ctx.primEnv ctx.dagCont v.1.g5Cert ∧
    v.1.claimedJointPrimDeps.g6PrimDepIds =
      deriveG6PrimDeps ctx.primEnv ctx.dagCont v.1.g6Suite ∧
    v.1.claimedJointPrimDeps.jointPrimDepIds =
      deriveG56JointPrimDeps ctx.primEnv ctx.dagCont v.1.g5Cert v.1.g6Suite := by
  rcases verifiedG56_exists_verdictParams ctx v with ⟨_, _, hc⟩
  rcases unpack_g56Verified hc with ⟨_, _, _, _, _, _, _, hd5, hd6, hd56, _⟩
  exact ⟨hd5, hd6, hd56⟩

private theorem retreatPairsLoop_none_mem
    (fuel : Nat) (Γ : PrimPremiseEnv) (C : G7DagContainer)
    (D_old : G7DomTag) (Γ_old : List StrictForm) (specNewId : String)
    (Φ_shared : ExcisedLocus) :
    ∀ (items : List G6ProtectedInvariantSpec) (binds : List G56ItemLossBinding),
      binds.map (·.invariantId) = items.map (·.invariantId) →
      (checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared items binds).2 = none →
      ∀ item ∈ items, ∃ bind ∈ binds,
        checkSingleRetreatItemLossPair fuel Γ C D_old Γ_old specNewId Φ_shared item bind = none
  | [], [], _, _, _, hIn => nomatch hIn
  | _ :: _, [], hMap, _, _, _ => nomatch hMap
  | [], _ :: _, hMap, _, _, _ => nomatch hMap
  | it :: restItems, bd :: restBinds, hMap, hNone, item, hMem => by
      simp only [List.map_cons] at hMap
      injection hMap with _ hTailMap
      unfold checkRetreatItemPairsLoop at hNone
      dsimp only at hNone
      cases hCur : checkSingleRetreatItemLossPair fuel Γ C D_old Γ_old specNewId Φ_shared it bd with
      | some _ =>
          rw [hCur] at hNone
          cases checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared restItems restBinds
          nomatch hNone
      | none =>
          rw [hCur] at hNone
          cases hLoop : checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared restItems restBinds with
          | mk _ tErr =>
              rw [hLoop] at hNone
              dsimp only at hNone
              rcases List.mem_cons.mp hMem with rfl | hRestMem
              · exact ⟨bd, List.mem_cons_self .., hCur⟩
              · have hTailNone :
                    (checkRetreatItemPairsLoop fuel Γ C D_old Γ_old specNewId Φ_shared restItems restBinds).2 = none := by
                  rw [hLoop]; exact hNone
                rcases retreatPairsLoop_none_mem fuel Γ C D_old Γ_old specNewId Φ_shared
                  restItems restBinds hTailMap hTailNone item hRestMem with ⟨b', hb'Mem, hb'Ok⟩
                exact ⟨b', List.mem_cons_of_mem bd hb'Mem, hb'Ok⟩

/-- Unconditional transition-binding, relational-compatibility, and retreat-iff-loss projections
    from `v : VerifiedG56Object ctx` (`0` `SemValidPrimId` assumptions needed, enabling total reification!). -/
theorem verifiedG56_projects_bindingAndFlags (ctx : G56SharedContext) (v : VerifiedG56Object ctx) :
    projectG5Transition ⟨v.1.g5Cert, v.1.transitionBinding.assignedEvalEpoch⟩ =
      v.1.transitionBinding ∧
    G6TransitionCompatibleRel v.1.g6Suite v.1.transitionBinding ∧
    v.1.g5Cert.requiresRetreatHistory =
      v.1.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) := by
  rcases verifiedG56_exists_verdictParams ctx v with ⟨hl, rr, hc⟩
  rcases unpack_g56Verified hc with
    ⟨_, _, hBindNone, hScopeNone, hG5Ok, _, _, _, _, _, _⟩
  rcases bindingDiag_none_implies_components hBindNone with
    ⟨_, hG5Proj, hG6Key, hG6Ep, hItemCarr, _⟩
  have hNonEmpty : v.1.g6Suite.items ≠ [] :=
    (isG6SuiteVerifiedBool_implies_nonEmpty (verifiedG56_projects_g6Bool ctx v)).1
  have hCarrProps : ∀ item ∈ v.1.g6Suite.items,
      item.specId = v.1.transitionBinding.specNewId ∧
      item.oldNewState.specOldId = v.1.transitionBinding.specOldId ∧
      item.oldNewState.specNewId = v.1.transitionBinding.specNewId ∧
      item.oldNewState.domOld = v.1.transitionBinding.domOld ∧
      item.oldNewState.guardsOld = v.1.transitionBinding.guardsOld ∧
      item.oldNewState.domNew = v.1.transitionBinding.domNew ∧
      item.oldNewState.guardsNew = v.1.transitionBinding.guardsNew ∧
      item.protectedDomain = v.1.transitionBinding.domNew ∧
      item.protectedGuards = v.1.transitionBinding.guardsNew := by
    intro item hMem
    have hC := hItemCarr item hMem
    unfold checkG6ItemCarrierAlignedBool at hC
    simp only [Bool.and_eq_true, beq_iff_eq] at hC
    exact ⟨hC.1.1.1.1.1.1.1.1, hC.1.1.1.1.1.1.1.2, hC.1.1.1.1.1.1.2,
           hC.1.1.1.1.1.2, hC.1.1.1.1.2, hC.1.1.1.2, hC.1.1.2, hC.1.2, hC.2⟩
  have hReqEqB : v.1.g5Cert.requiresRetreatHistory = v.1.transitionBinding.requiresRetreatHistory :=
    congrArg G56TransitionBinding.requiresRetreatHistory hG5Proj
  refine ⟨hG5Proj, ?_, ?_⟩
  · unfold G6TransitionCompatibleRel
    refine ⟨hG6Key, hG6Ep, hNonEmpty, hCarrProps, ?_⟩
    cases hRk : v.1.transitionBinding.reflexKind with
    | repair =>
        unfold evalG56ScopeDiag at hScopeNone
        rw [hRk] at hScopeNone; dsimp only at hScopeNone
        by_cases hFl : (!checkReflexRetreatFlagConsistentBool v.1) = true
        · rw [if_pos hFl] at hScopeNone; nomatch hScopeNone
        · rw [if_neg hFl] at hScopeNone
          have hFlTrue : checkReflexRetreatFlagConsistentBool v.1 = true := by
            cases hb : checkReflexRetreatFlagConsistentBool v.1 <;> simp_all
          unfold checkReflexRetreatFlagConsistentBool at hFlTrue
          rw [hRk] at hFlTrue
          simp only [Bool.and_eq_true] at hFlTrue
          have hReqF : v.1.transitionBinding.requiresRetreatHistory = false :=
            Bool.eq_false_iff.mpr (fun ht => by rw [ht] at hFlTrue; nomatch hFlTrue.2)
          by_cases hMode : (!(v.1.scopeCompatibility == .repairSameScope)) = true
          · rw [if_pos hMode] at hScopeNone; nomatch hScopeNone
          · rw [if_neg hMode] at hScopeNone
            cases hBad : (v.1.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) with
            | cons _ _ => rw [hBad] at hScopeNone; nomatch hScopeNone
            | nil =>
                refine ⟨hReqF, ?_⟩
                intro item hMem
                cases hcPol : checkItemSameScopePolBool item with
                | false =>
                    have hInM : item.invariantId ∈
                        (v.1.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) :=
                      List.mem_map_of_mem (List.mem_filter.mpr ⟨hMem, by rw [hcPol]; rfl⟩)
                    rw [hBad] at hInM; nomatch hInM
                | true =>
                    unfold checkItemSameScopePolBool at hcPol
                    simp only [Bool.and_eq_true] at hcPol
                    exact Option.isNone_iff_eq_none.mp hcPol.1
    | refinement =>
        unfold evalG56ScopeDiag at hScopeNone
        rw [hRk] at hScopeNone; dsimp only at hScopeNone
        cases hSc : v.1.scopeCompatibility <;> rw [hSc] at hScopeNone
        case repairSameScope => dsimp only at hScopeNone; split at hScopeNone <;> nomatch hScopeNone
        case retreatExactSharedLoss => dsimp only at hScopeNone; split at hScopeNone <;> nomatch hScopeNone
        case refinementSameScope =>
          dsimp only at hScopeNone
          by_cases hFl : (!checkReflexRetreatFlagConsistentBool v.1) = true
          · rw [if_pos hFl] at hScopeNone; nomatch hScopeNone
          · rw [if_neg hFl] at hScopeNone
            have hFlTrue : checkReflexRetreatFlagConsistentBool v.1 = true := by
              cases hb : checkReflexRetreatFlagConsistentBool v.1 <;> simp_all
            unfold checkReflexRetreatFlagConsistentBool at hFlTrue
            rw [hRk] at hFlTrue
            simp only [Bool.and_eq_true] at hFlTrue
            have hReqF : v.1.transitionBinding.requiresRetreatHistory = false :=
              Bool.eq_false_iff.mpr (fun ht => by rw [ht] at hFlTrue; nomatch hFlTrue.2)
            refine ⟨hReqF, ?_⟩
            intro item hMem
            have hBad : (v.val.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) = [] := by
              cases hRf : v.val.g5Cert.refinementCert? with
              | none =>
                  rw [hRf] at hScopeNone; dsimp only at hScopeNone
                  cases hb : (v.val.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) with
                  | cons _ _ => rw [hb] at hScopeNone; nomatch hScopeNone
                  | nil => rfl
              | some rf =>
                  rw [hRf] at hScopeNone; dsimp only at hScopeNone
                  cases hExpB : rf.scopeExpanded <;>
                    simp only [hExpB, Bool.not_true, Bool.not_false, Bool.false_eq_true, ↓reduceIte] at hScopeNone
                  case true => nomatch hScopeNone
                  case false =>
                    cases hb : (v.val.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) with
                    | cons _ _ => rw [hb] at hScopeNone; nomatch hScopeNone
                    | nil => rfl
            cases hcPol : checkItemSameScopePolBool item with
            | false =>
                have hInM : item.invariantId ∈
                    (v.val.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) :=
                  List.mem_map_of_mem (List.mem_filter.mpr ⟨hMem, by rw [hcPol]; rfl⟩)
                rw [hBad] at hInM; nomatch hInM
            | true =>
                unfold checkItemSameScopePolBool at hcPol
                simp only [Bool.and_eq_true] at hcPol
                exact Option.isNone_iff_eq_none.mp hcPol.1
        case refinementExpandedScope =>
          dsimp only at hScopeNone
          by_cases hFl : (!checkReflexRetreatFlagConsistentBool v.1) = true
          · rw [if_pos hFl] at hScopeNone; nomatch hScopeNone
          · rw [if_neg hFl] at hScopeNone
            have hFlTrue : checkReflexRetreatFlagConsistentBool v.1 = true := by
              cases hb : checkReflexRetreatFlagConsistentBool v.1 <;> simp_all
            unfold checkReflexRetreatFlagConsistentBool at hFlTrue
            rw [hRk] at hFlTrue
            simp only [Bool.and_eq_true] at hFlTrue
            have hReqF : v.1.transitionBinding.requiresRetreatHistory = false :=
              Bool.eq_false_iff.mpr (fun ht => by rw [ht] at hFlTrue; nomatch hFlTrue.2)
            refine ⟨hReqF, ?_⟩
            intro item hMem
            have hBad : (v.val.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId) = [] := by
              cases hRf : v.val.g5Cert.refinementCert? with
              | none =>
                  rw [hRf] at hScopeNone; dsimp only at hScopeNone
                  cases hb : (v.val.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId) with
                  | cons _ _ => rw [hb] at hScopeNone; nomatch hScopeNone
                  | nil => rfl
              | some rf =>
                  rw [hRf] at hScopeNone; dsimp only at hScopeNone
                  cases hExpB : rf.scopeExpanded <;>
                    simp only [hExpB, Bool.false_eq_true, ↓reduceIte] at hScopeNone
                  case false => nomatch hScopeNone
                  case true =>
                    cases hb : (v.val.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId) with
                    | cons _ _ => rw [hb] at hScopeNone; nomatch hScopeNone
                    | nil => rfl
            cases hcPol : checkItemExpandedScopePolBool item with
            | false =>
                have hInM : item.invariantId ∈
                    (v.val.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId) :=
                  List.mem_map_of_mem (List.mem_filter.mpr ⟨hMem, by rw [hcPol]; rfl⟩)
                rw [hBad] at hInM; nomatch hInM
            | true =>
                unfold checkItemExpandedScopePolBool at hcPol
                simp only [Bool.and_eq_true] at hcPol
                exact Option.isNone_iff_eq_none.mp hcPol.1
    | retreat =>
        rcases T_I0_A4_05_TopLevelForcesConstrainedL1Path ctx v.1 v.2 hRk with
          ⟨Φ_shared, itemBinds, _, _, _, _, hConstr⟩
        have hReqT : v.1.transitionBinding.requiresRetreatHistory = true := by
          unfold checkG5DischargeBool checkG5CoreProofsBool at hG5Ok
          simp only [Bool.and_eq_true] at hG5Ok
          have hBr := hG5Ok.2.2
          have hRk5 : v.1.g5Cert.reflexKind = .retreat :=
            (congrArg G56TransitionBinding.reflexKind hG5Proj).trans hRk
          rw [hRk5] at hBr
          simp only [Bool.and_eq_true] at hBr
          exact hReqEqB.symm.trans hBr.1.1.1
        unfold checkAllItemsRetreatLossConstrainedBool at hConstr
        simp only [Bool.and_eq_true] at hConstr
        have hMapEq : itemBinds.map (·.invariantId) = v.1.g6Suite.items.map (·.invariantId) :=
          eq_of_beq hConstr.1.1
        have hLoopNone :
            (checkRetreatItemPairsLoop ctx.fuelG6 ctx.primEnv ctx.dagCont
              v.1.transitionBinding.domOld v.1.transitionBinding.guardsOld
              v.1.transitionBinding.specNewId Φ_shared v.1.g6Suite.items itemBinds).2 = none :=
          Option.isNone_iff_eq_none.mp hConstr.1.2
        refine ⟨hReqT, ?_⟩
        intro item hMem
        rcases retreatPairsLoop_none_mem ctx.fuelG6 ctx.primEnv ctx.dagCont
            v.1.transitionBinding.domOld v.1.transitionBinding.guardsOld
            v.1.transitionBinding.specNewId Φ_shared v.1.g6Suite.items itemBinds
            hMapEq hLoopNone item hMem with ⟨bind, _, hPairNone⟩
        unfold checkSingleRetreatItemLossPair at hPairNone
        by_cases hPolNe : (item.oldNewState.scopePolicy != .retreatWithLossAccounting) = true
        · rw [if_pos hPolNe] at hPairNone; nomatch hPairNone
        · rw [if_neg hPolNe] at hPairNone
          have hPolEq : item.oldNewState.scopePolicy = .retreatWithLossAccounting := by
            cases hb : (item.oldNewState.scopePolicy == .retreatWithLossAccounting) with
            | true => exact eq_of_beq hb
            | false => simp [bne, hb] at hPolNe
          cases hLr : item.scopeLossRecord? with
          | none => rw [hLr] at hPairNone; nomatch hPairNone
          | some _ => exact ⟨hPolEq, fun h => nomatch h⟩
  · cases hRk : v.1.transitionBinding.reflexKind with
    | repair =>
        unfold evalG56ScopeDiag at hScopeNone
        rw [hRk] at hScopeNone; dsimp only at hScopeNone
        by_cases hFl : (!checkReflexRetreatFlagConsistentBool v.1) = true
        · rw [if_pos hFl] at hScopeNone; nomatch hScopeNone
        · rw [if_neg hFl] at hScopeNone
          have hFlTrue : checkReflexRetreatFlagConsistentBool v.1 = true := by
            cases hb : checkReflexRetreatFlagConsistentBool v.1 <;> simp_all
          unfold checkReflexRetreatFlagConsistentBool at hFlTrue
          rw [hRk] at hFlTrue
          simp only [Bool.and_eq_true] at hFlTrue
          have hReqF : v.1.g5Cert.requiresRetreatHistory = false := by
            rw [hReqEqB]
            exact Bool.eq_false_iff.mpr (fun ht => by rw [ht] at hFlTrue; nomatch hFlTrue.2)
          by_cases hMode : (!(v.1.scopeCompatibility == .repairSameScope)) = true
          · rw [if_pos hMode] at hScopeNone; nomatch hScopeNone
          · rw [if_neg hMode] at hScopeNone
            cases hBad : (v.1.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) with
            | cons _ _ => rw [hBad] at hScopeNone; nomatch hScopeNone
            | nil =>
                have hAnyF : v.1.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) = false := by
                  apply Bool.eq_false_iff.mpr; intro hAny
                  rcases List.any_eq_true.mp hAny with ⟨it, hitM, hitS⟩
                  cases hcPol : checkItemSameScopePolBool it with
                  | false =>
                      have hInM : it.invariantId ∈
                          (v.1.g6Suite.items.filter (fun x => !checkItemSameScopePolBool x)).map (·.invariantId) :=
                        List.mem_map_of_mem (List.mem_filter.mpr ⟨hitM, by rw [hcPol]; rfl⟩)
                      rw [hBad] at hInM; nomatch hInM
                  | true =>
                      unfold checkItemSameScopePolBool at hcPol
                      simp only [Bool.and_eq_true] at hcPol
                      rw [Option.isNone_iff_eq_none.mp hcPol.1] at hitS; nomatch hitS
                rw [hReqF, hAnyF]
    | refinement =>
        unfold evalG56ScopeDiag at hScopeNone
        rw [hRk] at hScopeNone; dsimp only at hScopeNone
        cases hSc : v.1.scopeCompatibility <;> rw [hSc] at hScopeNone
        case repairSameScope => dsimp only at hScopeNone; split at hScopeNone <;> nomatch hScopeNone
        case retreatExactSharedLoss => dsimp only at hScopeNone; split at hScopeNone <;> nomatch hScopeNone
        case refinementSameScope =>
          dsimp only at hScopeNone
          by_cases hFl : (!checkReflexRetreatFlagConsistentBool v.1) = true
          · rw [if_pos hFl] at hScopeNone; nomatch hScopeNone
          · rw [if_neg hFl] at hScopeNone
            have hFlTrue : checkReflexRetreatFlagConsistentBool v.1 = true := by
              cases hb : checkReflexRetreatFlagConsistentBool v.1 <;> simp_all
            unfold checkReflexRetreatFlagConsistentBool at hFlTrue
            rw [hRk] at hFlTrue
            simp only [Bool.and_eq_true] at hFlTrue
            have hReqF : v.1.g5Cert.requiresRetreatHistory = false := by
              rw [hReqEqB]
              exact Bool.eq_false_iff.mpr (fun ht => by rw [ht] at hFlTrue; nomatch hFlTrue.2)
            have hBad : (v.val.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) = [] := by
              cases hRf : v.val.g5Cert.refinementCert? with
              | none =>
                  rw [hRf] at hScopeNone; dsimp only at hScopeNone
                  cases hb : (v.val.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) with
                  | cons _ _ => rw [hb] at hScopeNone; nomatch hScopeNone
                  | nil => rfl
              | some rf =>
                  rw [hRf] at hScopeNone; dsimp only at hScopeNone
                  cases hExpB : rf.scopeExpanded <;>
                    simp only [hExpB, Bool.not_true, Bool.not_false, Bool.false_eq_true, ↓reduceIte] at hScopeNone
                  case true => nomatch hScopeNone
                  case false =>
                    cases hb : (v.val.g6Suite.items.filter (fun it => !checkItemSameScopePolBool it)).map (·.invariantId) with
                    | cons _ _ => rw [hb] at hScopeNone; nomatch hScopeNone
                    | nil => rfl
            have hAnyF : v.1.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) = false := by
              apply Bool.eq_false_iff.mpr; intro hAny
              rcases List.any_eq_true.mp hAny with ⟨it, hitM, hitS⟩
              cases hcPol : checkItemSameScopePolBool it with
              | false =>
                  have hInM : it.invariantId ∈
                      (v.val.g6Suite.items.filter (fun x => !checkItemSameScopePolBool x)).map (·.invariantId) :=
                    List.mem_map_of_mem (List.mem_filter.mpr ⟨hitM, by rw [hcPol]; rfl⟩)
                  rw [hBad] at hInM; nomatch hInM
              | true =>
                  unfold checkItemSameScopePolBool at hcPol
                  simp only [Bool.and_eq_true] at hcPol
                  rw [Option.isNone_iff_eq_none.mp hcPol.1] at hitS; nomatch hitS
            rw [hReqF, hAnyF]
        case refinementExpandedScope =>
          dsimp only at hScopeNone
          by_cases hFl : (!checkReflexRetreatFlagConsistentBool v.1) = true
          · rw [if_pos hFl] at hScopeNone; nomatch hScopeNone
          · rw [if_neg hFl] at hScopeNone
            have hFlTrue : checkReflexRetreatFlagConsistentBool v.1 = true := by
              cases hb : checkReflexRetreatFlagConsistentBool v.1 <;> simp_all
            unfold checkReflexRetreatFlagConsistentBool at hFlTrue
            rw [hRk] at hFlTrue
            simp only [Bool.and_eq_true] at hFlTrue
            have hReqF : v.1.g5Cert.requiresRetreatHistory = false := by
              rw [hReqEqB]
              exact Bool.eq_false_iff.mpr (fun ht => by rw [ht] at hFlTrue; nomatch hFlTrue.2)
            have hBad : (v.val.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId) = [] := by
              cases hRf : v.val.g5Cert.refinementCert? with
              | none =>
                  rw [hRf] at hScopeNone; dsimp only at hScopeNone
                  cases hb : (v.val.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId) with
                  | cons _ _ => rw [hb] at hScopeNone; nomatch hScopeNone
                  | nil => rfl
              | some rf =>
                  rw [hRf] at hScopeNone; dsimp only at hScopeNone
                  cases hExpB : rf.scopeExpanded <;>
                    simp only [hExpB, Bool.false_eq_true, ↓reduceIte] at hScopeNone
                  case false => nomatch hScopeNone
                  case true =>
                    cases hb : (v.val.g6Suite.items.filter (fun it => !checkItemExpandedScopePolBool it)).map (·.invariantId) with
                    | cons _ _ => rw [hb] at hScopeNone; nomatch hScopeNone
                    | nil => rfl
            have hAnyF : v.1.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) = false := by
              apply Bool.eq_false_iff.mpr; intro hAny
              rcases List.any_eq_true.mp hAny with ⟨it, hitM, hitS⟩
              cases hcPol : checkItemExpandedScopePolBool it with
              | false =>
                  have hInM : it.invariantId ∈
                      (v.val.g6Suite.items.filter (fun x => !checkItemExpandedScopePolBool x)).map (·.invariantId) :=
                    List.mem_map_of_mem (List.mem_filter.mpr ⟨hitM, by rw [hcPol]; rfl⟩)
                  rw [hBad] at hInM; nomatch hInM
              | true =>
                  unfold checkItemExpandedScopePolBool at hcPol
                  simp only [Bool.and_eq_true] at hcPol
                  rw [Option.isNone_iff_eq_none.mp hcPol.1] at hitS; nomatch hitS
            rw [hReqF, hAnyF]
    | retreat =>
        rcases T_I0_A4_05_TopLevelForcesConstrainedL1Path ctx v.1 v.2 hRk with
          ⟨Φ_shared, itemBinds, _, _, _, _, hConstr⟩
        have hReqT : v.1.g5Cert.requiresRetreatHistory = true := by
          unfold checkG5DischargeBool checkG5CoreProofsBool at hG5Ok
          simp only [Bool.and_eq_true] at hG5Ok
          have hBr := hG5Ok.2.2
          have hRk5 : v.1.g5Cert.reflexKind = .retreat :=
            (congrArg G56TransitionBinding.reflexKind hG5Proj).trans hRk
          rw [hRk5] at hBr
          simp only [Bool.and_eq_true] at hBr
          exact hBr.1.1.1
        unfold checkAllItemsRetreatLossConstrainedBool at hConstr
        simp only [Bool.and_eq_true] at hConstr
        have hMapEq : itemBinds.map (·.invariantId) = v.1.g6Suite.items.map (·.invariantId) :=
          eq_of_beq hConstr.1.1
        have hLoopNone :
            (checkRetreatItemPairsLoop ctx.fuelG6 ctx.primEnv ctx.dagCont
              v.1.transitionBinding.domOld v.1.transitionBinding.guardsOld
              v.1.transitionBinding.specNewId Φ_shared v.1.g6Suite.items itemBinds).2 = none :=
          Option.isNone_iff_eq_none.mp hConstr.1.2
        have hAnyT : v.1.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome) = true := by
          cases hIts : v.1.g6Suite.items with
          | nil => exact False.elim (hNonEmpty hIts)
          | cons it0 rest =>
              apply List.any_eq_true.mpr
              rcases retreatPairsLoop_none_mem ctx.fuelG6 ctx.primEnv ctx.dagCont
                  v.1.transitionBinding.domOld v.1.transitionBinding.guardsOld
                  v.1.transitionBinding.specNewId Φ_shared v.1.g6Suite.items itemBinds
                  hMapEq hLoopNone it0 (by rw [hIts]; exact List.mem_cons_self ..) with
                ⟨bd0, _, hp0⟩
              unfold checkSingleRetreatItemLossPair at hp0
              by_cases hpNe : (it0.oldNewState.scopePolicy != .retreatWithLossAccounting) = true
              · rw [if_pos hpNe] at hp0; nomatch hp0
              · rw [if_neg hpNe] at hp0
                cases hLr0 : it0.scopeLossRecord? with
                | none => rw [hLr0] at hp0; nomatch hp0
                | some _ => exact ⟨it0, List.mem_cons_self .., by rw [hLr0]; rfl⟩
        rw [hReqT, hAnyT]

/-! ### 2. Coherent `G56QualifiedRecord`, `reifyVerifiedG56`, & 4-Way `I0-A7` Theorems -/

/-- Helper extractor on `SlotWitness G56CouplingCert ... .verified`. -/
def extractVerifiedG56 {ctx : G56SharedContext}
    (w : SlotWitness G56CouplingCert (isG56CouplingVerifiedBool ctx) .verified) :
    G56CouplingCert :=
  match w with
  | .mkVerified sub => sub.1

/-- Helper extractor on `SlotWitness G5DischargeCert ... .verified`. -/
def extractVerifiedG5 {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    (w : SlotWitness G5DischargeCert (checkG5DischargeBool fuel Γ C) .verified) :
    G5DischargeCert :=
  match w with
  | .mkVerified sub => sub.1

/-- **Coherent `G56QualifiedRecord` (`F-B3-T17-02`, `R1-A2`, `I0-A7`)**:
    Encapsulated via `private mk ::` with explicit propositional equalities sealing EVERY
    single data field canonically to the underlying `VerifiedG56Object ctx`! -/
structure G56QualifiedRecord (ctx : G56SharedContext) where
  private mk ::
  verifiedG56Slot                         : SlotWitness G56CouplingCert
                                              (isG56CouplingVerifiedBool ctx) .verified
  verifiedG5Slot                          : SlotWitness G5DischargeCert
                                              (checkG5DischargeBool ctx.fuelG5 ctx.primEnv ctx.dagCont) .verified
  verifiedG6Slot                          : SlotWitness G6ProtectedSuite
                                              (isG6SuiteVerifiedBool ctx.fuelG6 ctx.primEnv ctx.dagCont) .verified
  g5SlotMatchesCoupling_eq                : extractVerifiedG5 verifiedG5Slot =
                                              (extractVerifiedG56 verifiedG56Slot).g5Cert
  g6SlotMatchesCoupling_eq                : extractVerifiedG6Suite verifiedG6Slot =
                                              (extractVerifiedG56 verifiedG56Slot).g6Suite
  transitionBinding                       : G56TransitionBinding
  bindingMatchesCoupling_eq               : transitionBinding =
                                              (extractVerifiedG56 verifiedG56Slot).transitionBinding
  bindingMatchesG5_eq                     : projectG5Transition
                                              ⟨(extractVerifiedG56 verifiedG56Slot).g5Cert,
                                               transitionBinding.assignedEvalEpoch⟩ =
                                              transitionBinding
  bindingMatchesG6Rel                     : G6TransitionCompatibleRel
                                              (extractVerifiedG56 verifiedG56Slot).g6Suite
                                              transitionBinding
  verifiedInvariantCount                  : Nat
  verifiedCount_eq                        : verifiedInvariantCount =
                                              (extractVerifiedG56 verifiedG56Slot).g6Suite.items.length
  verifiedCountPos                        : 0 < verifiedInvariantCount
  requiresRetreatHistory                  : Bool
  requiresRetreat_eq                      : requiresRetreatHistory =
                                              (extractVerifiedG56 verifiedG56Slot).g5Cert.requiresRetreatHistory
  hasCertifiedScopeLoss                   : Bool
  hasScopeLoss_eq                         : hasCertifiedScopeLoss =
                                              (extractVerifiedG56 verifiedG56Slot).g6Suite.items.any
                                                (fun it => it.scopeLossRecord?.isSome)
  retreatIffLoss_eq                       : requiresRetreatHistory = hasCertifiedScopeLoss
  jointPrimDeps                           : G56JointPrimDeps
  jointDepsMatchesCoupling_eq             : jointPrimDeps =
                                              (extractVerifiedG56 verifiedG56Slot).claimedJointPrimDeps
  g5PrimDeps_eq                           : jointPrimDeps.g5PrimDepIds =
                                              deriveG5PrimDeps ctx.primEnv ctx.dagCont
                                                (extractVerifiedG56 verifiedG56Slot).g5Cert
  g6PrimDeps_eq                           : jointPrimDeps.g6PrimDepIds =
                                              deriveG6PrimDeps ctx.primEnv ctx.dagCont
                                                (extractVerifiedG56 verifiedG56Slot).g6Suite
  jointPrimDeps_eq                        : jointPrimDeps.jointPrimDepIds =
                                              deriveG56JointPrimDeps ctx.primEnv ctx.dagCont
                                                (extractVerifiedG56 verifiedG56Slot).g5Cert
                                                (extractVerifiedG56 verifiedG56Slot).g6Suite
  submittedSuiteComplete                  : Bool
  submittedSuiteComplete_eq_true          : submittedSuiteComplete = true
  officialProtectionRegistryAuthenticated : Bool
  officialRegistryAuth_eq_false           : officialProtectionRegistryAuthenticated = false
  officialRegistryBindingSlot             : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  g1IntegritySlot                         : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  b4CompositeSlot                         : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked
  grantFlag                               : CheckDerivesNoGrant
  grantFlag_eq                            : grantFlag = .noGrantFromMathCheck

/-- Canonical object extractor `E : G56QualifiedRecord ctx → VerifiedG56Object ctx`. -/
def extractVerifiedObject {ctx : G56SharedContext}
    (rec : G56QualifiedRecord ctx) : VerifiedG56Object ctx :=
  match rec.verifiedG56Slot with
  | .mkVerified sub => sub

/-- Canonical deterministic reifier `Q := reifyVerifiedG56 : VerifiedG56Object ctx → G56QualifiedRecord ctx`. -/
def reifyVerifiedG56 (ctx : G56SharedContext) (v : VerifiedG56Object ctx) :
    G56QualifiedRecord ctx :=
  let hG5   := verifiedG56_projects_g5Bool ctx v
  let hG6   := verifiedG56_projects_g6Bool ctx v
  let hPos  := verifiedG56_projects_posCount ctx v
  let hDeps := verifiedG56_projects_jointDeps ctx v
  let hBind := verifiedG56_projects_bindingAndFlags ctx v
  { verifiedG56Slot                         := .mkVerified v
    verifiedG5Slot                          := .mkVerified ⟨v.1.g5Cert, hG5⟩
    verifiedG6Slot                          := .mkVerified ⟨v.1.g6Suite, hG6⟩
    g5SlotMatchesCoupling_eq                := rfl
    g6SlotMatchesCoupling_eq                := rfl
    transitionBinding                       := v.1.transitionBinding
    bindingMatchesCoupling_eq               := rfl
    bindingMatchesG5_eq                     := hBind.1
    bindingMatchesG6Rel                     := hBind.2.1
    verifiedInvariantCount                  := v.1.g6Suite.items.length
    verifiedCount_eq                        := rfl
    verifiedCountPos                        := hPos
    requiresRetreatHistory                  := v.1.g5Cert.requiresRetreatHistory
    requiresRetreat_eq                      := rfl
    hasCertifiedScopeLoss                   := v.1.g6Suite.items.any (fun it => it.scopeLossRecord?.isSome)
    hasScopeLoss_eq                         := rfl
    retreatIffLoss_eq                       := hBind.2.2
    jointPrimDeps                           := v.1.claimedJointPrimDeps
    jointDepsMatchesCoupling_eq             := rfl
    g5PrimDeps_eq                           := hDeps.1
    g6PrimDeps_eq                           := hDeps.2.1
    jointPrimDeps_eq                        := hDeps.2.2
    submittedSuiteComplete                  := true
    submittedSuiteComplete_eq_true          := rfl
    officialProtectionRegistryAuthenticated := false
    officialRegistryAuth_eq_false           := rfl
    officialRegistryBindingSlot             := .mkUnchecked
    g1IntegritySlot                         := .mkUnchecked
    b4CompositeSlot                         := .mkUnchecked
    grantFlag                               := .noGrantFromMathCheck
    grantFlag_eq                            := rfl }

/-- Official coupled qualification entry point returning `Option (G56QualifiedRecord ctx)`. -/
def qualifyG56Coupled? (ctx : G56SharedContext) (c56 : G56CouplingCert) :
    Option (G56QualifiedRecord ctx) :=
  if hVer : isG56CouplingVerifiedBool ctx c56 = true then
    some (reifyVerifiedG56 ctx ⟨c56, hVer⟩)
  else
    none

private theorem slotWitness_g56_ext {ctx : G56SharedContext}
    (w1 w2 : SlotWitness G56CouplingCert (isG56CouplingVerifiedBool ctx) .verified)
    (hVal : extractVerifiedG56 w1 = extractVerifiedG56 w2) :
    w1 = w2 := by
  cases w1 with
  | mkVerified s1 =>
      cases w2 with
      | mkVerified s2 =>
          unfold extractVerifiedG56 at hVal
          exact congrArg SlotWitness.mkVerified (Subtype.ext hVal)

private theorem slotWitness_g5_ext {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    (w1 w2 : SlotWitness G5DischargeCert (checkG5DischargeBool fuel Γ C) .verified)
    (hVal : extractVerifiedG5 w1 = extractVerifiedG5 w2) :
    w1 = w2 := by
  cases w1 with
  | mkVerified s1 =>
      cases w2 with
      | mkVerified s2 =>
          unfold extractVerifiedG5 at hVal
          exact congrArg SlotWitness.mkVerified (Subtype.ext hVal)

private theorem slotWitness_g6_ext {fuel : Nat} {Γ : PrimPremiseEnv} {C : G7DagContainer}
    (w1 w2 : SlotWitness G6ProtectedSuite (isG6SuiteVerifiedBool fuel Γ C) .verified)
    (hVal : extractVerifiedG6Suite w1 = extractVerifiedG6Suite w2) :
    w1 = w2 := by
  cases w1 with
  | mkVerified s1 =>
      cases w2 with
      | mkVerified s2 =>
          unfold extractVerifiedG6Suite at hVal
          exact congrArg SlotWitness.mkVerified (Subtype.ext hVal)

private theorem slotWitness_unchecked_unique
    (w1 w2 : SlotWitness UnauthorizedStageCert checkUnauthStageCertBool .unchecked) :
    w1 = w2 := by
  cases w1; cases w2; rfl

/-- **`T_I0_A7_EXISTENCE` (`F-B3-T18-01` Part 1 — Verified Object Recovery)**:
    Every `rec : G56QualifiedRecord ctx` recovers a valid `v : VerifiedG56Object ctx` whose
    certificate equals `extractVerifiedG56 rec.verifiedG56Slot`, and enforces internal coherence
    across `verifiedG5Slot`, `verifiedG6Slot`, `transitionBinding`, and all 3 `jointPrimDeps` fields. -/
theorem T_I0_A7_EXISTENCE (ctx : G56SharedContext) (rec : G56QualifiedRecord ctx) :
    (∃ v : VerifiedG56Object ctx,
       v = extractVerifiedObject rec ∧
       v.1 = extractVerifiedG56 rec.verifiedG56Slot) ∧
    extractVerifiedG5 rec.verifiedG5Slot =
      (extractVerifiedG56 rec.verifiedG56Slot).g5Cert ∧
    extractVerifiedG6Suite rec.verifiedG6Slot =
      (extractVerifiedG56 rec.verifiedG56Slot).g6Suite ∧
    rec.transitionBinding =
      (extractVerifiedG56 rec.verifiedG56Slot).transitionBinding ∧
    rec.jointPrimDeps =
      (extractVerifiedG56 rec.verifiedG56Slot).claimedJointPrimDeps := by
  refine ⟨⟨extractVerifiedObject rec, rfl, ?_⟩,
          rec.g5SlotMatchesCoupling_eq,
          rec.g6SlotMatchesCoupling_eq,
          rec.bindingMatchesCoupling_eq,
          rec.jointDepsMatchesCoupling_eq⟩
  unfold extractVerifiedObject extractVerifiedG56
  cases rec.verifiedG56Slot with
  | mkVerified _ => rfl

/-- **`T_I0_A7_TOTALITY` (`F-B3-T18-01` Part 2 — Totality of Reification & `qualifyG56Coupled?`)**:
    (1) `reifyVerifiedG56 ctx` is a total function on `VerifiedG56Object ctx`;
    (2) `qualifyG56Coupled? ctx c56` returns `some rec` IF AND ONLY IF
        `isG56CouplingVerifiedBool ctx c56 = true`! -/
theorem T_I0_A7_TOTALITY (ctx : G56SharedContext) (c56 : G56CouplingCert) :
    ((qualifyG56Coupled? ctx c56).isSome = true ↔
      isG56CouplingVerifiedBool ctx c56 = true) ∧
    (∀ hVer : isG56CouplingVerifiedBool ctx c56 = true,
      qualifyG56Coupled? ctx c56 = some (reifyVerifiedG56 ctx ⟨c56, hVer⟩)) := by
  refine ⟨?_, fun hVer => by unfold qualifyG56Coupled?; rw [dif_pos hVer]⟩
  unfold qualifyG56Coupled?
  by_cases hVer : isG56CouplingVerifiedBool ctx c56 = true
  · rw [dif_pos hVer]; simp [hVer]
  · rw [dif_neg hVer]; simp [hVer]

/-- **`T_I0_A7_UNIQUENESS` (`F-B3-T18-01` Part 4 — Canonical Record Extensional Uniqueness)**:
    Because every `Type`-valued field of `G56QualifiedRecord ctx` is sealed by an explicit
    propositional equality to `extractVerifiedG56 verifiedG56Slot` (or a singleton `.unchecked` /
    `CheckDerivesNoGrant` constructor), any two records `r1, r2 : G56QualifiedRecord ctx` with
    the same extracted coupled certificate are **propositionally equal (`r1 = r2`)**! -/
theorem T_I0_A7_UNIQUENESS (ctx : G56SharedContext)
    (r1 r2 : G56QualifiedRecord ctx)
    (hSameCert : extractVerifiedG56 r1.verifiedG56Slot =
                 extractVerifiedG56 r2.verifiedG56Slot) :
    r1 = r2 := by
  have hSlot56 : r1.verifiedG56Slot = r2.verifiedG56Slot :=
    slotWitness_g56_ext r1.verifiedG56Slot r2.verifiedG56Slot hSameCert
  have hSlot5 : r1.verifiedG5Slot = r2.verifiedG5Slot := by
    apply slotWitness_g5_ext
    rw [r1.g5SlotMatchesCoupling_eq, r2.g5SlotMatchesCoupling_eq, hSameCert]
  have hSlot6 : r1.verifiedG6Slot = r2.verifiedG6Slot := by
    apply slotWitness_g6_ext
    rw [r1.g6SlotMatchesCoupling_eq, r2.g6SlotMatchesCoupling_eq, hSameCert]
  have hBind : r1.transitionBinding = r2.transitionBinding := by
    rw [r1.bindingMatchesCoupling_eq, r2.bindingMatchesCoupling_eq, hSameCert]
  have hCnt : r1.verifiedInvariantCount = r2.verifiedInvariantCount := by
    rw [r1.verifiedCount_eq, r2.verifiedCount_eq, hSameCert]
  have hReq : r1.requiresRetreatHistory = r2.requiresRetreatHistory := by
    rw [r1.requiresRetreat_eq, r2.requiresRetreat_eq, hSameCert]
  have hLoss : r1.hasCertifiedScopeLoss = r2.hasCertifiedScopeLoss := by
    rw [r1.hasScopeLoss_eq, r2.hasScopeLoss_eq, hSameCert]
  have hDeps : r1.jointPrimDeps = r2.jointPrimDeps := by
    rw [r1.jointDepsMatchesCoupling_eq, r2.jointDepsMatchesCoupling_eq, hSameCert]
  have hSubComp : r1.submittedSuiteComplete = r2.submittedSuiteComplete := by
    rw [r1.submittedSuiteComplete_eq_true, r2.submittedSuiteComplete_eq_true]
  have hOffAuth : r1.officialProtectionRegistryAuthenticated =
      r2.officialProtectionRegistryAuthenticated := by
    rw [r1.officialRegistryAuth_eq_false, r2.officialRegistryAuth_eq_false]
  have hOffSlot : r1.officialRegistryBindingSlot = r2.officialRegistryBindingSlot :=
    slotWitness_unchecked_unique _ _
  have hG1Slot : r1.g1IntegritySlot = r2.g1IntegritySlot :=
    slotWitness_unchecked_unique _ _
  have hB4Slot : r1.b4CompositeSlot = r2.b4CompositeSlot :=
    slotWitness_unchecked_unique _ _
  have hGrant : r1.grantFlag = r2.grantFlag := by
    cases r1.grantFlag; cases r2.grantFlag; rfl
  rcases r1 with ⟨s56_1, s5_1, s6_1, _, _, tb1, _, _, _, cnt1, _, _, rr1, _, hl1, _, _, jd1, _, _, _, _, sc1, _, oa1, _, os1, g1_1, b4_1, gf1, _⟩
  rcases r2 with ⟨s56_2, s5_2, s6_2, _, _, tb2, _, _, _, cnt2, _, _, rr2, _, hl2, _, _, jd2, _, _, _, _, sc2, _, oa2, _, os2, g1_2, b4_2, gf2, _⟩
  dsimp only at hSlot56 hSlot5 hSlot6 hBind hCnt hReq hLoss hDeps hSubComp hOffAuth hOffSlot hG1Slot hB4Slot hGrant
  subst hSlot56; subst hSlot5; subst hSlot6; subst hBind; subst hCnt
  subst hReq; subst hLoss; subst hDeps; subst hSubComp; subst hOffAuth
  subst hOffSlot; subst hG1Slot; subst hB4Slot; subst hGrant
  rfl

/-- **`T_I0_A7_ROUNDTRIP` (`F-B3-T18-01` Part 3 — Bidirectional Isomorphism `E ∘ Q = id_V` & `Q ∘ E = id_R`)**:
    (1) `extractVerifiedObject (reifyVerifiedG56 ctx v) = v` (`E ∘ Q = id_V`);
    (2) `reifyVerifiedG56 ctx (extractVerifiedObject r) = r` (`Q ∘ E = id_R`). -/
theorem T_I0_A7_ROUNDTRIP (ctx : G56SharedContext) :
    (∀ v : VerifiedG56Object ctx,
       extractVerifiedObject (reifyVerifiedG56 ctx v) = v) ∧
    (∀ r : G56QualifiedRecord ctx,
       reifyVerifiedG56 ctx (extractVerifiedObject r) = r) := by
  refine ⟨fun _ => rfl, ?_⟩
  intro r
  apply T_I0_A7_UNIQUENESS ctx
  unfold reifyVerifiedG56 extractVerifiedObject extractVerifiedG56
  dsimp only
  cases r.verifiedG56Slot with
  | mkVerified _ => rfl

/-- Contrast wrapper with an unsealed `Type`-valued `unsealedAuditTag : String` (`CE-I0-01` — `F-B3-T18-01`):
    Demonstrates constructively why `EXISTENCE` (`∀ r, ∃ v, v.1 = r.verifiedObj.1`) does NOT imply
    `UNIQUENESS` (`r1 = r2`) when unsealed auxiliary data fields exist! -/
structure UncanonicalTaggedRecord (ctx : G56SharedContext) where
  verifiedObj      : VerifiedG56Object ctx
  unsealedAuditTag : String
  deriving DecidableEq

theorem T_I0_A7_CE01_ExistenceDoesNotImplyUniquenessOnUncanonicalRecord
    (ctx : G56SharedContext) (v : VerifiedG56Object ctx) :
    let r1 : UncanonicalTaggedRecord ctx := ⟨v, "tag_alpha"⟩
    let r2 : UncanonicalTaggedRecord ctx := ⟨v, "tag_beta"⟩
    (∃ u : VerifiedG56Object ctx, u.1 = r1.verifiedObj.1) ∧
    (∃ u : VerifiedG56Object ctx, u.1 = r2.verifiedObj.1) ∧
    r1.verifiedObj = r2.verifiedObj ∧
    r1 ≠ r2 := by
  dsimp only
  refine ⟨⟨v, rfl⟩, ⟨v, rfl⟩, rfl, ?_⟩
  intro hEq
  have hTag : "tag_alpha" = "tag_beta" := congrArg UncanonicalTaggedRecord.unsealedAuditTag hEq
  nomatch hTag

/-- **`T_I0_A7_ZeroAuthorityAndNoFullReflex` (`C-B3-10`, `CE-G56-16`)**:
    Every `rec : G56QualifiedRecord ctx` seals `0 < rec.verifiedInvariantCount`,
    `officialProtectionRegistryAuthenticated = false`, `.mkUnchecked` across `officialRegistryBindingSlot`,
    `g1IntegritySlot`, `b4CompositeSlot`, and `grantFlag = .noGrantFromMathCheck`; furthermore,
    `FullReflexAdmitted checkUnauthStageCertBool (isG56CouplingVerifiedBool ctx) checkCertifiedG7BundleBool`
    is provably uninhabited (`Empty`)! -/
theorem T_I0_A7_ZeroAuthorityAndNoFullReflex (ctx : G56SharedContext) :
    (∀ rec : G56QualifiedRecord ctx,
       0 < rec.verifiedInvariantCount ∧
       rec.submittedSuiteComplete = true ∧
       rec.officialProtectionRegistryAuthenticated = false ∧
       rec.officialRegistryBindingSlot = .mkUnchecked ∧
       rec.g1IntegritySlot = .mkUnchecked ∧
       rec.b4CompositeSlot = .mkUnchecked ∧
       rec.grantFlag = .noGrantFromMathCheck) ∧
    ¬ Nonempty (FullReflexAdmitted
        checkUnauthStageCertBool
        (isG56CouplingVerifiedBool ctx)
        checkCertifiedG7BundleBool) := by
  refine ⟨?_, ?_⟩
  · intro rec
    exact ⟨rec.verifiedCountPos,
           rec.submittedSuiteComplete_eq_true,
           rec.officialRegistryAuth_eq_false,
           slotWitness_unchecked_unique _ _,
           slotWitness_unchecked_unique _ _,
           slotWitness_unchecked_unique _ _,
           rec.grantFlag_eq⟩
  · rintro ⟨full⟩
    rcases verified_slot_has_checked_cert full.slotG1 with ⟨_, hBad⟩
    nomatch hBad

/-! ### 3. `I0-A8` — Ledger Step/Fold Monotonicity & Stale State Invalidation (`Q-B3-R1-04`) -/

/-- Retracted premise list of a `StructuralLedgerState`. -/
def retractedOfState (st : StructuralLedgerState) : List String :=
  st.epistemic.retractedPremises

/-- Retracted premise list of a folded ledger `L : List StructuralLedgerEvent`. -/
def retractedOfLedger (L : List StructuralLedgerEvent) : List String :=
  retractedOfState (foldStructuralLedger L)

/-- Pure read-only snapshot activity check on `(L, ctx, c56)` (`Layer T2` — mutates zero state!). -/
def checkActiveG56CouplingBool (L : List StructuralLedgerEvent)
    (ctx : G56SharedContext) (c56 : G56CouplingCert) : Bool :=
  let ep := (foldStructuralLedger L).epistemic
  isG56CouplingVerifiedBool ctx c56 &&
  c56.claimedJointPrimDeps.jointPrimDepIds.all (fun p => !ep.retractedPremises.contains p) &&
  c56.g6Suite.items.all (fun it =>
    !it.versionEpoch.revokedBool &&
    decide (it.versionEpoch.effectiveFromEpoch ≤ ep.currentEpoch) &&
    decide (ep.currentEpoch < it.versionEpoch.expiresAtEpoch))

/-- Pure read-only snapshot activity check on a coherent `G56QualifiedRecord ctx` (`R1-A7`). -/
def checkActiveG56RecordBool (L : List StructuralLedgerEvent)
    {ctx : G56SharedContext} (rec : G56QualifiedRecord ctx) : Bool :=
  checkActiveG56CouplingBool L ctx (extractVerifiedG56 rec.verifiedG56Slot)

/-- Split-ledger packet rejection gate (`CE-G56-14A`: forbids asymmetric `L5 ≠ L6` ledger views!). -/
def checkActiveG56SplitLedgerPacketBool (L5 L6 : List StructuralLedgerEvent)
    (ctx : G56SharedContext) (c56 : G56CouplingCert) : Bool :=
  (L5 == L6) && checkActiveG56CouplingBool L5 ctx c56

/-- Read-only official protection-registry reference comparator (`CE-G56-15`; full `B4` auth `HELD`). -/
def checkOfficialG56SuiteIdsMatchBool (officialIds : List String)
    (c56 : G56CouplingCert) : Bool :=
  checkOfficialSuiteIdsMatchBool officialIds c56.g6Suite

/-- **`T_I0_A8_01` — Single-Step Retraction Monotonicity (`R(s) ⊆ R(stepStructuralLedger s ev)`)**:
    Proved exhaustively across all 5 constructors of frozen `StructuralLedgerEvent`. -/
theorem T_I0_A8_01_StepRetractionMonotone
    (st : StructuralLedgerState) (ev : StructuralLedgerEvent) (p : String)
    (hMem : p ∈ retractedOfState st) :
    p ∈ retractedOfState (stepStructuralLedger st ev) := by
  cases ev with
  | recordStructuralReflex _ => exact hMem
  | retractPremise q         => exact List.mem_append_left [q] hMem
  | advanceEpoch _           => exact hMem
  | issueGrantHeld _         => exact hMem
  | revokeGrantHeld _        => exact hMem

private theorem foldl_step_retraction_monotone
    (st : StructuralLedgerState) (ΔL : List StructuralLedgerEvent) {p : String}
    (hMem : p ∈ retractedOfState st) :
    p ∈ retractedOfState (ΔL.foldl stepStructuralLedger st) := by
  induction ΔL generalizing st with
  | nil => exact hMem
  | cons ev tail ih =>
      dsimp only [List.foldl]
      exact ih (stepStructuralLedger st ev)
        (T_I0_A8_01_StepRetractionMonotone st ev p hMem)

/-- **`T_I0_A8_02` — Append-Only Fold Retraction Monotonicity (`R(L) ⊆ R(L ++ ΔL)`)**:
    For any valid append-only extension `L ++ ΔL` in the same ledger lineage, every retracted
    premise `p ∈ R(L)` remains in `R(L ++ ΔL)`. -/
theorem T_I0_A8_02_FoldAppendRetractionSubset
    (L ΔL : List StructuralLedgerEvent) (p : String)
    (hMem : p ∈ retractedOfLedger L) :
    p ∈ retractedOfLedger (L ++ ΔL) := by
  unfold retractedOfLedger foldStructuralLedger at hMem ⊢
  rw [List.foldl_append]
  exact foldl_step_retraction_monotone (L.foldl stepStructuralLedger initStructuralLedger) ΔL hMem

/-- **`T_I0_A8_03` — Monotone Stale-State Invalidation on Fixed `(ctx, c56)`**:
    Once any premise `p ∈ c56.claimedJointPrimDeps.jointPrimDepIds` belongs to `retractedOfLedger L`,
    `checkActiveG56CouplingBool (L ++ ΔL) ctx c56 = false` holds permanently for ALL append-only
    extensions `ΔL`! -/
theorem T_I0_A8_03_CoupledActiveMonotoneInvalidation
    (L ΔL : List StructuralLedgerEvent)
    (ctx : G56SharedContext) (c56 : G56CouplingCert) (p : String)
    (hDep : p ∈ c56.claimedJointPrimDeps.jointPrimDepIds)
    (hRet : p ∈ retractedOfLedger L) :
    checkActiveG56CouplingBool (L ++ ΔL) ctx c56 = false := by
  have hRetExt : p ∈ (foldStructuralLedger (L ++ ΔL)).epistemic.retractedPremises :=
    T_I0_A8_02_FoldAppendRetractionSubset L ΔL p hRet
  have hContains :
      (foldStructuralLedger (L ++ ΔL)).epistemic.retractedPremises.contains p = true :=
    List.contains_iff_mem.mpr hRetExt
  have hAllFalse :
      c56.claimedJointPrimDeps.jointPrimDepIds.all
        (fun q => !(foldStructuralLedger (L ++ ΔL)).epistemic.retractedPremises.contains q) = false := by
    apply Bool.eq_false_iff.mpr
    intro hAllTrue
    have hpNot := List.all_eq_true.mp hAllTrue p hDep
    rw [hContains] at hpNot
    nomatch hpNot
  unfold checkActiveG56CouplingBool
  dsimp only
  rw [hAllFalse]
  simp

/-- **`T_I0_A8_04` — Cross-Term Closure (`Object Coherence × Joint Closure × Monotone Invalidation`)**:
    For ANY `rec : G56QualifiedRecord ctx` and ANY premise `p` in EITHER `deriveG5PrimDeps` OR
    `deriveG6PrimDeps` of the underlying coupled certificate (`CE-G56-14B` one-sided retraction!),
    retracting `p` in `L` forces `checkActiveG56RecordBool (L ++ ΔL) rec = false` across ALL
    append-only extensions `ΔL`! -/
theorem T_I0_A8_04_RecordActiveMonotoneInvalidation
    (L ΔL : List StructuralLedgerEvent)
    {ctx : G56SharedContext} (rec : G56QualifiedRecord ctx) (p : String)
    (hIn5Or6 :
      p ∈ deriveG5PrimDeps ctx.primEnv ctx.dagCont (extractVerifiedG5 rec.verifiedG5Slot) ∨
      p ∈ deriveG6PrimDeps ctx.primEnv ctx.dagCont (extractVerifiedG6Suite rec.verifiedG6Slot))
    (hRet : p ∈ retractedOfLedger L) :
    checkActiveG56RecordBool (L ++ ΔL) rec = false := by
  let c56 := extractVerifiedG56 rec.verifiedG56Slot
  rw [rec.g5SlotMatchesCoupling_eq, rec.g6SlotMatchesCoupling_eq] at hIn5Or6
  have hInD56 : p ∈ deriveG56JointPrimDeps ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite :=
    ((T_I0_A3_01_JointPrimDepsExactUnionAndCanonicalClosure
      ctx.primEnv ctx.dagCont c56.g5Cert c56.g6Suite).1 p).mpr hIn5Or6
  have hInClaimed : p ∈ c56.claimedJointPrimDeps.jointPrimDepIds := by
    rw [← rec.jointDepsMatchesCoupling_eq, rec.jointPrimDeps_eq]
    exact hInD56
  unfold checkActiveG56RecordBool
  exact T_I0_A8_03_CoupledActiveMonotoneInvalidation L ΔL ctx c56 p hInClaimed hRet

end OmegaCellC1P1B2BB3
