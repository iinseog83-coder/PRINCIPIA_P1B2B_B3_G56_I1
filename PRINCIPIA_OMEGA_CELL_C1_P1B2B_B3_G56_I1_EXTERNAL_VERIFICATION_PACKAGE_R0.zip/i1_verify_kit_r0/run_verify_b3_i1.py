"""
PRINCIPIA Ω-CELL-C1-P1B2B-B3 G56 — I1 Independent External Replay Act (`KitB3I1`)
CLI Entrypoint: run_verify_b3_i1.py

Supports two strictly separated epistemic execution contexts (`Q-B3-I1-05`):
  - `LOCAL_DOUBLE_CLEAN_REPLAY`: Author/local self-contained double clean replay (Method A).
  - `EXTERNAL_CI_REPRODUCED`: External Linux GitHub Actions double clean replay (enforcing strict
    executed-vs-bundled workflow `.yml` SHA-256 identity `H_W`!).

Binds the 5-tuple replay evidence identity `E_I1 = (H_S, H_E, H_O, H_W, H_R)` in a single
cryptographically cross-linked JSON receipt without mutating `source_root`.
"""

from __future__ import annotations

import argparse
import datetime
import json
from pathlib import Path

from audit_b3_i1_core import (
    canonical_json_bytes,
    run_double_clean_replay_pipeline,
    sha256_bytes,
    sha256_file,
)
from run_calibration_b3_i1 import run_b3_i1_calibration_suite


def _is_valid_sha256_hex(s: str) -> bool:
    return len(s) == 64 and all(c in "0123456789ABCDEF" for c in s)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="PRINCIPIA P1B2B-B3 G56 I1 Independent External Replay Runner (`KitB3I1`)"
    )
    parser.add_argument(
        "--source-root",
        required=True,
        help="Path to workspace root or unpacked self-contained bundle root",
    )
    parser.add_argument(
        "--receipt-out",
        required=True,
        help="Output path for the I1 verification receipt JSON",
    )
    parser.add_argument(
        "--evidence-dir",
        default="",
        help="Optional directory to emit R1/R2 build logs, live observations, and CanSem comparison",
    )
    parser.add_argument(
        "--execution-context",
        default="LOCAL_DOUBLE_CLEAN_REPLAY",
        choices=["LOCAL_DOUBLE_CLEAN_REPLAY", "EXTERNAL_CI_REPRODUCED"],
        help="Epistemic execution classification (`Q-B3-I1-05`: never conflates local vs external CI)",
    )
    parser.add_argument(
        "--executed-workflow-sha256",
        default="",
        help="SHA-256 of actual executed `.github/workflows/...yml` (mandatory in EXTERNAL_CI_REPRODUCED)",
    )
    parser.add_argument(
        "--executed-workflow-bytes",
        type=int,
        default=0,
        help="Byte length of actual executed `.github/workflows/...yml`",
    )
    parser.add_argument(
        "--bundled-workflow-sha256",
        default="",
        help="SHA-256 of bundled `principia_p1b2b_b3_g56_i1_external_replay_r0.yml` (`H_W`)",
    )
    parser.add_argument(
        "--with-calibration",
        action="store_true",
        help="Also run CAL-B3-I1-01..06 isolated fault-injection calibration checks",
    )
    args = parser.parse_args()

    kit_dir = Path(__file__).resolve().parent
    source_root = Path(args.source_root).resolve()
    receipt_out = Path(args.receipt_out).resolve()
    ev_dir = Path(args.evidence_dir).resolve() if args.evidence_dir else None
    if ev_dir is not None:
        ev_dir.mkdir(parents=True, exist_ok=True)

    wf_kit_path = kit_dir / "principia_p1b2b_b3_g56_i1_external_replay_r0.yml"
    kit_wf_bytes, kit_wf_sha = sha256_file(wf_kit_path) if wf_kit_path.is_file() else (0, "")

    exec_wf_sha = args.executed_workflow_sha256.strip().upper()
    bund_wf_sha = (args.bundled_workflow_sha256.strip().upper() or kit_wf_sha)

    if args.execution_context == "EXTERNAL_CI_REPRODUCED":
        wf_ok = (
            _is_valid_sha256_hex(exec_wf_sha)
            and _is_valid_sha256_hex(bund_wf_sha)
            and args.executed_workflow_bytes > 0
            and (exec_wf_sha == bund_wf_sha)
            and (not kit_wf_sha or bund_wf_sha == kit_wf_sha)
        )
    else:
        if exec_wf_sha:
            wf_ok = _is_valid_sha256_hex(exec_wf_sha) and (exec_wf_sha == bund_wf_sha)
        else:
            wf_ok = _is_valid_sha256_hex(bund_wf_sha)

    ts_utc = datetime.datetime.now(datetime.timezone.utc).isoformat()

    if not wf_ok:
        ok_main = False
        code_main = "VERIFY_FAILED__WORKFLOW_BYTE_MISMATCH"
        summary = {
            "workflowByteGateError": "EXECUTED_OR_BUNDLED_WORKFLOW_SHA256_MISMATCH",
            "executedWorkflowSha256": exec_wf_sha,
            "bundledWorkflowSha256": bund_wf_sha,
        }
        cal_ok = False
        cal_report = None
    else:
        ok_main, code_main, summary = run_double_clean_replay_pipeline(
            source_root, kit_dir, ev_dir
        )
        cal_ok = True
        cal_report = None
        if ok_main and args.with_calibration:
            probe_p = (ev_dir / "i1_live_lean_oracle_tamper_probe.json") if ev_dir else None
            cal_ok, cal_report = run_b3_i1_calibration_suite(source_root, kit_dir, probe_p)

    overall_ok = wf_ok and ok_main and cal_ok
    if overall_ok:
        if args.execution_context == "EXTERNAL_CI_REPRODUCED":
            verdict_token = "I1_EXTERNAL_CI_DOUBLE_CLEAN_REPLAY_VERIFIED__PENDING_TRIBUNAL_AND_HUMAN_L4"
        else:
            verdict_token = "I1_LOCAL_DOUBLE_CLEAN_REPLAY_VERIFIED__EXTERNAL_LINUX_REPLAY_HELD"
    else:
        verdict_token = code_main

    # Compute deterministic H_R over the core execution payload before wrapping outer receipt digest
    core_execution_body = {
        "workId": "PRINCIPIA_OMEGA_CELL_C1_P1B2B_B3_G56_I1_INDEPENDENT_EXTERNAL_REPLAY_ACT",
        "executionContext_Q_B3_I1_05": args.execution_context,
        "overallPassed": overall_ok,
        "verdictToken": verdict_token,
        "pipelineCode": code_main,
        "workflowProvenance": {
            "kitBundledWorkflowBytes": kit_wf_bytes,
            "H_W_bundledWorkflowSha256": bund_wf_sha,
            "executedWorkflowBytes": args.executed_workflow_bytes,
            "executedWorkflowSha256": exec_wf_sha if exec_wf_sha else "NOT_EXECUTED_IN_GITHUB_ACTIONS_YET",
            "workflowByteGatePassed": wf_ok,
        },
        "doubleReplaySummary": summary,
        "calibrationReport": cal_report,
        "epistemicBoundaries_Q_B3_I1_01_to_05": {
            "retroactiveI0OraclePrecommitmentClaimed": False,
            "historicalI0OracleStatus": "HELD",
            "tribunalDirectMechanicalReplayClaimed": False,
            "i0PermanentCanonicalPromotion": "HELD_PENDING_EXTERNAL_REPLAY_AND_HUMAN_L4",
            "runtimeAndBSeriesAuthority": 0,
        },
    }
    h_r = sha256_bytes(canonical_json_bytes(core_execution_body))

    final_receipt = {
        "receiptSchema": "principia.omega.p1b2b.b3.i1.replay_verification_receipt.v1",
        "generatedAtUtc": ts_utc,
        "fiveTupleEvidenceLineage_E_I1": {
            "H_S_sourceManifestSha256": summary.get("H_S_active62SourceManifestSha256", ""),
            "H_E_environmentAndCanSemSpecSha256": summary.get("H_E_environmentAndCanSemSpecSha256", ""),
            "H_O_precommittedOracle71Sha256": summary.get("H_O_precommittedOracle71Sha256", ""),
            "H_W_workflowSha256": bund_wf_sha,
            "H_R_coreExecutionResultSha256": h_r,
        },
        "coreExecutionBody": core_execution_body,
    }
    receipt_out.parent.mkdir(parents=True, exist_ok=True)
    receipt_out.write_text(
        json.dumps(final_receipt, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
        newline="\n",
    )
    print(
        json.dumps(
            {
                "overallPassed": overall_ok,
                "verdictToken": verdict_token,
                "fiveTuple_E_I1": final_receipt["fiveTupleEvidenceLineage_E_I1"],
            },
            indent=2,
        )
    )
    return 0 if overall_ok else 1


if __name__ == "__main__":
    raise SystemExit(main())
