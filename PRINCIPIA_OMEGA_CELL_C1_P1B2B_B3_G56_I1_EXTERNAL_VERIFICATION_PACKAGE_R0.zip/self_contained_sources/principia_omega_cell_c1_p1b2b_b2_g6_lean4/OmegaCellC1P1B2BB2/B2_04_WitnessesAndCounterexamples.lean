/-
  PRINCIPIA Ω-CELL-C1-P1B2B-B2 — Isolated G6 Protected Invariant Kernel
  Module: OmegaCellC1P1B2BB2.B2_04_WitnessesAndCounterexamples

  Authorization: Scoped Human Execution Approval for `P1B2B-B2 G6 Isolated Lean Proof Core R0`
  Normative Specification:
    - `B2 G6 Static Contract R0` (`POS-G6-01..07`, `CE-G6-01..12`, `Gate A8.(2)`, `Gate A9`, `Gate A11`)
    - `Static Corrigendum 01` (`CE-G6-07B`, `NEG-G6-EMPTY-01`)
    - Twelfth Independent Tribunal (`F-B2-T12-01..04`, including `F-B2-T12-03` negative companion)

  Mechanically Proves (`0` `sorry`, `0` `Classical.choice`):
    1. All 7 Non-Empty Positive Inhabitation Witnesses (`POS-G6-01` .. `POS-G6-07`) +
       Derived-Refutation Witness (`POS-G6-02B`) + Sequential Partial-Div Retreat (`POS-G6-06B`) +
       `Gate A8.(2)` Retreat/Truth Orthogonality (`T_B2_A8_2_RetreatTruthOrthogonality`).
    2. Complete Adversarial & Cross-Term Suite (`CE-G6-01` .. `CE-G6-12` + `CE-G6-07B` +
       `NEG-G6-EMPTY-01` + `F-B2-T12-03` Negative Companion).
-/
import OmegaCellC1P1B2BB2.B2_03_SoundnessPriorityAndClosure

namespace OmegaCellC1P1B2BB2

open OmegaCellC1P1A0
open OmegaCellC1P1B1
open OmegaCellC1P1B2A
open OmegaCellC1P1B2BA0
open OmegaCellC1P1B2BB1

/-! ### 1. Shared Helper Metadata & Default Same-Domain Scope Policy -/

/-- Default active `G6VersionEpoch` (`effectiveFrom = 0 ≤ 10 < 100 = expiresAt`). -/
def defaultActiveEpoch : G6VersionEpoch where
  specVersion        := "v1"
  effectiveFromEpoch := 0
  expiresAtEpoch     := 100
  revokedBool        := false

/-- Default untrusted `G6RegistryOrigin` metadata. -/
def defaultUntrustedOrigin : G6RegistryOrigin where
  registryId          := "reg_local_snap_v1"
  originCellCid       := "cell_orig_v1"
  originRecordCid     := "rec_orig_001"
  claimedApprovedFlag := false

/-- Trivial syntactic same-domain `G6ScopePolicy` on `dom` with empty guards `[]`. -/
def sameDomEmptyGuardsPolicy (dom : G7DomTag) : G6ScopePolicy :=
  .globalPostSameDom {
    baseEquivStep           := .sameBaseDom dom
    oldGuardsDefNodeId?     := none
    oldEntailsNewGuardNodes := []
    newEntailsOldGuardNodes := []
    redundantGuardNodeId?   := none
  }

/-! ### 2. Mandatory Non-Empty Positive Witnesses (`POS-G6-01` .. `POS-G6-07` & `Gate A8.(2)`) -/

/-- **`POS-G6-01`**: Fixed global invariant `x^2 + 1 > 0` on `.domQ`, non-integer witness `(1/2, 0)`. -/
def formXSqPlusOnePos : StrictForm :=
  .pos (.add (.mul .varX .varX) (.const 1))

def containerPos01 : G7DagContainer where
  nodes := [
    { nodeId     := "n_pos01_xsq1"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_pos01_new"
      guards     := []
      conclusion := formXSqPlusOnePos
      step       := .directDerivStep
                      (.certStep formXSqPlusOnePos
                        (.polyPositivstellensatz ⟨1, 1, [(1, .pVarX)], [], [], []⟩)) }
  ]

def itemPos01_GlobalFixed : G6ProtectedInvariantSpec where
  invariantId      := "inv_pos01"
  specId           := "spec_pos01_new"
  protectedDomain  := .domQ
  protectedGuards  := []
  protectedFormula := .fixedStateForm formXSqPlusOnePos
  parameterBinding := .noParam
  versionEpoch     := defaultActiveEpoch
  evidenceRoots    := {
    declaredItemProofNids := ["n_pos01_xsq1"]
    itemEvidence          := .claimVerified "n_pos01_xsq1"
  }
  registryOrigin   := defaultUntrustedOrigin
  oldNewState      := {
    specOldId                := "spec_pos01_old"
    specNewId                := "spec_pos01_new"
    domOld                   := .domQ
    guardsOld                := []
    formOldInst              := formXSqPlusOnePos
    domNew                   := .domQ
    guardsNew                := []
    formNewInst              := formXSqPlusOnePos
    oldBaselineProofNodeId?  := none
    newGuardsDefNodeId?      := none
    postDomNonEmptyWitness   := ⟨1, 2, 0, 1⟩
    scopePolicy              := sameDomEmptyGuardsPolicy .domQ
  }
  scopeLossRecord? := none

def posG6Suite01_GlobalFixed : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_pos01_global_fixed"
  rflxCid              := "rflx_pos01"
  cellOldCid           := "cell_pos01_old"
  cellNewCid           := "cell_pos01_new"
  baseId               := "base_Q"
  specOldId            := "spec_pos01_old"
  specNewId            := "spec_pos01_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_pos01"]
  items                := [itemPos01_GlobalFixed]
  claimedPrimDeps      := ⟨[]⟩

/-- **`POS-G6-02`**: Genuine point-violated invariant `x - 1 ≥ 0` on `.domQ` at `(0, 0)`. -/
def formXMinusOneNonneg : StrictForm :=
  .nonneg (.sub .varX (.const 1))

def itemPos02_PointViolated : G6ProtectedInvariantSpec where
  invariantId      := "inv_pos02"
  specId           := "spec_pos02_new"
  protectedDomain  := .domQ
  protectedGuards  := []
  protectedFormula := .fixedStateForm formXMinusOneNonneg
  parameterBinding := .noParam
  versionEpoch     := defaultActiveEpoch
  evidenceRoots    := {
    declaredItemProofNids := []
    itemEvidence          := .claimViolated (.counterexamplePoint ⟨0, 1, 0, 1⟩)
  }
  registryOrigin   := defaultUntrustedOrigin
  oldNewState      := {
    specOldId                := "spec_pos02_old"
    specNewId                := "spec_pos02_new"
    domOld                   := .domQ
    guardsOld                := []
    formOldInst              := formXMinusOneNonneg
    domNew                   := .domQ
    guardsNew                := []
    formNewInst              := formXMinusOneNonneg
    oldBaselineProofNodeId?  := none
    newGuardsDefNodeId?      := none
    postDomNonEmptyWitness   := ⟨2, 1, 0, 1⟩
    scopePolicy              := sameDomEmptyGuardsPolicy .domQ
  }
  scopeLossRecord? := none

def posG6Suite02_GenuineViolated : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_pos02_violated"
  rflxCid              := "rflx_pos02"
  cellOldCid           := "cell_pos02_old"
  cellNewCid           := "cell_pos02_new"
  baseId               := "base_Q"
  specOldId            := "spec_pos02_old"
  specNewId            := "spec_pos02_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_pos02"]
  items                := [itemPos02_PointViolated]
  claimedPrimDeps      := ⟨[]⟩

/-- **`POS-G6-02B`**: Derived-refutation positive witness (`-(x^2 + 1) > 0` refuted via `G7` node
    proving `atomicComplement = -(-(x^2 + 1)) ≥ 0`), proving `Gate A4b` non-vacuous on derived refutations. -/
def formNegXSqPlusOnePos : StrictForm :=
  .pos (.neg (.add (.mul .varX .varX) (.const 1)))

def containerPos02B_DerivedRefut : G7DagContainer where
  nodes := [
    { nodeId     := "n_pos02b_refut"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_pos02b_new"
      guards     := []
      conclusion := atomicComplement formNegXSqPlusOnePos
      step       := .directDerivStep
                      (.certStep (atomicComplement formNegXSqPlusOnePos)
                        (.polyPositivstellensatz ⟨1, 1, [(1, .pVarX)], [], [], []⟩)) }
  ]

def posG6Suite02B_DerivedRefut : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_pos02b_derived_refut"
  rflxCid              := "rflx_pos02b"
  cellOldCid           := "cell_pos02b_old"
  cellNewCid           := "cell_pos02b_new"
  baseId               := "base_Q"
  specOldId            := "spec_pos02b_old"
  specNewId            := "spec_pos02b_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_pos02b"]
  items                := [{
    invariantId      := "inv_pos02b"
    specId           := "spec_pos02b_new"
    protectedDomain  := .domQ
    protectedGuards  := []
    protectedFormula := .fixedStateForm formNegXSqPlusOnePos
    parameterBinding := .noParam
    versionEpoch     := defaultActiveEpoch
    evidenceRoots    := {
      declaredItemProofNids := ["n_pos02b_refut"]
      itemEvidence          := .claimViolated (.derivedRefutationNode "n_pos02b_refut" ⟨0, 1, 0, 1⟩)
    }
    registryOrigin   := defaultUntrustedOrigin
    oldNewState      := {
      specOldId                := "spec_pos02b_old"
      specNewId                := "spec_pos02b_new"
      domOld                   := .domQ
      guardsOld                := []
      formOldInst              := formNegXSqPlusOnePos
      domNew                   := .domQ
      guardsNew                := []
      formNewInst              := formNegXSqPlusOnePos
      oldBaselineProofNodeId?  := none
      newGuardsDefNodeId?      := none
      postDomNonEmptyWitness   := ⟨0, 1, 0, 1⟩
      scopePolicy              := sameDomEmptyGuardsPolicy .domQ
    }
    scopeLossRecord? := none
  }]
  claimedPrimDeps      := ⟨[]⟩

/-- **`POS-G6-03`**: Conservative `Unresolved` suite (`x^4 + 1 > 0` on `.domQ`). -/
def formXFourthPlusOnePos : StrictForm :=
  .pos (.add (.mul (.mul .varX .varX) (.mul .varX .varX)) (.const 1))

def itemPos03_Unresolved : G6ProtectedInvariantSpec where
  invariantId      := "inv_pos03"
  specId           := "spec_pos03_new"
  protectedDomain  := .domQ
  protectedGuards  := []
  protectedFormula := .fixedStateForm formXFourthPlusOnePos
  parameterBinding := .noParam
  versionEpoch     := defaultActiveEpoch
  evidenceRoots    := {
    declaredItemProofNids := []
    itemEvidence          := .claimUnresolved .insufficientProofSearch
  }
  registryOrigin   := defaultUntrustedOrigin
  oldNewState      := {
    specOldId                := "spec_pos03_old"
    specNewId                := "spec_pos03_new"
    domOld                   := .domQ
    guardsOld                := []
    formOldInst              := formXFourthPlusOnePos
    domNew                   := .domQ
    guardsNew                := []
    formNewInst              := formXFourthPlusOnePos
    oldBaselineProofNodeId?  := none
    newGuardsDefNodeId?      := none
    postDomNonEmptyWitness   := ⟨1, 1, 0, 1⟩
    scopePolicy              := sameDomEmptyGuardsPolicy .domQ
  }
  scopeLossRecord? := none

def posG6Suite03_Unresolved : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_pos03_unresolved"
  rflxCid              := "rflx_pos03"
  cellOldCid           := "cell_pos03_old"
  cellNewCid           := "cell_pos03_new"
  baseId               := "base_Q"
  specOldId            := "spec_pos03_old"
  specNewId            := "spec_pos03_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_pos03"]
  items                := [itemPos03_Unresolved]
  claimedPrimDeps      := ⟨[]⟩

/-- **`POS-G6-04`**: Parameterized `I(x; θ) : x^2 + θ ≥ 0` preserved across `θ: 2/1 ↦ 5/1`. -/
def containerPos04_ParamPreserved : G7DagContainer where
  nodes := [
    { nodeId     := "n_f05_inv_old"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_f05_old"
      guards     := []
      conclusion := instantiateInvariantAtParam 2 1 f05_invTemplate
      step       := .directDerivStep
                      (.certStep (instantiateInvariantAtParam 2 1 f05_invTemplate)
                        (.polyPositivstellensatz f05_sosCertOldInv)) },
    { nodeId     := "n_pos04_inv_new"
      topoRank   := 1
      domTag     := .domQ
      specId     := "spec_pos04_new"
      guards     := []
      conclusion := instantiateInvariantAtParam 5 1 f05_invTemplate
      step       := .directDerivStep
                      (.certStep (instantiateInvariantAtParam 5 1 f05_invTemplate)
                        (.polyPositivstellensatz ⟨1, 5, [(1, .pVarX)], [], [], []⟩)) }
  ]

def posG6Suite04_ParamPreserved : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_pos04_param_preserved"
  rflxCid              := "rflx_pos04_theta_2_to_5"
  cellOldCid           := "cell_f05_old"
  cellNewCid           := "cell_pos04_new"
  baseId               := "base_Q"
  specOldId            := "spec_f05_old"
  specNewId            := "spec_pos04_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_pos04"]
  items                := [{
    invariantId      := "inv_pos04"
    specId           := "spec_pos04_new"
    protectedDomain  := .domQ
    protectedGuards  := []
    protectedFormula := f05_invTemplate
    parameterBinding := .boundCellParam 2 1 5 1
    versionEpoch     := defaultActiveEpoch
    evidenceRoots    := {
      declaredItemProofNids := ["n_f05_inv_old", "n_pos04_inv_new"]
      itemEvidence          := .claimVerified "n_pos04_inv_new"
    }
    registryOrigin   := defaultUntrustedOrigin
    oldNewState      := {
      specOldId                := "spec_f05_old"
      specNewId                := "spec_pos04_new"
      domOld                   := .domQ
      guardsOld                := []
      formOldInst              := instantiateInvariantAtParam 2 1 f05_invTemplate
      domNew                   := .domQ
      guardsNew                := []
      formNewInst              := instantiateInvariantAtParam 5 1 f05_invTemplate
      oldBaselineProofNodeId?  := some "n_f05_inv_old"
      newGuardsDefNodeId?      := none
      postDomNonEmptyWitness   := ⟨0, 1, 0, 1⟩
      scopePolicy              := sameDomEmptyGuardsPolicy .domQ
    }
    scopeLossRecord? := none
  }]
  claimedPrimDeps      := ⟨[]⟩

/-- **`POS-G6-05` & `CE-G6-01` Cross-Term Suite**:
    Parameterized `I(x; θ) : x^2 + θ ≥ 0` shifting `θ: 2/1 ↦ -2/1` (matching `posG5Repair_F05_SOS`),
    where old invariant `I(x; 2)` is `G7`-verified (`"n_f05_inv_old"`) and new invariant `I(x; -2)`
    is genuinely violated at `(0, 0)`. -/
def containerPos05_SharedWithG5 : G7DagContainer where
  nodes := f05_dagContainerOldInv.nodes ++ [
    { nodeId     := "n_f05_goal_new"
      topoRank   := 1
      domTag     := .domQ
      specId     := "spec_f05_new"
      guards     := []
      conclusion := f05_goalNew
      step       := .directDerivStep
                      (.certStep f05_goalNew (.polyPositivstellensatz f05_sosCertGoalNew)) }
  ]

def posG6Suite05_ParamViolated : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_pos05_param_violated"
  rflxCid              := "rflx_b1_pos_repair_f05"
  cellOldCid           := "cell_f05_old"
  cellNewCid           := "cell_f05_new"
  baseId               := "base_Q"
  specOldId            := "spec_f05_old"
  specNewId            := "spec_f05_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_pos05"]
  items                := [{
    invariantId      := "inv_pos05"
    specId           := "spec_f05_new"
    protectedDomain  := .domQ
    protectedGuards  := []
    protectedFormula := f05_invTemplate
    parameterBinding := .boundCellParam 2 1 (-2) 1
    versionEpoch     := defaultActiveEpoch
    evidenceRoots    := {
      declaredItemProofNids := ["n_f05_inv_old"]
      itemEvidence          := .claimViolated (.counterexamplePoint ⟨0, 1, 0, 1⟩)
    }
    registryOrigin   := defaultUntrustedOrigin
    oldNewState      := {
      specOldId                := "spec_f05_old"
      specNewId                := "spec_f05_new"
      domOld                   := .domQ
      guardsOld                := []
      formOldInst              := instantiateInvariantAtParam 2 1 f05_invTemplate
      domNew                   := .domQ
      guardsNew                := []
      formNewInst              := instantiateInvariantAtParam (-2) 1 f05_invTemplate
      oldBaselineProofNodeId?  := some "n_f05_inv_old"
      newGuardsDefNodeId?      := none
      postDomNonEmptyWitness   := ⟨0, 1, 0, 1⟩
      scopePolicy              := sameDomEmptyGuardsPolicy .domQ
    }
    scopeLossRecord? := none
  }]
  claimedPrimDeps      := ⟨[]⟩

/-- **`POS-G6-06`**: `Retreat` `.domQ → .domQNonzero` with exact loss partition `[[x = 0]]`,
    preserving `(x / x) - 1 = 0` on `.domQNonzero`, evaluating to `.verified true`. -/
def sharedRetreatNzLossRecord : G6ScopeLossRecord where
  baseStep                := .qToQNonzero
  deltaGuards             := []
  prefixDefNodeId         := "n_nz_prefix_def"
  guardConn               := .syntacticConcat
  excisedBranches         := [[.eqZero .varX]]
  reexprCert?             := none
  strictLossWitness       := ⟨0, 1, 0, 1⟩
  claimedRetentionAnchors := [⟨1, 1, 0, 1⟩]

def posG6Suite06_RetreatExactLoss : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_pos06_retreat_nz"
  rflxCid              := "rflx_b1_pos_retreat_nz"
  cellOldCid           := "cell_divself_old"
  cellNewCid           := "cell_divself_new"
  baseId               := "base_Q"
  specOldId            := "spec_ret_nz_old"
  specNewId            := "spec_ret_nz_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_pos06"]
  items                := [{
    invariantId      := "inv_pos06"
    specId           := "spec_ret_nz_new"
    protectedDomain  := .domQNonzero
    protectedGuards  := []
    protectedFormula := .fixedStateForm (.eqZero exprDivSelfMinusOne)
    parameterBinding := .noParam
    versionEpoch     := defaultActiveEpoch
    evidenceRoots    := {
      declaredItemProofNids := ["n_nz_goal_divself", "n_nz_prefix_def"]
      itemEvidence          := .claimVerified "n_nz_goal_divself"
    }
    registryOrigin   := defaultUntrustedOrigin
    oldNewState      := {
      specOldId                := "spec_ret_nz_old"
      specNewId                := "spec_ret_nz_new"
      domOld                   := .domQ
      guardsOld                := []
      formOldInst              := .eqZero exprDivSelfMinusOne
      domNew                   := .domQNonzero
      guardsNew                := []
      formNewInst              := .eqZero exprDivSelfMinusOne
      oldBaselineProofNodeId?  := none
      newGuardsDefNodeId?      := none
      postDomNonEmptyWitness   := ⟨3, 4, 0, 1⟩
      scopePolicy              := .retreatWithLossAccounting
    }
    scopeLossRecord? := some sharedRetreatNzLossRecord
  }]
  claimedPrimDeps      := ⟨[]⟩

/-- **`POS-G6-06B`**: Sequential partial-definedness guard `Retreat` `ℚ → [x ≠ 0, 1/x > 0]`
    with `newGuardsDefNodeId? = some "n_seq_prefix_def"` and 2-branch partition
    `[[x = 0], [x ≠ 0, -1/x ≥ 0]]`. -/
def posG6Suite06B_PartialDivRetreat : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_pos06b_seq_recip"
  rflxCid              := "rflx_b1_pos_retreat_seq_recip"
  cellOldCid           := "cell_recip_old"
  cellNewCid           := "cell_recip_new"
  baseId               := "base_Q"
  specOldId            := "spec_recip_old"
  specNewId            := "spec_a0"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_pos06b"]
  items                := [{
    invariantId      := "inv_pos06b"
    specId           := "spec_a0"
    protectedDomain  := .domQ
    protectedGuards  := deltaSeqRecipGuards
    protectedFormula := .fixedStateForm (.pos (.div (.const 1) .varX))
    parameterBinding := .noParam
    versionEpoch     := defaultActiveEpoch
    evidenceRoots    := {
      declaredItemProofNids := ["n_seq_goal_recip_pos", "n_seq_prefix_def"]
      itemEvidence          := .claimVerified "n_seq_goal_recip_pos"
    }
    registryOrigin   := defaultUntrustedOrigin
    oldNewState      := {
      specOldId                := "spec_recip_old"
      specNewId                := "spec_a0"
      domOld                   := .domQ
      guardsOld                := []
      formOldInst              := .pos (.div (.const 1) .varX)
      domNew                   := .domQ
      guardsNew                := deltaSeqRecipGuards
      formNewInst              := .pos (.div (.const 1) .varX)
      oldBaselineProofNodeId?  := none
      newGuardsDefNodeId?      := some "n_seq_prefix_def"
      postDomNonEmptyWitness   := ⟨5, 2, 0, 1⟩
      scopePolicy              := .retreatWithLossAccounting
    }
    scopeLossRecord? := some {
      baseStep                := .sameBaseDom .domQ
      deltaGuards             := deltaSeqRecipGuards
      prefixDefNodeId         := "n_seq_prefix_def"
      guardConn               := .syntacticConcat
      excisedBranches         := [[.eqZero .varX],
                                  [.neqZero .varX, .nonneg (.neg (.div (.const 1) .varX))]]
      reexprCert?             := none
      strictLossWitness       := ⟨0, 1, 0, 1⟩
      claimedRetentionAnchors := [⟨2, 1, 0, 1⟩]
    }
  }]
  claimedPrimDeps      := ⟨[]⟩

/-- **`POS-G6-07` (`Gate A9.(3)` & `(4)`)**: Shared `(envPos07, containerPos07)` demonstrating
    bidirectional `Deps_G5 ≠ Deps_G6` AND `G6` semantic immunity to a FALSE `G5`-only premise! -/
def envPos07_DisjointDeps : PrimPremiseEnv :=
  [ ⟨"p_common",        .domQ, "spec_pos07_new", formXSqPlusOnePos, []⟩
  , ⟨"p_g5_only",       .domQ, "spec_pos07_new", .pos (.const 0),   ["p_common"]⟩
  , ⟨"p_g6_only",       .domQ, "spec_pos07_new", .pos (.const 2),   ["p_common"]⟩
  , ⟨"p_unused_poison", .domQ, "spec_pos07_new", .pos (.const (-1)), []⟩ ]

def containerPos07_DisjointDeps : G7DagContainer where
  nodes := [
    { nodeId     := "n_pos07_g5_goal"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_pos07_new"
      guards     := []
      conclusion := .pos (.const 0)
      step       := .directDerivStep (.primPrem "p_g5_only" (.pos (.const 0))) },
    { nodeId     := "n_pos07_g6_inv"
      topoRank   := 1
      domTag     := .domQ
      specId     := "spec_pos07_new"
      guards     := []
      conclusion := .pos (.const 2)
      step       := .directDerivStep (.primPrem "p_g6_only" (.pos (.const 2))) }
  ]

def g5CertPos07_UsesFalsePrem : G5DischargeCert where
  certVersion            := "g5_b1_v1"
  rflxCid                := "rflx_pos07_disjoint"
  cellOldCid             := "cell_pos07_old"
  obstCid                := "obst_pos07_x1"
  cellNewCid             := "cell_pos07_new"
  baseId                 := "base_Q"
  specOldId              := "spec_pos07_old"
  specNewId              := "spec_pos07_new"
  domOld                 := .domQ
  guardsOld              := []
  goalOld                := f05_goalOld
  domNew                 := .domQ
  guardsNew              := []
  goalNew                := .pos (.const 0)
  reflexKind             := .repair
  obstructionSpec        := {
    obstCid          := "obst_pos07_x1"
    targetCellOldCid := "cell_pos07_old"
    targetSpecOldId  := "spec_pos07_old"
    obstKind         := .counterexamplePoint
    evidence         := .counterexamplePt ⟨1, 1, 0, 1⟩
  }
  nonEmptyWitness        := ⟨⟨1, 1, 0, 1⟩⟩
  goalNewNodeId          := "n_pos07_g5_goal"
  repairCert?            := some {
    baseEquivStep           := .sameBaseDom .domQ
    oldGuardsDefNodeId?     := none
    oldEntailsNewGuardNodes := []
    newEntailsOldGuardNodes := []
    redundantGuardNodeId?   := none
  }
  retreatCert?           := none
  refinementCert?        := none
  claimedPrimDeps        := ⟨["p_common", "p_g5_only"]⟩
  requiresRetreatHistory := false

def posG6Suite07_DisjointDeps : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_pos07_disjoint_deps"
  rflxCid              := "rflx_pos07_disjoint"
  cellOldCid           := "cell_pos07_old"
  cellNewCid           := "cell_pos07_new"
  baseId               := "base_Q"
  specOldId            := "spec_pos07_old"
  specNewId            := "spec_pos07_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_pos07"]
  items                := [{
    invariantId      := "inv_pos07"
    specId           := "spec_pos07_new"
    protectedDomain  := .domQ
    protectedGuards  := []
    protectedFormula := .fixedStateForm (.pos (.const 2))
    parameterBinding := .noParam
    versionEpoch     := defaultActiveEpoch
    evidenceRoots    := {
      declaredItemProofNids := ["n_pos07_g6_inv"]
      itemEvidence          := .claimVerified "n_pos07_g6_inv"
    }
    registryOrigin   := defaultUntrustedOrigin
    oldNewState      := {
      specOldId                := "spec_pos07_old"
      specNewId                := "spec_pos07_new"
      domOld                   := .domQ
      guardsOld                := []
      formOldInst              := .pos (.const 2)
      domNew                   := .domQ
      guardsNew                := []
      formNewInst              := .pos (.const 2)
      oldBaselineProofNodeId?  := none
      newGuardsDefNodeId?      := none
      postDomNonEmptyWitness   := ⟨1, 1, 0, 1⟩
      scopePolicy              := sameDomEmptyGuardsPolicy .domQ
    }
    scopeLossRecord? := none
  }]
  claimedPrimDeps      := ⟨["p_common", "p_g6_only"]⟩

private theorem semValidPrimId_pos07_g6 :
    ∀ p ∈ deriveG6PrimDeps envPos07_DisjointDeps containerPos07_DisjointDeps posG6Suite07_DisjointDeps,
      SemValidPrimId envPos07_DisjointDeps p := by
  have hDeps : deriveG6PrimDeps envPos07_DisjointDeps containerPos07_DisjointDeps
      posG6Suite07_DisjointDeps = ["p_common", "p_g6_only"] := by decide
  rw [hDeps]
  intro p hp e hFind
  rcases List.mem_cons.mp hp with rfl | hTail
  · have hSome : lookupPrimPrem? envPos07_DisjointDeps "p_common" =
        some ⟨"p_common", .domQ, "spec_pos07_new", formXSqPlusOnePos, []⟩ := by decide
    rw [hFind] at hSome
    injection hSome with heq
    subst heq
    intro ρ hDom
    have hSem : SemValidSequent ⟨.domQ, "spec_pos01_new", [], formXSqPlusOnePos⟩ :=
      verifyReachable_master_sound 6 [] containerPos01 "n_pos01_xsq1" _
        (by decide) (by decide) (fun _ h => nomatch h)
    exact hSem.2 ρ hDom (fun _ h => nomatch h)
  · rcases List.mem_cons.mp hTail with rfl | hNil
    · have hSome : lookupPrimPrem? envPos07_DisjointDeps "p_g6_only" =
          some ⟨"p_g6_only", .domQ, "spec_pos07_new", .pos (.const 2), ["p_common"]⟩ := by decide
      rw [hFind] at hSome
      injection hSome with heq
      subst heq
      intro ρ _
      exact ⟨⟨2, .const 2 ρ⟩, ⟨2, .const 2 ρ, by decide⟩⟩
    · nomatch hNil

private theorem not_semValidPrimId_pos07_g5_only :
    ¬ SemValidPrimId envPos07_DisjointDeps "p_g5_only" := by
  intro hValid
  have hFind : lookupPrimPrem? envPos07_DisjointDeps "p_g5_only" =
      some ⟨"p_g5_only", .domQ, "spec_pos07_new", .pos (.const 0), ["p_common"]⟩ := by decide
  have hSat := hValid _ hFind (0, 0) rfl
  rcases hSat.2 with ⟨v, hv, hPos⟩
  cases hv
  exact Rat.lt_irrefl hPos

/-- **`Gate A11` (`T_B2_A11_PositiveWitnessSuite_NonVacuous`)**:
    Constructively establishes non-vacuity and full semantic soundness across all 7 mandatory
    positive witnesses (`POS-G6-01` .. `POS-G6-07`), plus `POS-G6-02B` (`.derivedRefutationNode`)
    and `POS-G6-06B` (sequential partial-division `Retreat`). -/
theorem T_B2_A11_PositiveWitnessSuite_NonVacuous :
    -- POS-G6-01: Verified global fixed invariant
    checkG6Suite 6 [] containerPos01 posG6Suite01_GlobalFixed = .verified false ∧
    (qualifyG6Isolated? 6 [] containerPos01 posG6Suite01_GlobalFixed).isSome = true ∧
    SemValidG6ProtectedSuite posG6Suite01_GlobalFixed ∧
    -- POS-G6-02 & POS-G6-02B: Point-based AND derived-refutation Violated suites
    checkG6Suite 6 [] containerPos01 posG6Suite02_GenuineViolated = .violated ["inv_pos02"] [] ∧
    SemPointCounterexampleOnNewDom posG6Suite02_GenuineViolated ["inv_pos02"] ∧
    SemViolatedG6ProtectedSuite posG6Suite02_GenuineViolated ["inv_pos02"] ∧
    checkG6Suite 6 [] containerPos02B_DerivedRefut posG6Suite02B_DerivedRefut = .violated ["inv_pos02b"] [] ∧
    SemViolatedG6ProtectedSuite posG6Suite02B_DerivedRefut ["inv_pos02b"] ∧
    -- POS-G6-03: Conservative Unresolved suite
    checkG6Suite 6 [] containerPos01 posG6Suite03_Unresolved = .unresolved ["inv_pos03"] ∧
    qualifyG6Isolated? 6 [] containerPos01 posG6Suite03_Unresolved = none ∧
    -- POS-G6-04: Parameterized invariant preserved across θ: 2/1 ↦ 5/1
    checkG6Suite 6 [] containerPos04_ParamPreserved posG6Suite04_ParamPreserved = .verified false ∧
    SemValidG6ProtectedSuite posG6Suite04_ParamPreserved ∧
    -- POS-G6-05: Parameterized invariant violated across θ: 2/1 ↦ -2/1
    checkG6Suite 6 [] containerPos05_SharedWithG5 posG6Suite05_ParamViolated = .violated ["inv_pos05"] [] ∧
    SemPointCounterexampleOnNewDom posG6Suite05_ParamViolated ["inv_pos05"] ∧
    SemViolatedG6ProtectedSuite posG6Suite05_ParamViolated ["inv_pos05"] ∧
    -- POS-G6-06 & POS-G6-06B: Retreat with exact loss accounting (`hasCertifiedScopeLoss = true`)
    checkG6Suite 6 [] containerPosRetreatBaseNz posG6Suite06_RetreatExactLoss = .verified true ∧
    SemValidG6ProtectedSuite posG6Suite06_RetreatExactLoss ∧
    checkG6Suite 6 [] containerPosRetreatPartialDiv posG6Suite06B_PartialDivRetreat = .verified true ∧
    SemValidG6ProtectedSuite posG6Suite06B_PartialDivRetreat ∧
    -- POS-G6-07: Bidirectional Deps_G5 ≠ Deps_G6 & G6 semantic immunity to false G5 premise
    deriveG5PrimDeps envPos07_DisjointDeps containerPos07_DisjointDeps g5CertPos07_UsesFalsePrem =
      ["p_common", "p_g5_only"] ∧
    deriveG6PrimDeps envPos07_DisjointDeps containerPos07_DisjointDeps posG6Suite07_DisjointDeps =
      ["p_common", "p_g6_only"] ∧
    ¬ SemValidPrimId envPos07_DisjointDeps "p_g5_only" ∧
    checkG6Suite 6 envPos07_DisjointDeps containerPos07_DisjointDeps posG6Suite07_DisjointDeps =
      .verified false ∧
    SemValidG6ProtectedSuite posG6Suite07_DisjointDeps := by
  have hV01 : checkG6Suite 6 [] containerPos01 posG6Suite01_GlobalFixed = .verified false := by decide
  have hS01 : SemValidG6ProtectedSuite posG6Suite01_GlobalFixed :=
    (T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness 6 [] containerPos01
      posG6Suite01_GlobalFixed false hV01 (fun _ h => nomatch h)).2.2.2.2.2.1
  have hV02 : checkG6Suite 6 [] containerPos01 posG6Suite02_GenuineViolated =
      .violated ["inv_pos02"] [] := by decide
  have hP02 : SemPointCounterexampleOnNewDom posG6Suite02_GenuineViolated ["inv_pos02"] :=
    (T_B2_A4a_CounterexampleSound_Unconditional 6 [] containerPos01
      posG6Suite02_GenuineViolated ["inv_pos02"] [] hV02 (by decide)).2.2
  have hS02 : SemViolatedG6ProtectedSuite posG6Suite02_GenuineViolated ["inv_pos02"] :=
    T_B2_A4c_PremiseFreeViolation_BridgeViaA4b 6 [] containerPos01
      posG6Suite02_GenuineViolated ["inv_pos02"] [] hV02 (by decide)
  have hV02B : checkG6Suite 6 [] containerPos02B_DerivedRefut posG6Suite02B_DerivedRefut =
      .violated ["inv_pos02b"] [] := by decide
  have hS02B : SemViolatedG6ProtectedSuite posG6Suite02B_DerivedRefut ["inv_pos02b"] :=
    T_B2_A4c_PremiseFreeViolation_BridgeViaA4b 6 [] containerPos02B_DerivedRefut
      posG6Suite02B_DerivedRefut ["inv_pos02b"] [] hV02B (by decide)
  have hV04 : checkG6Suite 6 [] containerPos04_ParamPreserved posG6Suite04_ParamPreserved =
      .verified false := by decide
  have hS04 : SemValidG6ProtectedSuite posG6Suite04_ParamPreserved :=
    (T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness 6 [] containerPos04_ParamPreserved
      posG6Suite04_ParamPreserved false hV04 (fun _ h => nomatch h)).2.2.2.2.2.1
  have hV05 : checkG6Suite 6 [] containerPos05_SharedWithG5 posG6Suite05_ParamViolated =
      .violated ["inv_pos05"] [] := by decide
  have hP05 : SemPointCounterexampleOnNewDom posG6Suite05_ParamViolated ["inv_pos05"] :=
    (T_B2_A4a_CounterexampleSound_Unconditional 6 [] containerPos05_SharedWithG5
      posG6Suite05_ParamViolated ["inv_pos05"] [] hV05 (by decide)).2.2
  have hS05 : SemViolatedG6ProtectedSuite posG6Suite05_ParamViolated ["inv_pos05"] :=
    T_B2_A4c_PremiseFreeViolation_BridgeViaA4b 6 [] containerPos05_SharedWithG5
      posG6Suite05_ParamViolated ["inv_pos05"] [] hV05 (by decide)
  have hV06 : checkG6Suite 6 [] containerPosRetreatBaseNz posG6Suite06_RetreatExactLoss =
      .verified true := by decide
  have hS06 : SemValidG6ProtectedSuite posG6Suite06_RetreatExactLoss :=
    (T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness 6 [] containerPosRetreatBaseNz
      posG6Suite06_RetreatExactLoss true hV06 (fun _ h => nomatch h)).2.2.2.2.2.1
  have hV06B : checkG6Suite 6 [] containerPosRetreatPartialDiv posG6Suite06B_PartialDivRetreat =
      .verified true := by decide
  have hS06B : SemValidG6ProtectedSuite posG6Suite06B_PartialDivRetreat :=
    (T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness 6 [] containerPosRetreatPartialDiv
      posG6Suite06B_PartialDivRetreat true hV06B (fun _ h => nomatch h)).2.2.2.2.2.1
  have hV07 : checkG6Suite 6 envPos07_DisjointDeps containerPos07_DisjointDeps
      posG6Suite07_DisjointDeps = .verified false := by decide
  have hS07 : SemValidG6ProtectedSuite posG6Suite07_DisjointDeps :=
    (T_B2_A3_VerifiedSuite_Conditional_SemanticSoundness 6 envPos07_DisjointDeps
      containerPos07_DisjointDeps posG6Suite07_DisjointDeps false hV07
      semValidPrimId_pos07_g6).2.2.2.2.2.1
  exact ⟨hV01, by decide, hS01,
         hV02, hP02, hS02, hV02B, hS02B,
         by decide, by decide,
         hV04, hS04,
         hV05, hP05, hS05,
         hV06, hS06, hV06B, hS06B,
         by decide, by decide, not_semValidPrimId_pos07_g5_only, hV07, hS07⟩

/-- **`Gate A8.(2)` (`T_B2_A8_2_RetreatTruthOrthogonality`)**:
    Scope-loss partition validity (`sharedRetreatNzLossRecord`, `.domQ → .domQNonzero`) is
    strictly orthogonal to post-domain invariant truth: three suites with the EXACT SAME
    certified `G6ScopeLossRecord` evaluate to `.verified true`, `.violated`, and `.unresolved`! -/
def retreatOrthSuite_Violated : G6ProtectedSuite :=
  let item0 := match posG6Suite06_RetreatExactLoss.items with | it :: _ => it | [] => itemPos01_GlobalFixed
  { posG6Suite06_RetreatExactLoss with
    suiteCid             := "suite_orth_retreat_violated"
    declaredInvariantIds := ["inv_orth_viol"]
    items                := [{ item0 with
      invariantId      := "inv_orth_viol"
      protectedFormula := .fixedStateForm (.pos (.sub .varX (.const 2)))
      evidenceRoots    := {
        declaredItemProofNids := ["n_nz_prefix_def"]
        itemEvidence          := .claimViolated (.counterexamplePoint ⟨1, 1, 0, 1⟩)
      }
      oldNewState      := { item0.oldNewState with
        formOldInst := .pos (.sub .varX (.const 2))
        formNewInst := .pos (.sub .varX (.const 2))
      }
    }] }

def retreatOrthSuite_Unresolved : G6ProtectedSuite :=
  let item0 := match posG6Suite06_RetreatExactLoss.items with | it :: _ => it | [] => itemPos01_GlobalFixed
  { posG6Suite06_RetreatExactLoss with
    suiteCid             := "suite_orth_retreat_unresolved"
    declaredInvariantIds := ["inv_orth_unr"]
    items                := [{ item0 with
      invariantId      := "inv_orth_unr"
      protectedFormula := .fixedStateForm formXFourthPlusOnePos
      evidenceRoots    := {
        declaredItemProofNids := ["n_nz_prefix_def"]
        itemEvidence          := .claimUnresolved .insufficientProofSearch
      }
      oldNewState      := { item0.oldNewState with
        formOldInst := formXFourthPlusOnePos
        formNewInst := formXFourthPlusOnePos
      }
    }] }

theorem T_B2_A8_2_RetreatTruthOrthogonality :
    (posG6Suite06_RetreatExactLoss.items.map (·.scopeLossRecord?) = [some sharedRetreatNzLossRecord]) ∧
    (retreatOrthSuite_Violated.items.map (·.scopeLossRecord?) = [some sharedRetreatNzLossRecord]) ∧
    (retreatOrthSuite_Unresolved.items.map (·.scopeLossRecord?) = [some sharedRetreatNzLossRecord]) ∧
    checkG6Suite 6 [] containerPosRetreatBaseNz posG6Suite06_RetreatExactLoss = .verified true ∧
    checkG6Suite 6 [] containerPosRetreatBaseNz retreatOrthSuite_Violated = .violated ["inv_orth_viol"] [] ∧
    checkG6Suite 6 [] containerPosRetreatBaseNz retreatOrthSuite_Unresolved = .unresolved ["inv_orth_unr"] := by
  exact ⟨rfl, rfl, rfl, by decide, by decide, by decide⟩

/-! ### 3. Complete Adversarial & Cross-Term Suite (`CE-G6-01` .. `CE-G6-12`, `07B`, `NEG-G6-EMPTY-01`) -/

/-- **`CE-G6-01` & `Gate A9`**: Full 4-part `G5` vs `G6` epistemic orthogonality:
    (1) `G5Pass ∧ G6Violated` on shared `rflx_b1_pos_repair_f05` (`θ: 2 ↦ -2`),
    (2) `G5Fail ∧ G6Verified` (`ce07a_fakeObstructionPtCert` vs `posG6Suite04_ParamPreserved`),
    (3) Bidirectional `Deps_G5 \ Deps_G6 ≠ ∅` (`"p_g5_only"`) and `Deps_G6 \ Deps_G5 ≠ ∅` (`"p_g6_only"`),
    (4) Mutating `"p_g5_only"` in `envPos07_DisjointDeps` leaves `checkG6Suite` & `verifyMultiRootTraced` identical. -/
theorem B2_CE01_And_GateA9_G5_G6_EpistemicOrthogonality :
    -- (1) G5Pass ∧ G6Violated:
    checkG5DischargeBool 6 [] containerPos05_SharedWithG5 posG5Repair_F05_SOS = true ∧
    SemValidG5Discharge posG5Repair_F05_SOS ∧
    checkG6Suite 6 [] containerPos05_SharedWithG5 posG6Suite05_ParamViolated = .violated ["inv_pos05"] [] ∧
    SemViolatedG6ProtectedSuite posG6Suite05_ParamViolated ["inv_pos05"] ∧
    qualifyG6Isolated? 6 [] containerPos05_SharedWithG5 posG6Suite05_ParamViolated = none ∧
    -- (2) G5Fail ∧ G6Verified:
    checkG5DischargeBool 6 [] f05_dagContainerGoalNew ce07a_fakeObstructionPtCert = false ∧
    checkG6Suite 6 [] containerPos04_ParamPreserved posG6Suite04_ParamPreserved = .verified false ∧
    SemValidG6ProtectedSuite posG6Suite04_ParamPreserved ∧
    -- (3) Bidirectional Deps_G5 ≠ Deps_G6:
    ("p_g5_only" ∈ deriveG5PrimDeps envPos07_DisjointDeps containerPos07_DisjointDeps g5CertPos07_UsesFalsePrem ∧
     "p_g5_only" ∉ deriveG6PrimDeps envPos07_DisjointDeps containerPos07_DisjointDeps posG6Suite07_DisjointDeps) ∧
    ("p_g6_only" ∈ deriveG6PrimDeps envPos07_DisjointDeps containerPos07_DisjointDeps posG6Suite07_DisjointDeps ∧
     "p_g6_only" ∉ deriveG5PrimDeps envPos07_DisjointDeps containerPos07_DisjointDeps g5CertPos07_UsesFalsePrem) ∧
    -- (4) Mutating "p_g5_only" has zero effect on G6 checkG6Suite or traced lookups:
    (let Γ_mut := replacePrimFormulaInEnv envPos07_DisjointDeps "p_g5_only" (.eqZero (.const 99))
     checkG6Suite 6 Γ_mut containerPos07_DisjointDeps posG6Suite07_DisjointDeps =
       checkG6Suite 6 envPos07_DisjointDeps containerPos07_DisjointDeps posG6Suite07_DisjointDeps ∧
     verifyMultiRootTraced 6 Γ_mut containerPos07_DisjointDeps (collectG6ProofRootIds posG6Suite07_DisjointDeps) =
       verifyMultiRootTraced 6 envPos07_DisjointDeps containerPos07_DisjointDeps
         (collectG6ProofRootIds posG6Suite07_DisjointDeps)) := by
  have hPos := T_B2_A11_PositiveWitnessSuite_NonVacuous
  have hG5Sem : SemValidG5Discharge posG5Repair_F05_SOS := B1_PosWitnessSuite_Proven.1.2
  have hNonInt := T_B2_A7_4_OutsidePremise_FullNonInterference 6 envPos07_DisjointDeps
    containerPos07_DisjointDeps posG6Suite07_DisjointDeps (by decide) "p_g5_only"
    (by decide) (.eqZero (.const 99))
  exact ⟨by decide, hG5Sem, by decide, hPos.2.2.2.2.2.2.2.2.2.2.2.2.2.2.1, by decide,
         by decide, by decide, hPos.2.2.2.2.2.2.2.2.2.2.2.1,
         ⟨by decide, by decide⟩, ⟨by decide, by decide⟩,
         ⟨hNonInt.2.2.1, hNonInt.2.2.2⟩⟩

/-- **`CE-G6-02`**: Forged SOS certificate (`02A`) and undeclared/missing premise (`02B`) rejected. -/
def ce02a_forgedSosSuite : G6ProtectedSuite :=
  { posG6Suite05_ParamViolated with
    suiteCid := "ce02a_forged_sos"
    items    := [{
      invariantId      := "inv_pos05"
      specId           := "spec_f05_new"
      protectedDomain  := .domQ
      protectedGuards  := []
      protectedFormula := .fixedStateForm (.nonneg (.add (.mul .varX .varX) (.const (-2))))
      parameterBinding := .noParam
      versionEpoch     := defaultActiveEpoch
      evidenceRoots    := {
        declaredItemProofNids := ["n_ce07_forged_sos"]
        itemEvidence          := .claimVerified "n_ce07_forged_sos"
      }
      registryOrigin   := defaultUntrustedOrigin
      oldNewState      := {
        specOldId                := "spec_f05_old"
        specNewId                := "spec_f05_new"
        domOld                   := .domQ
        guardsOld                := []
        formOldInst              := .nonneg (.add (.mul .varX .varX) (.const (-2)))
        domNew                   := .domQ
        guardsNew                := []
        formNewInst              := .nonneg (.add (.mul .varX .varX) (.const (-2)))
        oldBaselineProofNodeId?  := none
        newGuardsDefNodeId?      := none
        postDomNonEmptyWitness   := ⟨0, 1, 0, 1⟩
        scopePolicy              := sameDomEmptyGuardsPolicy .domQ
      }
      scopeLossRecord? := none
    }] }

def containerCE02B_MissingPrem : G7DagContainer where
  nodes := [
    { nodeId     := "n_ce02b_ghost_prem"
      topoRank   := 0
      domTag     := .domQ
      specId     := "spec_pos01_new"
      guards     := []
      conclusion := formXSqPlusOnePos
      step       := .directDerivStep (.primPrem "p_nonexistent" formXSqPlusOnePos) }
  ]

def ce02b_missingPremSuite : G6ProtectedSuite :=
  { posG6Suite01_GlobalFixed with
    suiteCid        := "ce02b_missing_prem"
    items           := [{ itemPos01_GlobalFixed with
      evidenceRoots := {
        declaredItemProofNids := ["n_ce02b_ghost_prem"]
        itemEvidence          := .claimVerified "n_ce02b_ghost_prem"
      }
    }]
    claimedPrimDeps := ⟨["p_nonexistent"]⟩ }

theorem B2_CE02_ForgedProofWithoutPremise_Rejected :
    checkG6Suite 6 [] containerCE07ForgedSos ce02a_forgedSosSuite =
      .invalid (.forgedVerificationProof "inv_pos05") ∧
    checkG6Suite 6 [] containerCE02B_MissingPrem ce02b_missingPremSuite =
      .invalid (.forgedVerificationProof "inv_pos01") := by
  exact ⟨by decide, by decide⟩

/-- **`CE-G6-03`**: Cross-formula proof reuse (`03A`: valid node for `x^2 + 1 > 0` reused to claim
    `x - 1 ≥ 0`) and duplicate `invariantId` (`03B`) rejected. -/
def ce03a_crossFormulaReuseSuite : G6ProtectedSuite :=
  { posG6Suite02_GenuineViolated with
    suiteCid := "ce03a_cross_formula_reuse"
    specOldId := "spec_pos01_old"
    specNewId := "spec_pos01_new"
    items := [{ itemPos02_PointViolated with
      specId := "spec_pos01_new"
      evidenceRoots := {
        declaredItemProofNids := ["n_pos01_xsq1"]
        itemEvidence          := .claimVerified "n_pos01_xsq1"
      }
      oldNewState := { itemPos02_PointViolated.oldNewState with
        specOldId := "spec_pos01_old"
        specNewId := "spec_pos01_new"
      }
    }] }

def ce03b_duplicateIdSuite : G6ProtectedSuite :=
  { posG6Suite01_GlobalFixed with
    suiteCid             := "ce03b_dup_id"
    declaredInvariantIds := ["inv_pos01", "inv_pos01"]
    items                := [itemPos01_GlobalFixed, itemPos01_GlobalFixed] }

theorem B2_CE03_CrossFormulaProofReuse_And_DupId_Rejected :
    verifyReachableDerivation 6 [] containerPos01 "n_pos01_xsq1" =
      .accept ⟨.domQ, "spec_pos01_new", [], formXSqPlusOnePos⟩ ∧
    checkG6Suite 6 [] containerPos01 ce03a_crossFormulaReuseSuite =
      .invalid (.forgedVerificationProof "inv_pos02") ∧
    checkG6Suite 6 [] containerPos01 ce03b_duplicateIdSuite =
      .invalid .duplicateOrEmptyInvariantId := by
  exact ⟨by decide, by decide, by decide⟩

/-- **`CE-G6-04`**: Parameter `θ` vs spatial `y` collision (`04A` `.domQ2`, `04B` `.varY` guard,
    `04C` uninstantiated `formNewInst`) rejected. -/
def ce04a_domQ2ParamSuite : G6ProtectedSuite :=
  let it0 := match posG6Suite04_ParamPreserved.items with | a :: _ => a | [] => itemPos01_GlobalFixed
  { posG6Suite04_ParamPreserved with
    suiteCid := "ce04a_domQ2_param"
    items := [{ it0 with
      protectedDomain := .domQ2
      oldNewState := { it0.oldNewState with
        domOld := .domQ2
        domNew := .domQ2
        scopePolicy := sameDomEmptyGuardsPolicy .domQ2
      }
    }] }

def ce04b_varYGuardParamSuite : G6ProtectedSuite :=
  let it0 := match posG6Suite04_ParamPreserved.items with | a :: _ => a | [] => itemPos01_GlobalFixed
  { posG6Suite04_ParamPreserved with
    suiteCid := "ce04b_vary_guard_param"
    items := [{ it0 with
      protectedGuards := [.pos .varY]
      oldNewState := { it0.oldNewState with
        guardsOld := [.pos .varY]
        guardsNew := [.pos .varY]
      }
    }] }

def ce04c_wrongInstParamSuite : G6ProtectedSuite :=
  let it0 := match posG6Suite04_ParamPreserved.items with | a :: _ => a | [] => itemPos01_GlobalFixed
  { posG6Suite04_ParamPreserved with
    suiteCid := "ce04c_wrong_inst"
    items := [{ it0 with
      oldNewState := { it0.oldNewState with
        formNewInst := instantiateInvariantAtParam 2 1 f05_invTemplate
      }
    }] }

theorem B2_CE04_ParamThetaAndSpatialYCollision_Rejected :
    checkG6Suite 6 [] containerPos04_ParamPreserved ce04a_domQ2ParamSuite =
      .invalid (.illFormedParameterBinding "inv_pos04") ∧
    checkG6Suite 6 [] containerPos04_ParamPreserved ce04b_varYGuardParamSuite =
      .invalid (.illFormedParameterBinding "inv_pos04") ∧
    checkG6Suite 6 [] containerPos04_ParamPreserved ce04c_wrongInstParamSuite =
      .invalid (.illFormedParameterBinding "inv_pos04") := by
  exact ⟨by decide, by decide, by decide⟩

/-- **`CE-G6-05`**: Partial reciprocal `(1/x) - (1/x) = 0` on `.domQ` without `x ≠ 0` guard:
    (`05A`) at `(0, 0)` witness → `.invalid (.undefinedPointTreatedAsTrue ...)`,
    (`05B`) at `(1, 0)` witness with forged proof → `.invalid (.forgedVerificationProof ...)`,
    (`05C`) honest `.claimUnresolved` → `.unresolved` (never `.verified`). -/
def formRecipSubSelfEqZero : StrictForm :=
  .eqZero (.sub (.div (.const 1) .varX) (.div (.const 1) .varX))

def ce05a_undefinedWitnessSuite : G6ProtectedSuite :=
  { posG6Suite01_GlobalFixed with
    suiteCid := "ce05a_undef_pt"
    items := [{ itemPos01_GlobalFixed with
      invariantId      := "inv_ce05"
      protectedFormula := .fixedStateForm formRecipSubSelfEqZero
      oldNewState      := { itemPos01_GlobalFixed.oldNewState with
        formOldInst            := formRecipSubSelfEqZero
        formNewInst            := formRecipSubSelfEqZero
        postDomNonEmptyWitness := ⟨0, 1, 0, 1⟩
      }
    }]
    declaredInvariantIds := ["inv_ce05"] }

def ce05b_unguardedRecipClaimVerified : G6ProtectedSuite :=
  let it0 := match ce05a_undefinedWitnessSuite.items with | a :: _ => a | [] => itemPos01_GlobalFixed
  { ce05a_undefinedWitnessSuite with
    suiteCid := "ce05b_unguarded_forged"
    items := [{ it0 with
      oldNewState := { it0.oldNewState with postDomNonEmptyWitness := ⟨1, 1, 0, 1⟩ }
    }] }

def ce05c_unguardedRecipUnresolved : G6ProtectedSuite :=
  let it0 := match ce05b_unguardedRecipClaimVerified.items with | a :: _ => a | [] => itemPos01_GlobalFixed
  { ce05b_unguardedRecipClaimVerified with
    suiteCid := "ce05c_unguarded_unres"
    items := [{ it0 with
      evidenceRoots := {
        declaredItemProofNids := []
        itemEvidence          := .claimUnresolved .undefinedSingularityUnresolved
      }
    }] }

theorem B2_CE05_UndefinedReciprocalPointLaundering_FixedVerdict :
    checkG6Suite 6 [] containerPos01 ce05a_undefinedWitnessSuite =
      .invalid (.undefinedPointTreatedAsTrue "inv_ce05") ∧
    checkG6Suite 6 [] containerPos01 ce05b_unguardedRecipClaimVerified =
      .invalid (.forgedVerificationProof "inv_ce05") ∧
    checkG6Suite 6 [] containerPos01 ce05c_unguardedRecipUnresolved =
      .unresolved ["inv_ce05"] ∧
    ¬ FormDefined formRecipSubSelfEqZero (0, 0) := by
  refine ⟨by decide, by decide, by decide, ?_⟩
  rintro ⟨v, hv⟩
  cases hv with
  | sub h1 _ =>
      cases h1 with
      | div _ hd hne =>
          cases hd
          exact hne rfl

/-- **`CE-G6-06` + `F-B2-T12-03` Negative Companion**:
    Out-of-domain counterexample `(0, 0)` for `x^2 > 0` on `.domQNonzero` is rejected with
    `.invalid (.outOfDomainCounterexample "inv_ce06")`, AND even though `deriveG6PrimDeps = []`,
    `SemViolatedG6ProtectedSuite` is **FALSE** (proving `deriveG6PrimDeps = []` alone without
    `hViol : checkG6Suite ... = .violated _ _` does NOT imply `SemViolatedG6ProtectedSuite`!). -/
def formXSqPos : StrictForm := .pos (.mul .varX .varX)

def ce06_outOfDomCounterexampleSuite : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "ce06_out_of_dom_ce"
  rflxCid              := "rflx_ce06"
  cellOldCid           := "cell_ce06_old"
  cellNewCid           := "cell_ce06_new"
  baseId               := "base_Q"
  specOldId            := "spec_ce06_old"
  specNewId            := "spec_ce06_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_ce06"]
  items                := [{
    invariantId      := "inv_ce06"
    specId           := "spec_ce06_new"
    protectedDomain  := .domQNonzero
    protectedGuards  := []
    protectedFormula := .fixedStateForm formXSqPos
    parameterBinding := .noParam
    versionEpoch     := defaultActiveEpoch
    evidenceRoots    := {
      declaredItemProofNids := []
      itemEvidence          := .claimViolated (.counterexamplePoint ⟨0, 1, 0, 1⟩)
    }
    registryOrigin   := defaultUntrustedOrigin
    oldNewState      := {
      specOldId                := "spec_ce06_old"
      specNewId                := "spec_ce06_new"
      domOld                   := .domQNonzero
      guardsOld                := []
      formOldInst              := formXSqPos
      domNew                   := .domQNonzero
      guardsNew                := []
      formNewInst              := formXSqPos
      oldBaselineProofNodeId?  := none
      newGuardsDefNodeId?      := none
      postDomNonEmptyWitness   := ⟨1, 1, 0, 1⟩
      scopePolicy              := sameDomEmptyGuardsPolicy .domQNonzero
    }
    scopeLossRecord? := none
  }]
  claimedPrimDeps      := ⟨[]⟩

theorem B2_CE06_OutOfDomainCounterexample_And_F12_03_NegativeCompanion :
    deriveG6PrimDeps [] containerPos01 ce06_outOfDomCounterexampleSuite = [] ∧
    checkG6Suite 6 [] containerPos01 ce06_outOfDomCounterexampleSuite =
      .invalid (.outOfDomainCounterexample "inv_ce06") ∧
    ¬ SemViolatedG6ProtectedSuite ce06_outOfDomCounterexampleSuite ["inv_ce06"] := by
  refine ⟨by decide, by decide, ?_⟩
  intro hSemViol
  rcases hSemViol.allViolatedRecordsSound "inv_ce06" (List.mem_cons_self ..) with
    ⟨item, hMem, _, _, _, _, ⟨ρ, hInNz, _, hNotSat⟩⟩
  rcases List.mem_cons.mp hMem with rfl | hNil
  · have hxNe : ρ.1 ≠ 0 := hInNz.1.1
    have hSqPos : (0 : Rat) < ρ.1 * ρ.1 := (rat_sq_pos_iff_ne_zero ρ.1).mpr hxNe
    have hEval : PartExprEvalRel (.mul .varX .varX) ρ (ρ.1 * ρ.1) :=
      .mul (.varX ρ) (.varX ρ)
    exact hNotSat ⟨⟨ρ.1 * ρ.1, hEval⟩, ⟨ρ.1 * ρ.1, hEval, hSqPos⟩⟩
  · nomatch hNil

/-- **`CE-G6-07A` & `CE-G6-07B` (`F-B2-T11-02`)**:
    (`07A`) Omitting a declared item (`declaredInvariantIds = ["inv_pos01", "inv_pos05"]` with only
    `[itemPos01_GlobalFixed]`) is rejected with `.invalid .suiteCoverageMismatch`.
    (`07B`) Upfront truncation before submission (`officialRequiredIds = ["inv_pos01", "inv_pos05"]`
    submitted as `posG6Suite01_GlobalFixed` with `["inv_pos01"]`): `G6QualifiedRecord` explicitly
    seals `officialProtectionRegistryAuthenticated = false` and `officialRegistryBindingSlot = .mkUnchecked`,
    and external `checkOfficialSuiteIdsMatchBool` catches the truncation (`= false`)! -/
def ce07a_partialItemsSuite : G6ProtectedSuite :=
  { posG6Suite01_GlobalFixed with
    suiteCid             := "ce07a_partial_items"
    declaredInvariantIds := ["inv_pos01", "inv_pos05"]
    items                := [itemPos01_GlobalFixed] }

theorem B2_CE07A_And_CE07B_PartialSuite_And_UpfrontOfficialTruncation :
    -- CE-G6-07A: Internal partial-suite omission rejected
    checkG6Suite 6 [] containerPos01 ce07a_partialItemsSuite = .invalid .suiteCoverageMismatch ∧
    -- CE-G6-07B: Upfront official-list truncation explicitly unauthenticated in B2 & caught by matcher
    checkOfficialSuiteIdsMatchBool ["inv_pos01", "inv_pos05"] posG6Suite01_GlobalFixed = false ∧
    checkOfficialSuiteIdsMatchBool ["inv_pos01"] posG6Suite01_GlobalFixed = true ∧
    (∀ rec : G6QualifiedRecord 6 [] containerPos01,
      rec.submittedSuiteComplete = true ∧
      rec.officialProtectionRegistryAuthenticated = false ∧
      rec.officialRegistryBindingSlot = .mkUnchecked) := by
  refine ⟨by decide, by decide, by decide, ?_⟩
  intro rec
  have hSeal := (T_B2_A10_RecordSealing_ZeroLedgerMutation_And_NoFullReflex.1 6 [] containerPos01 rec)
  exact ⟨hSeal.2.2.2.1, hSeal.2.2.2.2.1, hSeal.2.2.2.2.2.1⟩

/-- **`CE-G6-08`**: Omitting transitive primitive premise `"p_root_ax"` from `claimedPrimDeps`
    returns `.invalid .primDepsClosureMismatch`, whereas full `["p_mid", "p_root_ax"]` succeeds. -/
def ce08_omittedMidPremSuite : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "ce08_omitted_prim_dep"
  rflxCid              := "rflx_ce08"
  cellOldCid           := "cell_ce08_old"
  cellNewCid           := "cell_ce08_new"
  baseId               := "base_Q"
  specOldId            := "spec_ce08"
  specNewId            := "spec_ce08"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := ["inv_ce08"]
  items                := [{
    invariantId      := "inv_ce08"
    specId           := "spec_ce08"
    protectedDomain  := .domQ
    protectedGuards  := []
    protectedFormula := .fixedStateForm f05_goalNew
    parameterBinding := .noParam
    versionEpoch     := defaultActiveEpoch
    evidenceRoots    := {
      declaredItemProofNids := ["n_ce08_goal"]
      itemEvidence          := .claimVerified "n_ce08_goal"
    }
    registryOrigin   := defaultUntrustedOrigin
    oldNewState      := {
      specOldId                := "spec_ce08"
      specNewId                := "spec_ce08"
      domOld                   := .domQ
      guardsOld                := []
      formOldInst              := f05_goalNew
      domNew                   := .domQ
      guardsNew                := []
      formNewInst              := f05_goalNew
      oldBaselineProofNodeId?  := none
      newGuardsDefNodeId?      := none
      postDomNonEmptyWitness   := ⟨0, 1, 0, 1⟩
      scopePolicy              := sameDomEmptyGuardsPolicy .domQ
    }
    scopeLossRecord? := none
  }]
  claimedPrimDeps      := ⟨["p_mid"]⟩

def ce08_completePrimDepSuite : G6ProtectedSuite :=
  { ce08_omittedMidPremSuite with
    suiteCid        := "ce08_complete_prim_deps"
    claimedPrimDeps := ⟨["p_mid", "p_root_ax"]⟩ }

theorem B2_CE08_OmittedIntermediatePrimPremise_Rejected :
    deriveG6PrimDeps ce08_primEnv containerCE08TransPrem ce08_omittedMidPremSuite =
      ["p_mid", "p_root_ax"] ∧
    checkG6Suite 6 ce08_primEnv containerCE08TransPrem ce08_omittedMidPremSuite =
      .invalid .primDepsClosureMismatch ∧
    checkG6Suite 6 ce08_primEnv containerCE08TransPrem ce08_completePrimDepSuite =
      .verified false := by
  exact ⟨by decide, by decide, by decide⟩

/-- **`CE-G6-09`**: Revoked spec (`09A`), expired epoch (`09B`), and retracted premise (`09C`)
    permanently rejected/deactivated across append-only ledger extensions. -/
def ce09a_revokedSpecSuite : G6ProtectedSuite :=
  { posG6Suite01_GlobalFixed with
    suiteCid := "ce09a_revoked"
    items    := [{ itemPos01_GlobalFixed with
      versionEpoch := { defaultActiveEpoch with revokedBool := true }
    }] }

def ce09b_expiredEpochSuite : G6ProtectedSuite :=
  { posG6Suite01_GlobalFixed with
    suiteCid        := "ce09b_expired"
    evaluationEpoch := 100 }

theorem B2_CE09_RevokedOrStaleSpecAndRetractedPremise_Rejected :
    checkG6Suite 6 [] containerPos01 ce09a_revokedSpecSuite =
      .invalid (.staleOrRevokedSpecVersion "inv_pos01") ∧
    checkG6Suite 6 [] containerPos01 ce09b_expiredEpochSuite =
      .invalid (.staleOrRevokedSpecVersion "inv_pos01") ∧
    checkActiveG6SuiteBool [] 6 ce08_primEnv containerCE08TransPrem ce08_completePrimDepSuite = true ∧
    checkActiveG6SuiteBool [.retractPremise "p_root_ax"] 6 ce08_primEnv containerCE08TransPrem
      ce08_completePrimDepSuite = false ∧
    (∀ ΔL : List StructuralLedgerEvent,
      checkActiveG6SuiteBool ([.retractPremise "p_root_ax"] ++ ΔL) 6 ce08_primEnv
        containerCE08TransPrem ce08_completePrimDepSuite = false) := by
  refine ⟨by decide, by decide, by decide, by decide, ?_⟩
  intro ΔL
  exact ((T_B2_A7_0_PrimDepsEquation_And_PermanentRetraction 6 ce08_completePrimDepSuite).2
    [.retractPremise "p_root_ax"] ΔL ce08_primEnv containerCE08TransPrem "p_root_ax"
    (by decide) (by decide)).2

/-- **`CE-G6-10`**: `Unresolved` non-promotion & multi-item priority (`[Verified, Unresolved] ↦ Unresolved`
    and `[Violated, Unresolved] ↦ Violated`). -/
def ce10a_mixedVerAndUnresSuite : G6ProtectedSuite :=
  { posG6Suite01_GlobalFixed with
    suiteCid             := "ce10a_ver_plus_unres"
    declaredInvariantIds := ["inv_pos01", "inv_pos03"]
    items                := [
      itemPos01_GlobalFixed,
      { itemPos03_Unresolved with
        specId      := "spec_pos01_new"
        oldNewState := { itemPos03_Unresolved.oldNewState with
          specOldId := "spec_pos01_old"
          specNewId := "spec_pos01_new"
        } }
    ] }

def ce10b_mixedViolAndUnresSuite : G6ProtectedSuite :=
  { posG6Suite01_GlobalFixed with
    suiteCid             := "ce10b_viol_plus_unres"
    declaredInvariantIds := ["inv_pos02", "inv_pos03"]
    items                := [
      { itemPos02_PointViolated with
        specId      := "spec_pos01_new"
        oldNewState := { itemPos02_PointViolated.oldNewState with
          specOldId := "spec_pos01_old"
          specNewId := "spec_pos01_new"
        } },
      { itemPos03_Unresolved with
        specId      := "spec_pos01_new"
        oldNewState := { itemPos03_Unresolved.oldNewState with
          specOldId := "spec_pos01_old"
          specNewId := "spec_pos01_new"
        } }
    ] }

theorem B2_CE10_UnresolvedToVerifiedPromotion_And_PriorityLattice :
    checkG6Suite 6 [] containerPos01 ce10a_mixedVerAndUnresSuite = .unresolved ["inv_pos03"] ∧
    qualifyG6Isolated? 6 [] containerPos01 ce10a_mixedVerAndUnresSuite = none ∧
    checkG6Suite 6 [] containerPos01 ce10b_mixedViolAndUnresSuite =
      .violated ["inv_pos02"] ["inv_pos03"] ∧
    qualifyG6Isolated? 6 [] containerPos01 ce10b_mixedViolAndUnresSuite = none := by
  exact ⟨by decide, by decide, by decide, by decide⟩

/-- **`CE-G6-11`**: Silent post-domain shrinkage (`11A` `.globalPostSameDom` `.domQ → .domQNonzero`,
    `11B` `.oldScopeInclusion` `.domQ → .domQNonzero`, `11C` `Retreat` omitting excised branch)
    all rejected with `.invalid (.uncertifiedScopeShrinkOrPolicy ...)`. -/
def ce11a_sameDomShrinkSuite : G6ProtectedSuite :=
  let it0 := match posG6Suite06_RetreatExactLoss.items with | a :: _ => a | [] => itemPos01_GlobalFixed
  { posG6Suite06_RetreatExactLoss with
    suiteCid := "ce11a_same_dom_shrink"
    items := [{ it0 with
      evidenceRoots := {
        declaredItemProofNids := ["n_nz_goal_divself"]
        itemEvidence          := .claimVerified "n_nz_goal_divself"
      }
      oldNewState := { it0.oldNewState with
        scopePolicy := sameDomEmptyGuardsPolicy .domQNonzero
      }
      scopeLossRecord? := none
    }] }

def ce11b_inclusionShrinkSuite : G6ProtectedSuite :=
  let it0 := match ce11a_sameDomShrinkSuite.items with | a :: _ => a | [] => itemPos01_GlobalFixed
  { ce11a_sameDomShrinkSuite with
    suiteCid := "ce11b_inclusion_shrink"
    items := [{ it0 with
      oldNewState := { it0.oldNewState with
        scopePolicy := .oldScopeInclusion (.sameBaseDom .domQNonzero) none [] [] false none
      }
    }] }

def ce11c_partialLossHidingSuite : G6ProtectedSuite :=
  let it0 := match posG6Suite06B_PartialDivRetreat.items with | a :: _ => a | [] => itemPos01_GlobalFixed
  { posG6Suite06B_PartialDivRetreat with
    suiteCid := "ce11c_partial_loss_hiding"
    items := [{ it0 with
      scopeLossRecord? := some {
        baseStep                := .sameBaseDom .domQ
        deltaGuards             := deltaSeqRecipGuards
        prefixDefNodeId         := "n_seq_prefix_def"
        guardConn               := .syntacticConcat
        excisedBranches         := [[.eqZero .varX]]
        reexprCert?             := none
        strictLossWitness       := ⟨0, 1, 0, 1⟩
        claimedRetentionAnchors := [⟨2, 1, 0, 1⟩]
      }
    }] }

theorem B2_CE11_SilentPostDomainShrinkage_Blocked :
    checkG6Suite 6 [] containerPosRetreatBaseNz ce11a_sameDomShrinkSuite =
      .invalid (.uncertifiedScopeShrinkOrPolicy "inv_pos06") ∧
    checkG6Suite 6 [] containerPosRetreatBaseNz ce11b_inclusionShrinkSuite =
      .invalid (.uncertifiedScopeShrinkOrPolicy "inv_pos06") ∧
    checkG6Suite 6 [] containerPosRetreatPartialDiv ce11c_partialLossHidingSuite =
      .invalid (.uncertifiedScopeShrinkOrPolicy "inv_pos06b") := by
  exact ⟨by decide, by decide, by decide⟩

/-- **`CE-G6-12`**: Even when BOTH `G5` (`posG5Repair_F05_SOS`) and `G6` (`posG6Suite01_GlobalFixed`)
    independently pass and issue qualified records, neither can mint institutional grants,
    authenticate `G1`, or inhabit `FullReflexAdmitted`! -/
theorem B2_CE12_G5AndG6Alone_CannotAdmitFullReflex_Or_MintGrant :
    (qualifyG5Isolated? 6 [] f05_dagContainerGoalNew posG5Repair_F05_SOS).isSome = true ∧
    (qualifyG6Isolated? 6 [] containerPos01 posG6Suite01_GlobalFixed).isSome = true ∧
    (∀ rec6 : G6QualifiedRecord 6 [] containerPos01,
      rec6.g5DischargeSlot = .mkUnchecked ∧
      rec6.g1IntegritySlot = .mkUnchecked ∧
      rec6.officialRegistryBindingSlot = .mkUnchecked ∧
      rec6.officialProtectionRegistryAuthenticated = false ∧
      rec6.grantFlag = .noGrantFromMathCheck) ∧
    (∀ {G56Raw : Type} (c56 : G56Raw → Bool),
      ¬ Nonempty (FullReflexAdmitted checkUnauthStageCertBool c56 checkCertifiedG7BundleBool)) := by
  refine ⟨by decide, by decide, ?_, T_B2_A10_RecordSealing_ZeroLedgerMutation_And_NoFullReflex.2.2⟩
  intro rec6
  have hS := T_B2_A10_RecordSealing_ZeroLedgerMutation_And_NoFullReflex.1 6 [] containerPos01 rec6
  exact ⟨hS.2.2.2.2.2.2.1, hS.2.2.2.2.2.2.2.1, hS.2.2.2.2.2.1, hS.2.2.2.2.1, hS.2.2.2.2.2.2.2.2⟩

/-- **`NEG-G6-EMPTY-01` (`B2_Neg_EmptySuite_NeverIssues_G6QualifiedRecord` — `F-B2-T11-01` & `F-B2-T12-02`)**:
    Concrete empty suites under `.forbidEmptySuite` and `.allowExplicitEmpty`:
    (1) `.forbidEmptySuite` evaluates to `.invalid .unauthorizedEmptySuite`,
    (2) `.allowExplicitEmpty "pol_empty_unauth_v1"` evaluates to `.emptySuiteAccepted "pol_empty_unauth_v1"`,
        emits `G6EmptySuiteNotice` with `verifiedInvariantCount = 0` & `officialProtectionRegistryAuthenticated = false`,
        satisfies `SemValidEmptyG6Notice`, refutes `SemValidG6ProtectedSuite`, returns `qualifyG6Isolated? = none`,
        and CANNOT inhabit `G6QualifiedRecord`! -/
def ceSuite_EmptyForbidden : G6ProtectedSuite where
  suiteVersion         := "g6_b2_v1"
  suiteCid             := "suite_neg_empty_forbidden"
  rflxCid              := "rflx_neg_empty"
  cellOldCid           := "cell_empty_old"
  cellNewCid           := "cell_empty_new"
  baseId               := "base_Q"
  specOldId            := "spec_empty_old"
  specNewId            := "spec_empty_new"
  evaluationEpoch      := 10
  emptySuitePolicy     := .forbidEmptySuite
  declaredInvariantIds := []
  items                := []
  claimedPrimDeps      := ⟨[]⟩

def adminSuite_EmptyExplicit : G6ProtectedSuite :=
  { ceSuite_EmptyForbidden with
    suiteCid         := "suite_neg_empty_explicit_notice"
    emptySuitePolicy := .allowExplicitEmpty "pol_empty_unauth_v1" }

theorem B2_Neg_EmptySuite_NeverIssues_G6QualifiedRecord :
    checkG6Suite 6 [] containerPos01 ceSuite_EmptyForbidden =
      .invalid .unauthorizedEmptySuite ∧
    checkG6Suite 6 [] containerPos01 adminSuite_EmptyExplicit =
      .emptySuiteAccepted "pol_empty_unauth_v1" ∧
    isG6SuiteVerifiedBool 6 [] containerPos01 adminSuite_EmptyExplicit = false ∧
    qualifyG6Isolated? 6 [] containerPos01 adminSuite_EmptyExplicit = none ∧
    (∃ notice : G6EmptySuiteNotice,
      inspectG6EmptySuiteNotice? 6 [] containerPos01 adminSuite_EmptyExplicit = some notice ∧
      notice.verifiedInvariantCount = 0 ∧
      notice.unauthPolicyCid = "pol_empty_unauth_v1" ∧
      notice.emptyPolicyAuthSlot = .mkUnchecked ∧
      notice.grantFlag = .noGrantFromMathCheck) ∧
    SemValidEmptyG6Notice adminSuite_EmptyExplicit "pol_empty_unauth_v1" ∧
    ¬ SemValidG6ProtectedSuite adminSuite_EmptyExplicit ∧
    ¬ ∃ rec : G6QualifiedRecord 6 [] containerPos01,
        extractVerifiedG6Suite rec.verifiedG6Slot = adminSuite_EmptyExplicit := by
  have hEmp : checkG6Suite 6 [] containerPos01 adminSuite_EmptyExplicit =
      .emptySuiteAccepted "pol_empty_unauth_v1" := by decide
  have hNoticeSem := T_B2_A3b_EmptySuiteAccepted_NoticeSound 6 [] containerPos01
    adminSuite_EmptyExplicit "pol_empty_unauth_v1" hEmp
  have hTypeBlock := (T_B2_F12_02B_EmptySuite_TypeForbidsRecord 6 [] containerPos01).2.2
    adminSuite_EmptyExplicit rfl
  refine ⟨by decide, hEmp, by decide, by decide, ?_, hNoticeSem.1, hNoticeSem.2, hTypeBlock⟩
  unfold inspectG6EmptySuiteNotice?
  rw [hEmp]
  exact ⟨_, rfl, rfl, rfl, rfl, rfl⟩

end OmegaCellC1P1B2BB2
